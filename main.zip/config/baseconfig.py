from DBQuery.dbservice import execute_db_query
from config.commonobj import CommonObject
from screenlaunch.utils import read_file


def screenlaunch_config(file, test_id):
    df = read_file(file,"")
    dict = {}
    for i in range(len(df)):
        if df.loc[i]["TEST_CONFIG_VALUE"] == test_id:
            j = i
            while j < len(df):
                dict[df.loc[j]["TEST_CONFIG_KEY"]] = df.loc[j]["TEST_CONFIG_VALUE"]
                j = j+1
            break

    CommonObject.config = dict
    if CommonObject.config["FileType"] == "CSV":
        CommonObject.fileformat = ".csv"
    elif CommonObject.config["FileType"] == "Excel":
        CommonObject.fileformat = ".xlsx"
        CommonObject.loginsheet = "login"
        CommonObject.switchsheet = "switchcontext"
        CommonObject.navigationsheet = 'NavConfig'
    elif CommonObject.config["FileType"] == "DBQuery":
        if CommonObject.config["ParallelExecution"] != "ON":
            execute_db_query()
        CommonObject.fileformat = ".csv"
