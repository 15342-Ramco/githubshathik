
import pandas as pd
from config.commonobj import CommonObject
import numpy as np



def filterdata(Process, Component, Activity, Navfile):
    try:
        if Process == "All":
            Process = "nan"
        if Component== "All":
            Component = "nan"
        if Activity== "All":
            Activity = "nan"
        global df1
        if str(Process) == 'nan' and str(Component) == 'nan'  and str(Activity) == 'nan':
            df1 = Navfile
        elif str(Process) != 'nan' and str(Component) == 'nan' and str(Activity) == 'nan':
            Process = Process.split(";")
            df1=pd.DataFrame()
            for i in Process:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Navfile.loc[(Navfile["Process Name"].str.contains(i[1:-1], case=False))]
                    df1 = pd.concat([df1, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Navfile[Navfile["Process Name"].str.startswith(i[:-1], na=False)]
                    df1 = pd.concat([df1, df3], axis=0, ignore_index=True)
                else:
                    df3 = Navfile[Navfile["Process Name"] == i]
                    df1 = pd.concat([df1, df3], axis=0, ignore_index=True)
        elif str(Process) == 'nan' and str(Component) != 'nan' and str(Activity) == 'nan':
            Component = Component.split(";")
            df1 = pd.DataFrame()
            for i in Component:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Navfile.loc[(Navfile["Component Name"].str.contains(i[1:-1], case=False))]
                    df1 = pd.concat([df1, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Navfile[Navfile["Component Name"].str.startswith(i[:-1], na=False)]
                    df1 = pd.concat([df1, df3], axis=0, ignore_index=True)
                else:
                    df3 = Navfile[Navfile["Component Name"] == i]
                    df1 = pd.concat([df1, df3], axis=0, ignore_index=True)
        elif str(Process) == 'nan' and str(Component) == 'nan' and str(Activity) != 'nan':
            Activity = Activity.split(";")
            df1 = pd.DataFrame()
            for i in Activity:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Navfile.loc[(Navfile["Activity Name"].str.contains(i[1:-1], case=False))]
                    df1 = pd.concat([df1, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Navfile[Navfile["Activity Name"].str.startswith(i[:-1], na=False)]
                    df1 = pd.concat([df1, df3], axis=0, ignore_index=True)
                else:
                    df3 = Navfile[Navfile["Activity Name"] == i]
                    df1 = pd.concat([df1, df3], axis=0, ignore_index=True)
        elif str(Process) != 'nan' and str(Component) != 'nan' and str(Activity) != 'nan' :
            Component = Component.split(";")
            Process = Process.split(";")
            Activity = Activity.split(";")
            Com = pd.DataFrame()
            Pro = pd.DataFrame()
            Act = pd.DataFrame()
            for i in Process:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Navfile.loc[(Navfile["Process Name"].str.contains(i[1:-1], case=False))]
                    Pro = pd.concat([Pro, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Navfile[Navfile["Process Name"].str.startswith(i[:-1], na=False)]
                    Pro = pd.concat([Pro, df3], axis=0, ignore_index=True)
                else:
                    df3 = Navfile[Navfile["Process Name"] == i]
                    Pro = pd.concat([Pro, df3], axis=0, ignore_index=True)
            for i in Component:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Pro.loc[(Pro["Component Name"].str.contains(i[1:-1], case=False))]
                    Com = pd.concat([Com, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Pro[Pro["Component Name"].str.startswith(i[:-1], na=False)]
                    Com = pd.concat([Com, df3], axis=0, ignore_index=True)
                else:
                    df3 = Pro[Pro["Component Name"] == i]
                    Com = pd.concat([Com, df3], axis=0, ignore_index=True)

            for i in Activity:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Com.loc[(Com["Activity Name"].str.contains(i[1:-1], case=False))]
                    Act = pd.concat([Act, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Com[Com["Activity Name"].str.startswith(i[:-1], na=False)]
                    Act = pd.concat([Act, df3], axis=0, ignore_index=True)
                else:
                    df3 = Com[Com["Activity Name"] == i]
                    Act = pd.concat([Act, df3], axis=0, ignore_index=True)
            df1 = Act
        elif str(Process) != 'nan' and str(Component) != 'nan' and str(Activity) == 'nan':
            Component = Component.split(";")
            Process = Process.split(";")
            Com = pd.DataFrame()
            Pro = pd.DataFrame()
            for i in Process:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Navfile.loc[(Navfile["Process Name"].str.contains(i[1:-1], case=False))]
                    Pro = pd.concat([Pro, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Navfile[Navfile["Process Name"].str.startswith(i[:-1], na=False)]
                    Pro = pd.concat([Pro, df3], axis=0, ignore_index=True)
                else:
                    df3 = Navfile[Navfile["Process Name"] == i]
                    Pro = pd.concat([Pro, df3], axis=0, ignore_index=True)
            for i in Component:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Pro.loc[(Pro["Component Name"].str.contains(i[1:-1], case=False))]
                    Com = pd.concat([Com, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Pro[Pro["Component Name"].str.startswith(i[:-1], na=False)]
                    Com = pd.concat([Com, df3], axis=0, ignore_index=True)
                else:
                    df3 = Pro[Pro["Component Name"] == i]
                    Com = pd.concat([Com, df3], axis=0, ignore_index=True)

            df1 =Com
        elif str(Process) == 'nan' and str(Component) != 'nan' and str(Activity) != 'nan':
            Component = Component.split(";")
            Activity = Activity.split(";")
            Com = pd.DataFrame()
            Act = pd.DataFrame()
            for i in Component:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Navfile.loc[(Navfile["Component Name"].str.contains(i[1:-1], case=False))]
                    Com = pd.concat([Com, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Navfile[Navfile["Component Name"].str.startswith(i[:-1], na=False)]
                    Com = pd.concat([Com, df3], axis=0, ignore_index=True)
                else:
                    df3 = Navfile[Navfile["Component Name"] == i]
                    Com = pd.concat([Com, df3], axis=0, ignore_index=True)
            for i in Activity:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Com.loc[(Com["Activity Name"].str.contains(i[1:-1], case=False))]
                    Act = pd.concat([Act, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Com[Com["Activity Name"].str.startswith(i[:-1], na=False)]
                    Act = pd.concat([Act, df3], axis=0, ignore_index=True)
                else:
                    df3 = Com[Com["Activity Name"] == i]
                    Act = pd.concat([Act, df3], axis=0, ignore_index=True)

            df1 =Act
        elif str(Process) != 'nan' and str(Component) == 'nan' and str(Activity) != 'nan':
            Process = Process.split(";")
            Activity = Activity.split(";")
            Pro = pd.DataFrame()
            Act = pd.DataFrame()
            for i in Process:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Navfile.loc[(Navfile["Process Name"].str.contains(i[1:-1], case=False))]
                    Pro = pd.concat([Pro, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Navfile[Navfile["Process Name"].str.startswith(i[:-1], na=False)]
                    Pro = pd.concat([Pro, df3], axis=0, ignore_index=True)
                else:
                    df3 = Navfile[Navfile["Process Name"] == i]
                    Pro = pd.concat([Pro, df3], axis=0, ignore_index=True)
            for i in Activity:
                if i[0] == "*" and i[-1] == "*":
                    df3 = Pro.loc[(Pro["Activity Name"].str.contains(i[1:-1], case=False))]
                    Act = pd.concat([Act, df3], axis=0, ignore_index=True)
                elif i[-1] == "*":
                    df3 = Pro[Pro["Activity Name"].str.startswith(i[:-1], na=False)]
                    Act = pd.concat([Act, df3], axis=0, ignore_index=True)
                else:
                    df3 = Pro[Pro["Activity Name"] == i]
                    Act = pd.concat([Act, df3], axis=0, ignore_index=True)
            df1 =Act

        return df1
    except Exception as error:
        print("Please Check the Navigation Filter Input")


def filterby_login_id(Navfile):
    try:
        global df4, df
        unique_login_id = Navfile[Navfile.Login.notnull()]
        zip_by_index_values = dict(zip(unique_login_id.index.values, unique_login_id.Login))
        list_of_dict_keys = []
        for n in zip_by_index_values.keys():
            list_of_dict_keys.append(n)
        if len(list_of_dict_keys) > 0:
            df4 = pd.DataFrame()
            df1 = pd.DataFrame()
            df2 = pd.DataFrame()
            for i in range(0, len(list_of_dict_keys)):
                loginid = zip_by_index_values[list_of_dict_keys[i]]
                index_lower_limit1 = list_of_dict_keys[i]
                if i == len(list_of_dict_keys) - 1:
                    index_upper_limit1 = (Navfile[len(Navfile) - 1:].index[0]) + 1
                else:
                    index_upper_limit1 = list_of_dict_keys[i + 1]
                filter = Navfile[index_lower_limit1: index_upper_limit1]
                switchcontextunique0 = filter[filter.SwitchContext.notnull()]
                zip_by_index_values_switchcontext = dict(zip(switchcontextunique0.index.values, switchcontextunique0.SwitchContext))
                list_of_dict_keys_switch = []
                for l in zip_by_index_values_switchcontext.keys():
                    list_of_dict_keys_switch.append(l)
                if len(list_of_dict_keys_switch) == 0:
                    filter_after_login_filter1 = filterdata(CommonObject.config['Process'],CommonObject.config['Component'],CommonObject.config['Activity'],filter)
                    if filter_after_login_filter1.empty == False:
                        filter_after_login_filter1=filter_after_login_filter1.sort_values(by='Sno',ascending=True).reset_index(drop=True)
                        filter_after_login_filter1["Login"]=filter_after_login_filter1["Login"].replace(zip_by_index_values[list_of_dict_keys[i]], np.NaN)
                        filter_after_login_filter1.at[0, 'Login'] = loginid
                        df4 = pd.concat([df4, filter_after_login_filter1], axis=0, ignore_index=True)
                    elif filter_after_login_filter1.empty == True:
                        print("There is no values for your required filtration in NO " + str(i + 1) + " user login " + loginid + " filtration")
                elif len(list_of_dict_keys_switch) > 0:
                    if str(filter.iloc[0]["SwitchContext"]) != "nan":
                        filter1 = filter.reset_index(drop=True)
                        switchcontextunique1 = filter1[filter1.SwitchContext.notnull()]
                        zip_by_index_values_switchcontext1 = dict(zip(switchcontextunique1.index.values, switchcontextunique1.SwitchContext))
                        list_of_dict_keys_switch1 = []
                        for p in zip_by_index_values_switchcontext1.keys():
                            list_of_dict_keys_switch1.append(p)
                        for j in range(0, len(list_of_dict_keys_switch1)):
                            index_lower_limit = list_of_dict_keys_switch1[j]
                            if j == len(list_of_dict_keys_switch1) - 1:
                                index_upper_limit = (filter1[len(filter1) - 1:].index[0]) + 1
                            else:
                                index_upper_limit = list_of_dict_keys_switch1[j + 1]
                            filter_switch1 = filter1[index_lower_limit: index_upper_limit]
                            filter_after_login_filter2 = filterdata(CommonObject.config['Process'],CommonObject.config['Component'],CommonObject.config['Activity'],filter_switch1)
                            if filter_after_login_filter2.empty == False:
                                filter_after_login_filter2=filter_after_login_filter2.sort_values(by='Sno',ascending=True).reset_index(drop=True)
                                filter_after_login_filter2["Login"]=filter_after_login_filter2["Login"].replace(zip_by_index_values[list_of_dict_keys[i]], np.NaN)
                                filter_after_login_filter2["SwitchContext"] = filter_after_login_filter2["SwitchContext"].replace(zip_by_index_values_switchcontext1[list_of_dict_keys_switch1[j]], np.NaN)
                                switch_context_id1 = zip_by_index_values_switchcontext1[list_of_dict_keys_switch1[j]]
                                filter_after_login_filter2.at[0, 'Login'] = loginid
                                filter_after_login_filter2.at[0, 'SwitchContext'] = switch_context_id1
                                df1 = pd.concat([df1, filter_after_login_filter2], axis=0, ignore_index=True)
                            elif filter_after_login_filter2.empty == True:
                                print("There is no values for your required filtration in NO " + str(i + 1) + " user login " + loginid + " filtration")
                    elif str(filter.iloc[0]["SwitchContext"]) == "nan":
                        filter2 = filter.reset_index(drop=True)
                        switchcontextunique2 = filter2[filter2.SwitchContext.notnull()]
                        zip_by_index_values_switchcontext2 = dict(zip(switchcontextunique2.index.values, switchcontextunique2.SwitchContext))
                        list_of_dict_keys_switch2 = []
                        for m in zip_by_index_values_switchcontext2.keys():
                            list_of_dict_keys_switch2.append(m)
                        for k in range(0, len(list_of_dict_keys_switch2) + 1):
                            if k == 0:
                                index_lower_limit = 0
                                index_upper_limit = list_of_dict_keys_switch2[0]
                                filter_switch2 = filter2[index_lower_limit: index_upper_limit]
                                filter_after_login_filter3 = filterdata(CommonObject.config['Process'],CommonObject.config['Component'],CommonObject.config['Activity'],filter_switch2)
                                if filter_after_login_filter3.empty == False:
                                    filter_after_login_filter3=filter_after_login_filter3.sort_values(by='Sno',ascending=True).reset_index(drop=True)
                                    filter_after_login_filter3["Login"]=filter_after_login_filter3["Login"].replace(zip_by_index_values[list_of_dict_keys[i]],np.NaN)
                                    filter_after_login_filter3.at[0, 'Login'] = loginid
                                    df2 = pd.concat([df2, filter_after_login_filter3], axis=0, ignore_index=True)
                                elif filter_after_login_filter3.empty == True:
                                    print("There is no values for your required filtration in NO " + str(i + 1) + " user login " + loginid + " filtration")
                            elif k == len(list_of_dict_keys_switch2):
                                index_lower_limit = list_of_dict_keys_switch2[k - 1]
                                index_upper_limit = (filter2[len(filter2) - 1:].index[0]) + 1
                                filter_switch3 = filter2[index_lower_limit: index_upper_limit]
                                filter_after_login_filter4 = filterdata(CommonObject.config['Process'],CommonObject.config['Component'],CommonObject.config['Activity'],filter_switch3)
                                if filter_after_login_filter4.empty == False:
                                    filter_after_login_filter4=filter_after_login_filter4.sort_values(by='Sno',ascending=True).reset_index(drop=True)
                                    filter_after_login_filter4["Login"]=filter_after_login_filter4["Login"].replace(zip_by_index_values[list_of_dict_keys[i]],np.NaN)
                                    filter_after_login_filter4["SwitchContext"] = filter_after_login_filter4["SwitchContext"].replace(zip_by_index_values_switchcontext2[list_of_dict_keys_switch2[k - 1]], np.NaN)
                                    switch_context_id2 = zip_by_index_values_switchcontext2[list_of_dict_keys_switch2[k - 1]]
                                    filter_after_login_filter4.at[0, 'Login'] = loginid
                                    filter_after_login_filter4.at[0, 'SwitchContext'] = switch_context_id2
                                    df2 = pd.concat([df2, filter_after_login_filter4], axis=0, ignore_index=True)
                                elif filter_after_login_filter4.empty == True:
                                    print("There is no values for your required filtration in NO " + str(i + 1) + " user login " + loginid + " filtration")

                            else:
                                index_lower_limit = list_of_dict_keys_switch2[k - 1]
                                index_upper_limit = list_of_dict_keys_switch2[k]
                                filter_switch4 = filter2[index_lower_limit: index_upper_limit]
                                filter_after_login_filter5 = filterdata(CommonObject.config['Process'],CommonObject.config['Component'],CommonObject.config['Activity'],filter_switch4)
                                if filter_after_login_filter5.empty == False:
                                    filter_after_login_filter5=filter_after_login_filter5.sort_values(by='Sno',ascending=True).reset_index(drop=True)
                                    filter_after_login_filter5["Login"]=filter_after_login_filter5["Login"].replace(zip_by_index_values[list_of_dict_keys[i]], np.NaN)
                                    filter_after_login_filter5["SwitchContext"] = filter_after_login_filter5["SwitchContext"].replace(zip_by_index_values_switchcontext2[list_of_dict_keys_switch2[k - 1]], np.NaN)
                                    switch_context_id3 = zip_by_index_values_switchcontext2[list_of_dict_keys_switch2[k - 1]]
                                    filter_after_login_filter5.at[0, 'Login'] = loginid
                                    filter_after_login_filter5.at[0, 'SwitchContext'] = switch_context_id3
                                    df2 = pd.concat([df2, filter_after_login_filter5], axis=0, ignore_index=True)
                                elif filter_after_login_filter5.empty == True:
                                    print("There is no values for your required filtration in NO " + str(i + 1) + " user login " + loginid + " filtration")
            duplicated = df1.duplicated('Login')
            df1.loc[duplicated, ["Login"]] = np.NaN
            duplicated1 = df2.duplicated('Login')
            df2.loc[duplicated1, ["Login"]] = np.NaN
            df_con = pd.concat([df1, df2], axis=0, ignore_index=True)
            df = pd.concat([df4, df_con], axis=0, ignore_index=True)
            return df
    except Exception as Error:
        print("Please Check the Navigation Filter Input")
