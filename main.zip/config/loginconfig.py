import time

from config.commonobj import CommonObject
from screenlaunch.browser import Browser
from screenlaunch.pageaction import page_action
from screenlaunch.pageobjectwrapper import findlocator
from screenlaunch.utils import read_file
from screenlaunch.webutils import pleasewait


def login(login_id):
    login_file = CommonObject.project_path + "Files\\ScreenLaunchLogin" + CommonObject.fileformat
    df = read_file(login_file, CommonObject.loginsheet)
    for i in range(len(df)):
        if df.loc[i]["LOGIN_CREDENTIALS"] == "LOGIN_ID":
            if df.loc[i].iloc[1] == login_id:
                j = 0
                while j < 3:
                    loc = df.loc[i + 2].iloc[2]
                    action = df.loc[i + 2].iloc[3]
                    data = df.loc[i + 2].iloc[4]
                    CommonObject.element_value = loc
                    CommonObject.action = action
                    page_action(action, findlocator(), data)
                    i = i + 1
                    j = j + 1
                CommonObject.loginflag = True
                CommonObject.loginfirsttime = True
                break


def switchcontext(switch_id):
    pleasewait()
    if CommonObject.config["App Type"] == "Nebula co-existence":
    # menu = "//*[@aria-label='Open menu']"
        menu = "//*[@id ='MenuBar_Icon_toggleSideNav']"
        Browser.page.click(menu)
    else:
        usermenu = Browser.page.click( "//*[starts-with(@id,'userMenu-button')]")
        changecontext = Browser.page.locator("//*[starts-with(@id,'menuitem')]//*[contains(@id, 'textEl')][text()='Change Context']").count()
        switchcontext = Browser.page.locator( "//*[starts-with(@id,'menuitem')]//*[contains(@id, 'textEl')][text()='Switch Contexts']").count()
        if changecontext != 0:
            changecontext ="//*[starts-with(@id,'menuitem')]//*[contains(@id, 'textEl')][text()='Change Context']"
            Browser.page.click(changecontext)
        elif switchcontext != 0:
            switchcontext ="//*[starts-with(@id,'menuitem')]//*[contains(@id, 'textEl')][text()='Switch Contexts']"
            Browser.page.click(switchcontext)
    time.sleep(0.50)
    pleasewait()
    switch_file = CommonObject.project_path + "Files\\ScreenLaunchSwitchContext" + CommonObject.fileformat
    df = read_file(switch_file, CommonObject.switchsheet)
    for i in range(len(df)):
        if df.loc[i]["SWITCH_CONTEXT_CREDENTIALS"] == "SWITCH_CONTEXT_ID":
            if df.loc[i].iloc[1] == switch_id:
                j = 0
                while j < 4:
                    loc = df.loc[i + 2].iloc[2]
                    action = df.loc[i + 2].iloc[3]
                    data = df.loc[i + 2].iloc[4]
                    CommonObject.element_value = loc
                    CommonObject.action = action
                    page_action(action, findlocator(), data)
                    i = i + 1
                    j = j + 1
                break
