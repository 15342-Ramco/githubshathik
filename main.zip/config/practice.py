import psutil
from playwright.sync_api import sync_playwright
import time

# def kill_browser_by_pid(target_pid):
#     try:
#         target_process = psutil.Process(target_pid)
#         process_name = target_process.name()
#         print(f"Killing process: {process_name} (PID: {target_pid})")
#         target_process.terminate()
#     except psutil.NoSuchProcess:
#         print(f"No such process with PID: {target_pid}")
#     except psutil.AccessDenied:
#         print(f"Access denied for PID: {target_pid}")



p = sync_playwright().start()
browser = p.chromium.launch(channel="msedge", headless=False)
#browser = p.chromium.launch(channel="chrome", headless=False)
print("Browser Launched")
context = browser.new_context()
page = context.new_page()
#page.on("response", lambda response: handle_response(response))
#page.goto('http://bavnwebcnv01.ramco/Extui/hub/index.html?_dc=1690366605259&RVWRTQS_REQID=a1fe575e-5bf8-4aba-9c48-293154c99bd2',timeout=1200000)
time.sleep(2)
# Get the PID of the browser process using psutil
browser_pid = None
for proc in psutil.process_iter(['pid', 'name']):
    print(proc)
    if 'msedge.exe' in proc.info['name']:
        browser_pid = proc.info['pid']
        print("Found",browser_pid)
        for proc in psutil.process_iter(['pid', 'name']):
            #print(proc)
            if proc.info['pid']==browser_pid:
                try:
                    print(f"Killing process: {proc.info['name']} (PID: {proc.info['pid']})")
                    psutil.Process(proc.info['pid']).terminate()
                except psutil.NoSuchProcess:
                    pass
        # browser_names = ['msedge.exe']  # Add more browser names if needed
        # for proc in psutil.process_iter(['pid', 'name']):
        #     print(proc)
        #     if proc.info['name'].lower() in browser_names and proc.info['pid'] == browser_pid:

if browser_pid:
    print(f"Browser PID: {browser_pid}")
else:
    print("Browser PID not found")






# def kill_browsers():
#     browser_names = ['chrome.exe', 'firefox.exe']  # Add more browser names if needed
#
#     for proc in psutil.process_iter(['pid', 'name']):
#         if proc.info['name'].lower() in browser_names:
#             try:
#                 print(f"Killing process: {proc.info['name']} (PID: {proc.info['pid']})")
#                 psutil.Process(proc.info['pid']).terminate()
#             except psutil.NoSuchProcess:
#                 pass



# from playwright.sync_api import sync_playwright
# # Function to extract a unique identifier from the webpage
# def extract_unique_identifier(page):
#     # Customize this code to extract the unique identifier from the webpage
#     # Example: Extracting an element's ID attribute
#     element = page.query_selector('#unique-id-element')
#     if element:
#         unique_id = element.get_attribute('id')
#         return unique_id
#     else:
#         return None
# p = sync_playwright().start()
# browser = p.chromium.launch(channel="msedge", headless=False)
# page = browser.new_page()
#
# # Navigate to the webpage
# page.goto('https://www.google.com/search?q=i+used+one+directory+in+python+without+closing+how+to+close+it+%3F&biw=1366&bih=625&sxsrf=APwXEdcE1-8AWhOpEAsSDCDoRdpc-4yFRw%3A1685938895768&ei=z2J9ZKzALorgseMPleCP8AM&ved=0ahUKEwjs4_rno6v_AhUKcGwGHRXwAz4Q4dUDCA8&uact=5&oq=i+used+one+directory+in+python+without+closing+how+to+close+it+%3F&gs_lcp=Cgxnd3Mtd2l6LXNlcnAQAzoHCCMQ6gIQJzoPCAAQigUQ6gIQtAIQQxgBOgQIIxAnOgcIABCKBRBDOgsIABCABBCxAxCDAToRCC4QigUQsQMQgwEQ5QQQ1AI6CAgAEIAEELEDOggILhCABBDlBDoICC4QgAQQsQM6CAgAEIoFEJECOgUIABCABDoICAAQigUQsQM6BQguEIAEOggILhCABBDUAjoICC4Q1AIQgAQ6CwgAEIoFELEDEIMBOhMILhCABBCXBRDcBBDeBBDgBBgCOggIABAWEB4QDzoGCAAQFhAeOggIABAWEB4QCjoICAAQigUQhgM6CAghEBYQHhAdOgoIIRAWEB4QDxAdOgcIIRCgARAKOgUIIRCgAToFCAAQogQ6BAghEBVKBAhBGABQmA9YitMBYMzUAWgIcAF4AYAB9QSIAddhkgELMC41My4xMS41LTKYAQCgAQGwARHAAQHaAQYIARABGAHaAQYIAhABGBQ&sclient=gws-wiz-serp')
#
# # Extract the unique identifier from the webpage
# unique_identifier = extract_unique_identifier(page)
#
# if unique_identifier:
#     print("Unique identifier:", unique_identifier)
# else:
#     print("Failed to extract unique identifier")
#
# # Perform actions on the webpage
#
# # Extract the same unique identifier from the webpage
# unique_identifier = extract_unique_identifier(page)
#
# if unique_identifier:
#     print("Unique identifier:", unique_identifier)
# else:
#     print("Failed to extract unique identifier")
#
# # Close the browser
# browser.close()

# # Function to generate a consistent unique ID for a URL
# def generate_unique_id(url):
#     unique_id = hashlib.sha256(url.encode()).hexdigest()
#     return unique_id
# playwright = sync_playwright().start()
# browser = playwright.chromium.launch(channel="msedge", headless=False)
# page = browser.new_page()
#
# # Navigate to the URL
# url = 'https://www.google.com/search?q=i+used+one+directory+in+python+without+closing+how+to+close+it+%3F&biw=1366&bih=625&sxsrf=APwXEdcE1-8AWhOpEAsSDCDoRdpc-4yFRw%3A1685938895768&ei=z2J9ZKzALorgseMPleCP8AM&ved=0ahUKEwjs4_rno6v_AhUKcGwGHRXwAz4Q4dUDCA8&uact=5&oq=i+used+one+directory+in+python+without+closing+how+to+close+it+%3F&gs_lcp=Cgxnd3Mtd2l6LXNlcnAQAzoHCCMQ6gIQJzoPCAAQigUQ6gIQtAIQQxgBOgQIIxAnOgcIABCKBRBDOgsIABCABBCxAxCDAToRCC4QigUQsQMQgwEQ5QQQ1AI6CAgAEIAEELEDOggILhCABBDlBDoICC4QgAQQsQM6CAgAEIoFEJECOgUIABCABDoICAAQigUQsQM6BQguEIAEOggILhCABBDUAjoICC4Q1AIQgAQ6CwgAEIoFELEDEIMBOhMILhCABBCXBRDcBBDeBBDgBBgCOggIABAWEB4QDzoGCAAQFhAeOggIABAWEB4QCjoICAAQigUQhgM6CAghEBYQHhAdOgoIIRAWEB4QDxAdOgcIIRCgARAKOgUIIRCgAToFCAAQogQ6BAghEBVKBAhBGABQmA9YitMBYMzUAWgIcAF4AYAB9QSIAddhkgELMC41My4xMS41LTKYAQCgAQGwARHAAQHaAQYIARABGAHaAQYIAhABGBQ&sclient=gws-wiz-serp'
# page.goto(url)
#
# # Generate a unique ID for the URL
# unique_id = generate_unique_id(url)
# print("Unique ID for", url, ":", unique_id)
#
# # Redo the navigation to the same URL
# page.goto(url)
#
# # Generate the same unique ID for the URL
# unique_id = generate_unique_id(url)
# print("Unique ID for", url, ":", unique_id)
#
# # Close the browser
# browser.close()