import time
from datetime import datetime
from config.loginconfig import login, switchcontext
from config.navigationfilter import filterby_login_id
from logandreport.logger import advanced_debug_report
from screenlaunch.browser import Browser,find_browser_process_id
from screenlaunch.screenlaunchtest import execute_screenlaunch
from screenlaunch.utils import read_file,remove_folder
from screenlaunch.webutils import screenshot, pleasewait, screenlaunchpopup, pageload,is_in_sequence
from config.commonobj import CommonObject
import psutil
import gc
import json
import sys

import csv

def custom_crash_handler():
    print("Browser process crashed. Handling the crash...")
    
    # Add your custom handling code here
    # For example, you can restart the browser or take any necessary actions.

    # Restart the browser
    Browser.page.close()
    Browser.context.close()
    Browser.context = Browser.driver.new_context()
    Browser.page = Browser.context.new_page()
    
class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, "a")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass


def filter_activities(data, required_word):
    Result = []
    count = 0
    for rvwbpc_entry in data.get("data", {}).get("rvwbpc", []):
        for component in rvwbpc_entry.get("components", []):
            for activity in component.get("activities", []):
                if activity.get("description") == required_word:
                    Result.append({
                        "Process": rvwbpc_entry["description"],
                        "Component": component["description"],
                        "Activity": activity["description"],
                        "sequence": count
                    })
                    count += 1
    
    return Result




def save_response(response):
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    file_name = f'response_{timestamp}.txt'
    with open(file_name, 'w', encoding='utf-8') as file:
        file.write(response.text())

def memoryusage(thresh):
    # Get memory usage
    memory_info = psutil.virtual_memory()

    # Calculate and print memory percentage
    memory_percentage = memory_info.percent
    print(f"Memory Usage: {memory_percentage}%")
    if memory_percentage > thresh:
        return True
    return False

def check_high_cpu_usage(threshold):
    cpu_percentage = psutil.cpu_percent(interval=1)
    print(f"Overall CPU Usage: {cpu_percentage}%")
    if cpu_percentage > threshold:
        return True
    return False

def clear_memory():
    gc.collect()  # Trigger garbage collection
    if hasattr(psutil, 'virtual_memory'):
        mem = psutil.virtual_memory()
        if mem.percent > 85:
            print("Memory usage is above 85%. Clearing memory...")
            # Attempt to release memory by running additional garbage collection
            gc.collect()
            print("Memory cleared.")
def getid():
    chrome_with_python_parent = {}
    for process in psutil.process_iter(['pid', 'name']):
        process_id = process.pid
        process_name = process.name()
        process_status = process.status()
        is_python_parent = False
        is_node_parent = False
        is_exe_parent = False
        if process_name == CommonObject.browsertype:
            parent_processes = process.parents()
            parent_python_process_id = None
            parent_node_process_id = None
            parent_exe_process_id = None
            for parent_process in parent_processes:
                if (parent_process.name() == "Code.exe"):
                    is_python_parent = True
                    parent_python_process_id = parent_process.pid
                elif (parent_process.name() == "node.exe"):
                    is_node_parent = True
                    parent_node_process_id = parent_process.pid
                # elif (parent_process.name() == exe_name):
                #     is_exe_parent = True
                #     parent_exe_process_id = parent_process.pid
        if is_python_parent and is_node_parent :
            # if chrome_with_python_parent.get(parent_python_process_id) == None :
            #     chrome_with_python_parent.update({parent_python_process_id:[process_id]})
            # else:
                # chrome_with_python_parent.get(parent_python_process_id).append(process_id)
            if chrome_with_python_parent.get(parent_node_process_id)==None:
                chrome_with_python_parent.update({parent_node_process_id:[process_id]})
            else:
                chrome_with_python_parent.get(parent_node_process_id).append(process_id)
    print("from parallel")
    print(chrome_with_python_parent)

def memorymonitor():
    chrome_with_python_parent = {}
    exe_name = "NightlySwifTest-ScreenLaunch_V3.8.exe"
    report_csv = "Memory_report.csv"
    with open(report_csv, 'w', newline='') as csvfile:
        fieldnames = ["pid_to_monitor", "cpu_percent", "memory_usage","Date&time"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for process in psutil.process_iter(['pid', 'name']):
            process_id = process.pid
            process_name = process.name()
            process_status = process.status()
            is_python_parent = False
            is_node_parent = False
            is_exe_parent = False
            if process_name == "msedge.exe":
                parent_processes = process.parents()
                parent_python_process_id = None
                parent_node_process_id = None
                parent_exe_process_id = None
                for parent_process in parent_processes:
                    if (parent_process.name() == "cmd.exe"):
                        is_python_parent = True
                        parent_python_process_id = parent_process.pid
                    elif (parent_process.name() == "node.exe"):
                        is_node_parent = True
                        parent_node_process_id = parent_process.pid
                    elif (parent_process.name() == exe_name):
                        is_exe_parent = True
                        parent_exe_process_id = parent_process.pid
            if is_python_parent and is_node_parent and is_exe_parent:
                if chrome_with_python_parent.get(parent_python_process_id) == None:
                    chrome_with_python_parent.update({parent_python_process_id:[process_id]})
                else:
                    chrome_with_python_parent.get(parent_python_process_id).append(process_id)

        for each_python_parent_key, each_python_parent_values in chrome_with_python_parent.items():
            for each_each_python_parent_values in each_python_parent_values:
                try:
                    pid_to_monitor = each_each_python_parent_values
                    process = psutil.Process(pid_to_monitor)
                    cpu_percent = process.cpu_percent(interval=1.0)
                    memory_info = process.memory_info()
                    memory_usage = memory_info.rss
                    timestamp = datetime.now().strftime("%d-%m-%Y %H-%M-%S").replace(":", "_")
                    writer.writerow({
                    'pid_to_monitor':pid_to_monitor,
                    'cpu_percent': str('{:.2f}'.format(cpu_percent)),
                    'memory_usage':str(memory_usage / (1024 ** 2))+"MB",
                    "Date&time":str(timestamp)})

                    print(f"Chrome PID: {pid_to_monitor}, CPU Usage: {cpu_percent:.2f}%, Memory Usage: {memory_usage / (1024 * 1024):.2f} MB")
                except Exception as error:
                    print(error)


def get_memory_usage():
    memory_info = Browser.page.evaluate("""
        () => {
            const memoryInfo = performance.memory;
            return {
                jsHeapSizeLimit: memoryInfo.jsHeapSizeLimit,
                totalJSHeapSize: memoryInfo.totalJSHeapSize,
                usedJSHeapSize: memoryInfo.usedJSHeapSize
            };
        }
    """)
    return memory_info

def is_element_displayed(page, selector):
    # This method checks if an element is displayed based on its CSS 'display' property
    element = page.query_selector(selector)
    if element:
        display = page.evaluate("element => getComputedStyle(element).display", element)
        return display != 'none'
    return False

def process_navigation_config(input_file,processID,logfolder,logfoldername):
    global temploginid, df
    if CommonObject.config["ParallelExecution"] == "ON":
        CommonObject.process_id = "_" + str(processID)
        file = CommonObject.project_path + "Files/" + str(input_file) + CommonObject.fileformat
    else:
        CommonObject.process_id = ""
        file = CommonObject.project_path + "Files/" + str(input_file) + CommonObject.fileformat
    CommonObject.logfoldername = logfoldername
    CommonObject.logfolder = logfolder
    df2 = read_file(file, CommonObject.navigationsheet)
    if CommonObject.config["ParallelExecution"] == "ON":
        df = df2
    else:
        if CommonObject.config["Process"] == "All" and CommonObject.config["Component"] == "All" and CommonObject.config[
            "Activity"] == "All":
            df = df2
            CommonObject.filter = False
            CommonObject.filter_applied = "No"
        elif str(CommonObject.config["Process"]) == "nan" and str(CommonObject.config["Component"]) == "nan" and str(
                CommonObject.config["Activity"]) == "nan":
            df = df2
            CommonObject.filter = False
            CommonObject.filter_applied = "No"
        else:
            CommonObject.filter = True
            CommonObject.filter_applied = "Yes"
            df = filterby_login_id(df2)
            try:
                if df.empty == True:
                    raise Exception
            except Exception as error:
                print("""Kindly give the inputs correctly in ScreenLaunchConfig.csv file filter Process,Component,Activity.
                        There is no values for your required filtration If you don't want filter,Don't fill the values in Process,Component,Activity""")
    column_list = df.columns.tolist()
    for i in range(len(df)):
        try:
            currentnavigation = str(i + 1)
            if CommonObject.config["ParallelExecution"] == "ON":
                CommonObject.process_id = "_" + str(processID)
                print("[Parallel Execution : " + str(
                    CommonObject.process_id1) + "] Executing " + currentnavigation + " out of " + str(
                    len(df)) + " Navigation Activity")
            else:
                print("Executing " + currentnavigation + " out of " + str(len(df)) + " Navigation Activity")
            result = is_in_sequence(i)
            CommonObject.screenshotflag=False
            if result:
                print("Fifty once Time relauch Entered")
                relaunchurl()
                try:
                    login(temploginid)
                except Exception as Loginerror:
                    print(Loginerror)

            #     Browser.context.clear_cookies()
            #     print("Cleared the cookies")
            #     clear_memory()
                # Browser.context.clear_storage_state()
                # print("Storage state Cleared")
            CommonObject.login_id = str(df.iloc[i]["Login"])
            CommonObject.sno = int(df.iloc[i]["Sno"])
            CommonObject.switchcontext_id = str(df.iloc[i]["SwitchContext"])
            CommonObject.navigation_config_id = df.iloc[i]["NavigationConfigID"]
            CommonObject.process_name = str(df.iloc[i]["Process Name"])
            CommonObject.component_name = str(df.iloc[i]["Component Name"])
            CommonObject.activity_name = str(df.iloc[i]["Activity Name"])
            CommonObject.page_reference_name = df.iloc[i]["Page Reference Name"]
            CommonObject.PATCH_ID = df.iloc[i]["PATCH_ID"]

            if "Window" in column_list:
                CommonObject.window=df.iloc[i]["Window"]

            if CommonObject.login_id != "nan":
                temploginid = CommonObject.login_id
                if CommonObject.loginflag:
                    logout()
                    relaunchurl()
                    try:
                        login(temploginid)
                    except Exception as Loginerror:
                        print(Loginerror)
                else:
                    try:
                        login(temploginid)
                    except Exception as Loginerror:
                        print(Loginerror)
            pleasewait()
            #memoryusage(90)
            # Get memory usage information
            # memorymonitor()
            memory_info = get_memory_usage()
            # print(memory_info)
            # print("Memory Usage:")
            # print(f"JS Heap Size Limit: {memory_info['jsHeapSizeLimit']} bytes")
            # print(f"Total JS Heap Size: {memory_info['totalJSHeapSize']} bytes")
            # print(f"Used JS Heap Size: {memory_info['usedJSHeapSize']} bytes")

            
            if CommonObject.config["App Type"] == "Nebula co-existence":
                if check_high_cpu_usage(99) or memoryusage(95):
                    print("CPU/Memory usage is above 90%!")
                    relaunchurl()
                    print("Relaunch Because of CPU usage/Memory is above 90%!")
                    try:
                        login(temploginid)
                    except Exception as Loginerror:
                        print(Loginerror)
            if CommonObject.config["App Type"] == "Nebula co-existence":
                #menu = "//*[@aria-label='Open menu']"
                menu = "//*[@id ='MenuBar_Icon_toggleSideNav']"
                #menu = "//*[@class='icon-wrap icon-s icon-left']"
            elif CommonObject.config["App Type"] == "ePubs":
                menu = "//*[@class='container-fluid headerMaster']/div/button[@class='btn btn-primary dropdown-toggle hdrBtn']"
            elif str(CommonObject.config["App Type"]).lower()=="openworks":
                menu="//*[starts-with(@id,'mainNbMenu-button')]//*[contains(@id, 'btnWrap')]"
            else:
                menu = "//div/a[@name = 'mainMenu_button']"
            if CommonObject.config["App Type"] == "Nebula co-existence":
                # Browser.page.wait_for_selector(menu, state='visible', timeout=2000)
                try:
                    # print("Relaunch in nav config")
                    Browser.page.wait_for_load_state('domcontentloaded')
                    Browser.page.wait_for_selector(menu,timeout=10000)
                    element =Browser.page.locator(menu)
                    if element.count() == 0:
                        raise Exception
                except Exception as er:
                    Browser.page.reload()
                    print("Relaunch in Nebula Menu button not found")
                    relaunchurl()
                    try:
                        login(temploginid)
                    except Exception as Loginerror:
                        print(Loginerror)
            #Browser.page.wait_for_load_state('domcontentloaded')
            #menu = "//div/a[@name = 'mainMenu_button']"
            if CommonObject.switchcontext_id != "nan":
                switchcontext(CommonObject.switchcontext_id)
                pleasewait()
            now = datetime.now()
            local_now = now.astimezone()
            local_tz = local_now.tzinfo
            local_tzname = local_tz.tzname(local_now)
            CommonObject.timezone = str(local_tzname)
            CommonObject.exe_start_time = datetime.now().replace(microsecond=0)
            if CommonObject.loginfirsttime is True:
                Browser.page.wait_for_selector(menu, state='visible', timeout=30000)
                CommonObject.loginfirsttime = False
            else:
                pleasewait()
                panelbutton = Browser.page.locator("//div[@name='northPanel_panel' and @aria-expanded ='false']").count()
                if panelbutton != 0:
                    panel_button = "//*[starts-with(@id,'northPanel-panel')]//*[contains(@id, 'splitter-collapseEl')]"
                    Browser.page.click(panel_button)
            pleasewait()
            
            if  CommonObject.config["App Type"] == "Nebula co-existence" and CommonObject.config["NavigationType"].lower()!="activitysearch":
            #     element = page.locator(menu)
            #     if element.count() == 0:
            #         relaunchurl()
            #         print("Relaunch in Nebula")
            #         login(temploginid)
                Component = "//*[@class='sidenav-menu-item sidenav-component-menu-item']/div[text()='"+CommonObject.component_name+"']"
                Activity = "//*[@class='sidenav-menu-item  sidenav-activity-menu-item']/div[text()='"+CommonObject.activity_name+"']"
                if int(currentnavigation) > 1 :
                    print("click Menu Button")
                    Browser.page.locator(menu).click()
                    print("click Component Button")
                    Browser.page.locator(Component).click()
                    print("click Activity Button")
                    Browser.page.locator(Activity).click()
                    #Browser.page.wait_for_navigation()
                    # page.click(menu,timeout=5000)
                    # #page.click(Process,timeout=5000)
                    # page.click(Component,timeout=5000)
                    # #page.locator(Component).click()
                    # page.click(Activity,timeout=5000)
                    #relaunchurl()
                    pleasewait()
                    #Reload_page()
                    screenlaunchpopup()
                    filename = CommonObject.project_path + 'Files/' + CommonObject.page_reference_name.split(":")[
                        0] + CommonObject.fileformat
                    execute_screenlaunch(filename, CommonObject.page_reference_name.split(":")[1])
                else:
                    time.sleep(5)
                    if CommonObject.switchcontext_id != "nan":
                        Browser.page.locator(menu).click()
                    #page.click(menu,timeout=5000)
                    # page.click(Process,timeout=5000)
                    # page.locator(Component).click()
                    #Browser.page.wait_for_navigation()

                    print("click Menu Button")
                    Browser.page.locator(menu).click()
                    print("click Component Button")
                    Browser.page.locator(Component).click()
                    print("click Activity Button")
                    Browser.page.locator(Activity).click()
                    Browser.page.wait_for_load_state('domcontentloaded')



                    #Browser.page.wait_for_navigation()

                    # page.click(Component, timeout=5000)
                    # page.click(Activity, timeout=5000)
                    pleasewait()
                    screenlaunchpopup()
                    filename = CommonObject.project_path + 'Files\\' + CommonObject.page_reference_name.split(":")[
                        0] + CommonObject.fileformat

                    execute_screenlaunch(filename, CommonObject.page_reference_name.split(":")[1])
            elif CommonObject.config["App Type"] == "ePubs":
                sidemenu = Browser.page.locator("//*[@id='mySidenav' and @style='display: block;']").count()
                if sidemenu != 0:
                    Browser.page.click(menu, timeout=5000)
                Browser.page.click(menu, timeout=5000)
                Process = "//*[@class='panel-title expand']//a[text()='" + CommonObject.process_name + "']"
                ComponentList_open = Browser.page.locator("//*[@id='mySidenav']/div/h4/a[text()='" + CommonObject.process_name + "']/following::div[1][@class='panel-collapse collapse in']/a[text()='" + CommonObject.component_name + "']").count()
                if ComponentList_open == 0:
                    Browser.page.click(Process, timeout=3000)
                Component = "//*[@id='mySidenav']/div/h4/a[text()='" + CommonObject.process_name + "']/following::div[1][@class='panel-collapse collapse in']/a[text()='" + CommonObject.component_name + "']"
                Browser.page.click(Component, timeout=3000)
                pleasewait()
                screenlaunchpopup()
                filename = CommonObject.project_path + 'Files\\' + CommonObject.page_reference_name.split(":")[0] + CommonObject.fileformat
                execute_screenlaunch(filename, CommonObject.page_reference_name.split(":")[1])
            elif CommonObject.config["App Type"] == "Nebula co-existence"and CommonObject.config["NavigationType"].lower()=="activitysearch":
                search_box="//*[@class='search-box']//input[@id='activitySearchInput']"
                Browser.page.wait_for_selector(search_box, state='visible', timeout=10000)
                element = Browser.page.locator(search_box)
                element.click()
                element.fill(CommonObject.activity_name)
                activityloc="//*[@class='dropdown-wrapper  undefined bottom-left dropdown-active']//*[text()='"+CommonObject.activity_name+"']"
                # activityelement = Browser.page.locator(activityloc)
                # activityelement.first.click()
                # Find all elements matching the XPath
              
                try:
                    Browser.page.wait_for_selector(activityloc,state='visible',timeout=3000)
                    elements = Browser.page.query_selector_all(activityloc)
                    if len(elements)>1:
                       
                        # Record the start time
                        start_time = time.time()
                        # Assuming you have already imported json module and have data in the correct path
                        with open(CommonObject.project_path +"API-Responses\\APIresponse.json", "r") as read_it:
                            data = json.load(read_it)
                            filtered_result = filter_activities(data,CommonObject.activity_name)
                            for filterdata in filtered_result:
                                Process_Name=filterdata.get('Process')
                                Component_Name=filterdata.get('Component')
                                Activity_Name=filterdata.get('Activity')
                                if Process_Name==CommonObject.process_name and Component_Name==CommonObject.component_name and Activity_Name==CommonObject.activity_name:
                                    elements[int(filterdata.get('sequence'))].click()
                        end_time = time.time()
                        # Calculate the duration
                        duration = end_time - start_time
                        # Print the duration
                        print(f"Execution time for Json filter: {duration} seconds")
                    elif elements:
                        # Click the first element
                        elements[0].click()
                except Exception as clickerror:
                    print("Click_error :"+str(clickerror))
                    raise Exception (str(clickerror))
                Browser.page.wait_for_selector(search_box, state='visible', timeout=30000)  # Wait up to 5 seconds
                pleasewait()
                screenlaunchpopup()
                filename = CommonObject.project_path + 'Files\\' + CommonObject.page_reference_name.split(":")[0] + CommonObject.fileformat
                execute_screenlaunch(filename, CommonObject.page_reference_name.split(":")[1])
            elif str(CommonObject.config["App Type"]).lower()=="openworks":
                # Replace with the actual selector of the DOM structure you want to check
                # selector = 'your-selector'

                # is_displayed = is_element_displayed(Browser.page, selector)
                # print(f"Is the element displayed? {is_displayed}")
    
                expander="//li[contains(@class,'expanded')]"
                Browser.page.click(menu,timeout=5000)
                try:
                    # Try to locate the div element that matches the criteria
                    div_element = Browser.page.wait_for_selector("//div[contains(@id,'window') and @aria-hidden='false']", timeout=5000)
                    # If the element is found and visible
                    if div_element.is_visible():
                        print("Element located and visible. Proceeding with actions.")
                        # Perform your specific actions here
                    else:
                        raise Exception("Element not visible")

                except Exception as e:
                    print("Element not found or not visible. Clicking the menu button.")
                    # Click the menu button
                    Browser.page.click(menu,timeout=5000)
                try:
                    # Select all elements that match the provided selector
                    elements = Browser.page.query_selector_all(expander)
                    if len(elements)>2:
                        relaunchurl()
                        try:
                            login(temploginid)
                        except Exception as Loginerror:
                            print(Loginerror)
                    if elements:
                        # Iterate over the reversed elements
                        for rev_ind, element in enumerate(reversed(elements)):
                            # Calculate the corresponding reverse index
                            ind = len(elements) - 1 - rev_ind
                            text = element.inner_text()
                            # print(f"Element text: {text}")  # Debug: print each element's text
                            if len(Previous_Process_and_component)!=0:
                                # Check if the element's text matches the text_to_match
                                if Previous_Process_and_component[ind] in text:
                                    # print(f"Clicking on element with text: {text}")
                                    Browser.page.click("//li[contains(@class,'expanded')]//div[@class='x-treelist-item-text' and text()='"+str(Previous_Process_and_component[ind])+"']")
                                    # element.click()
                    else:
                        print(f"No elements found for selector '{expander}'")

                except Exception as expander_error:
                    print(f"Timeout: No elements found for selector '{expander}' within the given time")
                
                # if elements:
                #     print(elements)
                #     # Iterate over each element in reverse order and click on it
                #     for element in reversed(elements):
                #         element.click()

                # element = Browser.page.query_selector(expander)
                Process = "//*[contains(@class,'collapsed')]//*[contains(@id,'ext-element') and @style='margin-left: 0px;']//*[text()='" + CommonObject.process_name + "']"
                #print("Process_Locator: "+Process)
                # is_displayed = is_element_displayed(Browser.page, Process)
                # print(f"Is the element displayed? {is_displayed}")
                # Process = "//div[@class='x-treelist-item-wrap']//div[text()='" + CommonObject.process_name + "']"
                # try:
                Browser.page.click(Process,timeout=3000)
                # except Exception as processclickerror:
                #     print("Process_Click_error :"+str(processclickerror))
                    
                #Component ="//*[contains(@id,'ext-element') and @style='margin-left: 5px;']//*[text()='" + CommonObject.component_name + "']"
                Component ="//li[contains(@class,'expanded')]//*[contains(@id,'ext-element') and @style='margin-left: 0px;']//*[text()='" + CommonObject.process_name + "']//..//..//..//*[contains(@class,'collapsed')]//*[contains(@id,'ext-element') and @style='margin-left: 5px;']//*[text()='" + CommonObject.component_name + "']"
                #print("Component_Locator: "+Component)
                # Component = "//div[@class='x-treelist-item-wrap']//div[text()='" + CommonObject.component_name + "']"
                Previous_Process_and_component=[str(CommonObject.process_name),str(CommonObject.component_name)]
                Browser.page.click(Component,timeout=3000)
                activityloc="//li[contains(@class,'expanded')]//*[contains(@id,'ext-element') and @style='margin-left: 0px;']//*[text()='" + CommonObject.process_name + "']//..//..//..//..//*[contains(@class,'expanded')]//*[contains(@id,'ext-element') and @style='margin-left: 5px;']//*[text()='" + CommonObject.component_name + "']//..//..//..//../*[contains(@class,'leaf')]//*[contains(@id,'ext-element') and @style='margin-left: 10px;']//*[text()='" +CommonObject.activity_name + "']"
                # activityloc="//*[contains(@id,'ext-element') and @style='margin-left: 10px;']//*[text()='" +CommonObject.activity_name + "']"
                # activityloc="//div[@class='x-treelist-item-wrap']//div[text()='" +CommonObject.activity_name + "']"

                #print("Activity_Locator: "+activityloc)
                try:
                    Browser.page.wait_for_selector(activityloc,state='visible',timeout=3000)
                    elements_activity = Browser.page.query_selector_all(activityloc)
                    if elements_activity:
                        # Click the first element
                        elements_activity[0].click()
                    
                except Exception as clickerror:
                    print("Click_error :"+str(clickerror))
                    raise Exception (str(clickerror))
                
                pleasewait()
                screenlaunchpopup()
                filename = CommonObject.project_path + 'Files\\' + CommonObject.page_reference_name.split(":")[0] + CommonObject.fileformat
                execute_screenlaunch(filename, CommonObject.page_reference_name.split(":")[1])
                # Browser.page.click(menu,timeout=5000)
                # Browser.page.click(Process,timeout=3000)
                # Browser.page.click(menu,timeout=5000)
            else:
                Browser.page.click(menu,timeout=5000)
                Process = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr x-menu-bpc']//span[text()='" + CommonObject.process_name + "']"
                Browser.page.click(Process,timeout=3000)
                Component = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr x-menu-component']//span[text()='" + CommonObject.component_name + "']"
                Browser.page.click(Component,timeout=3000)
             
                Activity="//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr x-menu-activity']//span[text()=\"" + CommonObject.activity_name + "\"]"
                Browser.page.click(Activity,timeout=3000)
              
                pleasewait()
                if CommonObject.window==1:
                    # element = find_element(loc, None)
                    Temp_tab =Browser.page
                    with Browser.page.context.expect_page() as tab_two:
                        # element.first.click()
                        Browser.page = tab_two.value
                        Browser.page.bring_to_front()
                    try:
                        # Browser.page.wait_for_selector("//a[@title='Show Navigation Component']", state='visible', timeout=2000)
                        Browser.page.wait_for_load_state('domcontentloaded')
                        screenlaunchpopup()
                        filename = CommonObject.project_path + 'Files\\' + CommonObject.page_reference_name.split(":")[
                            0] + CommonObject.fileformat
                        execute_screenlaunch(filename, CommonObject.page_reference_name.split(":")[1])
                        #Questionicon = Browser.page.locator("//button[@class='btn btn-primary hdrBtn']").count()
                        Browser.page.close()
                        Browser.page = Temp_tab
                    except Exception as Error:
                        # takesnapshot()
                        CommonObject.errormessage = Error
                    
                        Browser.page = Temp_tab
                        raise Exception("Window switch Verification Failed")
                else:
                    screenlaunchpopup()
                    filename = CommonObject.project_path + 'Files\\' + CommonObject.page_reference_name.split(":")[
                            0] + CommonObject.fileformat
                    execute_screenlaunch(filename, CommonObject.page_reference_name.split(":")[1])

        except Exception as e:
            print(e)
            try:
                print("Element not found")
                CommonObject.status = "FAIL"
                timestamp = str(datetime.now()).replace(":", "_")
                if not CommonObject.screenshotflag:
                    screenshot(CommonObject.logfolder + '\\screenshot_' + timestamp +str(CommonObject.process_id)+'.png')
                    if str(e).find(str(CommonObject.process_name)) != -1:
                        CommonObject.errormessage = "Unable to locate the Process " + CommonObject.process_name
                        Browser.page.click(menu)
                    elif str(e).find(str(CommonObject.component_name)) != -1:
                        CommonObject.errormessage = "Unable to locate the Component " + CommonObject.component_name
                    elif str(e).find(str(CommonObject.activity_name)) != -1:
                        CommonObject.errormessage = "Unable to locate the Activity " + CommonObject.activity_name
                    elif str(e).find("mainMenu") != -1 and str(e).find("element click intercepted") != -1:
                        CommonObject.errormessage = "Menubutton Click intercepted"
                    elif str(e).find("Timeout") != -1 and str(e).find("exceeded")and str(e).find("northPanel-panel") != -1:
                        CommonObject.errormessage = "Timeout Exceeded to located the panelbutton"
                    # elif str(e).find("Timeout") != -1 and str(e).find("exceeded")!= -1 :
                    #     CommonObject.errormessage = "Timeout Exceeded"
                    else:
                        errormessage = str(e).replace('"', '').replace("'", '')
                        CommonObject.errormessage = errormessage
                    
                           
                    print("Before clicking the escape")
                    Browser.page.keyboard.press("Escape")
                    if CommonObject.config["App Type"] != "Nebula co-existence":
                        pleasewait()
                    time.sleep(0.2)
                    print("Escape2 Clicking")
                    Browser.page.keyboard.press("Escape")
                    time.sleep(0.2)
                    print("After clicking the escape")
                advanced_debug_report(CommonObject.logfolder+'\\ScreenLaunchAdvancedDebugLog'+str(CommonObject.process_id)+'.csv')
                if CommonObject.screenshoterrorflag:
                    try:
                        relaunchurl()
                        print("launched  the brower by drive under exception1")
                        try:
                            login(temploginid)
                        except Exception as Loginerror:
                            print(Loginerror)
                        CommonObject.screenshoterrorflag =False
                        CommonObject.pleasewaiterror=False
                    except Exception as e:
                        print("Exception in browser killed")
                        relaunchurl()
                        print("launched  the brower by drive1")
                        try:
                            login(temploginid)
                        except Exception as Loginerror:
                            print(Loginerror)
                        CommonObject.screenshoterrorflag =False
                        CommonObject.pleasewaiterror=False
                if str(e).find("Application Error Message: SessionID Doesnot Exists.")!= -1 or str(e).find("Service Unavailable")!= -1:
                    CommonObject.pagetimeout =True
           
                #is_dev_tools_connected = Browser.context.is_connected()
                if CommonObject.pagetimeout or CommonObject.session_expired:
                    print("First Relaunch Due to Pagetimeout/Session expired")
                    relaunchurl()
                    try:
                        login(temploginid)
                    except Exception as Loginerror:
                        print(Loginerror)
                    CommonObject.pagetimeout = False
                    CommonObject.session_expired = False
                if CommonObject.config["App Type"] == "Nebula co-existence":
                    #Browser.page.wait_for_selector(menu, state='visible', timeout=2000)
                    try:
                        Browser.page.wait_for_load_state('domcontentloaded')
                        Browser.page.wait_for_selector(menu,timeout=5000)
                        print("Waiting for DOM content loaded")
                        element=Browser.page.locator(menu)
                        print("menu located")
                        if element.count() == 0:
                            print("menu content check")
                            raise Exception
                    except Exception as er:
                        print("Relaunch under exception catch")
                        Browser.page.reload()
                        relaunchurl()
                        print("Relaunch in Nebula menu is not there")
                        try:
                            login(temploginid)
                        except Exception as Loginerror:
                            print(Loginerror)
                print("Exception code surpassed")
                if CommonObject.config["App Type"] == "Nebula co-existence":
                    if CommonObject.Toast_error_pop_up:
                        print("Relaunch in Toast error pop presents")
                        relaunchurl()
                        try:
                            login(temploginid)
                        except Exception as Loginerror:
                            print(Loginerror)
                        CommonObject.Toast_error_pop_up=False
                    toasterror="//div[@class='Toastify__toast-container Toastify__toast-container--top-right']"
                    toasterror_loc=Browser.page.query_selector(toasterror)
                    print(toasterror_loc)
                    if toasterror_loc!=None and toasterror_loc.is_visible():
                        relaunchurl()
                        print("Relaunch in Toast error pop presents")
                        try:
                            login(temploginid)
                        except Exception as Loginerror:
                            print(Loginerror)
                # elif str(CommonObject.config["App Type"]).lower() == "openworks":
                    # Browser.page.click(menu,timeout=5000)
                    # Browser.page.click(Component,timeout=3000)
                    # Browser.page.click(Process,timeout=3000)
                    # Browser.page.click(menu,timeout=5000)

                
            except Exception as Exceptions:
                print("End Exceptions"+str(Exceptions))
                if CommonObject.screenshoterrorflag:
                    try:
                        relaunchurl()
                        print("launched  the brower by drive2")
                        try:
                            login(temploginid)
                        except Exception as Loginerror:
                            print(Loginerror)
                        CommonObject.screenshoterrorflag =False
                        CommonObject.pleasewaiterror=False
                        
                    except Exception as e:
                        print("Exception in browser killed2")
                        relaunchurl()
                        print("launched  the brower by drive2")
                        try:
                            login(temploginid)
                        except Exception as Loginerror:
                            print(Loginerror)
                        CommonObject.screenshoterrorflag =False
                        CommonObject.pleasewaiterror=False


def relaunchurlnebula():
    print("Entered in to Nebula error relaunch")
    driver = Browser.initialize(CommonObject.config["ApplicationURL"])
    Browser.page.wait_for_load_state('domcontentloaded')
    print("Successfully Relaunched")

def logout():
    menuclick = Browser.page.click("//*[starts-with(@id,'userMenu-button')]")
    signout = Browser.page.locator("//*[starts-with(@id,'menuitem') and text()='Signout']")
    lognout = Browser.page.locator("//*[starts-with(@id,'menuitem') and text()='Log Out']")
    if signout != 0:
        signout = Browser.page.click("//*[starts-with(@id,'menuitem') and text()='Signout']")
    elif lognout != 0:
        lognout = Browser.page.click("//*[starts-with(@id,'menuitem') and text()='Log Out']")
    CommonObject.loginflag = False



def Killrunningbrowsers():
    if CommonObject.config["ParallelExecution"] == "ON":
        try:
            if not CommonObject.firstkill:
                print("Entered in to the Killing Browsers")
                # Deserialize JSON from a file back to a dictionary
                with open(f'data{str(CommonObject.process_id1)}.json', 'r') as json_file:
                    chrome_with_python_parent= json.load(json_file)
                    key1=list(chrome_with_python_parent.keys())
                    CommonObject.Keyfor_pid= key1[0]
                if len(chrome_with_python_parent)!=0:
                    for parent_pid, child_pids in chrome_with_python_parent.items():
                        parent_process = psutil.Process(int(parent_pid))
                        children = parent_process.children(recursive=True)
                        for child in children:
                            try:
                                if child.pid in child_pids:
                                    print("Terminating Child instances "+str(child.pid))
                                    child.terminate()
                                CommonObject.firstkill=True
                            except Exception as terminateerror:
                                print("termination error "+str(terminateerror))
            else:
                time.sleep(3)
                browser_with_python_parent=find_browser_process_id()
                print("AfterFirstkill")
                print(browser_with_python_parent)
                while not browser_with_python_parent:
                    print("The dictionary is empty. Trying to find the browser process ID...")
                    browser_with_python_parent=find_browser_process_id()
                print(CommonObject.Keyfor_pid)
                if CommonObject.Keyfor_pid in browser_with_python_parent:
                    print("Key "+str(CommonObject.Keyfor_pid)+" exists in the dictionary")
                for key,value in browser_with_python_parent.items():
                    if str(key)==str(CommonObject.Keyfor_pid):
                        chrome_with_python_parent={key:value}
                print(chrome_with_python_parent)
                if len(chrome_with_python_parent)!=0:
                    for parent_pid, child_pids in chrome_with_python_parent.items():
                        parent_process = psutil.Process(int(parent_pid))
                        children = parent_process.children(recursive=True)
                        for child in children:
                            try:
                                if child.pid in child_pids:
                                    print("Terminating Child instances "+str(child.pid))
                                    child.terminate()
                                CommonObject.firstkill=True
                            except Exception as terminateerror:
                                print("termination error "+str(terminateerror))

        except Exception as browserkillerror:
            print("browserkillerror,"+str(browserkillerror)) 
    else:
        try:
            print("Entered in to the Killing Browsers")
            exe_name = CommonObject.executable_name
            chrome_with_python_parent = {}
            for process in psutil.process_iter(['pid', 'name']):
                process_id = process.pid
                process_name = process.name()
                process_status = process.status()
                is_python_parent = False
                is_node_parent = False
                is_exe_parent = False
                if process_name == CommonObject.browsertype:
                    parent_processes = process.parents()
                    parent_python_process_id = None
                    parent_node_process_id = None
                    parent_exe_process_id = None
                    for parent_process in parent_processes:
                        if (parent_process.name() == "cmd.exe"):
                            is_python_parent = True
                            parent_python_process_id = parent_process.pid
                        elif (parent_process.name() == "node.exe"):
                            is_node_parent = True
                            parent_node_process_id = parent_process.pid
                        elif (parent_process.name() == exe_name):
                            is_exe_parent = True
                            parent_exe_process_id = parent_process.pid
                            
                if is_python_parent and is_node_parent and is_exe_parent:
                    if chrome_with_python_parent.get(parent_python_process_id) == None :
                        chrome_with_python_parent.update({parent_python_process_id:[process_id]})
                    else:
                        chrome_with_python_parent.get(parent_python_process_id).append(process_id)
                    if chrome_with_python_parent.get(parent_node_process_id)==None:
                        chrome_with_python_parent.update({parent_node_process_id:[process_id]})
                    else:
                        chrome_with_python_parent.get(parent_node_process_id).append(process_id)
            print(chrome_with_python_parent)
            if len(chrome_with_python_parent)!=0:
                for parent_pid, child_pids in chrome_with_python_parent.items():
                    parent_process = psutil.Process(parent_pid)
                    children = parent_process.children(recursive=True)
                    for child in children:
                        try:
                            if child.pid in child_pids:
                                print("Terminating Child instances "+str(child.pid))
                                child.terminate()
                        except Exception as terminateerror:
                            print(terminateerror)
                    # parent_process.terminate()
                    print("Parent Process terminated")
        except Exception as browserkillerror:
            print(browserkillerror)    

            

def relaunchurl():
    try:
        print("Entered in to relaunch")
        if CommonObject.pagetimeout or CommonObject.session_expired:
            if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                print("Page object closed")
                Killrunningbrowsers()
            else:
                Browser.page.close()
                Browser.context.close()
                Browser.browser.close()
            try:
                remove_folder(CommonObject.user_dir)
            except Exception as remove_error:
                
                if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                    print("Page object closed")
                    Killrunningbrowsers()
                else:
                    Browser.page.close()
                    Browser.context.close()
                    Browser.browser.close()
                time.sleep(1)
                try:
                    remove_folder(CommonObject.user_dir)
                except Exception as remove_error:
                    print("RemoveError:"+str(remove_error))
            
            # Browser.context= Browser.driver.new_context()
            # Browser.page = Browser.context.new_page()
            # Browser.page.on("response", lambda response: handle_response(response))
            # Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
            # Browser.page.set_viewport_size({"width": 1366, "height": 768})
            CommonObject.nebularelaunch=True
            Browser.initialize(CommonObject.config["ApplicationURL"])
            pageload()
        elif str(CommonObject.config["App Type"]).lower() =="ninja":
            print("Ninja connect relaunch")
            logout()
            Browser.page.close()
            Browser.page = Browser.context.new_page()
            Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
            Browser.page.set_viewport_size({"width": 1366, "height": 768})
            pageload()
        else:
            
            if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                print("Page object closed")
                Killrunningbrowsers()
            else:
                Browser.page.close()
                Browser.context.close()
                Browser.browser.close()
            try:
                remove_folder(CommonObject.user_dir)
            except Exception as remove_error:
                
                if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                    print("Page object closed")
                    Killrunningbrowsers()
                else:
                    Browser.page.close()
                    Browser.context.close()
                    Browser.browser.close()
                time.sleep(1)
                try:
                    remove_folder(CommonObject.user_dir)
                except Exception as remove_error:
                    print("RemoveError:"+str(remove_error))
            # Browser.context= Browser.driver.new_context()
            # Browser.page = Browser.context.new_page()
            # Browser.page.on("response", lambda response: handle_response(response))
            # Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
            # Browser.page.set_viewport_size({"width": 1366, "height": 768})
            CommonObject.nebularelaunch=True
            Browser.initialize(CommonObject.config["ApplicationURL"])
            pageload()
        print("Successfully Relaunched")

    except Exception as errormessage:
        print(errormessage)
        print("Getting exception in relaunch so second time relaunching")
        try:
            if CommonObject.pagetimeout or CommonObject.session_expired:
                
                if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                    print("Page object closed")
                    Killrunningbrowsers()
                else:
                    Browser.page.close()
                    Browser.context.close()
                    Browser.browser.close()
                try:
                    remove_folder(CommonObject.user_dir)
                except Exception as remove_error:
                    
                    if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                        print("Page object closed")
                        Killrunningbrowsers()
                    else:
                        Browser.page.close()
                        Browser.context.close()
                        Browser.browser.close()
                    time.sleep(1)
                    try:
                        remove_folder(CommonObject.user_dir)
                    except Exception as remove_error:
                        print("RemoveError:"+str(remove_error))# Browser.context= Browser.driver.new_context()
                # Browser.page = Browser.context.new_page()
                # Browser.page.on("response", lambda response: handle_response(response))
                # Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                # Browser.page.set_viewport_size({"width": 1366, "height": 768})
                CommonObject.nebularelaunch=True
                Browser.initialize(CommonObject.config["ApplicationURL"])
                pageload()
            elif str(CommonObject.config["App Type"]).lower() =="ninja":
                print("Ninja connect relaunch")
                logout()
                Browser.page.close()
                Browser.page = Browser.context.new_page()
                Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                Browser.page.set_viewport_size({"width": 1366, "height": 768})
                pageload()
            else:
                
                
                if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                    print("Page object closed")
                    Killrunningbrowsers()
                else:
                    Browser.page.close()
                    Browser.context.close()
                    Browser.browser.close()
                try:
                    remove_folder(CommonObject.user_dir)
                except Exception as remove_error:
                    
                    if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                        print("Page object closed")
                        Killrunningbrowsers()
                    else:
                        Browser.page.close()
                        Browser.context.close()
                        Browser.browser.close()
                    time.sleep(1)
                    try:
                        remove_folder(CommonObject.user_dir)
                    except Exception as remove_error:
                        print("RemoveError:"+str(remove_error))
                # Browser.context= Browser.driver.new_context()
                # Browser.page = Browser.context.new_page()
                # Browser.page.on("response", lambda response: handle_response(response))
                # Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                # Browser.page.set_viewport_size({"width": 1366, "height": 768})
                CommonObject.nebularelaunch=True
                Browser.initialize(CommonObject.config["ApplicationURL"])
                pageload()
            print("Successfully Relaunched")
        except Exception as errormessage:
            print("Getting exception in relaunch so third time relaunching")
            try:
                if CommonObject.pagetimeout or CommonObject.session_expired:
                    
                    if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                        print("Page object closed")
                        Killrunningbrowsers()
                    else:
                        Browser.page.close()
                        Browser.context.close()
                        Browser.browser.close()
                    try:
                        remove_folder(CommonObject.user_dir)
                    except Exception as remove_error:
                        
                        if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                            print("Page object closed")
                            Killrunningbrowsers()
                        else:
                            Browser.page.close()
                            Browser.context.close()
                            Browser.browser.close()
                        time.sleep(1)
                        try:
                            remove_folder(CommonObject.user_dir)
                        except Exception as remove_error:
                            print("RemoveError:"+str(remove_error))
                    # Browser.context= Browser.driver.new_context()
                    # Browser.page = Browser.context.new_page()
                    # Browser.page.on("response", lambda response: handle_response(response))
                    # Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                    # Browser.page.set_viewport_size({"width": 1366, "height": 768})
                    CommonObject.nebularelaunch=True
                    Browser.initialize(CommonObject.config["ApplicationURL"])
                    pageload()
                elif str(CommonObject.config["App Type"]).lower() =="ninja":
                    print("Ninja connect relaunch")
                    logout()
                    Browser.page.close()
                    Browser.page = Browser.context.new_page()
                    Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                    Browser.page.set_viewport_size({"width": 1366, "height": 768})
                    pageload()
                else:
                    
                    if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                        print("Page object closed")
                        Killrunningbrowsers()
                    else:
                        Browser.page.close()
                        Browser.context.close()
                        Browser.browser.close()
                    try:
                        remove_folder(CommonObject.user_dir)
                    except Exception as remove_error:
                        
                        if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                            print("Page object closed")
                            Killrunningbrowsers()
                        else:
                            Browser.page.close()
                            Browser.context.close()
                            Browser.browser.close()
                        time.sleep(1)
                        try:
                            remove_folder(CommonObject.user_dir)
                        except Exception as remove_error:
                            print("RemoveError:"+str(remove_error))
                    # Browser.context= Browser.driver.new_context()
                    # Browser.page = Browser.context.new_page()
                    # Browser.page.on("response", lambda response: handle_response(response))
                    # Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                    # Browser.page.set_viewport_size({"width": 1366, "height": 768})
                    CommonObject.nebularelaunch=True
                    Browser.initialize(CommonObject.config["ApplicationURL"])
                    pageload()
                print("Successfully Relaunched")
            except Exception as errormessage:
                print("Getting exception in relaunch so Fourth time relaunching")
                try:
                    if CommonObject.pagetimeout or CommonObject.session_expired:
                        
                        if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                            print("Page object closed")
                            Killrunningbrowsers()
                        else:
                            Browser.page.close()
                            Browser.context.close()
                            Browser.browser.close()
                        try:
                            remove_folder(CommonObject.user_dir)
                        except Exception as remove_error:
                            
                            if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                                print("Page object closed")
                                Killrunningbrowsers()
                            else:
                                Browser.page.close()
                                Browser.context.close()
                                Browser.browser.close()
                            time.sleep(1)
                            try:
                                remove_folder(CommonObject.user_dir)
                            except Exception as remove_error:
                                print("RemoveError:"+str(remove_error))
                        # Browser.context= Browser.driver.new_context()
                        # Browser.page = Browser.context.new_page()
                        # Browser.page.on("response", lambda response: handle_response(response))
                        # Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                        # Browser.page.set_viewport_size({"width": 1366, "height": 768})
                        CommonObject.nebularelaunch=True
                        Browser.initialize(CommonObject.config["ApplicationURL"])
                        pageload()
                    elif str(CommonObject.config["App Type"]).lower() =="ninja":
                        print("Ninja connect relaunch")
                        logout()
                        Browser.page.close()
                        Browser.page = Browser.context.new_page()
                        Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                        Browser.page.set_viewport_size({"width": 1366, "height": 768})
                        pageload()
                    else:
                        
                        if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                            print("Page object closed")
                            Killrunningbrowsers()
                        else:
                            Browser.page.close()
                            Browser.context.close()
                            Browser.browser.close()
                        try:
                            remove_folder(CommonObject.user_dir)
                        except Exception as remove_error:
                            
                            if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                                print("Page object closed")
                                Killrunningbrowsers()
                            else:
                                Browser.page.close()
                                Browser.context.close()
                                Browser.browser.close()
                            time.sleep(1)
                            try:
                                remove_folder(CommonObject.user_dir)
                            except Exception as remove_error:
                                print("RemoveError:"+str(remove_error))
                        # Browser.context= Browser.driver.new_context()
                        # Browser.page = Browser.context.new_page()
                        # Browser.page.on("response", lambda response: handle_response(response))
                        # Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                        # Browser.page.set_viewport_size({"width": 1366, "height": 768})
                        CommonObject.nebularelaunch=True
                        Browser.initialize(CommonObject.config["ApplicationURL"])
                        pageload()
                    print("Successfully Relaunched")
                except Exception as errormessage:
                    #print(errormessage)
                    print("Getting exception in relaunch so Fifth time relaunching")
                    try:
                        if CommonObject.pagetimeout or CommonObject.session_expired:
                            
                            if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                                print("Page object closed")
                                Killrunningbrowsers()
                            else:
                                Browser.page.close()
                                Browser.context.close()
                                Browser.browser.close()
                            try:
                                remove_folder(CommonObject.user_dir)
                            except Exception as remove_error:
                                
                                if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                                    print("Page object closed")
                                    Killrunningbrowsers()
                                else:
                                    Browser.page.close()
                                    Browser.context.close()
                                    Browser.browser.close()
                                time.sleep(1)
                                try:
                                    remove_folder(CommonObject.user_dir)
                                except Exception as remove_error:
                                    print("RemoveError:"+str(remove_error))
                            # Browser.context= Browser.driver.new_context()
                            # Browser.page = Browser.context.new_page()
                            # Browser.page.on("response", lambda response: handle_response(response))
                            # Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                            # Browser.page.set_viewport_size({"width": 1366, "height": 768})
                            CommonObject.nebularelaunch=True
                            Browser.initialize(CommonObject.config["ApplicationURL"])
                            pageload()
                        elif str(CommonObject.config["App Type"]).lower() =="ninja":
                            print("Ninja connect relaunch")
                            logout()
                            Browser.page.close()
                            Browser.page = Browser.context.new_page()
                            Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                            Browser.page.set_viewport_size({"width": 1366, "height": 768})
                            pageload()
                        else:
                           
                            if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                                print("Page object closed")
                                Killrunningbrowsers()
                            else:
                                Browser.page.close()
                                Browser.context.close()
                                Browser.browser.close()
                            try:
                                remove_folder(CommonObject.user_dir)
                            except Exception as remove_error:
                                
                                if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
                                    print("Page object closed")
                                    Killrunningbrowsers()
                                else:
                                    Browser.page.close()
                                    Browser.context.close()
                                    Browser.browser.close()
                                time.sleep(1)
                                try:
                                    remove_folder(CommonObject.user_dir)
                                except Exception as remove_error:
                                    print("RemoveError:"+str(remove_error))
                            # Browser.context= Browser.driver.new_context()
                            # Browser.page = Browser.context.new_page()
                            # Browser.page.on("response", lambda response: handle_response(response))
                            # Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
                            # Browser.page.set_viewport_size({"width": 1366, "height": 768})
                            CommonObject.nebularelaunch=True
                            Browser.initialize(CommonObject.config["ApplicationURL"])
                            pageload()
                        print("Successfully Relaunched")
                    except Exception as errormessage:
                        print(errormessage)


# def get_browser_pid(browser_name):
#     for process in psutil.process_iter(attrs=['pid', 'name']):
#         if browser_name.lower() in process.info['name'].lower():
#             return process.info['pid']
#     return None
#
# def relaunchurl():
#     try:
#         if CommonObject.pagetimeout or CommonObject.session_expired:
#             Browser.page.close()
#             Browser.context.close()
#             Browser.browser.close()
#             Browser.playwright.stop()
#             driver = Browser.initialize(CommonObject.config["ApplicationURL"])
#             Browser.page.wait_for_load_state('domcontentloaded')
#         else:
#             Browser.page.close()
#             Browser.context.close()
#             Browser.browser.close()
#             Browser.playwright.stop()
#             driver = Browser.initialize(CommonObject.config["ApplicationURL"])
#             Browser.page.wait_for_load_state('domcontentloaded')
#         print("Successfully Relaunched")
#     except Exception as errormessage:
#         print(errormessage)
#         print("Getting exception in relaunch so second time relaunching")
#         try:
#             if CommonObject.pagetimeout or CommonObject.session_expired:
#                 Browser.page.close()
#                 Browser.context.close()
#                 Browser.browser.close()
#                 Browser.playwright.stop()
#                 driver = Browser.initialize(CommonObject.config["ApplicationURL"])
#                 Browser.page.wait_for_load_state('domcontentloaded')
#             else:
#                 Browser.page.close()
#                 Browser.context.close()
#                 Browser.browser.close()
#                 Browser.playwright.stop()
#                 driver = Browser.initialize(CommonObject.config["ApplicationURL"])
#                 Browser.page.wait_for_load_state('domcontentloaded')
#             print("Successfully Relaunched")
#         except Exception as errormessage:
#             print("Getting exception in relaunch so third time relaunching")
#             try:
#                 if CommonObject.pagetimeout or CommonObject.session_expired:
#                     Browser.page.close()
#                     Browser.context.close()
#                     Browser.browser.close()
#                     Browser.playwright.stop()
#                     driver = Browser.initialize(CommonObject.config["ApplicationURL"])
#                     Browser.page.wait_for_load_state('domcontentloaded')
#                 else:
#                     Browser.page.close()
#                     Browser.context.close()
#                     Browser.browser.close()
#                     Browser.playwright.stop()
#                     driver = Browser.initialize(CommonObject.config["ApplicationURL"])
#                     Browser.page.wait_for_load_state('domcontentloaded')
#                 print("Successfully Relaunched")
#             except Exception as errormessage:
#                 print("Getting exception in relaunch so Fourth time relaunching")
#                 try:
#                     if CommonObject.pagetimeout or CommonObject.session_expired:
#                         Browser.page.close()
#                         Browser.context.close()
#                         Browser.browser.close()
#                         Browser.playwright.stop()
#                         driver = Browser.initialize(CommonObject.config["ApplicationURL"])
#                         Browser.page.wait_for_load_state('domcontentloaded')
#                     else:
#                         Browser.page.close()
#                         Browser.context.close()
#                         Browser.browser.close()
#                         Browser.playwright.stop()
#                         driver = Browser.initialize(CommonObject.config["ApplicationURL"])
#                         Browser.page.wait_for_load_state('domcontentloaded')
#                     print("Successfully Relaunched")
#                 except Exception as errormessage:
#                     #print(errormessage)
#                     print("Getting exception in relaunch so Fifth time relaunching")
#                     try:
#                         if CommonObject.pagetimeout or CommonObject.session_expired:
#                             Browser.page.close()
#                             Browser.context.close()
#                             Browser.browser.close()
#                             Browser.playwright.stop()
#                             driver = Browser.initialize(CommonObject.config["ApplicationURL"])
#                             Browser.page.wait_for_load_state('domcontentloaded')
#                         else:
#                             Browser.page.close()
#                             Browser.context.close()
#                             Browser.browser.close()
#                             Browser.playwright.stop()
#                             driver = Browser.initialize(CommonObject.config["ApplicationURL"])
#                             Browser.page.wait_for_load_state('domcontentloaded')
#                         print("Successfully Relaunched")
#                     except Exception as errormessage:
#                         print(errormessage)
#
#
