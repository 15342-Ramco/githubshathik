import os
import re
import xml.etree.ElementTree as ET


def delete_parent_div(xml_file, parent_tag, desired_words):
    tree = ET.parse(xml_file)
    root = tree.getroot()

    # Find the parent div tags
    parent_divs = root.findall(".//{}".format(parent_tag))

    # Check each parent div tag's id attribute
    for parent_div in parent_divs:
        div_id = parent_div.get('id')

        # Check if the 'id' attribute exists and if the desired words are present in it
        if div_id is not None and any(word in div_id for word in desired_words):
            parent_div.clear()

            # Save the modified XML
    tree.write(xml_file + "mlgrid_deleted.xml")



def check_id_contains_gridview(attributes):
    #id_value = attributes.get('id')
    if 'gridview' in attributes:
        return True
    return False


def create_directory_only(parent_dir,directory):
    if not os.path.exists(parent_dir+"\\"+directory):
        os.mkdir(parent_dir+"\\"+directory)



def create_directory(parent_dir, directory):
    if not os.path.exists(parent_dir):
        os.mkdir(parent_dir)
    # Path
    path = os.path.join(parent_dir, directory)

    # Create the directory
    if not os.path.exists(path):
        os.mkdir(path)
    return path


def compare_values(value1, value2, key):
    if key != "style" :
        value1 = re.sub(r'\d', '', value1)
        value2 = re.sub(r'\d', '', value2)
    return value1 == value2


def attribute_differences(dict1,dict2):
    # Function to compare values excluding numerical characters for 'id' key

    # Find keys with different values
    keys_with_different_values = [
        key
        for key in dict1.keys() & dict2.keys()
        if not compare_values(dict1[key].strip(), dict2[key].strip(), key)
    ]

    # Get the dictionary differences
    differences = {
        key: (dict1[key].strip(), dict2[key].strip())
        for key in keys_with_different_values
    }

    if len(differences)!=0:
        return True,differences
    else:
        return False,""

def extract_numeric_part(string):
    numeric_part = re.findall(r'\d+', string)
    return int(numeric_part[0]) if numeric_part else string


def execution_time(seconds):
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return hours, minutes, seconds


def get_element_coordinates(element):
    bounding_box = element.bounding_box()
    x = bounding_box['x']
    y = bounding_box['y']
    return x, y

class pObject:
    properties=None