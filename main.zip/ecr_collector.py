import json
from urllib.parse import urlparse, parse_qs
from config.commonobj import CommonObject



def handle_response(response):
        parsed_url = urlparse(response.url)
        query_params = parse_qs(parsed_url.query)
        
         # Check if the response has been received (status code 2xx indicates success)
        if response.status >= 200 and response.status < 300:
            # print(f'Response received')
            # Add your response handling logic here
            CommonObject.API_Status='Response received'
        else:
            CommonObject.API_Status='Response not received'
            # print(f'Error receiving response for {response.url}, status code: {response.status}')
        try:
            if "/dispatcher.aspx" in str(parsed_url):
                RVWRTQS_COMPONENT = query_params.get('RVWRTQS_COMPONENT')[0]
                RVWRTQS_ACTIVITY = query_params.get('RVWRTQS_ACTIVITY')[0]
                RVWRTQS_ILBO = query_params.get('RVWRTQS_ILBO')[0]
                RVWRTQS_EVENTNAME = query_params.get('RVWRTQS_EVENTNAME')[0]
                RVWRTQS_REQID = query_params.get('RVWRTQS_REQID')[0]
                # Split the content into lines
                lines = str(response.text()).split('\n')
                # Filter lines containing 'rid='
                filtered_lines = [line for line in lines if 'rid=' in line]
                # Join the filtered lines back into a string
                CommonObject.RID_value = '\n'.join(filtered_lines)
                if CommonObject.Event_turn_count == 0:
                    CommonObject.RVWRTQS_COMPONENT_PARENT_1 = RVWRTQS_COMPONENT
                    CommonObject.RVWRTQS_ACTIVITY_PARENT_1 = RVWRTQS_ACTIVITY
                    CommonObject.RVWRTQS_ILBO_PARENT_1 = RVWRTQS_ILBO
                    CommonObject.RVWRTQS_EVENTNAME_PARENT_1 = RVWRTQS_EVENTNAME
                    CommonObject.RVWRTQS_REQID_PARENT_1=RVWRTQS_REQID
                    CommonObject.Event_turn_count = CommonObject.Event_turn_count + 1
                else:
                    CommonObject.RVWRTQS_COMPONENT_CHILD_1 = RVWRTQS_COMPONENT
                    CommonObject.RVWRTQS_ACTIVITY_CHILD_1 = RVWRTQS_ACTIVITY
                    CommonObject.RVWRTQS_ILBO_CHILD_1 = RVWRTQS_ILBO
                    CommonObject.RVWRTQS_REQID_CHILD_1=RVWRTQS_REQID
                    CommonObject.RVWRTQS_EVENTNAME_CHILD_1 = RVWRTQS_EVENTNAME
            if "/GetPageDetails.ashx" in str(response.url) or "/GetPageDetails.aspx" in str(response.url):
                resp=json.loads(response.text())
                if 'version' in resp.keys():
                    PAGE_VERSION=resp.get("version")
                    CommonObject.ECR_VERSION = PAGE_VERSION
            if "/plfdispatcherpers.aspx" in str(response.url):
                CommonObject.plfdispatchid=response.text()
            resp=json.loads(response.text())
            # if 'rid' in resp:
            #     CommonObject.RID_value = resp['rid']
            #     print(f"The value associated with 'rid' is: { CommonObject._value}")
            if 'data' in resp.keys() and 'totalCount' not in resp.keys():
                #timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
                #{timestamp}
                file_name = f"API-Responses\\APIresponse.json"
                with open(file_name, "w") as f:
                    json.dump(resp, f, indent=4)


        except Exception as error:
            pass
            #print(str(error))

