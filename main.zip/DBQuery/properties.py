from screenlaunch.utils import read_file


def getProperty(basepath):
    df = read_file(basepath, "")
    # Find the indices of empty rows
    # Find the row indices where NaN values are present
    empty_row_indices = df.index[df.isna().any(axis=1)]
    # Split DataFrame into chunks based on the empty rows
    chunks = []
    start_idx = 0
    for end_idx in empty_row_indices:
        chunk = df.iloc[start_idx:end_idx]
        # Convert the DataFrame columns to a dictionary
        result_dict = dict(zip(chunk['Key'], chunk['Values']))
        chunks.append(result_dict)
        start_idx = end_idx + 1

    # If there are any remaining rows after the last empty row, add them as the last chunk
    if start_idx < len(df):
        chunk = df.iloc[start_idx:]
        result_dict = dict(zip(chunk['Key'],chunk['Values']))
        chunks.append(result_dict)
    return chunks


def getconnection(basepath, key):
    df = read_file(basepath, "")
    dict = {}
    for i in range(len(df)):
        dict[df.loc[i]["DBCONNECTION"]] = df.loc[i]["VALUES"]
    config = dict
    print(config[key])
    return config[key]
