import pyodbc
import pandas as pd
import os
from DBQuery.properties import getProperty
from DBQuery.properties import getconnection
from config.commonobj import CommonObject


def execute_db_query():
    global mydb
    try:
        Navfile = CommonObject.project_path+"\\Files\\NavigationConfig.csv"
        ## If file exists, delete it ##
        if os.path.exists(Navfile):
            os.remove(Navfile)
            print("Removed the already existing Navigation file")
        basepath = CommonObject.project_path + "\\Files\\DBQuery\\DBMaster.csv"
        DBpath=CommonObject.project_path + "Files\\DBQuery\\DBProperties.csv"
        savepath = CommonObject.project_path + "\\Files"
        list_of_queries=getProperty(DBpath)
        Navigation = pd.DataFrame()
        for dic in list_of_queries:
            df = pd.DataFrame()
            Driver = getconnection(basepath, "DRIVER")
            Server = getconnection(basepath, "SERVER")
            Username = getconnection(basepath, "USERNAME")
            Password = getconnection(basepath, "PASSWORD")
            Database = getconnection(basepath, "DATABASE")
            #Connecting the Database
            con = f"Driver={Driver};Server={Server};UID={Username};PWD={Password};Database={Database};"
            mydb = pyodbc.connect(con)
            # Databaseconnection = f'mssql://{Username}:{Password}@{Server}/{Database}?driver={Driver}'
            # engine = create_engine(Databaseconnection)
            # connection=engine.connect()
            # mydb = pyodbc.connect('Driver=SQL Server;'
            #                   'Server=172.27.5.153;'
            #                   'UID=readuser;'
            #                   'PWD=readuser;'
            #                   'Database=AVNAPPDB;')

            mycursor = mydb.cursor()
            mycursor.execute(dic["query"])
            while mycursor.nextset():
                try:
                    results = mycursor.fetchall()
                    df = pd.DataFrame.from_records(results)
                    break
                except pyodbc.ProgrammingError:
                    continue
            mydb.commit()
            mycursor.close()
            #Hard code for fetching datas to required format
            df.index = df.index + 1
            df["Sno"] = df.index
            mapping = {df.columns[2]: 'Process Name', df.columns[3]: 'Component Name', df.columns[8]: 'Activity Name'}
            df = df.rename(columns=mapping)
            df["Login"] = ""
            df["SwitchContext"] = ""
            df["NavigationConfigID"] = df.index
            df["Page Reference Name"] = dic["pageref"]
            df.at[1,'Login'] = dic["loginref"]
            #Rearranging the columns
            df = df[
                ["Sno", "Login", "SwitchContext", "NavigationConfigID", "Process Name", "Component Name", "Activity Name",
                 "Page Reference Name"]]
            #Navigation ID assigning
            df['NavigationConfigID'] = df['NavigationConfigID'].apply(lambda x: "{}{}".format('NAV_ID_', x))
            CommonObject.filetype = "CSV"
            Navigation=pd.concat([Navigation, df], axis=0, ignore_index=True)
        # save to excel/csv
        # df.to_excel(basepath + "\\NavigationConfig.xlsx")
        # Replace 'Column1' values with index + 1
        Navigation['Sno'] = Navigation.index + 1
        Navigation.to_csv(savepath + "\\NavigationConfig.csv",index= False)
        print("DB navigation file generation Over")
    except Exception as error:
        print("Failed to read data from table", error)
    finally:
        if mydb:
            mydb.close()
            print("The Sql Server connection is closed")
