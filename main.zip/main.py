import os
from datetime import datetime
from multiprocessing import freeze_support
from config.baseconfig import screenlaunch_config
from config.commonobj import CommonObject
from config.navigationconfig import process_navigation_config,Killrunningbrowsers
from screenlaunch.SSH_Remote import SSH_remote
from screenlaunch.browser import Browser
from screenlaunch.parallel import read_config_file, start_server, get_server_details,delete_environment
from screenlaunch.parallel_main import parallel_main
from screenlaunch.utils import read_file, create_directory,Create_folder,remove_folder
from screenlaunch.webutils import pageload
import sys
import time

CommonObject.executable_name = sys.argv[0]
print(f"The name of the executable is: {CommonObject.executable_name}")
CommonObject.project_path = os.getcwd() + "/"
timestamp = datetime.now().strftime("%d-%m-%Y %H-%M-%S").replace(":", "_")
CommonObject.config["ParallelExecution"] = ""
screenlaunch_config_file = CommonObject.project_path + 'Files/ScreenLaunchConfig.csv'
df = read_file(screenlaunch_config_file, "")
testconfigid = df.loc[0]["TEST_CONFIG_VALUE"]
screenlaunch_config(screenlaunch_config_file, testconfigid)

def main():
    
    timestamp = datetime.now().strftime("%d-%m-%Y %H-%M-%S").replace(":", "_")
    Create_folder(CommonObject.project_path +'API-Responses')
    Create_folder(CommonObject.project_path +'Console_log')
    CommonObject.consolefilename='ScreenLaunch_console'+ timestamp+'.txt'
    # Create_folder(CommonObject.project_path +'videos//ScreenLaunchVideo'+ timestamp)
    freeze_support()
    logfoldername = 'ScreenLaunchAdvancedLog ' + timestamp + '_web_sltest'
    CommonObject.Videoname='ScreenLaunchVideo'+ timestamp +"/"
    logfolder = create_directory(CommonObject.project_path +'Output', logfoldername)

    if CommonObject.config["ParallelExecution"] == "ON":
        config_file_data = read_config_file("config.properties")
        if config_file_data['Grid_mode'] == "Remote":
            project_path = os.getcwd() + "/"
            SSH_remote(project_path)
        elif config_file_data['Grid_mode'] == "Local":
            print("[NOTE]: In Local Grid Mode Run instances of Chrome Browser")
            parallel_main(logfolder, logfoldername)
        elif config_file_data['Grid_mode'] == "Localhost":
            path = os.getcwd() + "/"
            # start_hub(path)
            start_server(path)
            hub_det = get_server_details()
            if hub_det["status"] == False:
                print("[INFO]:hub is not ready,Exception occured", hub_det['exception'])
            elif hub_det["status"] == True:
                slotCounts = hub_det["Connected_nodes"]
                Avail_insta = len(hub_det["Avail_node_list"]) - len(hub_det["occupied_node"])
                total_insta = len(hub_det["Avail_node_list"])
                host = hub_det["URL_Hub"]
                print("[INFO]:Your host set : ", host)
                print("[INFO]:Total instances : ", total_insta)
                print("[INFO]:Available instances : ", Avail_insta)
                if int(Avail_insta) > 0:
                    parallel_main(logfolder, logfoldername)
                    print("Parallel Execution Done")
                    delete_environment()
                else:
                    print("[INFO]:there is no node is available for Grid testing")
        else:
            print("Please Ensure the Grid Mode on Config.properties")
    else:
        user_dir = 'tmp/playwright'
        CommonObject.user_dir = os.path.join(os.getcwd(), user_dir)
        remove_folder(CommonObject.user_dir)
        screenlaunch_config(screenlaunch_config_file, testconfigid)
        driver = Browser.initialize(CommonObject.config["ApplicationURL"])
        pageload()
        CommonObject.advanced_log_df = read_file(
            CommonObject.project_path + 'Templates/ScreenLaunchAdvancedDebugLog.csv', "")
        process_navigation_config("NavigationConfig", 0, logfolder, logfoldername)
        #Browser.page.close()
        #Browser.page.video.save_as(path=CommonObject.project_path +"videos\\"+Videoname)
        if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
            Killrunningbrowsers()
            time.sleep(0.1)
            try:
                remove_folder(CommonObject.user_dir)
            except Exception as remove_error:
                Killrunningbrowsers()
                time.sleep(1)
                try:
                    remove_folder(CommonObject.user_dir)
                except Exception as remove_error:
                    print("RemoveError:"+str(remove_error))
        else:
            Browser.page.close()
            Browser.context.close()
            Browser.browser.close()

if __name__ == "__main__":
    main()
    
   