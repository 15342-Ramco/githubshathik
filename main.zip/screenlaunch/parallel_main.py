import multiprocessing
import os
import time
from config.commonobj import CommonObject
from config.navigationconfig import process_navigation_config,Killrunningbrowsers
from screenlaunch.browser import Browser,find_browser_process_id
from screenlaunch.parallel import read_config_file, xlsx_file_splitter
from screenlaunch.utils import read_file
from screenlaunch.webutils import pageload
from DBQuery.dbservice import execute_db_query
from screenlaunch.utils import remove_folder
import json
import sys

# def find_browser_process(browser_name):
#     browser_names = [browser_name]  # Add more browser names if needed
#     for proc in psutil.process_iter(attrs=['pid', 'ppid', 'name']):
#         if proc.info['name'] in browser_names:
#             return proc

#     return None

def worker(arg, processID, logfolder, logfoldername, q):
    dic_value = {'session_id': [], 'process_id': []}
    start_time = time.perf_counter()
    CommonObject.process_id1 = (processID)
    CommonObject.executable_name = sys.argv[0]
    print(f"The name of the executable is: {CommonObject.executable_name}")
    user_dir = 'tmp\\playwright'+"_" + str(processID)
    CommonObject.user_dir = os.path.join(os.getcwd(), user_dir)
    remove_folder(CommonObject.user_dir)
    driver = Browser.initialize(CommonObject.config["ApplicationURL"])
    pageload()
    CommonObject.advanced_log_df = read_file(CommonObject.project_path + 'Templates\\ScreenLaunchAdvancedDebugLog.csv',"")
    process_navigation_config(arg, processID, logfolder, logfoldername)
    end_time = time.perf_counter()
    print("[INFO]:Process " + str(processID) + " closed")
    print("[INFO]:Time consumed by process " + str(processID) + ": " + str(round(end_time - start_time)) + " seconds")

    if os.path.exists(CommonObject.project_path + "Files\\" + str(arg) + CommonObject.fileformat):
        os.remove(CommonObject.project_path + "Files\\" + str(arg) + CommonObject.fileformat)
    else:
        print("The file does not exist")
    
    if str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() =="msedge-persistent-context":
        try:
            Killrunningbrowsers()
            time.sleep(0.1)
            remove_folder(CommonObject.user_dir)
        except Exception as remove_error:
            Killrunningbrowsers()
            time.sleep(1)
            try:
                remove_folder(CommonObject.user_dir)
            except Exception as remove_error:
                print("RemoveError:"+str(remove_error))
    else:
        Browser.page.close()
        Browser.context.close()
        Browser.browser.close()

def compare_dicts(dict1, dict2):
    keys_list1 = list(dict1.keys())
    # Access key at index 1
    key1 = keys_list1[0]
    keys_list2 = list(dict2.keys())
    # Access key at index 1
    key2 = keys_list2[0]
    values_dict1 = set(dict1[key1])
    values_dict2 = set(dict2[key2])

    result_dict1 = list(values_dict1 - values_dict2)
    result_dict2 = list(values_dict2 - values_dict1)

    return result_dict1, result_dict2

def parallel_main(logfolder, logfoldername):
    #freeze_support()
    agent_avail = 3  # default
    agent_run = 0
    config_file_data = read_config_file("config.properties")
    print("[INFO]:Agent available: " + str(agent_avail))
    agent_con = 0
    print("[INFO]:Agent Needed: " + str(len(config_file_data["Agents"])))
    manager = multiprocessing.Manager()
    q = manager.Queue()
    # print("q:",dict(q))
    # print("manager is:", dict(manager))
    pool = multiprocessing.Pool(multiprocessing.cpu_count() + 2)
    jobs = []
    if agent_avail >= len(config_file_data["Agents"]):
        input_file = config_file_data['Filename'] + CommonObject.fileformat
        if CommonObject.config["FileType"] == "DBQuery":
            execute_db_query()
        else:
            pass
        xlsx_work_check = xlsx_file_splitter(input_file, config_file_data["Agents"])
    if str(CommonObject.config["Browser"]).lower() == "edge":
        CommonObject.browsertype="msedge.exe"
    elif str(CommonObject.config["Browser"]).lower()=="chrome":
        CommonObject.browsertype="chrome.exe"
    elif str(CommonObject.config["Browser"]).lower() == "chrome-persistent-context":
        CommonObject.browsertype = "chrome.exe"
    elif str(CommonObject.config["Browser"]).lower() == "msedge-persistent-context":
        CommonObject.browsertype = "msedge.exe"
    for i in range(len(config_file_data['Agents'])):
        job = pool.apply_async(worker, ("NavigationConfig_" + str(i), i, logfolder, logfoldername, q))
        jobs.append(job)
        time.sleep(5)
        if str(CommonObject.config["Browser"]).lower()=="chrome-persistent-context" or  str(CommonObject.config["Browser"]).lower()== "msedge-persistent-context":
            if i==0:
                process_1=find_browser_process_id()
                # Loop until the dictionary is not empty
                while not process_1:
                    print("The dictionary is empty. Trying to find the browser process ID...")
                    process_1=find_browser_process_id()
                # Serialize dictionary to JSON and write to a file
                with open(f'data{i}.json', 'w') as json_file:
                    json.dump(process_1, json_file)
            elif i==1:
                process_2=find_browser_process_id()
                while not process_2:
                    print("The dictionary is empty. Trying to find the browser process ID...")
                    process_2=find_browser_process_id()
                keys_process_1=set(process_1.keys())
                keys_process_2 =set(process_2.keys())
                # Get the different keys
                different_keys1 = list(keys_process_1.symmetric_difference(keys_process_2))
                for key,value in process_2.items():
                    if str(key)==str(different_keys1[0]):
                        second={key:value}
                # Serialize dictionary to JSON and write to a file
                with open(f'data{i}.json', 'w') as json_file:
                    json.dump(second, json_file)

            elif i==2:
                process_3=find_browser_process_id()
                while not process_3:
                    print("The dictionary is empty. Trying to find the browser process ID...")
                    process_3=find_browser_process_id()
                keys_process_3 = set(process_3.keys())
                different_keys2 = list(keys_process_2.symmetric_difference(keys_process_3))
                for key,value in process_3.items():
                    if key==different_keys2[0]:
                        Third={key:value}
                # Serialize dictionary to JSON and write to a file
                with open(f'data{i}.json', 'w') as json_file:
                    json.dump(Third, json_file)
    
        


        
        #CommonObject.Browserpid = find_browser_process(CommonObject.browsertype)
        #print(CommonObject.Browserpid)
    # collect results from the workers through the pool result queue
    # if agent_avail >= len(config_file_data["Agents"]):
    #     input_file = config_file_data['Filename'] + CommonObject.fileformat
    #     if CommonObject.config["FileType"] == "DBQuery":
    #         execute_db_query()
    #     else:
    #         pass
    #     xlsx_work_check = xlsx_file_splitter(input_file, config_file_data["Agents"])
    if xlsx_work_check:
        for job in jobs:
            if agent_avail != 0:
                agent_avail -= 1
                agent_con += 1
                agent_run += 1
                print("[INFO]:Agent " + str(agent_run) + " Started")
        job.get()

    # now we are done, kill the listener
    # q.put("kill")
    pool.close()
    pool.join()
