from datetime import datetime
from config.commonobj import CommonObject
from logandreport.logger import advanced_debug_report
from screenlaunch.pageaction import page_action
from screenlaunch.pageobjectwrapper import findlocator
from screenlaunch.utils import read_file
from screenlaunch.webutils import screenlaunchpopup,screenshot, pleasewait


def execute_screenlaunch(file, sheet):
    df = read_file(file, sheet)
    # print(df)
    for i in range(len(df)):
        CommonObject.element = df.loc[i]["ELEMENT_NAME"]
        CommonObject.action = df.loc[i]["ACTION"]
        CommonObject.element_value = df.loc[i]["ELEMENT_VALUE"]
        if str(CommonObject.element_value).find(":")!=-1:
            excelInput = CommonObject.element_value.split(":")
            CommonObject.element_value = excelInput[0]
            CommonObject.framename = excelInput[1] if len(excelInput) >= 2 else ""
        CommonObject.data_value = df.loc[i]["DATA_VALUE"]
        #print(CommonObject.action)
        try:
            pleasewait()
            page_action(CommonObject.action, findlocator(), CommonObject.data_value)
            #print("Page Action:"+str(CommonObject.action))
            pleasewait()
            screenlaunchpopup()
            if CommonObject.action != "Assert Object":
                pleasewait()
            CommonObject.status = "PASS"
            print("Element found")
            advanced_debug_report(CommonObject.logfolder + '/ScreenLaunchAdvancedDebugLog' + str(CommonObject.process_id) + '.csv')

        except Exception as error:
            print("Error ScreenLaunch Test")
            print(error)
            print("Element not found")
            CommonObject.status = "FAIL"
            CommonObject.errormessage = error
            timestamp = str(datetime.now()).replace(":", "_")
            if CommonObject.screenshotflag == False:
                screenshot(CommonObject.logfolder + '/screenshot_' + timestamp + str(CommonObject.process_id) + '.png')
            print("After Screenshot")
            advanced_debug_report(CommonObject.logfolder + '/ScreenLaunchAdvancedDebugLog' + str(CommonObject.process_id) + '.csv')

                
            #     try:
            #         menu = "//*[@class='icon-wrap icon-s icon-left']"
            #         element = Browser.page.locator(menu)
            #         if element.count() == 0:
            #             raise Exception
            #     except Exception as err:
            #         raise Exception
            


