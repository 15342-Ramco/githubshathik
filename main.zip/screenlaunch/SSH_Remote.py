import glob
import os
import shutil
import sys
import time
import zipfile
import paramiko
import requests
import pandas as pd
from scp import SCPClient
from configobj import ConfigObj
from config.commonobj import CommonObject
from config.navigationfilter import filterby_login_id
from screenlaunch.parallel import read_config_file

def SSH_remote(project_path):
    print("Starting Remote Execution....")
    global exe_output, scp, ssh
    Project_path = project_path
    config_file_data = read_config_file("config.properties")

    if len(sys.argv) > 1:
        Customer = sys.argv[1]
        Customer_url = sys.argv[2]
        Customer_browser = sys.argv[3]
        config_df = pd.read_csv(project_path+"Files\\ScreenLaunchConfig.csv")
        config_browser=config_df.loc[1, "TEST_CONFIG_VALUE"]
        config_url=config_df.loc[2, "TEST_CONFIG_VALUE"]
        # updating the column value/data
        config_df.loc[1, "TEST_CONFIG_VALUE"] = Customer_url
        config_df.loc[2, "TEST_CONFIG_VALUE"] = Customer_browser
        # writing into the file
        config_df.to_csv(project_path+"Files\\ScreenLaunchConfig.csv", index=False)
        print("Updated Files...")
    else:
        Customer = "Default"

    def totallen():
        if CommonObject.fileformat == ".xlsx":
            df2 = pd.read_excel(CommonObject.project_path + "Files\\" + "NavigationConfig.xlsx",sheet_name=CommonObject.navigationsheet)
        else:
            df2 = pd.read_csv(CommonObject.project_path + "Files\\" + "NavigationConfig.csv")

        if CommonObject.config["Process"] == "All" and CommonObject.config["Component"] == "All" and \
                CommonObject.config[
                    "Activity"] == "All":
            df = df2
            CommonObject.filter = False
            CommonObject.filter_applied = "No"

        elif str(CommonObject.config["Process"]) == "nan" and str(CommonObject.config["Component"]) == "nan" and str(
                CommonObject.config["Activity"]) == "nan":
            df = df2
            CommonObject.filter = False
            CommonObject.filter_applied = "No"
        else:
            CommonObject.filter = True
            CommonObject.filter_applied = "Yes"
            df = filterby_login_id(df2)
        return str(len(df))

    def change_settings():
        config = ConfigObj("config.properties")
        if config['Grid_mode'] == "Local":
            config['Grid_mode'] = "Remote"
            config.write()
        if os.path.isdir(Project_path + "Output"):
            pass
        else:
            os.mkdir('Output')

    try:
        config = ConfigObj("config.properties")
        if config['Grid_mode'] == "Remote":
            config['Grid_mode'] = "Local"
            config.write()
        if CommonObject.fileformat == ".xlsx":
            df=pd.read_excel(Project_path+"Files/ScreenLaunch_Remote_Credentials.xlsx")
        else:
            df = pd.read_csv(Project_path+"Files/ScreenLaunch_Remote_Credentials.csv")

        for i in range(len(df)):
            if df.loc[i]["REMOTE_CREDENTIALS"] == "REMOTE_ID":
                if df.loc[i].iloc[1] == Customer:
                    j = 0
                    while j < 1:
                        hostname = df.loc[i+2].iloc[1]
                        username = df.loc[i+2].iloc[2]
                        password = df.loc[i+2].iloc[3]
                        Remote_drive = df.loc[i+2].iloc[4]
                        i = i + 1
                        j = j + 1
                    break

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname = hostname , username = str(username),password = str(password))
        scp=SCPClient(ssh.get_transport())
        
        def progress4(filename, size, sent, peername):
            sys.stdout.write("(%s:%s) %s's  progress : %.2f%%   \r" % (peername[0], peername[1], filename, float(sent)/float(size)*100) )
        scp = SCPClient(ssh.get_transport(), progress4 = progress4)
        
        def zip_directory(folder_path, zip_path):
            with zipfile.ZipFile(zip_path, mode= 'w') as zipf:
                len_dir_path = len(folder_path)
                for root, _, files in os.walk(folder_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        zipf.write(file_path, file_path[len_dir_path:])
                        
        def newest(path_var):
            files = os.listdir(path_var)
            paths = [os.path.join(path_var, basename) for basename in files]
            return max(paths, key= os.path.getctime)
        
        def delete_localfiles():
            time.sleep(1)
            if os.path.exists(Project_path + "Files.zip"):
                os.remove(Project_path + "Files.zip")
            if os.path.exists(Project_path + "Output.zip"):
                os.remove(Project_path + "Output.zip")
            if os.path.isdir(Project_path + "Output"):
                shutil.rmtree(Project_path + "Output", ignore_errors=True)

        var = "RMDIR " + Remote_drive + ":Grid_Executor /s /q"
        stdin, stdout, stderr = ssh.exec_command(var)
        var = "DEL " + Remote_drive + ":Files.zip /s /q"
        stdin, stdout, stderr = ssh.exec_command(var)
        var = "DEL " + Remote_drive + ":Output.zip /s /q"
        stdin, stdout, stderr = ssh.exec_command(var)
        time.sleep(1)
        delete_localfiles()
        zip_directory(Project_path, Project_path+"Files.zip")
        print("File Compressed")

        try:
            scp.put(Project_path+"Files.zip",Remote_drive+":/")# transfer file to remote device
            print("File transferred to Remote Device ")
            os.remove(Project_path+"Files.zip")
            time.sleep(1)
        except Exception as e:
            change_settings()
            print(e.args)

        stdin, stdout, stderr = ssh.exec_command("PowerShell Expand-Archive -Path " + Remote_drive + "':\Files.zip' -DestinationPath " + Remote_drive + "':\Grid_Executor'")
        time.sleep(10)
        print("File Successfully unzipped in Remote Device",stdout.read().decode())

        try:
            var = Remote_drive+": && cd "+Remote_drive+":Grid_Executor &&  mkdir Output"
            time.sleep(2)
            stdin, stdout, stderr=ssh.exec_command(var)
            print(stdout.read().decode())
            var = Remote_drive+": && cd "+Remote_drive+":\Grid_Executor &&  Screenlaunch.exe"
            #var = "E: && cd E:Grid_Executor && cd Final_Exe && hi.bat"
            print("Screenlaunch Test Started...")
            stdin, stdout, stderr=ssh.exec_command(var)
            exe_output = stdout.read().decode()
            print(exe_output)
        except Exception as e:
            print(e.args)
            change_settings()

        stdin, stdout, stderr=ssh.exec_command('PowerShell Compress-Archive -Path '+Remote_drive+':\Grid_Executor\Output -DestinationPath '+Remote_drive+':\Output.zip')
        sys.stdout.write("(%s)'s progress:  \r" % (stdout.read().decode()))
        time.sleep(1)
        delete_localfiles()
        scp.get(Remote_drive+":/Output.zip")
        print("get output from Remote ")

        if os.path.exists("Output.zip"):
            shutil.move("Output.zip", Project_path+"Output.zip")
            path=Project_path+'Output'
            if os.path.isdir(path):
                    shutil.rmtree(path,ignore_errors=True)
            shutil.unpack_archive(Project_path+'Output.zip', Project_path, 'zip')
            time.sleep(2)
            path_var=Project_path+"Output"
            path =newest(path_var)
            csv_files = glob.glob(os.path.join(path, "*.csv"))
            df1=pd.DataFrame()
            for f in csv_files:
                df = pd.read_csv(f)
                df1=pd.concat([df1, df], axis=0, ignore_index=True)

            Count=dict(df1['TEST_STATUS'].value_counts())
            if "PASS" in Count.keys():
                Pass_count = Count["PASS"]
            else:
                Pass_count=0
            if "FAIL" in Count.keys():
                Fail_count=Count["FAIL"]
            else:
                Fail_count=0
            print("Total length of activity:",totallen())
            print("Total Pass Counts : ",Pass_count)
            print("Total Fail Counts : ",Fail_count)

            data = {"Total_Count=":str(totallen()), "Pass Count": Pass_count, "Fail Count": Fail_count}

            get_result = requests.get(
                config_file_data["url"]+"/product/installer_status?result=Success&url="+Project_path+"Output.zip"+"&data_details="+str(data))
            print(get_result.text)
        else:
            print("Problem On getting output from Remote device")
            print("Cleared Remote Folder")
            var = "RMDIR " + Remote_drive + ":Grid_Executor /s /q"
            stdin, stdout, stderr = ssh.exec_command(var)
            var = "DEL " + Remote_drive + ":Files.zip /s /q"
            stdin, stdout, stderr = ssh.exec_command(var)
            var = "DEL " + Remote_drive + ":Output.zip /s /q"
            stdin, stdout, stderr = ssh.exec_command(var)
            get_result = requests.get(
                config_file_data["url"] + "/product/installer_status?result=Failure&message=Problem On getting output from Remote device. Error Msg : " + str(exe_output))
            print(get_result.text)
            time.sleep(1)
        change_settings()

    except Exception as e:
        change_settings()
        get_result = requests.get(
            config_file_data["url"] + "/product/installer_status?result=Failure&message=Error Msg : " + str(e))
        print(get_result.text)
        print(e.args)
    config_df = pd.read_csv(project_path+"Files\\ScreenLaunchConfig.csv")
    # updating the column value/data
    config_df.loc[1, "TEST_CONFIG_VALUE"] = config_url
    config_df.loc[2, "TEST_CONFIG_VALUE"] = config_browser
    # writing into the file
    config_df.to_csv(project_path+"Files\\ScreenLaunchConfig.csv", index=False)
    print("Remote Connection closed")
    scp.close()
    ssh.close()