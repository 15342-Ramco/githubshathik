from Web_Page_Assertion.mlgrid import WebpageAssertion
from config.commonobj import CommonObject
from screenlaunch.browser import Browser
from screenlaunch.webutils import find_element, takesnapshot, screenshot, screenlaunchpopup
from logandreport.logger import advanced_debug_report

import glob
import os
import shutil
from io import StringIO
from pdfminer.pdftypes import resolve1
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfparser import PDFParser
from pathlib import Path
import time
from datetime import datetime
from screenlaunch.webutils import pleasewait


def page_action(action, loc, data, assertEqual=None):
    match action:
        case "Enter Text":
            element = find_element(loc, None)
            element.click()
            element.fill(str(data))
        case "Click Button":
            element = find_element(loc, None)
            element.first.click()
            time.sleep(0.5)
            pleasewait()
            screenlaunchpopup()
            # time.sleep(5)
        case "Assert Object":
            find_element(loc, None)
        case "Password Text":
            element = find_element(loc, None)
            element.click()
            if CommonObject.config["App Type"] == "ePubs":
                element.fill(str(data))
            elif CommonObject.config["App Type"] == "Nebula co-existence":
                element.fill(str(data))
            elif CommonObject.startsWithid.find("ramcopassword") != -1:
                element.type(str(data))
            else:
                element.fill(str(data))
            CommonObject.loginfirsttime = True
            # time.sleep(2)
        case "Enter Text Area":
            element = find_element(loc, None)
            element.click()
            element.type(data)
        case "Enter Number":
            element = find_element(loc, None)
            element.click()
            element.fill(data)
        case "Enter Time":
            element = find_element(loc, None)
            element.click()
            element.fill(data)
        case "Clear Text":
            element = find_element(loc, None)
            element.click()
            element.fill("")
        case "Select Combo":
            element = find_element(loc, None)
            element.click()
            time.sleep(0.25)
            if CommonObject.config["App Type"] == "Nebula co-existence":
                split_data = data.split(";")
                pickerlist_id = ((loc).split("trigger_picker"))[0] + "picker_listEl"
                selectValue = pickerlist_id + "']//ul//li//div//div[text()='" + split_data[0] + "']//..//*[text()='" + split_data[1] + "']"
                Browser.page.locator(selectValue).click()
            else:
                combo_value = "//*[starts-with(@id,'" + CommonObject.startsWithid + "')]//*[contains(@id, 'picker-listEl') and @aria-hidden='false']//li[text()='" +str(data) + "']"
                Browser.page.click(combo_value)
            time.sleep(0.25)
        case "Click Button Icon":
            time.sleep(0.25)
            pleasewait()
            screenlaunchpopup()
            element = find_element(loc, None)
            element.click()
            pleasewait()
            screenlaunchpopup()
            time.sleep(0.50)
        case "Click Link":
            element = find_element(loc, None)
            element.first.click()
            time.sleep(0.50)
            pleasewait()
            screenlaunchpopup()
        case "Click Help":
            element = find_element(loc, None)
            element.click()
            time.sleep(0.50)
            pleasewait()
            screenlaunchpopup()
        case "Enter Date":
            element = find_element(loc, None)
            element.click()
            element.fill(data)
        case "Click Toggle":
            element = find_element(loc, None)
            toggle = "//*[starts-with(@id,'" + CommonObject.startsWithid + "')]/div[@name='undefined_tool']"
            Browser.page.click(toggle)
            #element.click()
            pleasewait()
        case "Click Checkbox":
            element = find_element(loc, None)
            element.first.click()

        case "Click Radio Button":
            element = find_element(loc, None)
            element.click()
        case "Click Tab":
            element = find_element(loc, None)
            element.click()
            time.sleep(0.50)
            pleasewait()
            screenlaunchpopup()
        case "List Set Enter":
            element = find_element(loc, None)
            element.click()
            element.fill(data)
            time.sleep(5)
            Browser.page.keyboard.press("Enter")
            pleasewait()
            # Keyboard enter action need to add
        case "List Edit Enter":
            element = find_element(loc, None)
            element.click()
            element.type(data)
            time.sleep(5)
            Browser.page.keyboard.press("Enter")
            pleasewait()
            # Keyboard enter action need to add
        case "Smart Search":
            element = find_element(loc, None)
            element.click()
            element.fill("")
            data = data.split(";")
            search_value = data[0]
            data_value = data[1]
            search_value_length = len(search_value)
            i = 0
            while (i < search_value_length):
                if i == 0:
                    time.sleep(0.5)
                element.type(search_value[i], delay=100)
                #element.type(loc, search_value[i], delay=100)
                time.sleep(1)
                pleasewait()
                search_select = Browser.page.locator("//div[starts-with(@id,'"+CommonObject.startsWithid+"')]//*[contains(@id, 'picker-bodyWrap')]/div[@name='undefined_headercontainer' and @aria-hidden='false']/..//table//td/div[text()='"+data_value+"']").count()
                if search_select != 0:
                    search_select = "//div[starts-with(@id,'"+CommonObject.startsWithid+"')]//*[contains(@id, 'picker-bodyWrap')]/div[@name='undefined_headercontainer' and @aria-hidden='false']/..//table//td/div[text()='"+data_value+"']"
                    pleasewait()
                    Browser.page.click(search_select)
                    break
                i = i + 1
                if i == search_value_length:
                    CommonObject.errormessage = "Smart search result value not found"
            # Keyboard enter action need to add
        case "Grid Smart Search":
            element = find_element(loc, None)
            element.click()
            element.type("")
            data = data.split(";")
            search_value = data[0]
            data_value = data[1]
            search_value_length = len(search_value)
            i = 0
            while (i < search_value_length):
                element.type(search_value[i], delay=100)
                time.sleep(0.5)
                pleasewait()
                sxpath =Browser.page.locator("//div[@class='x-panel x-ltr x-boundlist x-avnsearchwindow x-layer x-panel-default x-grid x-border-box' and @aria-hidden='false']/..//table//td/div[text()='"+data_value+"']").count()
                #sxpath =Browser.page.locator("//*[@id='"+objectValue+"' and text()= '"+data_value+"']").count()
                if sxpath != 0:
                    sxpath = "//div[@class='x-panel x-ltr x-boundlist x-avnsearchwindow x-layer x-panel-default x-grid x-border-box' and @aria-hidden='false']/..//table//td/div[text()='"+data_value+"']"
                    Browser.page.click(sxpath)
                    break
                i = i + 1
                if i == search_value_length:
                    CommonObject.errormessage = "Smart search result value not found"
            # Keyboard enter action need to add
        case "Edit And Enter":
            element = find_element(loc, None)
            element.click()
            element.fill(data)
            Browser.page.keyboard.press("Enter")
        case "Grid Text":
            element = find_element(loc, None)
            element.click()
            element.fill(data)
        case "Grid Text Enter":
            element = find_element(loc, None)
            element.click()
            element.fill(data)
            Browser.page.keyboard.press("Enter")

        case "Display Block":
            element = find_element(loc, None)
            element.click()

        case "Close Dialog":
            loc = "//*[@role='dialog' and @aria-hidden='false']//*[@data-qtip='Close dialog'][starts-with(@id,'tool')]//*[contains(@id, 'toolEl')]"
            element = find_element(loc, None)
            element.click()

        case "Close Dialog2":
            # loc = "//*[@role='dialog' and @aria-hidden='false']//*[@data-qtip='Close dialog'][starts-with(@id,'tool')]//*[contains(@id, 'toolEl')]"
            Browser.page.keyboard.press("Escape")
           


        case "Click OK Button":
            element = find_element(loc, None)
            element.click()
            pleasewait()
            screenlaunchpopup()

        case "Click Show Help":
            element = find_element(loc, None)
            Temp_tab=Browser.page
            with Browser.page.context.expect_page() as tab_two:
                element.first.click()
            Browser.page=tab_two.value
            Browser.page.bring_to_front()
            try:
                #Browser.page.wait_for_selector("//a[@title='Show Navigation Component']", state='visible', timeout=2000)
                Browser.page.wait_for_load_state('domcontentloaded')
                show = Browser.page.locator("//a[@title='Show Navigation Component']").count()
                top = Browser.page.locator("//a[@id='Top']").count()
                topicHeader = Browser.page.locator("//div[@id='rh-topic-header']").count()
                topicHead = Browser.page.locator("//*[@class='TopicHead']").count()
                if (show != 0) or (top != 0) or (topicHeader != 0) or (topicHead != 0):
                    print("OLH Pass")
                    Browser.page.close()
                    Browser.page = Temp_tab
                else:
                    takesnapshot()
                    CommonObject.screenshotflag = True
                    Browser.page.close()
                    Browser.page = Temp_tab
                    raise Exception("OLH Verification Failed")
            except Exception as Error:
                #takesnapshot()
                CommonObject.errormessage=Error
                #CommonObject.screenshotflag = False
                #Browser.page.close()
                Browser.page = Temp_tab
                raise Exception("OLH Verification Failed")


        case "Assert Text":
            element = find_element(loc, None)
            appvalue = element.all_inner_texts()[0]
            assertEqual(appvalue, data, "Assertion Failed")

        case "Assert Label Text":
            element = find_element(loc, None)
            appvalue = element.all_inner_texts()[0]
            assertEqual(appvalue, data, "Assertion Failed")

        case "Switch window":
            elementdata = CommonObject.element_value
            Temp_tab = Browser.page
            if elementdata.find("Move") != -1:
                title = CommonObject.data_value
                with Browser.page.context.expect_page() as tab_two:
                    list = Browser.context.pages
                    Browser.page = tab_two.value
                    Browser.page.bring_to_front()

        case "To Save":
            time.sleep(2)
            element = find_element(loc.replace("/'", "'"),data)
            print("before click")
            element.click()
            print("Save button clicked")
            time.sleep(3)

        case "PDF Check":
            files = glob.glob(str(Path.home()) + '\Downloads\\*.pdf')
            latest_file = max(files, key=os.path.getctime)
            movefile(latest_file)
            fileList = os.listdir(CommonObject.pdfpath)
            elementdata = CommonObject.element_value
            if elementdata.find("PDF") != -1:
                output_string = StringIO()
                # file1 = CommonObject.pdfpath + fileList[0]
                pdffilepath = CommonObject.pdfpath + '\\' + fileList[0]
                with open(pdffilepath, 'rb') as in_file:
                    parser = PDFParser(in_file)
                    doc = PDFDocument(parser)
                    rsrcmgr = PDFResourceManager()
                    device = TextConverter(rsrcmgr, output_string, laparams=LAParams())
                    interpreter = PDFPageInterpreter(rsrcmgr, device)
                    pages = PDFPage.create_pages(doc)
                    # This will give you the count of pages
                    if (resolve1(doc.catalog['Pages'])['Count'] >= 1):
                        i = 0
                        for page in PDFPage.create_pages(doc):
                            i += 1
                            # print("In loop {}".format(i) )
                            interpreter.process_page(page)
                            if (len(output_string.getvalue()) > 0):
                                print("PDF is not empty")
                                CommonObject.status = "PASS"
                            else:
                                print("PDF doesnt have content (text) in it")
                                CommonObject.status = "Fail"
                            break
                    else:
                        print("PDF does not have pages")
                        CommonObject.status = "Fail"
                timestamp = datetime.now().strftime("%d-%m-%Y %H-%M-%S").replace(":", "_")
                screenshot(CommonObject.logfolder + '\\screenshot_' + timestamp + '.png')
                advanced_debug_report(CommonObject.logfolder + '\\ScreenLaunchAdvancedDebugLog.csv')

        case "Expand Child Tree":
            element = find_element(loc, None)
            element.first.click()
            time.sleep(0.5)
            pleasewait()
            screenlaunchpopup()
        
        case "Expand Tree":
            pleasewait()
            screenlaunchpopup()
            element = find_element(loc, None)
            element.click()
            pleasewait()
            screenlaunchpopup()
            time.sleep(0.50)

        case "Click Tree Item":
            pleasewait()
            screenlaunchpopup()
            element = find_element(loc, None)
            element.click()
            pleasewait()
            screenlaunchpopup()
            time.sleep(0.50)
        case "Assert Page CSS Styling":
            print("------------------->>>>>>>>>>Webpage Assertion started<<<<<<<<<<-------------------------")
            #print(CommonObject.config["WebPageAssertionMode"].lower())
            Browser.page.wait_for_load_state('load')
            Assertion_status = WebpageAssertion()
            print("------------------->>>>>>>>>>Webpage Assertion completed<<<<<<<<-------------------------")


def movefile(latest_file):
    now = datetime.now()
    current_time = now.strftime("%d%m%y %H%M%S")
    string = str(current_time)
    dir = os.path.join(CommonObject.project_path + "PDF", string)
    CommonObject.pdfpath = dir
    if not os.path.exists(dir):
        os.mkdir(dir)
    else:
        os.makedirs(dir)
    shutil.move(latest_file, dir)
    # if action == "Enter Text":
    #     print("enter text")
    #     print(loc)
    #     element = find_element(loc, None)
    #     element.send_keys(data)
    # if action == "Click Button":
    #     print("click")
    #     element = find_element(loc, None)
    #     time.sleep(2)
    #     element.click()
    #     time.sleep(5)
    # if action == "Assert Object":
    #     print("assert")
    #     find_element(loc, None)
    # if action == "Password Text":
    #     element = find_element(loc, None)
    #     element.click()
    #     element.send_keys(data)
