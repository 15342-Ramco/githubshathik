from config.commonobj import CommonObject

startsWithid = None
containsid = None
lastIndex = None
patternMatch = None
elementdata = None
numberPart = 0
tree = "NO"


def split_page_object_value_data():
    global startsWithid
    global containsid
    global lastIndex
    global patternMatch
    global elementdata
    global numberPart
    global tree
    elementdata = CommonObject.element_value
    tree = "NO"
    numberPart = 0
    element_data = str(elementdata)
    if (element_data.split("_").pop()).isdigit():
        numberPart = element_data.split("_").pop()
        element_data = element_data.replace("_"+str(numberPart), "")
    elementdata = element_data
    if CommonObject.config["App Type"] == "Nebula co-existence":
        patternMatch = "NO"
    elif CommonObject.config["App Type"] == "ePubs":
        patternMatch = "NO"
    else:
        match CommonObject.action:
            case 'Enter Text':
                if (elementdata.find("textfield") != -1 or elementdata.find("ramco") != -1) and (
                        elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case 'Assert Object':
                if (elementdata.find("textfield") != -1 or elementdata.find("numberfield") != -1 or elementdata.find(
                        "datafield") != -1 or elementdata.find("ramcodatetimefield") != -1 or elementdata.find(
                    "ramcotimefield") != -1 or elementdata.find("textarea") != -1 or elementdata.find(
                    "ramcolistedit") != -1 or elementdata.find("label") != -1 or elementdata.find(
                    "combofield") != -1 or elementdata.find("ramcocombo") != -1 or elementdata.find(
                    "ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("radio") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("combofield") != -1 or elementdata.find("ramcolistedit") != -1 or elementdata.find(
                        "ramcocombo") != -1) and (elementdata.find("trigger_picker") != -1):
                    containsid = "trigger-picker"
                    startsWithid = elementdata.replace("_trigger_picker", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramcofile") != -1) and (elementdata.find("fileInputEl") != -1):
                    containsid = "fileInputEl"
                    startsWithid = elementdata.replace("fileInputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    patternMatch = "YES"
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                elif (elementdata.find("link") != -1) and (elementdata.find("btnInnerEl") != -1):
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramco") != -1 or elementdata.find("linkcolumn") != -1) and (
                        elementdata.find("textInnerEl") != -1):
                    containsid = "textInnerEl"
                    startsWithid = elementdata.replace("_textInnerEl", "")
                    if startsWithid.split("_").length == 2:
                        lastIndex = startsWithid.rfind("_")
                        if lastIndex != 1:
                            startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("trigger_help") != -1:
                    containsid = "trigger-help"
                    startsWithid = elementdata.replace("_trigger_help", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcogridcolumn") != -1:
                    containsid = "helpEl"
                    startsWithid = elementdata.replace("_helpEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramcopanel") != -1) and (elementdata.find("header_title_textEl") != -1):
                    containsid = "header-title-textEl"
                    startsWithid = elementdata.replace("_header_title_textEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("_tab") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcotimefield") != -1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("button") != -1 and elementdata.find("btnInnerEl") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("_tbr_") != -1:
                    containsid = ""
                    startsWithid = elementdata
                    patternMatch = "YES"
                elif elementdata.find("button") != -1 or elementdata.find("link") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    if len(startsWithid.split("-")) == 3:
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                        print("three")
                        print(startsWithid)
                    elif len(startsWithid.split("-")) == 4:
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                        print("four")
                        print(startsWithid)
                    elif len(startsWithid.split("-")) == 5:
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                    # print("startsWithid : ", startsWithid)
                    patternMatch = "YES"
                elif (elementdata.find("checkbox") != -1) and (elementdata.find("inputEl") != -1):
                    containsId = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("check") != -1) and (elementdata.find("checkEl") != -1):
                    containsid = "checkEl"
                    startsWithid = elementdata.replace("_checkEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("ramcoimage") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    lastIndex = startsWithid.rfind("_")
                    # Need to update
                else:
                    patternMatch = "NO"

            case "Enter Text Area":
                if elementdata.find("textarea") != -1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES";
                else:
                    patternMatch = "NO";

            case "Enter Number":
                if elementdata.find("numberfield") != -1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES";
                else:
                    patternMatch = "NO";

            case "Password Text":
                if elementdata.find("textfield") != -1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif  elementdata.find("ramcopassword")!=-1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"

                else:
                    patternMatch = "NO";

            case "Enter Grid Page":
                if elementdata.find("tbr") != -1 or elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Clear Text":
                if (elementdata.find("textfield") != -1 or elementdata.find("numberfield") != -1) and (
                        elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("datefield") != -1 or elementdata.find("ramcodatetimefield") != -1) and (
                        elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Select Combo":
                if (elementdata.find("combofield") != -1 or elementdata.find("ramcocombo") != -1) and (
                        elementdata.find("trigger_picker") != -1):
                    containsid = "trigger-picker"
                    startsWithid = elementdata.replace("_trigger_picker", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("combofield") != -1 or elementdata.find("ramcocombo") != -1) and (
                        elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Click Button":
                if (elementdata.find("button") != -1) and (elementdata.find("btnInnerEl") != -1):
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != -1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Click Button Icon1":
                if elementdata.find("_tbr_") != -1:
                    containsid = ""
                    startsWithid = elementdata
                    patternMatch = "YES"
                elif (elementdata.find("icon") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        patternMatch = "YES"
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Click Link":
                if (elementdata.find("link") != -1) and (elementdata.find("btnInnerEl") != -1):
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramco") != -1 or elementdata.find("linkcolumn") != -1) and (
                        elementdata.find("textInnerEl") != -1):
                    containsid = "textInnerEl"
                    startsWithid = elementdata.replace("_textInnerEl", "")
                    if (startsWithid.split("_").length == 2):
                        lastIndex = startsWithid.rfind("_")
                        if (lastIndex != -1):
                            startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]

                    patternMatch = "YES"
                elif (elementdata.find("ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("link") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Click Help":
                if (elementdata.find("trigger_help") != -1):
                    containsid = "trigger-help"
                    startsWithid = elementdata.replace("_trigger_help", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramcogridcolumn") != -1):
                    containsid = "helpEl"
                    startsWithid = elementdata.replace("_helpEl", "")
                    if (len(startsWithid.split("_"))== 2):
                        lastIndex = startsWithid.rfind("_")
                        if (lastIndex != -1):
                            startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Enter Date":
                if (elementdata.find("datefield") != -1 or elementdata.find("ramcodatetimefield") != -1) and (
                        elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_helpEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Click Toggle":
                if (elementdata.find("ramcopanel") != -1) and (elementdata.find("header_title_textEl") != -1):
                    containsid = "header-title-textEl"
                    startsWithid = elementdata.replace("_header_title_textEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramcopanel") != -1) and (elementdata.find("splitter_collapseEl") != -1):
                    containsid = "splitter-collapseEl"
                    startsWithid = elementdata.replace("_splitter_collapseEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Click Checkbox":
                if (elementdata.find("checkbox") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("check") != -1) and (elementdata.find("checkEl") != -1):
                    containsid = "checkEl"
                    startsWithid = elementdata.replace("_checkEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Click Radio Button":
                if (elementdata.find("radio") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "List Edit Enter":
                if (elementdata.find("textfield") != -1 or elementdata.find("ramcolistedit") != -1) and (
                        elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "List Set Enter":
                if (elementdata.find("textfield") != -1 or elementdata.find("ramcolistedit") != -1) and (
                        elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Smart Search":
                if (elementdata.find("textfield") != -1 or elementdata.find("ramcolistedit") != -1) and (
                        elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Grid Smart Search":
                patternMatch = "NO"

            case "Edit And Enter":
                if (elementdata.find("textfield") != -1 or elementdata.find("numberfield") != -1 or elementdata.find(
                        "datefield") != -1 or elementdata.find("ramcodatetimefield") != -1) and (
                        elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Click Tab":
                if elementdata.find("tab") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Grid Text":
                patternMatch = "NO"

            case "Grid Text Enter":
                patternMatch = "NO"

            case "Display Block":
                patternMatch = "NO"

            case "Close Dialog":
                if elementdata.find("tool") != -1:
                    containsid = "toolEl"
                    startsWithid = elementdata.replace("_toolEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Close Dialog2":
                if elementdata.find("tool") != -1:
                    containsid = "toolEl"
                    startsWithid = elementdata.replace("_toolEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Save Data":
                patternMatch = "NO"

            case "Enter Time":
                if elementdata.find("ramcotimefield") != -1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Attach Document":
                if elementdata.find("ramcofile") != -1 and elementdata.find("fileInputEl") != -1:
                    containsid = "fileInputEl"
                    startsWithid = elementdata.replace("_fileInputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcofile") != -1 and elementdata.find("browse") != -1:
                    containsid = "trigger-browse"
                    startsWithid = elementdata.replace("_trigger_browse", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("filefield") != -1 and elementdata.find("button_fileInputEl") != -1:
                    containsid = "button-fileInputEl"
                    startsWithid = elementdata.replace("_", "-")
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Export File":
                # add later
                patternMatch = "NO"

            case "Import File":
                # add later
                patternMatch = "NO"

            case "Select Button Combo":
                # Not required in Screenlaunch
                patternMatch = "NO"

            case "Assert Grid Table":
                # Not required in Screenlaunch
                patternMatch = "NO"

            case "Assert Duplicate Grid Value":
                # Not required in Screenlaunch
                patternMatch = "NO"

            case "Click Show Help":
                if elementdata.find("button") != -1 and elementdata.find("Help") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Scroll Into View":
                # add later
                patternMatch = "NO"

            case "Assert Text":
                if (elementdata.find("textfield") != -1 or elementdata.find("numberfield") != -1 or elementdata.find(
                        "datefield") != -1 or elementdata.find("ramcodatetimefield") != -1 or elementdata.find(
                    "combofield") != -1 or elementdata.find("ramcolistedit") != -1) and (
                        elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    # add later
                    patternMatch = "NO"

            case "Assert Combo Selection":
                if elementdata.find("combofield") != -1 and elementdata.find("inputEl") != -1:
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    containsid = "inputEl";
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("combofield") != -1 or elementdata.find("ramcocombo") != -1) and (
                        elementdata.find("trigger_picker") != -1):
                    containsid = "inputEl";
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    # startsWithid = (startsWithid, 0, lastIndex) + "-" + startsWithid.split("_").pop()
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Assert Button Text":
                if elementdata.find("button") != -1 and elementdata.find("btnInnerEl") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    # add later
                    patternMatch = "NO"

            case "Assert Link Text":
                if elementdata.find("link") != -1 and elementdata.find("btnInnerEl") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Assert Label Text":
                if elementdata.find("label") != -1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("label") != -1:
                    containsid = ""
                    startsWithid = elementdata
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("button") != -1 and elementdata.find("btnInnerEl") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramco") != -1 and elementdata.find("textInnerEl") != -1:
                    containsid = "textInnerEl"
                    startsWithid = elementdata.replace("_textInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("tab") != -1 and elementdata.find("btnInnerEl") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "Assert Not Object":
                if (elementdata.find("textfield") != -1 or elementdata.find("numberfield") != -1 or elementdata.find(
                        "datafield") != -1 or elementdata.find("ramcodatetimefield") != -1 or elementdata.find(
                    "ramcotimefield") != -1 or elementdata.find("textarea") != -1 or elementdata.find(
                    "ramcolistedit") != -1 or elementdata.find("label") != -1 or elementdata.find(
                    "combofield") != -1 or elementdata.find("ramcocombo") != -1 or elementdata.find(
                    "ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    print(startsWithid)
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("radio") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("combofield") != -1 or elementdata.find("ramcolistedit") != -1 or elementdata.find(
                        "ramcocombo") != -1) and (elementdata.find("trigger_picker") != -1):
                    containsid = "trigger-picker"
                    print("test")
                    startsWithid = elementdata.replace("_trigger_picker", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    print(startsWithid)
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramcofile") != -1) and (elementdata.find("fileInputEl") != -1):
                    containsid = "fileInputEl"
                    startsWithid = elementdata.replace("fileInputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("link") != -1) and (elementdata.find("btnInnerEl") != -1):
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramco") != -1 or elementdata.find("linkcolumn") != -1) and (
                        elementdata.find("textInnerEl") != -1):
                    containsid = "textInnerEl"
                    startsWithid = elementdata.replace("_textInnerEl", "")
                    if startsWithid.split("_").length == 2:
                        lastIndex = startsWithid.rfind("_")
                        if lastIndex != 1:
                            startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("trigger_help") != -1:
                    containsid = "trigger-help"
                    startsWithid = elementdata.replace("_trigger_help", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcogridcolumn") != -1:
                    containsid = "helpEl"
                    startsWithid = elementdata.replace("_helpEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramcopanel") != -1) and (elementdata.find("header_title_textEl") != -1):
                    containsid = "header-title-textEl"
                    startsWithid = elementdata.replace("_header_title_textEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("tab") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcotimefield") != -1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("button") != -1 and elementdata.find("btnInnerEl") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("button") != -1 or elementdata.find("link") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    if startsWithid.split("-").length == 3:
                        firstPos = startsWithid.rfind("_")
                        # startsWithid = startsWithid[:firstPos] + "-" + startsWithid[:firstPos+1], startsWithid[:firstPos-1:]
                        # need to update
                elif (elementdata.find("checkbox") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("check") != -1) and (elementdata.find("checkEl") != -1):
                    containsid = "checkEl"
                    startsWithid = elementdata.replace("_checkEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcoimage") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    lastIndex = startsWithid.rfind("_")
                    # Need to update
                else:
                    patternMatch = "NO"

            case "Assert Non-editable":
                if (elementdata.find("textfield") != -1 or elementdata.find("numberfield") != -1 or elementdata.find(
                        "datafield") != -1 or elementdata.find("ramcodatetimefield") != -1 or elementdata.find(
                    "ramcotimefield") != -1 or elementdata.find("textarea") != -1 or elementdata.find(
                    "ramcolistedit") != -1 or elementdata.find("label") != -1 or elementdata.find(
                    "combofield") != -1 or elementdata.find("ramcocombo") != -1 or elementdata.find(
                    "ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    print(startsWithid)
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("radio") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("combofield") != -1 or elementdata.find("ramcolistedit") != -1 or elementdata.find(
                        "ramcocombo") != -1) and (elementdata.find("trigger_picker") != -1):
                    containsid = "trigger-picker"
                    print("test")
                    startsWithid = elementdata.replace("_trigger_picker", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    print(startsWithid)
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramcofile") != -1) and (elementdata.find("fileInputEl") != -1):
                    containsid = "fileInputEl"
                    startsWithid = elementdata.replace("fileInputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("link") != -1) and (elementdata.find("btnInnerEl") != -1):
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramco") != -1 or elementdata.find("linkcolumn") != -1) and (
                        elementdata.find("textInnerEl") != -1):
                    containsid = "textInnerEl"
                    startsWithid = elementdata.replace("_textInnerEl", "")
                    if startsWithid.split("_").length == 2:
                        lastIndex = startsWithid.rfind("_")
                        if lastIndex != 1:
                            startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("trigger_help") != -1:
                    containsid = "trigger-help"
                    startsWithid = elementdata.replace("_trigger_help", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("ramcogridcolumn") != -1:
                    containsid = "helpEl"
                    startsWithid = elementdata.replace("_helpEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramcopanel") != -1) and (elementdata.find("header_title_textEl") != -1):
                    containsid = "header-title-textEl"
                    startsWithid = elementdata.replace("_header_title_textEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("tab") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("ramcotimefield") != -1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("button") != -1 and elementdata.find("btnInnerEl") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("button") != -1 or elementdata.find("link") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    if startsWithid.split("-").length == 3:
                        firstPos = startsWithid.rfind("_")
                        # startsWithid = startsWithid[:firstPos] + "-" + startsWithid[:firstPos+1], startsWithid[:firstPos-1:]
                        # need to update
                elif (elementdata.find("checkbox") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("check") != -1) and (elementdata.find("checkEl") != -1):
                    containsid = "checkEl"
                    startsWithid = elementdata.replace("_checkEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcoimage") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    lastIndex = startsWithid.rfind("_")
                    # Need to update
                else:
                    patternMatch = "NO"

            case "Assert Visible":
                if (elementdata.find("textfield") != -1 or elementdata.find("numberfield") != -1 or elementdata.find(
                        "datafield") != -1 or elementdata.find("ramcodatetimefield") != -1 or elementdata.find(
                    "ramcotimefield") != -1 or elementdata.find("textarea") != -1 or elementdata.find(
                    "ramcolistedit") != -1 or elementdata.find("label") != -1 or elementdata.find(
                    "combofield") != -1 or elementdata.find("ramcocombo") != -1 or elementdata.find(
                    "ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    print(startsWithid)
                elif (elementdata.find("radio") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("combofield") != -1 or elementdata.find("ramcolistedit") != -1 or elementdata.find(
                        "ramcocombo") != -1) and (elementdata.find("trigger_picker") != -1):
                    containsid = "trigger-picker"
                    print("test")
                    startsWithid = elementdata.replace("_trigger_picker", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    print(startsWithid)
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramcofile") != -1) and (elementdata.find("fileInputEl") != -1):
                    containsid = "fileInputEl"
                    startsWithid = elementdata.replace("fileInputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("link") != -1) and (elementdata.find("btnInnerEl") != -1):
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramco") != -1 or elementdata.find("linkcolumn") != -1) and (
                        elementdata.find("textInnerEl") != -1):
                    containsid = "textInnerEl"
                    startsWithid = elementdata.replace("_textInnerEl", "")
                    if startsWithid.split("_").length == 2:
                        lastIndex = startsWithid.rfind("_")
                        if lastIndex != 1:
                            startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("trigger_help") != -1:
                    containsid = "trigger-help"
                    startsWithid = elementdata.replace("_trigger_help", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif elementdata.find("ramcogridcolumn") != -1:
                    containsid = "helpEl"
                    startsWithid = elementdata.replace("_helpEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramcopanel") != -1) and (elementdata.find("header_title_textEl") != -1):
                    containsid = "header-title-textEl"
                    startsWithid = elementdata.replace("_header_title_textEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("tab") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcotimefield") != -1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("button") != -1 and elementdata.find("btnInnerEl") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("button") != -1 or elementdata.find("link") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    if startsWithid.split("-").length == 3:
                        firstPos = startsWithid.rfind("_")
                        # startsWithid = startsWithid[:firstPos] + "-" + startsWithid[:firstPos+1], startsWithid[:firstPos-1:]
                        # need to update
                elif (elementdata.find("checkbox") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("check") != -1) and (elementdata.find("checkEl") != -1):
                    containsid = "checkEl"
                    startsWithid = elementdata.replace("_checkEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcoimage") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    lastIndex = startsWithid.rfind("_")
                    # Need to update
                else:
                    patternMatch = "NO"

            case "Assert Non-Visible":
                if (elementdata.find("textfield") != -1 or elementdata.find("numberfield") != -1 or elementdata.find(
                        "datafield") != -1 or elementdata.find("ramcodatetimefield") != -1 or elementdata.find(
                    "ramcotimefield") != -1 or elementdata.find("textarea") != -1 or elementdata.find(
                    "ramcolistedit") != -1 or elementdata.find("label") != -1 or elementdata.find(
                    "combofield") != -1 or elementdata.find("ramcocombo") != -1 or elementdata.find(
                    "ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    print(startsWithid)
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("radio") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("combofield") != -1 or elementdata.find("ramcolistedit") != -1 or elementdata.find(
                        "ramcocombo") != -1) and (elementdata.find("trigger_picker") != -1):
                    containsid = "trigger-picker"
                    print("test")
                    startsWithid = elementdata.replace("_trigger_picker", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    print(startsWithid)
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramcofile") != -1) and (elementdata.find("fileInputEl") != -1):
                    containsid = "fileInputEl"
                    startsWithid = elementdata.replace("fileInputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("link") != -1) and (elementdata.find("btnInnerEl") != -1):
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + startsWithid + "')]//*[contains(@id, '" + containsid + "')]"
                elif (elementdata.find("ramco") != -1 or elementdata.find("linkcolumn") != -1) and (
                        elementdata.find("textInnerEl") != -1):
                    containsid = "textInnerEl"
                    startsWithid = elementdata.replace("_textInnerEl", "")
                    if startsWithid.split("_").length == 2:
                        lastIndex = startsWithid.rfind("_")
                        if lastIndex != 1:
                            startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramco") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("trigger_help") != -1:
                    containsid = "trigger-help"
                    startsWithid = elementdata.replace("_trigger_help", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcogridcolumn") != -1:
                    containsid = "helpEl"
                    startsWithid = elementdata.replace("_helpEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("ramcopanel") != -1) and (elementdata.find("header_title_textEl") != -1):
                    containsid = "header-title-textEl"
                    startsWithid = elementdata.replace("_header_title_textEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("tab") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcotimefield") != -1 and elementdata.find("inputEl") != -1:
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("button") != -1 and elementdata.find("btnInnerEl") != -1:
                    containsid = "btnInnerEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if lastIndex != 1:
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("button") != -1 or elementdata.find("link") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    if startsWithid.split("-").length == 3:
                        firstPos = startsWithid.rfind("_")
                        # startsWithid = startsWithid[:firstPos] + "-" + startsWithid[:firstPos+1], startsWithid[:firstPos-1:]
                        # need to update
                elif (elementdata.find("checkbox") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif (elementdata.find("check") != -1) and (elementdata.find("checkEl") != -1):
                    containsid = "checkEl"
                    startsWithid = elementdata.replace("_checkEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                elif elementdata.find("ramcoimage") != -1:
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    lastIndex = startsWithid.rfind("_")
                    # Need to update
                else:
                    patternMatch = "NO"

            case "Click Button Icon2":
                if elementdata.find("_tbr_") != -1:
                    containsid = ""
                    startsWithId = elementdata
                    patternMatch = "YES"
                elif (elementdata.find("button") != -1) or (elementdata.find("link") != -1):
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    # if startsWithid.split("-").length == 3:
                    #     firstPos = startsWithid.find("-");
                    #     startsWithid = startsWithid.find(firstPos,"_")
                    # if startsWithid.split("-").length == 4:
                    #     firstPos = startsWithid.find("-");
                    #     startsWithid = startsWithid.find(firstPos,"_")
                    # if startsWithid.split("-").length == 5:
                    #     firstPos = startsWithid.find("-");
                    #     startsWithid = startsWithid.find(firstPos,"_")
                    patternMatch = "YES"
                elif (elementdata.find("icon") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("_btnInnerEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        patternMatch = "YES"
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                else:
                    patternMatch = "NO"

            case "Click Button Icon":
                if elementdata.find("_tbr_") != -1:
                    containsid = ""
                    startsWithid = elementdata
                    patternMatch = "YES"
                elif (elementdata.find("button") != -1) or (elementdata.find("link") != -1):
                    containsid = ""
                    startsWithid = elementdata.replace("_", "-")
                    if len(startsWithid.split("-")) == 3:
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                    if len(startsWithid.split("-")) == 4:
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                    if len(startsWithid.split("-")) == 5:
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                        firstPos = int(startsWithid.find("-"))
                        startsWithid = startsWithid[:firstPos] + "_" + startsWithid[firstPos + 1: len(startsWithid)]
                    patternMatch = "YES"
                elif (elementdata.find("icon") != -1) and (elementdata.find("inputEl") != -1):
                    containsid = "inputEl"
                    startsWithid = elementdata.replace("inputEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        patternMatch = "YES"
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                elif elementdata.find("tool") != -1 and elementdata.find("toolEl") != -1:
                    containsid = "toolEl"
                    startsWithid = elementdata.replace("_toolEl", "")
                    lastIndex = startsWithid.rfind("_")
                    if (lastIndex != -1):
                        startsWithid = startsWithid[:lastIndex] + "-" + startsWithid[lastIndex + 1:]
                    patternMatch = "YES"
                else:
                    patternMatch = "NO"

            case "To Save":
                patternMatch = "NO"

            case "Expand Tree":
                if elementdata == "" or elementdata == "NA":
                    tree = "YES"
                else:
                    idValue = CommonObject.element_value
                    rowIndex = int(idValue.find("row"))
                    length = len(idValue)
                    firstPart = idValue[0: rowIndex+3]
                    lastPart = idValue[rowIndex+3:]
                    lastPart = lastPart.replace("_", "-")
                    startsWithid = firstPart + lastPart
                    tree = "YES"

            case "Click Tree Item":
                if elementdata == "" or elementdata == "NA":
                    tree = "YES"
                else:
                    idValue = CommonObject.element_value
                    rowIndex = int(idValue.find("row"))
                    length = len(idValue)
                    firstPart = idValue[0: rowIndex+3]
                    lastPart = idValue[rowIndex+3:]
                    lastPart = lastPart.replace("_", "-")
                    startsWithid = firstPart + lastPart
                    tree = "YES"

            case "Expand Child Tree":
                if elementdata == "" or elementdata == "NA" or str(elementdata) == "None":
                    tree = "YES"
                else:
                    idValue = CommonObject.element_value
                    rowIndex = int(idValue.find("row"))
                    length = len(idValue)
                    firstPart = idValue[0: rowIndex+3]
                    lastPart = idValue[rowIndex+3:]
                    lastPart = lastPart.replace("_", "-")
                    startsWithid = firstPart + lastPart
                    tree = "YES"




def findlocator():
    split_page_object_value_data()
    global startsWithid, element
    global containsid
    global lastIndex
    global patternMatch
    CommonObject.startsWithid = startsWithid
    if tree == "YES":
        if (((elementdata == "") or (elementdata == "nan") or (elementdata == "None")) and ( CommonObject.action == "Expand Child Tree")):
            if str(elementdata) == "nan" or str(elementdata) == "None":
                elementdata == ""
            element = "//div[@class='TWBodyLeft TWSplitterRight']//td/span[text()='"+str(CommonObject.data_value)+"']/../preceding-sibling::td[1]/u[2]"
        elif(((elementdata == "") or (elementdata == "nan") or (elementdata == "None")) and (CommonObject.action == "Expand Tree")):
               element = "//div[@class='TWBodyLeft TWSplitterRight']//td/span[text()='"+str(CommonObject.data_value)+"']/../preceding-sibling::td[1]"
        elif(((elementdata == "") or (elementdata == "nan") or (elementdata == "None")) and (CommonObject.action == "Click Tree Item")):
               element = "//td/span[contains(@onclick, 'treeclick')][text()='"+str(CommonObject.data_value)+"']"
        else:
            element = "//*[@id='"+startsWithid+"']/div[2]"
    elif patternMatch == "YES":
        if numberPart == 0:
            if containsid == "":
                element = "(//*[starts-with(@id,'"+startsWithid+"')])[1]"
            else:
                element = "//*[starts-with(@id,'"+ startsWithid+"')]//*[contains(@id,'"+ containsid+"')]"
        else:
            if containsid == "":
                element = "//*[starts-with(@id,'"+startsWithid+"')])["+numberPart+"]"
            else:
                element = "(//*[starts-with(@id,'"+startsWithid+"')]//*[contains(@id, '"+containsid+"')])["+numberPart+"]"
    elif patternMatch == "NO":
            element = "//*[@id='"+elementdata+"']"
    return element
