import json
import sys
import time

import pandas as pd
import requests as requests
import uuid
from config.commonobj import CommonObject
from config.navigationfilter import filterby_login_id
from jproperties import Properties

pd.options.mode.chained_assignment = None
import os

configs = Properties()


def xlsx_file_splitter(input_file, agent_data):
    if CommonObject.fileformat == ".xlsx":
        df2 = pd.read_excel(CommonObject.project_path + "Files\\" + input_file, sheet_name=CommonObject.navigationsheet)
    else:
        df2 = pd.read_csv(CommonObject.project_path + "Files\\" + input_file)

    if CommonObject.config["Process"] == "All" and CommonObject.config["Component"] == "All" and CommonObject.config[
        "Activity"] == "All":
        df = df2
        CommonObject.filter = False
        CommonObject.filter_applied = "No"
    elif str(CommonObject.config["Process"]) == "nan" and str(CommonObject.config["Component"]) == "nan" and str(
            CommonObject.config["Activity"]) == "nan":
        df = df2
        CommonObject.filter = False
        CommonObject.filter_applied = "No"
    else:
        CommonObject.filter = True
        CommonObject.filter_applied = "Yes"
        df = filterby_login_id(df2)
    try:
        if df.empty == True:
            raise Exception
    except Exception as error:
        print("""Kindly give the inputs correctly in ScreenLaunchConfig.csv file filter Process,Component,Activity.
            There is no values for your required filtration If you don't want filter,Don't fill the values in Process,Component,Activity""")
        sys.exit(0)
    PATCH_ID = uuid.uuid4()
    df['PATCH_ID'] = PATCH_ID

    List_split = agent_data
    shape = df.shape
    dic = {}
    ss = 0
    # split the dataframe by percentage which user given
    try:
        if sum(List_split) == 100:
            for i in range(len(List_split)):
                df_range = round(List_split[i] * shape[0] / 100)
                df_range += ss
                if i == len(List_split) - 1:
                    df1 = df.iloc[ss:, :]
                    dic[i] = df1.reset_index(drop=True)
                else:
                    df1 = df.iloc[ss:df_range, :]
                    dic[i] = df1.reset_index(drop=True)
                    ss = df_range
            # check the dataframe login and switchcontext for the each dataframe
            for i in range(len(dic)):
                d = []
                d1 = []
                d2 = []
                temp_df = dic[i]
                if str(temp_df.iloc[0]["Login"]) == "nan":
                    if str(temp_df.iloc[0]["Login"]) == "nan":
                        temp_df2 = dic[i - 1]
                        for index, row in temp_df2[::-1].iterrows():
                            if (str(temp_df2.iloc[index]["Login"]) != 'nan'):
                                d.append(temp_df2.iloc[index]["Login"])
                                temp_df["Login"][0] = d[0]

                    if str(temp_df.iloc[0]["SwitchContext"]) == "nan":
                        temp_df2 = dic[i - 1]
                        for id1, rw in temp_df2[::-1].iterrows():
                            if str(temp_df2.iloc[id1]["Login"]) != "nan":
                                d1.append(id1)
                                for id1, rw in temp_df2[d1[0]::1].iterrows():
                                    if str(temp_df2.iloc[id1]["SwitchContext"]) != "nan":
                                        d2.append(temp_df2.iloc[id1]["SwitchContext"])
                                if d2:
                                    temp_df["SwitchContext"][0] = d2[-1]
                                else:
                                    temp_df["SwitchContext"][0] = ""
                dic[i] = temp_df
        else:
            print("Please give user splitting percentage around 100")

        for i in range(len(dic)):
            df2 = dic[i]
            file_name = "NavigationConfig" + "_" + str(i)
            if CommonObject.fileformat == ".xlsx":
                df2.to_excel(CommonObject.project_path + "Files\\" + file_name + CommonObject.fileformat,
                             sheet_name='NavConfig')
            else:
                df2.to_csv(CommonObject.project_path + "Files\\" + file_name + CommonObject.fileformat)

        print("[INFO]:NavigationConfig files splitted")
        return True
    except:
        print("[INFO]:NavigationConfig files not splitted")
        return False


def read_config_file(file_name):
    with open(file_name, "rb") as f:
        configs.load(f)
    data = [list(i) for i in configs.items()]
    dict_data = {}
    agents = []
    browser = []
    for d in data:
        if "Cluster" in d[0]:
            txt = (d[1])[0]
            x = str(txt)
            x = x.split(",")
            agents.append(x[0])
            browser.append(x[1])
        else:
            dict_data.update({d[0]: list(d[1])[0]})
    agents = [int(a) for a in agents]
    browser = [a for a in browser]
    dict_data.update({"Agents": agents, "Browser": browser})
    
    return dict_data


def get_hub_details():
    config_file_data = read_config_file("config.properties")
    try:
        response_API = requests.get(config_file_data["url"] + '/grid/api/hub/')
        data = response_API.text
        parse_json = json.loads(data)
        parse_json["status"] = True
        return parse_json

    except Exception as e:
        a = e.args
        dict = {}
        dict["exception"] = a
        dict["status"] = False
        return dict


def Session_Details(session_id):
    process_id = CommonObject.process_id1
    CommonObject.Parallel_det["session_id"].append(session_id)
    CommonObject.Parallel_det["process_id"].append(session_id)

# ---------driver start------------------------->

def start_server(path):
    print("[INFO]:Node And Hub Will Start..Please Wait for 10 seconds")
    y = "selenium-server-4.3.0.jar"
    os.chdir(path+'\Drivers\Localhost')
    try:
        os.popen("cmd /c java -jar \"{}\Drivers\Localhost\{}\" standalone".format(path, y))
    except Exception as e:
        print("[INFO]:Error on Start the Hub and Node",e.args)
    time.sleep(4)
    os.chdir(path)


def set_environment():
    config_file_data = read_config_file("config.properties")
    try:
        os.popen('start cmd /c SETX "SELENIUM_REMOTE_URL" ' + config_file_data["url"])
        print("[INFO]: Set the Selenium Environment Variable")
    except Exception as e:
        print("[INFO]:Error On Set Environment Variable", e.args)
    time.sleep(4)



def delete_environment():
    try:
        try:
            if os.environ["SELENIUM_REMOTE_URL"]:
                del os.environ["SELENIUM_REMOTE_URL"]
        except:
            pass
        os.popen('cmd /c REG delete "HKCU\Environment" /F /V "SELENIUM_REMOTE_URL" ')
        print("[INFO]: Deleted Environment variable SELENIUM_REMOTE_URL")
    except Exception as e:
        print("[INFO]:The environment variable is not deleted", e.args)




def get_server_details():
    config_file_data = read_config_file("config.properties")
    response_API = requests.get(config_file_data["url"] + '/status')
    data = response_API.text
    parse_json = json.loads(data)
    Connected_nodes=len(parse_json['value']['nodes'])
    URL_Hub=parse_json['value']['nodes'][0]['uri']
    Max_sessions=parse_json['value']['nodes'][0]['maxSessions']
    Avail_node_list=[]
    occupied_node=[]
    for i in range(Connected_nodes):
        for j in range(Max_sessions):
            if str(parse_json['value']['nodes'][i]['slots'][j]['session']) =="None" or "null":
                if str(parse_json['value']['nodes'][i]['slots'][j]['stereotype']["browserName"]) =="chrome" or "edge":
                    Avail_node_list.append(str(parse_json['value']['nodes'][i]['slots'][j]['stereotype']["browserName"]))
            else:
                occupied_node.append(str(parse_json['value']['nodes'][i]['slots'][j]['stereotype']["browserName"]))
    server_det=dict()
    server_det["URL_Hub"]=URL_Hub
    server_det["status"] = True
    server_det["Connected_nodes"]=Connected_nodes
    server_det["MaxSessions"]=parse_json['value']['nodes'][0]['maxSessions']
    server_det["ChromeNodes"]=Avail_node_list.count("chrome")
    server_det["EdgeNodes"]=Avail_node_list.count("edge")
    server_det["Avail_node_list"]=Avail_node_list
    server_det["occupied_node"]=occupied_node
    print(server_det)
    print("Your Hub IP is",URL_Hub)
    print("Total Connected Nodes",Connected_nodes)
    print("Total Max Sessions",parse_json['value']['nodes'][0]['maxSessions'])
    print("Total Chrome Nodes",Avail_node_list.count("chrome"))
    print("Total Edge Nodes",Avail_node_list.count("edge"))
    print("Available Nodes",len(Avail_node_list))
    print("Occupied Nodes",len(occupied_node))
    return server_det