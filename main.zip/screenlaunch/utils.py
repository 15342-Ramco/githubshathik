import os
import uuid
import pandas as pd
from config.commonobj import CommonObject
import shutil
import time

def read_file(file, sheet):
    if ".csv" in file:
        df = pd.read_csv(file)
        if CommonObject.config["ParallelExecution"] != "ON":
            PATCH_ID = uuid.uuid4()
            df['PATCH_ID'] = PATCH_ID
    else:
        df = pd.read_excel(file, sheet_name=sheet)
        if CommonObject.config["ParallelExecution"] != "ON":
            PATCH_ID = uuid.uuid4()
            df['PATCH_ID'] = PATCH_ID
    return df


def create_directory(parent_dir, directory):
    if not os.path.exists(parent_dir):
        os.mkdir("Output")
    # Path
    path = os.path.join(parent_dir, directory)

    # Create the directory
    if not os.path.exists(path):
        os.mkdir(path)
    return path



def Create_folder(dire):
    if not os.path.exists(dire):
        os.mkdir(dire)

def remove_folder(folder_path):
    try:    
        if os.path.exists(folder_path):   
            shutil.rmtree(folder_path)
            print(f"Folder '{folder_path}' removed successfully.")
        else:
            print(f"Folder '{folder_path}' does not exist.")
    except Exception as removeerror:
        time.sleep(0.5)
        try:    
            if os.path.exists(folder_path):
                shutil.rmtree(folder_path)
                print(f"Folder '{folder_path}' removed successfully.")
            else:
                print(f"Folder '{folder_path}' does not exist.")
        except Exception as removeerror:
            time.sleep(0.5)
            try:    
                if os.path.exists(folder_path):
                    shutil.rmtree(folder_path)
                    print(f"Folder '{folder_path}' removed successfully.")
                else:
                    print(f"Folder '{folder_path}' does not exist.")
            except Exception as removeerror:
                raise Exception (removeerror)
       
       