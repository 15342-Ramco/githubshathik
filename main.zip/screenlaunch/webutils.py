import base64
from PIL import Image
import time
from datetime import datetime
from datetime import date
from config.commonobj import CommonObject
from screenlaunch.browser import Browser
from jproperties import Properties
configs = Properties()
import os


def  find_element(locvalue, framename):
    global element
    try:
        if CommonObject.framename:
            framename = CommonObject.framename
            print("Iframe: " + framename)
            Frame=Browser.page.frame_locator("//iframe[starts-with(@id,'"+framename+"')]")
            element=Frame.locator(locvalue)
            print(element)
        else:
            if  CommonObject.config["App Type"] == "Nebula co-existence":
                Browser.page.wait_for_selector(locvalue,state='visible', timeout=10000)
            elif CommonObject.config["App Type"] == "ePubs":
                Browser.page.wait_for_selector(locvalue, state='attached', timeout=2000)
            else:
                Browser.page.wait_for_selector(locvalue,state='visible', timeout=2000)
            element = Browser.page.locator(locvalue)
            if element.count()==0:
                raise Exception
    except Exception as Error:
        CommonObject.errormessage = "Unable to find the element value " + CommonObject.element_value
        raise Exception("Unable to find the element value " + CommonObject.element_value)
    return element


def pleasewait():
    if  CommonObject.config["App Type"] == "Nebula co-existence":
        try:
             
            #Browser.page.wait_for_load_state('domcontentloaded')
            selector_circular_loading= "//div[@class='loader-wrapper full-page']//*[text()='Loading...']"
            circular_wait_element = Browser.page.query_selector(selector_circular_loading)
            count1=0
            if circular_wait_element!=None and circular_wait_element.is_visible():
                visible_element = circular_wait_element.is_visible()
                while visible_element:
                    print("Nebula - wait until please wait loader-wrapper full-page")
                    time.sleep(0.50)
                    count1 = count1 + 1
                    if count1 == 180:
                        print("Page load timeout")
                        takesnapshot()
                        CommonObject.pagetimeout = True
                        CommonObject.screenshotflag = True
                        CommonObject.errormessage = "Page load timeout"
                        raise Exception("Page load timeout")
                    visible_element = circular_wait_element.is_visible()
            else:
                pass


            loadingbar = "//*[@id='loadingbar' and @style='display:block']"
            
            loadingbar_element = Browser.page.query_selector(loadingbar)
            
            
            count2=0
            if loadingbar_element!=None and loadingbar_element.is_visible():
              
                loadingbar_visible = loadingbar_element.is_visible()
                while loadingbar_visible:
                    print("Nebula - wait until please wait loadingbar")
                    time.sleep(0.50)
                    count2 = count2 + 1
                    if count2 == 180:
                        print("Page load timeout")
                        takesnapshot()
                        CommonObject.pagetimeout = True
                        CommonObject.screenshotflag = True
                        CommonObject.errormessage = "Page load timeout"
                        raise Exception("Page load timeout")
                    loadingbar_visible = loadingbar_element.is_visible()

            else:
                pass

            load="//*[@class='disabled-opaque loader-wrapper full-page ']"
            element = Browser.page.query_selector(load)
            if element!=None and element.is_visible():
                print("disabled-opaque loader-wrapper is visible.")
                # Check if the element is visible
                count3 = 0
                element = Browser.page.query_selector(load)
                welement = element.is_visible()
                while welement:
                    time.sleep(0.50)
                    count3 = count3 + 1
                    if count3 == 180:
                        print("Page load timeout")
                        takesnapshot()
                        CommonObject.pagetimeout = True
                        CommonObject.screenshotflag = True
                        CommonObject.errormessage = "Page load timeout"
                        raise Exception("Page load timeout")
                    welement = element.is_visible()
            else:
                pass
        except Exception as Error:
            CommonObject.pleasewaiterror=True
            raise Exception(str(Error))

        # # Check if the element is visible
        # count = 0
        # menubutton = Browser.page.query_selector("//*[@id ='MenuBar_Icon_toggleSideNav']")
        # welement = menubutton.is_visible()
        # while not welement:
        #     time.sleep(0.50)
        #     count = count + 1
        #     if count == 60:
        #         print("Page load timeout")
        #         takesnapshot()
        #         CommonObject.pagetimeout = True
        #         CommonObject.screenshotflag = True
        #         CommonObject.errormessage = "Page load timeout"
        #         raise Exception("Page load timeout")
        #     element = Browser.page.query_selector("//*[@id ='MenuBar_Icon_toggleSideNav']")
        #     welement = element.is_visible()
        #     print(welement)
        # body_xpath = "//body"
        # Browser.page.wait_for_selector(body_xpath, state='attached', timeout=5000000)
        # # Find the element with the selector '#my-element'
        # element = page.query_selector("//*[@id='loadingbar']")
        #
        # # Check if the element is visible
        # if element.is_visible():
        #     print("Element is visible.")
        # else:
        #     print("Element is not visible.")
        # waitelementvisible=Browser.page.locator("//*[@id='loadingbar']",state = 'visible')
        # waitelement = Browser.page.locator("//*[@id='loadingbar']").count()
        # count = 0
        # while waitelement != 0:
        #     time.sleep(0.50)
        #     count = count + 1
        #     if CommonObject.loginfirsttime is True:
        #         body_xpath = "//body"
        #         Browser.page.wait_for_selector(body_xpath, state='attached', timeout=5000000)
        #     if count == 20:
        #         print("Page load timeout")
        #         takesnapshot()
        #         CommonObject.pagetimeout = True
        #         CommonObject.screenshotflag = True
        #         CommonObject.errormessage = "Page load timeout"
        #         raise Exception("Page load timeout")
        #     waitelement = Browser.page.locator("//*[@id='loadingbar']").count()

    elif CommonObject.config["App Type"] == "ePubs":
        time.sleep(0.5)
    else:
        body_xpath = "//body"
        Browser.page.wait_for_selector(body_xpath, state='attached', timeout=5000000)
        waitelement = Browser.page.locator( "//div[@name='undefined_loadmask' and @aria-hidden='false']").count()
        count = 0
        while waitelement != 0:
            time.sleep(0.50)
            count = count + 1
            if CommonObject.loginfirsttime is True:
                body_xpath = "//body"
                Browser.page.wait_for_selector(body_xpath, state='attached', timeout=5000000)
            if count ==180:
                print("Page load timeout")
                takesnapshot()
                CommonObject.pagetimeout = True
                CommonObject.screenshotflag = True
                CommonObject.errormessage = "Page load timeout"
                raise Exception("Page load timeout")
            waitelement = Browser.page.locator("//div[@name='undefined_loadmask' and @aria-hidden='false']").count()
#
# def Reload_page():
#     if  CommonObject.config["App Type"] == "Nebula co-existence":
#         Reloadpage = "//div[@class='card-header']//span[text()='Reload this page']"
#         Reload=Browser.page.locator(Reloadpage).count()
#         if Reload!= 0:
#             Browser.page.click(Reloadpage)

def pageload():
    if  CommonObject.config["App Type"] == "Nebula co-existence":
        loadpage = "//*[@id='button_btnInnerEl']"
    elif CommonObject.config["App Type"] == "ePubs":
        loadpage = "//*[@id='btnLogin']"
    else:
        body_xpath = "//body"
        Browser.page.wait_for_load_state('domcontentloaded')
        Browser.page.wait_for_selector(body_xpath, state='attached', timeout=90000)
        loadpage = "//*[starts-with(@id,'button')]//*[contains(@id, 'btnInnerEl')]"
    Browser.page.wait_for_selector(loadpage, state='visible', timeout=180000)

def screenshot(file):
    try:
        print("Inside screenshot")
        print(file)
        Browser.page.screenshot(path=file)
        print("Take Screenshot")
        image_file = Image.open(file)
        print("After Open the Image")
        rgb_im = image_file.convert('RGB')
        timestampcom = str(datetime.now()).replace(":", "_")
        customname = str(date.today()).replace("-", "/")
        file_name = os.path.basename(file)
        CommonObject.error_snapshot_filename=customname+"/"+file_name
        # CommonObject.error_snapshot_filename = customname + '/screenshot_' + timestampcom + str(CommonObject.process_id) + '.png'
        filecom = CommonObject.logfolder + '\\screenshot_compressed' + timestampcom + '.jpg'
        print("Screenshot before save")
        rgb_im.save(filecom, quality=10)
        print("Screenshot After save")
        with open(filecom, "rb") as imagetostring:
            converted_string = base64.b64encode(imagetostring.read())
            CommonObject.imagetostring = converted_string.decode('utf-8')
    except Exception as Error:
        print("error from Screenshot")
        CommonObject.screenshoterrorflag=True
        print(Error)
        raise Exception


def screenlaunchpopup():
    #global yesornopopup
    Framelocate=""
    frameerror=""
         
    if  CommonObject.config["App Type"] == "Nebula co-existence":
        popupBox = Browser.page.locator("//*[@class='nb_message']").count()
        toasterror=Browser.page.locator("//div[@class='Toastify__toast-container Toastify__toast-container--top-right']").count()
        if toasterror!=0:
            toasterror="//div[@class='Toastify__toast-container Toastify__toast-container--top-right']"
            toasterror_loc=Browser.page.query_selector(toasterror)
            if toasterror_loc!=None and toasterror_loc.is_visible():
                CommonObject.errormessage = Browser.page.locator("//div[@class='Toastify__toast-container Toastify__toast-container--top-right']").all_inner_texts()[0]
                CommonObject.Toast_error_pop_up=True
                raise Exception(str(CommonObject.errormessage))     
    elif CommonObject.config["App Type"] == "ePubs":
        popupBox = Browser.page.locator("//*[@id='errorPopUp' and @class='modal fade in']").count()

    else:
        Framelocate = Browser.page.locator("//iframe[starts-with(@id,'floatreview_sec1-ramcoiframe-')]").count()
        Frame = Browser.page.frame_locator("//iframe[starts-with(@id,'floatreview_sec1-ramcoiframe-')]")
        if Framelocate != 0:
            refuseconect = Frame.locator("//*[@id='sub-frame-error']").count()
            frameerror = ""
            if refuseconect !=0:
                refuseconect = Frame.locator("//*[@id='sub-frame-error']")
                frameerror = refuseconect.text_content()
                print(frameerror)
        popupBox = Browser.page.locator("//div[@name='undefined_messagebox' and @aria-hidden='false']").count()
    if popupBox != 0:
        if  CommonObject.config["App Type"] == "Nebula co-existence":
            errorPopup = Browser.page.locator("//*[@class='nb-icon nb-error']").count()
            # successPopup = Browser.page.locator("").count() # NEED TO ADD SUCESS POPUP XPATH 
            successPopup=Browser.page.locator("//*[@class='nb-icon nb-success']").count()
            # warning_popup_xpath ="//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-warning']"
            # questionmark_popup_xpath = "//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-question']"
            # is_nb_success_popup = "//*[@class='nb_message']//*[@class='nb-strip nb-success']"
            # is_nb_failure_popup = "//*[@class='nb_message']//*[@class='nb-strip nb-error']"
            yesornopopup=0
        elif CommonObject.config["App Type"] == "ePubs":
            errorPopup = Browser.page.locator("//*[@id='errorModalLabel' and text()='Error']").count()
            successPopup = 0
        else:
            successPopup = Browser.page.locator("//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-info']").count()
            errorPopup = Browser.page.locator("//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-error']").count()
            yesornopopup=Browser.page.locator("//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-question']").count()
        if successPopup!= 0:
            if CommonObject.config["App Type"] == "Nebula co-existence":
                # okbutton = "//*[@class='custom-table']//button[text()='Ok']"
                # popupokelement = Browser.page.query_selector(okbutton)
                # if popupokelement!=None and popupokelement.is_visible():
                #     Browser.page.click(okbutton)
                nbclose=Browser.page.query_selector("//div[@class='nb_close']//*[@id='Layer_1']")
                if nbclose!=None and nbclose.is_visible():
                    Browser.page.click("//div[@class='nb_close']//*[@id='Layer_1']")

            else:
                okbutton = "//*[starts-with(@id,'ok-button')]//*[contains(@id, '-btnInnerEl')]"
                errormessage =Browser.page.locator("//*[starts-with(@id,'messagebox')]//*[contains(@id, '-msg')]").all_inner_texts()[0]
                if errormessage=="File Not Found !":
                    raise Exception(errormessage)
                Browser.page.click(okbutton)
        if errorPopup != 0:
            takesnapshot()
            CommonObject.screenshotflag = True
            if  CommonObject.config["App Type"]== "Nebula co-existence":
                CommonObject.errormessage = Browser.page.locator("//*[@class='nb-detail-desc']").all_inner_texts()[0]
                Browser.page.wait_for_selector("//div[@class='nb_close']//*[@id='Layer_1']")
                # nbclose=Browser.page.query_selector("//div[@class='nb_close']//*[@id='Layer_1']")
                # if nbclose!=None and nbclose.is_visible():
                #     Browser.page.click("//div[@class='nb_close']//*[@id='Layer_1']")
                Browser.page.click("//div[@class='nb_close']//*[@id='Layer_1']")
            elif CommonObject.config["App Type"] == "ePubs":
                CommonObject.errormessage = Browser.page.locator("//*[@id='lblError']").all_inner_texts()[0]
            else:
                CommonObject.errormessage = Browser.page.locator("//*[starts-with(@id,'messagebox')]//*[contains(@id, '-msg')]").all_inner_texts()[0]
            if CommonObject.errormessage.find("Session expired. Please re-login.") != -1 or CommonObject.errormessage.find("Session expired")!= -1:
                print("Session Expired, Re-executing current screen")
                CommonObject.session_expired = True
                CommonObject.errormessage = "Session expired"
                raise Exception("Session expired")
            elif CommonObject.errormessage.find("Service Unavailable") != -1:
                print("Service Unavailable")
                CommonObject.session_expired = True
                CommonObject.errormessage = "Service Unavailable"
                raise Exception("Service Unavailable")
            else:
                okbutton = "//*[starts-with(@id,'ok-button')]//*[contains(@id, '-btnInnerEl')]"
                if  CommonObject.config["App Type"] == "Nebula co-existence":
                    Browser.page.keyboard.press("Escape")
                    # try:
                    #     closebutton=Browser.page.locator("//*[@id ='tool_toolEl']").count()
                    # except Exception as Er:
                    #     print(Er)
                    # if closebutton!=0:
                    #     closebutton = Browser.page.locator("//*[@id ='tool_toolEl']").click()
                elif CommonObject.config["App Type"] == "ePubs":
                    error_popup_ok = "//*[@id='btnErrOk' and text()='OK']"
                    Browser.page.click(error_popup_ok)
                else:
                    Browser.page.click(okbutton)
                CommonObject.errormessage = "Application Error Message: " + CommonObject.errormessage
                raise Exception(CommonObject.errormessage)
                #raise Exception(CommonObject.errormessage)
        if yesornopopup!=0:
            yesbutton="//*[starts-with(@id,'yes-button-')]//*[contains(@id, 'btnInnerEl')]"
            if Browser.page.locator(yesbutton).is_visible():
                Browser.page.click(yesbutton)
    if Framelocate != 0 and frameerror.find("refused to connect") != -1:
        takesnapshot()
        CommonObject.screenshotflag = True
        print("Refused connection, Re-executing current screen")
        CommonObject.session_expired = True
        CommonObject.errormessage = "Application Error: Refused connection"
        raise Exception("Refused to connect")

def takesnapshot():
    timestamp = str(datetime.now()).replace(":", "_")
    screenshot(CommonObject.logfolder + '\\screenshot_' + timestamp +str(CommonObject.process_id)+ '.png')

def is_in_sequence(num):
    # Check if the number is greater than or equal to 10 and divisible by 10
    return num >= 49 and num % 50 == 0


# def kill_browsers():
#     browser_names = ['chrome.exe', 'firefox.exe', 'edge.exe']  # Add more browser names if needed

#     for proc in psutil.process_iter(['pid', 'name']):
#         if proc.info['name'].lower() in browser_names:
#             try:
#                 print(f"Killing process: {proc.info['name']} (PID: {proc.info['pid']})")
#                 psutil.Process(proc.info['pid']).terminate()
#             except psutil.NoSuchProcess:
#                 pass




# def for_select_combo_nebula(page_object, selector, data):
#     if str(data).lower() != "nan" and str(data).lower() != "na" and str(data) != "":
#         if ";" not in data:
#             page_object.wait_for_selector(selector, timeout= 5000)
#             page_object.click(selector, timeout= Common_object.Timeout)
#             selectValue = "//ul[@role='listbox']//li[text()='"+data+"']"
#             page_object.click(selectValue, timeout= Common_object.Timeout)
#
#         else:
#             page_object.wait_for_selector(selector, timeout= 5000)
#             page_object.click(selector, timeout= Common_object.Timeout)
#             split_data = data.split(";")
#             pickerlist_id = ((Common_controls.control_Value).split("trigger_picker"))[0]+"picker_listEl"
#             selectValue = "//*[@id='"+pickerlist_id+"']//ul//li//div//div[text()='"+split_data[0]+"']//..//*[text()='"+split_data[1]+"']"
#             Variable_not_resettable.logger.info(selectValue)
#             page_object.click(selectValue, timeout= Common_object.Timeout)
#     else:
#         page_object.wait_for_selector(selector, timeout= 5000)
#         page_object.click(selector, timeout= Common_object.Timeout)
#         pickerlist_id_starts = ((Common_controls.control_Value).split("trigger_picker"))[0]+"picker_listEl"
#         pickerlist_id = "//*[@id='"+pickerlist_id_starts+"']//li"
#         # print("______________________________________")
#         Variable_not_resettable.logger.info(pickerlist_id)
#         combo_list_elements = page_object.query_selector_all(pickerlist_id)
#         for combo_element in combo_list_elements:
#             combo_li_text = combo_element.inner_text()
#             if combo_li_text =="":
#                 combo_element.click()
#                 break



# def buildversion(file_name):
#     with open(file_name, "rb") as f:
#         configs.load(f)
#     data = [list(i) for i in configs.items()]
#     dict_data = {}
#     agents = []
#     browser = []
#     for d in data:
#         if "BuildVersion" in d[0]:
#             txt = (d[1])[0]
#             x = str(txt)
#             x = x.split(",")
#             agents.append(x[0])
#     agents = [str(a) for a in agents]
#     dict_data.update({"BuildVersion": agents})
#     buildlist=dict_data["BuildVersion"]
#     str1 = " "
#     string=str1.join(buildlist)
#     return string