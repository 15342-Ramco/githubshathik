# c = 'customer_name_combofield_trigger_picker'
elementdata = 'customer_name_combofield_trigger_picker'
#
if (elementdata.find("textfield") != -1 or elementdata.find("numberfield") != -1 or elementdata.find(
                    "datafield") != -1 or elementdata.find("ramcodatetimefield") != -1 or elementdata.find(
                    "ramcotimefield") != -1 or elementdata.find("textarea") != -1 or elementdata.find(
                    "ramcolistedit") != -1 or elementdata.find("label") != -1 or elementdata.find(
                    "combofield") != -1 or elementdata.find("ramcocombo") != -1 or elementdata.find(
                    "ramco") != -1) and (elementdata.find("inputEl") != -1):
    print("entered")
else:
    print("pass")


# c = 'customer_name_combofield_trigger_picker'
# if ('combofield' or 'number') and ('inputl') in c:
#     print('c')
# else:
#     print('d')