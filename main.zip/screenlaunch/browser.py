from playwright.sync_api import sync_playwright
from config.commonobj import CommonObject
from screenlaunch.parallel import read_config_file
from ecr_collector import handle_response
import psutil
import sys



def custom_crash_handler():
    print("Browser process crashed. Handling the crash...")
    
    # Add your custom handling code here
    # For example, you can restart the browser or take any necessary actions.

    # Restart the browser
    Browser.page.close()
    Browser.context.close()
    Browser.context = Browser.driver.new_context()
    Browser.page = Browser.context.new_page()

# def findseparateprocessid():
    


def find_browser_process_id():
    try:
        CommonObject.executable_name = sys.argv[0]
        exe_name = CommonObject.executable_name
        print("exename "+str(CommonObject.executable_name))
        chrome_with_python_parent = {}
        for process in psutil.process_iter(['pid', 'name']):
            process_id = process.pid
            process_name = process.name()
            process_status = process.status()
            is_python_parent = False
            is_node_parent = False
            is_exe_parent = False
            if process_name == CommonObject.browsertype:
                parent_processes = process.parents()
                parent_python_process_id = None
                parent_node_process_id = None
                parent_exe_process_id = None
                for parent_process in parent_processes:
                    if (parent_process.name() == "cmd.exe"):
                        is_python_parent = True
                        parent_python_process_id = parent_process.pid
                    elif (parent_process.name() == "node.exe"):
                        is_node_parent = True
                        parent_node_process_id = parent_process.pid
                    elif (parent_process.name() == exe_name):
                        is_exe_parent = True
                        parent_exe_process_id = parent_process.pid
            if is_python_parent and is_node_parent and is_exe_parent:
                # if chrome_with_python_parent.get(parent_python_process_id) == None :
                #     chrome_with_python_parent.update({parent_python_process_id:[process_id]})
                # else:
                    # chrome_with_python_parent.get(parent_python_process_id).append(process_id)
                if chrome_with_python_parent.get(parent_node_process_id)==None:
                    chrome_with_python_parent.update({parent_node_process_id:[process_id]})
                else:
                    chrome_with_python_parent.get(parent_node_process_id).append(process_id)
        return chrome_with_python_parent
    except Exception as browserpiderror:
        print(browserpiderror)
        return {}



class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, "a")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass


class Browser:
    browser = None
    page = None
    context =None
    play=None
    def initialize(url):
        if not CommonObject.nebularelaunch:
            Browser.play = sync_playwright().start()
        config_file_data = read_config_file("config.properties")
        print(CommonObject.user_dir)
        CommonObject.config["Ninjaconnect"]=config_file_data['Ninjaconnect']
        if (config_file_data['Grid_mode'] == "Remote" or config_file_data['Grid_mode'] == "Localhost") and CommonObject.config["ParallelExecution"] == "ON":
            if CommonObject.config["Browser"] == "chrome":
                Browser.browser = Browser.play.chromium.launch(channel="chrome",timeout=100000, headless=False,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
                CommonObject.browsertype = "chrome.exe"
            elif CommonObject.config["Browser"] == "chrome-headless":
                Browser.browser = Browser.play.chromium.launch(channel="chrome",timeout=100000,headless=True,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
            elif CommonObject.config["Browser"] == "msedge":
                Browser.browser= Browser.play.chromium.launch(channel="msedge",timeout=100000, headless=False,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
                CommonObject.browsertype = "msedge.exe"
            elif CommonObject.config["Browser"] == "edge-headless":
                Browser.browser = Browser.play.chromium.launch(channel="msedge",timeout=100000, headless=True,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
            elif str(CommonObject.config["Browser"]).lower() == "msedge-persistent-context":
                Browser.browser = Browser.play.chromium.launch_persistent_context(user_data_dir=CommonObject.user_dir,channel="msedge",timeout=100000, headless=False,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
                CommonObject.browsertype = "msedge.exe"
            elif CommonObject.config["Browser"] == "chrome-persistent-context":
                Browser.browser = Browser.play.chromium.launch_persistent_context(user_data_dir=CommonObject.user_dir,channel="chrome",timeout=100000,headless=False,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
        else:
            if CommonObject.config["Browser"] == "chrome":
                Browser.browser = Browser.play.chromium.launch(channel="chrome",timeout=100000, headless=False,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
                CommonObject.browsertype = "chrome.exe"
            elif CommonObject.config["Browser"] == "chrome-headless":
                Browser.browser = Browser.play.chromium.launch(channel="chrome",timeout=100000,headless=True,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
            elif CommonObject.config["Browser"] == "msedge":
                Browser.browser = Browser.play.chromium.launch(channel="msedge",timeout=100000, headless=False,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
                CommonObject.browsertype = "msedge.exe"
            elif CommonObject.config["Browser"] == "edge-headless":
                Browser.browser = Browser.play.chromium.launch(channel="msedge",timeout=100000, headless=True,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
            elif str(CommonObject.config["Browser"]).lower() == "msedge-persistent-context":
                Browser.browser = Browser.play.chromium.launch_persistent_context(user_data_dir=CommonObject.user_dir,channel="msedge",timeout=100000, headless=False,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
                CommonObject.browsertype = "msedge.exe"
            elif CommonObject.config["Browser"] == "chrome-persistent-context":
                Browser.browser = Browser.play.chromium.launch_persistent_context(user_data_dir=CommonObject.user_dir,channel="chrome",timeout=100000,headless=False,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
            elif CommonObject.config["Browser"] == "playwright-firefox":
                Browser.browser = Browser.play.firefox.launch(executable_path=CommonObject.project_path + "Drivers\\firefox-1323\\firefox\\firefox.exe",timeout=100000,headless=False)
            elif CommonObject.config["Browser"] == "playwright-firefox-headless":
                Browser.browser = Browser.play.firefox.launch(executable_path=CommonObject.project_path + "Drivers\\firefox-1323\\firefox\\firefox.exe",timeout=100000,headless=True)
            elif CommonObject.config["Browser"] == "firefox":
                Browser.browser = Browser.play.firefox.launch(channel="firefox",timeout=100000,headless=False,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
            elif CommonObject.config["Browser"] == "firefox-headless":
                Browser.browser = Browser.play.firefox.launch(channel="firefox",timeout=100000,headless=True,args=['--shm-size=1gb','--crashpad-handler','--disable-dev-shm-usage','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-breakpad','--disable-extensions'])
            elif CommonObject.config["Browser"] == "webkit":
                Browser.browser = Browser.play.webkit.launch(executable_path=CommonObject.project_path + "Drivers\\webkit-1641\\Playwright.exe",timeout=100000,headless=True)
            elif CommonObject.config["Browser"] == "webkit-headless":
                Browser.browser =Browser.play.webkit.launch(executable_path=CommonObject.project_path + "Drivers\\webkit-1641\\Playwright.exe",timeout=100000,headless=True)
        if CommonObject.config["Browser"] == "chrome-persistent-context" or str(CommonObject.config["Browser"]).lower() == "msedge-persistent-context":
            Browser.page = Browser.browser.new_page()
        else:
            Browser.context = Browser.browser.new_context()
            Browser.page = Browser.context.new_page()
        Browser.page.on("response", lambda response: handle_response(response))
        #Browser.page.on('crash', lambda event: custom_crash_handler())
        #Browser.page.on("disconnected", custom_crash_handler())
        # Browser.page.on("pageerror", lambda exc: print(f"uncaught exception: {exc}"))
        # Browser.page.on('console', lambda message: print('Console Log:', message.text))
        # Browser.page.on('requestfailed', lambda request: print('Request Failed:', request.url))
        # Browser.page.on("close", custom_crash_handler())
        if str(CommonObject.config["App Type"]).lower() =="ninja":
            if int(CommonObject.config["Ninjaconnect"])>180000:
                print("Maximum Timeout limit for Ninja is 3 minutes please give less than 3 minutes")
                exit()
            else:
                Browser.page.wait_for_timeout(int(CommonObject.config["Ninjaconnect"]))  # The argument is in millisecond
        Browser.page.goto(CommonObject.config["ApplicationURL"],timeout=1200000)
        #Browser.page.set_viewport_size({"width": 1366, "height": 768})
        Browser.page.set_viewport_size({"width": 1280, "height": 680})
        # if CommonObject.config["ParallelExecution"] == "OFF":
        #     CommonObject.Browserpid = find_browser_process(CommonObject.browsertype)
        #Browser.page.stop_tracing()
        #sys.stdout = Logger(CommonObject.project_path +'Console_log//'+CommonObject.consolefilename)

        return Browser.page



# user_dir = 'tmp\\playwright'
        # user_dir = os.path.join(os.getcwd(), user_dir)
        
        # if not CommonObject.nebularelaunch:
        #     Browser.p = sync_playwright().start()
        # config_file_data = read_config_file("config.properties")
        # CommonObject.config["Ninjaconnect"]=config_file_data['Ninjaconnect']
        # if (config_file_data['Grid_mode'] == "Remote" or config_file_data['Grid_mode'] == "Localhost") and CommonObject.config["ParallelExecution"] == "ON":
        #     if CommonObject.config["Browser"] == "chrome":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,channel="chrome",headless=False)
        #         CommonObject.browsertype = "chrome.exe"
        #     elif CommonObject.config["Browser"] == "chrome-headless":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,channel="chrome",headless=True)
        #     elif CommonObject.config["Browser"] == "edge":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,channel="msedge", headless=False)
        #         CommonObject.browsertype = "msedge.exe"
        #     elif CommonObject.config["Browser"] == "edge-headless":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,channel="msedge", headless=True)

        # else:
        #     if CommonObject.config["Browser"] == "chrome":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,channel="chrome",headless=False)
        #         CommonObject.browsertype = "chrome.exe"
        #     elif CommonObject.config["Browser"] == "chrome-headless":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,channel="chrome",headless=True)
        #     elif CommonObject.config["Browser"] == "chromium":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,executable_path=CommonObject.project_path+"Drivers\\chromium-1005\\chrome-win\\chrome.exe",headless=False)
        #     elif CommonObject.config["Browser"] == "chromium-headless":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,executable_path=CommonObject.project_path+"Drivers\\chromium-1005\\chrome-win\\chrome.exe",headless=True)
        #     elif CommonObject.config["Browser"] == "edge":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,channel="msedge", headless=False)
        #         CommonObject.browsertype="msedge.exe"
        #     elif CommonObject.config["Browser"] == "edge-headless":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,channel="msedge", headless=True)
        #     elif CommonObject.config["Browser"] == "playwright-firefox":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,executable_path=CommonObject.project_path + "Drivers\\firefox-1323\\firefox\\firefox.exe",headless=False)
        #     elif CommonObject.config["Browser"] == "playwright-firefox-headless":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,executable_path=CommonObject.project_path + "Drivers\\firefox-1323\\firefox\\firefox.exe",headless=True)
        #     elif CommonObject.config["Browser"] == "firefox":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,channel="firefox",headless=False)
        #     elif CommonObject.config["Browser"] == "firefox-headless":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,channel="firefox",headless=True)
        #     elif CommonObject.config["Browser"] == "webkit":
        #         Browser.page = Browser.p.chromium.launch_persistent_context(user_data_dir=user_dir,executable_path=CommonObject.project_path + "Drivers\\webkit-1641\\Playwright.exe",headless=True)
        #     elif CommonObject.config["Browser"] == "webkit-headless":
        #         Browser.page = Browser.p.webkit.launch(executable_path=CommonObject.project_path + "Drivers\\webkit-1641\\Playwright.exe",headless=True)