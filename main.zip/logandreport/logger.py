from datetime import datetime
from config.commonobj import CommonObject
from screenlaunch.parallel import read_config_file
config_file_data = read_config_file("config.properties")



def advanced_debug_report(file):
    print("Writing Report")
    RVWRTQS_DISPATCH = ""
    if CommonObject.RVWRTQS_COMPONENT_PARENT_1 == None and CommonObject.RVWRTQS_ACTIVITY_PARENT_1 == None and CommonObject.RVWRTQS_ILBO_PARENT_1 == None and CommonObject.RVWRTQS_EVENTNAME_PARENT_1 == None and CommonObject.RVWRTQS_REQID_PARENT_1==None:
        if CommonObject.RVWRTQS_COMPONENT_CHILD_1 == None and CommonObject.RVWRTQS_ACTIVITY_CHILD_1 == None and CommonObject.RVWRTQS_ILBO_CHILD_1 == None and CommonObject.RVWRTQS_EVENTNAME_CHILD_1 == None and CommonObject.RVWRTQS_REQID_CHILD_1==None:
            CommonObject.RVWRTQS_DISPATCH = ""
        elif CommonObject.RVWRTQS_COMPONENT_CHILD_1 != None and CommonObject.RVWRTQS_ACTIVITY_CHILD_1 != None and CommonObject.RVWRTQS_ILBO_CHILD_1 != None and CommonObject.RVWRTQS_EVENTNAME_CHILD_1 != None and CommonObject.RVWRTQS_REQID_CHILD_1!=None:
            CommonObject.RVWRTQS_DISPATCH = f";{CommonObject.RVWRTQS_COMPONENT_CHILD_1}||{CommonObject.RVWRTQS_ACTIVITY_CHILD_1}||{CommonObject.RVWRTQS_ILBO_CHILD_1}||{CommonObject.RVWRTQS_EVENTNAME_CHILD_1}||{CommonObject.RVWRTQS_REQID_CHILD_1}"
    elif CommonObject.RVWRTQS_COMPONENT_PARENT_1 != None and CommonObject.RVWRTQS_ACTIVITY_PARENT_1 != None and CommonObject.RVWRTQS_ILBO_PARENT_1 != None and CommonObject.RVWRTQS_EVENTNAME_PARENT_1 != None and CommonObject.RVWRTQS_REQID_PARENT_1!=None:
        if CommonObject.RVWRTQS_COMPONENT_CHILD_1 == None and CommonObject.RVWRTQS_ACTIVITY_CHILD_1 == None and CommonObject.RVWRTQS_ILBO_CHILD_1 == None and CommonObject.RVWRTQS_EVENTNAME_CHILD_1 == None and CommonObject.RVWRTQS_REQID_CHILD_1==None:
            CommonObject.RVWRTQS_DISPATCH = f"{CommonObject.RVWRTQS_COMPONENT_PARENT_1}||{CommonObject.RVWRTQS_ACTIVITY_PARENT_1}||{CommonObject.RVWRTQS_ILBO_PARENT_1}||{CommonObject.RVWRTQS_EVENTNAME_PARENT_1}||{CommonObject.RVWRTQS_REQID_PARENT_1};"
        elif CommonObject.RVWRTQS_COMPONENT_CHILD_1 != None and CommonObject.RVWRTQS_ACTIVITY_CHILD_1 != None and CommonObject.RVWRTQS_ILBO_CHILD_1 != None and CommonObject.RVWRTQS_EVENTNAME_CHILD_1 != None and CommonObject.RVWRTQS_REQID_CHILD_1!=None:
            CommonObject.RVWRTQS_DISPATCH = f"{CommonObject.RVWRTQS_COMPONENT_PARENT_1}||{CommonObject.RVWRTQS_ACTIVITY_PARENT_1}||{CommonObject.RVWRTQS_ILBO_PARENT_1}||{CommonObject.RVWRTQS_EVENTNAME_PARENT_1}||{CommonObject.RVWRTQS_REQID_PARENT_1};{CommonObject.RVWRTQS_COMPONENT_CHILD_1}||{CommonObject.RVWRTQS_ACTIVITY_CHILD_1}||{CommonObject.RVWRTQS_ILBO_CHILD_1}||{CommonObject.RVWRTQS_EVENTNAME_CHILD_1}||{CommonObject.RVWRTQS_REQID_CHILD_1}"
    else:
        CommonObject.RVWRTQS_DISPATCH = ""
    CommonObject.executiontime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    CommonObject.exe_end_time = datetime.now().replace(microsecond=0)
    CommonObject.executionduration = CommonObject.exe_end_time - CommonObject.exe_start_time
    CommonObject.executionduration = str(CommonObject.executionduration).replace('0 days ', '')
    df = CommonObject.advanced_log_df
    if CommonObject.login_id == "nan":
        CommonObject.login_id = ""
    CommonObject.serialno = CommonObject.serialno + 1
    if CommonObject.config["ParallelExecution"] == "ON":
        Browser_name = list(config_file_data['Browser'])
        Browser_name = str(Browser_name[CommonObject.process_id1])
    else:
        Browser_name = CommonObject.config["Browser"]
    CommonObject.Build_Version=CommonObject.executable_name
    h=[CommonObject.serialno,CommonObject.navigation_config_id,
                            CommonObject.config["TestConfigID"],
                            CommonObject.config["ApplicationURL"],Browser_name,
                            CommonObject.config["Test Type"],CommonObject.config["JSThemeType"],
                            CommonObject.config["CustomerCode"],CommonObject.config["ProductLine"],
                            CommonObject.config["CUVersion"],CommonObject.config["RTVersion"],
                            CommonObject.config["ProductEnvironment"],CommonObject.config["GUID"],
                            CommonObject.logfoldername,
                            CommonObject.process_name,
                            CommonObject.component_name,CommonObject.activity_name,
                            CommonObject.element,CommonObject.element_value,
                            CommonObject.action,CommonObject.data_value,
                            CommonObject.status,CommonObject.errormessage,CommonObject.executionduration,
                            CommonObject.executiontime,CommonObject.timezone,CommonObject.login_id,CommonObject.PATCH_ID,
                            CommonObject.error_snapshot_filename,CommonObject.imagetostring,
                            str(CommonObject.Build_Version),CommonObject.switchcontext_id,CommonObject.RVWRTQS_DISPATCH,
                            CommonObject.ECR_VERSION]
    debug_list=[]
    for j in h:
        if j=='nan' or j=='NaN' or j== str(None) or j== "NA" or j== None:
            j= ""
        debug_list.append(j)
    df.loc[len(df.index)] =debug_list

    # df.loc[len(df.index)] = [CommonObject.serialno,CommonObject.navigation_config_id,
    #                          CommonObject.config["TestConfigID"],
    #                          CommonObject.config["ApplicationURL"],Browser_name,
    #                          CommonObject.config["Test Type"],CommonObject.config["JSThemeType"],
    #                          CommonObject.config["CustomerCode"],CommonObject.config["ProductLine"],
    #                          CommonObject.config["CUVersion"],CommonObject.config["RTVersion"],
    #                          CommonObject.config["ProductEnvironment"],CommonObject.config["GUID"],
    #                          CommonObject.logfoldername,
    #                          CommonObject.process_name,
    #                          CommonObject.component_name,CommonObject.activity_name,
    #                          CommonObject.element,CommonObject.element_value,
    #                          CommonObject.action,CommonObject.data_value,
    #                          CommonObject.status,CommonObject.errormessage,CommonObject.executionduration,
    #                          CommonObject.executiontime,CommonObject.timezone,CommonObject.login_id,CommonObject.PATCH_ID,
    #                          CommonObject.error_snapshot_filename,CommonObject.imagetostring,
    #                          "built-in-self-test-tool_V2.0"]

    #df['SCREEN_LAUNCH_ERROR']=df['SCREEN_LAUNCH_ERROR'].str.replace(r'"', '')
    #df.to_csv(file,quoting=csv.QUOTE_NONE,index=False,escapechar='\\')
    df.to_csv(file,index=False)
    print("To csv completed")
    CommonObject.errormessage = ""
    CommonObject.screenshotflag = False
    CommonObject.startsWithid = None
    CommonObject.imagetostring = ""
    CommonObject.error_snapshot_filename = ""
    CommonObject.element_value = ""
    CommonObject.element = ""
    CommonObject.action = ""
    CommonObject.data_value =""
    CommonObject.element_value = ""
    CommonObject.element = ""
    CommonObject.action = ""
    CommonObject.data_value = ""
    CommonObject.RVWRTQS_COMPONENT_PARENT_1=None
    CommonObject.RVWRTQS_ACTIVITY_PARENT_1=None
    CommonObject.RVWRTQS_ILBO_PARENT_1=None
    CommonObject.RVWRTQS_EVENTNAME_PARENT_1=None
    CommonObject.Event_turn_count=0
    CommonObject.RVWRTQS_ACTIVITY_CHILD_1=None
    CommonObject.RVWRTQS_ILBO_CHILD_1=None
    CommonObject.RVWRTQS_EVENTNAME_CHILD_1=None
    CommonObject.ECR_VERSION=None
    CommonObject.API_Status=None
    CommonObject.RID_value=None
    CommonObject.plfdispatchid=None