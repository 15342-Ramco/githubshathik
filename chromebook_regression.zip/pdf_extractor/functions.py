import itertools
import numpy as np
import pandas as pd

from PyPDF4 import PdfFileReader
from pdf_extractor.commonObject import pObject
import re
import math


def get_data(sentence, preceed, succeed):
    pObject.deduction_currency_list = None
    if len(pObject.currency_keys) == 0:
        preceed = preceed.rsplit('_', 1)[0]
        start = sentence.index(preceed) + len(preceed)
        if not succeed:
            result = sentence[start:].strip()
        else:
            succeed = succeed.rsplit('_', 1)[0]
            end = sentence.index(succeed)
            result = sentence[start:end].strip()
        return result.removeprefix(":").strip()
    else:
        currency = False
        removeC = ''
        if preceed in pObject.currency_keys.keys():
            currency = True
            removeC = pObject.currency_keys[preceed]
        preceed = preceed.rsplit('_', 1)[0]
        start = sentence.index(preceed) + len(preceed)
        if not succeed:
            if currency:
                result_ref = sentence[start:].strip()
                if '-' + removeC in result_ref:
                    pObject.deduction_currency_list = deduction_currency(result_ref, removeC)
                    result = result_ref.replace('-' + removeC, '').replace(removeC, '')
                else:
                    result = sentence[start:].strip().replace(removeC, '')
            else:
                result = sentence[start:].strip()
        else:
            succeed = succeed.rsplit('_', 1)[0]
            end = sentence.index(succeed)
            if currency:
                result_ref = sentence[start:end].strip()
                if '-' + removeC in result_ref:
                    pObject.deduction_currency_list = deduction_currency(result_ref, removeC)
                    result = result_ref.replace('-' + removeC, '').replace(removeC, '')
                else:
                    result = sentence[start:end].strip().replace(removeC, '')
            else:
                result = sentence[start:end].strip()
        return result.removeprefix(":").strip()


def deduction_currency(result_ref, removeC):
    negCurrency = '-'+removeC
    ref_dict = list_duplicates_of(result_ref.split(), negCurrency)
    data_list = []
    for k, v in ref_dict.items():
        data_list.append(result_ref.split()[v+1])
    return data_list


def execution_time(seconds):
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return hours, minutes, seconds


def add_key(index_dict, keys_list, line):
    for key in keys_list:
        if key in line:
            if not pObject.subset_superset:
                index_dict[line.index(key)] = key
            else:
                if key in pObject.subset_superset.keys():
                    elementFound = False
                    for element in pObject.subset_superset[key]:
                        if element in line:
                            elementFound = True
                            index_dict[line.index(element)] = element
                            break
                    if not elementFound:
                        index_dict[line.index(key)] = key
                else:
                    index_dict[line.index(key)] = key


def addTable_key(index_dict, line, keys_list):
    for key in keys_list:
        key_ref = key.rsplit('_', 1)[0]
        if len(key.rsplit('_', 1)) > 1:
            suffix = '_' + key.rsplit('_', 1)[1]
        else:
            suffix = ''
        if key_ref in line:
            if not pObject.subset_superset:
                if not pObject.duplicateTable_elements:
                    index_dict[line.index(key_ref)] = key_ref + suffix
                else:
                    if key_ref in pObject.duplicateTable_elements.keys():
                        return_table = returnKey_table(key)
                        if return_table == pObject.needed_table:
                            index_dict[line.index(key_ref)] = key_ref + suffix
                    else:
                        index_dict[line.index(key_ref)] = key_ref + suffix

            else:
                if not pObject.duplicateTable_elements:
                    if key_ref in pObject.subset_superset.keys():
                        elementFound = False
                        for element in pObject.subset_superset[key_ref]:
                            if element in line:
                                elementFound = True
                                index_dict[line.index(element)] = element + suffix
                                break
                        if not elementFound:
                            index_dict[line.index(key_ref)] = key_ref + suffix
                    else:
                        index_dict[line.index(key_ref)] = key_ref + suffix

                else:
                    if key_ref in pObject.subset_superset.keys() and key_ref in pObject.duplicateTable_elements.keys():
                        return_table = returnKey_table(key)
                        if return_table == pObject.needed_table:
                            elementFound = False
                            for element in pObject.subset_superset[key_ref]:
                                if element in line:
                                    elementFound = True
                                    index_dict[line.index(element)] = element + suffix
                                    break
                            if not elementFound:
                                index_dict[line.index(key_ref)] = key_ref + suffix

                    elif key_ref in pObject.duplicateTable_elements.keys():
                        return_table = returnKey_table(key)
                        if return_table == pObject.needed_table:
                            index_dict[line.index(key_ref)] = key_ref + suffix

                    else:
                        if key_ref in pObject.subset_superset.keys():
                            elementFound = False
                            for element in pObject.subset_superset[key_ref]:
                                if element in line:
                                    elementFound = True
                                    index_dict[line.index(element)] = element + suffix
                                    break
                            if not elementFound:
                                index_dict[line.index(key_ref)] = key_ref + suffix
                        else:
                            index_dict[line.index(key_ref)] = key_ref + suffix


def returnKey_table(key):
    for k, v in pObject.table_data.items():
        for element in v:
            if element == key:
                return k


def move_rows(data_df, df_sub, row_number):
    if row_number == 'last':
        df_result = pd.concat([df_sub, data_df])
    else:
        df1 = df_sub[0:row_number]
        df2 = df_sub[row_number:]
        df_result = pd.concat([df1, data_df, df2])
    return df_result


def elementTable_check(pdfObject, tableName, pdf_lines):
    x0, y0, x1, y1 = None, None, None, None
    elements_list = pObject.table_data[tableName]
    for line in pdf_lines:
        for element in elements_list:
            ele = element.rsplit('_', 1)[0]
            if ele in line:
                label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(ele))
                x0, y0, x1, y1 = float(label.attr('x0')), float(label.attr('y0')), float(label.attr('x1')), float(label.attr('y1'))
                break
    return [x0, y0, x1, y1]


def sort_label_dict(input_dict, base_head):
    data_list = []
    for k, v in input_dict.items():
        data_list.append(v)
    df = pd.DataFrame(columns=['x0', 'y0', 'x1', 'y1'], data=data_list)
    df.sort_values(by=['y0'], inplace=True, ascending=False)
    df.sort_values(by=['x0'], inplace=True)
    df.reset_index(drop=True, inplace=True)
    updated = {}
    for i in range(df.shape[0]):
        updated[base_head + '_' + str(i+1)] = [df.loc[i, 'x0'], df.loc[i, 'y0'], df.loc[i, 'x1'], df.loc[i, 'y1']]
    return updated


def yaxis_filter(input_dict, header_Yaxis):
    output = {}
    for k, v in input_dict.items():
        if v[1] == header_Yaxis:
            output[k] = v
    return output


def tableCount_check(input_dict, base_head):
    output_final = {}
    for k, v in input_dict.items():
        if k.count(base_head) > 1:
            for i in range(k.count(base_head)):
                output_final[k + '_' + str(i)] = v
        else:
            output_final[k] = v
    return output_final


def getHeader_Yaxis(tableName):
    table_name = tableName + '_table'
    for k, v in pObject.gTable_headers.items():
        if k.lower() == table_name.lower():
            store = v[list(v.keys())[0]]
            return store[1]


def update_getTable_header(pdfObject, tableName, keys_list):
    exactMatch = False
    uniqueLabel = False
    base_head = tableName.rsplit('_', 1)[0]
    base_label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(base_head))
    temp_label_dict_0 = {}
    for counter, i in enumerate(base_label.items('LTTextLineHorizontal')):
        temp_label_dict_0[i.text() + '_' + str(counter+1)] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]

    header_Yaxis = getHeader_Yaxis(base_head)
    temp_label_dict_1 = yaxis_filter(temp_label_dict_0, header_Yaxis)
    temp_label_dict_2 = tableCount_check(temp_label_dict_1, base_head)
    temp_label_dict = sort_label_dict(temp_label_dict_2, base_head)
    label_dict = {}
    label_dict[base_head] = temp_label_dict[tableName]
    base_x0, base_y0, base_x1, base_y1, base_Ymean = None, None, None, None, None
    for k, v in label_dict.items():
        if k == base_head:
            base_x0, base_y0, base_x1, base_y1 = v[0], v[1], v[2], v[3]
            base_Ymean = (base_y0 + base_y1) / 2
            exact_tableName = [key for key, value in pObject.raw_headers.items() if base_head == key.rsplit('_', 1)[0]][0]
            exactMatch = store_coordinate(pdfObject, exact_tableName, base_Ymean, base_y0, base_y1, base_x0)

    if not exactMatch:
        residual_labels = [key for key in label_dict.keys() if key not in keys_list]
        if len(residual_labels) == 1:
            values = label_dict[residual_labels[0]]
            base_x0, base_y0, base_x1, base_y1 = values[0], values[1], values[2], values[3]
            base_Ymean = (base_y0 + base_y1) / 2
            exact_tableName = [key for key, value in pObject.raw_headers.items() if base_head == key.rsplit('_', 1)[0]][0]
            uniqueLabel = store_coordinate(pdfObject, exact_tableName, base_Ymean, base_y0, base_y1, base_x0)

    if not exactMatch and not uniqueLabel:
        table_heads = pObject.raw_headers[tableName]
        firstHead = table_heads[0]
        head_label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(firstHead))
        hX0, hY0, hX1, hY1, h_Ymean = None, None, None, None, None
        for i in head_label.items('LTTextLineHorizontal'):
            if i.text() == firstHead:
                hX0, hY0, hX1, hY1 = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]
                h_Ymean = (hY0 + hY1) / 2
        for k, v in label_dict.items():
            if (h_Ymean >= v[1] and h_Ymean <= v[3]) or (base_y0 >= v[1] and base_y0 <= v[3]) or (base_y1 >= v[1] and base_y1 <= v[3]):
                base_x0, base_y0, base_x1, base_y1 = v[0], v[1], v[2], v[3]
                base_Ymean = (base_y0 + base_y1) / 2
        exact_tableName = [key for key, value in pObject.raw_headers.items() if base_head == key.rsplit('_', 1)[0]][0]
        result = store_coordinate(pdfObject, exact_tableName, base_Ymean, base_y0, base_y1, base_x0)


def getTable_header(pdfObject, tableName, keys_list, pdf_lines):
    if tableName in pObject.raw_headers_alignment.keys():
        fl_x0, fl_y0, fl_x1, fl_y1 = elementTable_check(pdfObject, tableName, pdf_lines)
        exactMatch = False
        base_head = tableName.rsplit('_', 1)[0]
        base_label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(base_head))
        label_dict = {}
        label_counter = 0
        for i in base_label.items('LTTextLineHorizontal'):
            if i.text() in label_dict.keys():
                label_counter += 1
                label_dict[i.text() + '~' + str(label_counter)] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]
            else:
                label_dict[i.text()] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]

        for k, v in label_dict.items():
            if k.rsplit('~', 1)[0] == base_head:
                base_x0, base_y0, base_x1, base_y1 = v[0], v[1], v[2], v[3]
                exactMatch = store_coordinate_alignment(pdfObject, tableName, fl_y0, base_y0, base_x0)
                if exactMatch:
                    break

        if not exactMatch:
            residual_labels = [key for key in label_dict.keys() if key.rsplit('~', 1)[0] not in keys_list]
            if len(residual_labels) == 1:
                values = label_dict[residual_labels[0]]
                base_x0, base_y0, base_x1, base_y1 = values[0], values[1], values[2], values[3]
                result = store_coordinate_alignment(pdfObject, tableName, fl_y0, base_y0, base_x0)

    else:
        exactMatch = False
        uniqueLabel = False
        base_head = tableName.rsplit('_', 1)[0]
        base_label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(base_head))
        label_dict = {}
        label_counter = 0
        for i in base_label.items('LTTextLineHorizontal'):
            if i.text() in label_dict.keys():
                label_counter += 1
                label_dict[i.text() + '~' + str(label_counter)] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]
            else:
                label_dict[i.text()] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]

        base_x0, base_y0, base_x1, base_y1, base_Ymean = None, None, None, None, None
        for k, v in label_dict.items():
            if k.rsplit('~', 1)[0] == base_head:
                base_x0, base_y0, base_x1, base_y1 = v[0], v[1], v[2], v[3]
                base_Ymean = (base_y0 + base_y1) / 2
                exactMatch = store_coordinate(pdfObject, tableName, base_Ymean, base_y0, base_y1, base_x0)
                if exactMatch:
                    break

        if not exactMatch:
            residual_labels = [key for key in label_dict.keys() if key.rsplit('~', 1)[0] not in keys_list]
            if len(residual_labels) == 1:
                values = label_dict[residual_labels[0]]
                base_x0, base_y0, base_x1, base_y1 = values[0], values[1], values[2], values[3]
                base_Ymean = (base_y0 + base_y1) / 2
                uniqueLabel = store_coordinate(pdfObject, tableName, base_Ymean, base_y0, base_y1, base_x0)

        if not exactMatch and not uniqueLabel:
            table_heads = pObject.raw_headers[tableName]
            firstHead = table_heads[0]
            head_label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(firstHead))
            hX0, hY0, hX1, hY1, h_Ymean = None, None, None, None, None
            for i in head_label.items('LTTextLineHorizontal'):
                if i.text() == firstHead:
                    hX0, hY0, hX1, hY1 = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]
                    h_Ymean = (hY0 + hY1) / 2
            for k, v in label_dict.items():
                if (h_Ymean >= v[1] and h_Ymean <= v[3]) or (base_y0 >= v[1] and base_y0 <= v[3]) or (base_y1 >= v[1] and base_y1 <= v[3]):
                    base_x0, base_y0, base_x1, base_y1 = v[0], v[1], v[2], v[3]
                    base_Ymean = (base_y0 + base_y1) / 2
            result = store_coordinate(pdfObject, tableName, base_Ymean, base_y0, base_y1, base_x0)


def store_coordinate(pdfObject, tableName, base_Ymean, base_y0, base_y1, base_x0):
    boolean = False
    head_store = {}
    for header in pObject.raw_headers[tableName]:
        label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(header))
        head_dict = {}
        for number, i in enumerate(label.items('LTTextLineHorizontal')):
            head_dict['head{}'.format(number)] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]

        interim_store = {}
        for key, val in head_dict.items():
            x0, y0, x1, y1 = val[0], val[1], val[2], val[3]
            if (base_Ymean >= y0 and base_Ymean <= y1) or (base_y0 >= y0 and base_y0 <= y1) or (base_y1 >= y0 and base_y1 <= y1):
                if x0 > base_x0:
                    interim_store[x0] = key

        if not interim_store:
            pass
        elif len(interim_store) == 1:
            for k, v in interim_store.items():
                head_store[header] = head_dict[v]
            pObject.gTable_headers[tableName] = head_store
        else:
            sorted_keys = list(sorted(interim_store.keys()))
            head_store[header] = head_dict[interim_store[sorted_keys[0]]]
            pObject.gTable_headers[tableName] = head_store

    if tableName in pObject.gTable_headers.keys():
        boolean = verify_heads(tableName)
    return boolean


def store_coordinate_alignment(pdfObject, tableName, fl_y0, base_y0, base_x0):
    boolean = False
    head_store = {}
    for header in pObject.raw_headers[tableName]:
        label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(header))
        head_dict = {}
        for number, i in enumerate(label.items('LTTextLineHorizontal')):
            head_dict['head{}'.format(number)] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]

        interim_store = {}
        for key, val in head_dict.items():
            x0, y0, x1, y1 = val[0], val[1], val[2], val[3]
            if y0 > fl_y0 and y0 < base_y0:
                if x0 > base_x0:
                    interim_store[x0] = key

        if not interim_store:
            pass
        elif len(interim_store) == 1:
            for k, v in interim_store.items():
                head_store[header] = head_dict[v]
            pObject.gTable_headers[tableName] = head_store
        else:
            sorted_keys = list(sorted(interim_store.keys()))
            head_store[header] = head_dict[interim_store[sorted_keys[0]]]
            pObject.gTable_headers[tableName] = head_store

    if tableName in pObject.gTable_headers.keys():
        boolean = verify_heads(tableName)
    return boolean


def verify_heads(tableName):
    counter = 0
    for x in pObject.raw_headers[tableName]:
        if x in pObject.gTable_headers[tableName].keys():
            counter += 1
    if len(pObject.raw_headers[tableName]) == counter:
        return True
    else:
        return False


def getData_by_query(pdfObject, table_name, header, elementName, values_list):
    table = pObject.gTable_headers[table_name]
    header_coordinates = table[header]
    header_x0 = header_coordinates[0]
    header_x1 = header_coordinates[2]
    header_mean = (header_x0 + header_x1)/2

    value_dict = {}
    value_output = ''
    valueCounter = 0
    for value in values_list:
        label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(value))
        label_dict = {}
        for number, i in enumerate(label.items('LTTextLineHorizontal')):
            label_dict['head{}'.format(number)] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]

        if len(label_dict) == 1:
            for k, v in label_dict.items():
                value_dict['value{}'.format(valueCounter)] = {value: v}
                valueCounter +=1

        else:
            key_label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(elementName))
            if not key_label:
                elementName = " ".join(elementName.split())
                key_label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(elementName))

            key_y0, key_y1 = float(key_label.attr('y0')), float(key_label.attr('y1'))
            key_Ymean = (key_y0 + key_y1)/2
            for k, v in label_dict.items():
                y0, y1 = v[1], v[3]
                if (key_Ymean > y0 and key_Ymean < y1) or (key_y0 >= y0 and key_y0 <= y1) or (key_y1 >= y0 and key_y1 <= y1):
                    value_dict['value{}'.format(valueCounter)] = {value: v}
                    valueCounter += 1

    pObject.value_coordinate[elementName + '_' + header] = value_dict
    for vals in value_dict.values():
        for k, v in vals.items():
            x0, x1 = v[0], v[2]
            if (header_mean > x0 and header_mean < x1) or (header_x0 >= x0 and header_x0 <= x1) or (header_x1 >= x0 and header_x1 <= x1):
                value_output = k

    return value_output


def storeTable_heads(keys_list, tables_present):
    for table in tables_present:
        heads_align = []
        heads = []
        table_index = keys_list.index(table)
        while True:
            table_index += 1
            if '_' in keys_list[table_index]:
                break
            else:
                if '~' in keys_list[table_index]:
                    colName = keys_list[table_index].split('~')[0]
                    heads.append(colName)
                    heads_align.append(keys_list[table_index])
                else:
                    heads.append(keys_list[table_index])
        pObject.raw_headers[table] = heads
        pObject.raw_headers_alignment[table] = heads_align
        pObject.raw_headers_alignment = {k: v for (k, v) in pObject.raw_headers_alignment.items() if v != []}


def storeTable_elements(table_data, keys_list, tables_present):
    for table in tables_present:
        table_index = keys_list.index(table)
        heads = pObject.raw_headers[table]
        elements = []
        while True:
            table_index += 1
            if table_index > len(keys_list) - 1:
                break
            elif keys_list[table_index] in tables_present:
                break
            for head in heads:
                if '_' + head in keys_list[table_index]:
                    elements.append(keys_list[table_index])
        table_data[table] = elements


def fetchTable_elements(table_data):
    table_info = {}
    for k, v in table_data.items():
        table_info[k] = [x.rsplit('_')[0] for x in v]
    return table_info


def table_check(line, pdf_lines, index):
    table_found = False
    for k, v in pObject.raw_headers.items():
        if k.rsplit('_', 1)[0] in line:
            if k in pObject.raw_headers_alignment.keys():
                counter = 0
                for header in pObject.raw_headers_alignment[k]:
                    head_name = header.split('~')[0]
                    row = re.search(r'[+-]\d+', header.split('~')[1]).group()
                    header_line = pdf_lines[index + eval(row)]
                    if head_name in header_line:
                        counter += 1
                if counter == len(v):
                    pObject.tableIteration[k] = pObject.table_data[k]
                    pObject.tableIteration_noSuffix[k] = pObject.table_info[k]
                    pObject.current_tables.append(k)
                    table_found = True
            else:
                counter = 0
                for header in v:
                    if header in line:
                        counter += 1
                if counter == len(v):
                    pObject.tableIteration[k] = pObject.table_data[k]
                    pObject.tableIteration_noSuffix[k] = pObject.table_info[k]
                    pObject.current_tables.append(k)
                    table_found = True

    return table_found


def get_occurrence(line):
    for k, v in pObject.raw_headers.items():
        if k.rsplit('_', 1)[0] in line and line.count(k.rsplit('_', 1)[0]) > 1:
            tableName_index = list_duplicates_of(line, k.rsplit('_', 1)[0])
            val_update_dict = {}
            for x in v:
                val_update_dict.update(list_duplicates_of(line, x))
            output_list = []
            for key, value in tableName_index.items():
                if list({a.rsplit('_', 1)[0]: b for a, b in val_update_dict.items()}.keys()) == pObject.raw_headers[k]:
                    if check(list(val_update_dict.values()), value):
                        output_list.append(value)

            output_list.sort()
            if len(output_list) == 0:
                return None
            else:
                return list(tableName_index.keys())[list(tableName_index.values()).index(output_list[-1])]


def list_duplicates_of(seq, item):
    start_at = -1
    locs = []
    dictionary = {}
    while True:
        try:
            loc = seq.index(item, start_at+1)
        except ValueError:
            break
        else:
            locs.append(loc)
            start_at = loc
    for i, x in enumerate(locs):
        dictionary[item + '_' + str(i+1)] = x
    return dictionary


def check(input_list, val):
    for x in input_list:
        if val>= x:
            return False
    return True


def checkTable_end(line, table_info, skip_list, index):
    flag = False
    alignFlag = False
    if index in skip_list:
        flag = True
        alignFlag = True
    else:
        for k, v in pObject.tableIteration_noSuffix.items():
            for element in v:
                if element in line:
                    flag = True
    return [flag, alignFlag]


def nearby(lst, table_index):
    next_index = next(x[0] for x in enumerate(lst) if x[1] >= table_index)
    result = lst[next_index] + 1
    return result


def skip_lines(pdf_lines, skip_keys):
    skip_dict = {}
    table_index = None
    table_name = None
    for index, line in enumerate(pdf_lines):
        for key in skip_keys:
            if '_table' in key.lower():
                table_name = key.rsplit('_', 1)[0]
            if key.find('_') != -1:
                key = key.rsplit('_', 1)[0]
            elif key.find('~') != -1:
                key = key.rsplit('~', 1)[0]
            if key in line:
                if key == table_name:
                    table_index = index
                if key in skip_dict.keys():
                    existing_list = skip_dict[key]
                    existing_list.extend([index])
                    skip_dict[key] = existing_list
                else:
                    skip_dict[key] = [index]
    result = {k:nearby(v, table_index) for k,v in skip_dict.items()}
    return list(result.values())


def getTable_name(label):
    tableName = [k for k, v in pObject.tableIteration.items() if label in v]
    if len(tableName) == 1:
        result = tableName[0]
    else:
        tableName = [k for k, v in pObject.tableIteration_noSuffix.items() if label in v]
        if len(tableName) == 1:
            result = tableName[0]
        else:
            result = 'Non tabular element'
    return result


def subset_superset(keys_list):
    subsetsuperset={}
    l=[]
    for g in keys_list:
        h=[]
        g=g.rsplit("_",1)[0]
        for u in keys_list:
            u=u.rsplit("_",1)[0]
            if u.find(g) != -1:
                if len(u)!=len(g):
                    h.append(u)
            else:
                pass
        if len(h)!=0:
            subsetsuperset[g]=h
    return subsetsuperset


def pair_keys(line, valueline_dict, keys_list):
    index_dict = {}
    add_key(index_dict, keys_list, line)
    occurence = ""
    for k, v in index_dict.items():
        if valueline_dict[v].lower() == "next":
            occurence = "next"
        elif valueline_dict[v].lower() == "previous":
            occurence = "previous"
    return occurence, index_dict


def pair_data(occurence, datatype_dict, filter_index_dict, index, pdf_lines, pdfObject):
    output_list=[]
    key = list(filter_index_dict.keys())
    values = list(filter_index_dict.values())
    sorted_value_index = np.argsort(key)
    sorted_dict = {key[i]: values[i] for i in sorted_value_index}
    basekey = ""
    for ke, va in datatype_dict.items():
        if str(va).lower() == "continuous":
            basekey = str(ke)
    if basekey == "":
        r_split = False
    else:
        base_index = list(filter_index_dict.keys())[list(filter_index_dict.values()).index(basekey)]
        r_split = False
        for k, v in filter_index_dict.items():
            if int(base_index) >= int(k):
                r_split = True
            else:
                r_split = False
    if occurence =="previous":
        if r_split:
            output_list = pdf_lines[index - 1].strip().rsplit(" ",1)
        else:
            output_list = pdf_lines[index - 1].strip().split(" ",1)
    elif occurence =="next":
        if r_split:
            output_list = pdf_lines[index + 1].strip().rsplit(" ",1)
        else:
            output_list = pdf_lines[index + 1].strip().split(" ",1)
    sorted_keys = list(sorted_dict.values())
    stored_dict = {sorted_keys[i]: output_list[i] for i in range(len(sorted_keys))}
    for key, value in stored_dict.items():
        if key in pObject.splitLines_keys:
            data_addOn = get_dataAddon(pdfObject, value, key)
            stored_dict[key] = data_addOn
    return stored_dict


def duplicateTable_elements(table_info):
    flipped = {}
    for key, value in table_info.items():
        for v in value:
            if v not in flipped:
                flipped[v] = [key]
            else:
                flipped[v].append(key)
    result = {k: list(set(v)) for k, v in flipped.items() if len(v) > 1}
    result = {k: v for k, v in result.items() if len(v) > 1}
    return result


def neededTable():
    new_list = []
    for table in pObject.current_tables:
        for values in pObject.duplicateTable_elements.values():
            if table in values:
                new_list.append(table)
    if len(new_list) >=1:
        return new_list[0]
    else:
        return new_list


def output_data(output_type, data):
    result = None
    if output_type.lower() == 'numeric':
        result = re.match('[-+0-9.]+', data).group()
    elif output_type.lower() == 'words':
        result = re.sub(r'[^A-Za-z ]+', '', data).strip()
    return result


def getMultirow_data(keys_list):
    store = {}
    lst = []
    for key in keys_list:
        if '_multirows stop' in key.lower():
            store[key.rsplit('_', 1)[0]] = lst
            lst = []
            continue
        if '_multirows' in key.lower():
            lst.append(key.rsplit('_', 1)[0])
    return store


def multiRow_check(line):
    multiRow_flag = False
    for k, v in pObject.multirows_dict.items():
        counter = 0
        for element in v:
            if element in line:
                counter += 1
        if counter == len(v):
            multiRow_flag = True
            pObject.multiRows_exit = k
            break
    return multiRow_flag


def multiRow_stopCheck(line):
    flag = False
    if pObject.multiRows_exit in line:
        flag = True
    return flag


def getData_multiRow(line):
    output = {}
    col_list = pObject.multirows_dict[pObject.multiRows_exit]
    pObject.multiRow_range += 1
    currency_index = multiRow_currencyCheck()
    if len(currency_index) == 0:
        data = line.split()
        data = data[-1::-1]
        for index, i in enumerate(reversed(col_list)):
            if index == len(col_list) - 1:
                output[i + '_' + str(pObject.multiRow_range)] = " ".join(data[index:][-1::-1])
            else:
                output[i + '_' + str(pObject.multiRow_range)] = data[index]
    else:
        line = line.replace(list(pObject.multiRow_currency_keys.values())[0], '')
        data = line.split()
        data = data[-1::-1]
        for index, i in enumerate(reversed(col_list)):
            if index == len(col_list) - 1:
                output[i + '_' + str(pObject.multiRow_range)] = " ".join(data[index:][-1::-1])
            else:
                output[i + '_' + str(pObject.multiRow_range)] = data[index]
        for x in currency_index:
            ele_name = col_list[x] + '_' + str(pObject.multiRow_range)
            output[ele_name] = list(pObject.multiRow_currency_keys.values())[0] + ' ' + output[ele_name]
    return output


def multiRow_currencyCheck():
    currency_index = []
    col_list = pObject.multirows_dict[pObject.multiRows_exit]
    for multiKey in pObject.multiRow_currency_keys.keys():
        if multiKey.rsplit('_', 1)[0] in col_list:
            currency_index.append(col_list.index(multiKey.rsplit('_', 1)[0]))
    return currency_index


def filterTable_keys_list(keys_list):
    uncommon_dict = {k: v for k, v in pObject.table_data.items() if k not in pObject.tableIteration.keys()}
    keys_list_temp = []
    for x in keys_list:
        if x in list(uncommon_dict.keys()) or x in list(
                itertools.chain(*[uncommon_dict[x] for x in list(uncommon_dict.keys())])):
            pass
        else:
            keys_list_temp.append(x)
    return keys_list_temp


def generate_boundingBox(table_name):
    box = {}
    given_dict = pObject.gTable_headers[table_name]
    partitions = []
    for count, (ke, va) in enumerate(given_dict.items()):
        if count == len(given_dict) - 1:
            x0, y0, x1, y1 = va[0], va[1], va[2], va[3]
            box[ke] = [partitions[count - 1], (x0 - partitions[count - 1]) + x1]
        else:
            x0, y0, x1, y1 = va[0], va[1], va[2], va[3]
            next = list(given_dict.values())[count + 1]
            nx0, ny0, nx1, ny1 = next
            partition = (x1 + nx0) / 2
            if count == 0:
                wall = x0 - (partition - x1)
                box[ke] = [wall, partition]
            else:
                box[ke] = [partitions[count - 1], partition]
            partitions.append(partition)
    return box


def generateMultirow_boundingBox(given_dict):
    box = {}
    partitions = []
    for count, (ke, va) in enumerate(given_dict.items()):
        if count == len(given_dict) - 1:
            x0, y0, x1, y1 = va[0], va[1], va[2], va[3]
            box[ke] = [partitions[count - 1], (x0 - partitions[count - 1]) + x1]
        else:
            x0, y0, x1, y1 = va[0], va[1], va[2], va[3]
            next = list(given_dict.values())[count + 1]
            nx0, ny0, nx1, ny1 = next
            partition = (x1 + nx0) / 2
            if count == 0:
                wall = x0 - (partition - x1)
                if wall < 100.00:
                    box[ke] = [0.00, partition]
                else:
                    box[ke] = [wall, partition]
            else:
                box[ke] = [partitions[count - 1], partition]
            partitions.append(partition)
    return box


def getData_by_BB(bounding_box):
    output = {}
    for k, v in pObject.value_coordinate.items():
        head_name = k.rsplit('_', 1)[1]
        boundary = bounding_box[head_name]
        for ke, va in v.items():
            for key, val in va.items():
                x0, x1 = val[0], val[2]
                if (x0 > boundary[0] and x0 < boundary[1]):
                    output[k] = key
    return output


def getBoxing_dict(boxing_keys):
    result = {}
    for element in boxing_keys:
        for k, v in pObject.multirows_dict.items():
            if element.rsplit('_', 1)[0] in v:
                result[k] = v
    return result


def return_elementCoordinate(pdfObject, element):
    label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(element))
    label_dict = {}
    for number, i in enumerate(label.items('LTTextLineHorizontal')):
        label_dict[element + '_{}'.format(number)] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]
    return label_dict


def getMultiRow_head_coordinate(pdfObject):
    head_list = pObject.multirows_dict[pObject.multiRows_exit]
    store_list = []
    for head in head_list:
        store_list.append(return_elementCoordinate(pdfObject, head))

    y_list = []
    for store in store_list:
        for k, v in store.items():
            y_list.append(v[1])

    count_dict = {x: y_list.count(x) for x in y_list}
    y_check = ''
    for k, v in count_dict.items():
        if v == len(head_list):
            y_check = k

    result = {}
    for store in store_list:
        for k, v in store.items():
            if y_check in v:
                result[k.rsplit('_', 1)[0]] = v
    return result


def getMultiRow_exit_coordinate(pdfObject):
    exit_label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(pObject.multiRows_exit))
    temp_dict = {}
    for counter, i in enumerate(exit_label.items('LTTextLineHorizontal')):
        temp_dict[str(counter + 1)] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]
    temp_dict = {k: v for k, v in temp_dict.items() if v[1] < list(pObject.multiRows_headCoordinate_dict.values())[0][1]}
    df = pd.DataFrame(columns=['x0', 'y0', 'x1', 'y1'], data=[v for k, v in temp_dict.items()])
    df.sort_values(by=['y0'], inplace=True, ascending=False)
    df.reset_index(drop=True, inplace=True)
    updated = []
    for i in range(df.shape[0]):
        updated.append([df.loc[i, 'x0'], df.loc[i, 'y0'], df.loc[i, 'x1'], df.loc[i, 'y1']])
    return updated[0]


def getData_multiRowBox(line, pdfObject):
    output = {}
    col_list = pObject.multirows_dict[pObject.multiRows_exit]
    pObject.multiRow_range += 1
    currency_index = multiRow_currencyCheck()

    if len(currency_index) == 0:
        pObject.multiRows_lineData = line.split()
        for head in col_list:
            getDataMultirow_by_BB(head, pObject.multiRows_lineData, pdfObject, output)

    else:
        line = line.replace(list(pObject.multiRow_currency_keys.values())[0], '')
        pObject.multiRows_lineData = line.split()
        for head in col_list:
            getDataMultirow_by_BB(head, pObject.multiRows_lineData, pdfObject, output)

        for x in currency_index:
            ele_name = col_list[x] + '_' + str(pObject.multiRow_range)
            output[ele_name] = list(pObject.multiRow_currency_keys.values())[0] + ' ' + output[ele_name]

    return output


def getDataMultirow_by_BB(head, data, pdfObject, output):
    boundary = pObject.boundingBox_dict[head]
    data_used = []
    unused = [data_used.append(x) for x in data if x not in data_used]
    for element in data_used:
        counter = 0
        value_coordinate = return_elementCoordinate(pdfObject, element)
        for ke, va in value_coordinate.items():
            x0, y0, x1, y1 = va[0], va[1], va[2], va[3]
            if (x0 > boundary[0]) and (x0 < boundary[1]):
                col_co = pObject.multiRows_headCoordinate_dict[head]
                cy0, cy1 = col_co[1], col_co[3]
                if (y1 < cy0) and (y0 > pObject.multiRows_exitCoordinate[3]):
                    counter += 1
                    if counter == 1:
                        pObject.multiRows_lineData.remove(element)
                        if head + '_' + str(pObject.multiRow_range) in output.keys():
                            output[head + '_' + str(pObject.multiRow_range)] = output[head + '_' + str(pObject.multiRow_range)] + ' ' + element
                        else:
                            output[head + '_' + str(pObject.multiRow_range)] = element


def remove_currency(df, currency):
    for i in range(df.shape[0]):
        for j in df.columns:
            if df.loc[i, j] == currency + ' ':
                df.loc[i, j] = ''
    return df


def get_key(val, my_dict):
    for key, value in my_dict.items():
        if val == value:
            return key


def get_keysGeometry(pdfObject, index_dict):
    label_dict = {}
    temp_dict = {}
    for key in list(index_dict.values()):
       key = key.rsplit('_', 1)[0]
       label = pdfObject.pq('LTTextLineHorizontal:contains("{}")'.format(key))
       for number, i in enumerate(label.items('LTTextLineHorizontal')):
           temp_dict[key + '_{}'.format(number)] = [float(i.attr('x0')), float(i.attr('y0')), float(i.attr('x1')), float(i.attr('y1'))]

    # getting same level key coordinates
    values_lst = list(temp_dict.values())
    for order, elements in enumerate(values_lst):
        for i in range(order + 1, len(values_lst)):
            # if elements[1] == values_lst[i][1] and elements[3] == values_lst[i][3]:
            if math.isclose(elements[1], values_lst[i][1], abs_tol= 1.00) and math.isclose(elements[3], values_lst[i][3], abs_tol= 1.00):
                label_dict[get_key(elements, temp_dict).rsplit('_', 1)[0]] = elements
                label_dict[get_key(values_lst[i], temp_dict).rsplit('_', 1)[0]] = values_lst[i]

    # sorting label_dict ascending
    data_list = []
    for k, v in label_dict.items():
        vals = v
        vals.append(k)
        data_list.append(vals)
    df = pd.DataFrame(columns=['x0', 'y0', 'x1', 'y1', 'key'], data=data_list)
    df.sort_values(by=['y0'], inplace=True, ascending=False)
    df.sort_values(by=['x0'], inplace=True)
    df.reset_index(drop=True, inplace=True)
    updated_label_dict = {}
    for i in range(df.shape[0]):
        updated_label_dict[df.loc[i, 'key']] = [df.loc[i, 'x0'], df.loc[i, 'y0'], df.loc[i, 'x1'], df.loc[i, 'y1']]

    # generate boundaries
    box = {}
    partitions = []
    for count, (ke, va) in enumerate(updated_label_dict.items()):
        if count == len(updated_label_dict) - 1:
            box[ke] = [partitions[count - 1], 1000.00]
        else:
            x0, y0, x1, y1 = va[0], va[1], va[2], va[3]
            next = list(updated_label_dict.values())[count + 1]
            nx0, ny0, nx1, ny1 = next
            if count == 0:
                box[ke] = [x0, nx0]
            else:
                box[ke] = [partitions[count - 1], nx0]
            partitions.append(nx0)

    return [updated_label_dict, box]


def get_dataAddon(pdfObject, initial_text, keyName):
    text_list = pdfObject.tree.xpath("//text()")
    text_list = [x.strip() for x in text_list]
    result = initial_text
    try:
        index = text_list.index(initial_text)
    except ValueError:
        try:
            initial_text = " ".join(initial_text.split())
            index = text_list.index(initial_text)
        except ValueError:
            initial_text = " ".join(initial_text.split())
            indices = [i for i, text in enumerate(text_list) if initial_text in text]
            index = indices[0]

    trim = False
    if keyName in pObject.trim_keys:
        trim = True
    counter = 0
    while True:
        index += 1
        if text_list[index] == '':
            break
        else:
            if trim:
                result = result + text_list[index]
                pObject.stored_addOns.append(text_list[index])
                counter += 1
                if pObject.addOns_counter < counter:
                    pObject.addOns_counter = counter
            else:
                result = result + ' ' + text_list[index]
                pObject.stored_addOns.append(text_list[index])
                counter += 1
                if pObject.addOns_counter < counter:
                    pObject.addOns_counter = counter
    return result.strip()


def update_data(input_data):
    result = input_data
    for x in pObject.stored_addOns:
        pattern = re.compile(x)
        if pattern.search(input_data):
            result = result.replace(x, '').strip()
    return result


def get_nonTabular_keys(keys_list):
    heads = [x for v in pObject.raw_headers.values() for x in v]
    elements = [x for v in pObject.table_data.values() for x in v]
    tableNames = list(pObject.raw_headers.keys())
    nonTabular_keys = [key for key in keys_list if key not in heads and key not in elements and key not in tableNames]
    return nonTabular_keys


def get_tableHeadLine_data(line):
    output = {}
    index_dict = {}
    add_key(index_dict, pObject.nonTabular_keys, line)
    sorted_keys = list(sorted(index_dict.keys()))
    for j in range(len(sorted_keys)):
        if j == len(sorted_keys) - 1:
            data = get_data(line, index_dict[sorted_keys[j]], None)
            output[index_dict[sorted_keys[j]]] = data
        else:
            data = get_data(line, index_dict[sorted_keys[j]], index_dict[sorted_keys[j + 1]])
            output[index_dict[sorted_keys[j]]] = data
    return output


def valuesInLine_count():
    output = {}
    for i in range(1, 20):
        for x in pObject.valuesInLine_keys:
            pattern = re.compile(r'(?i){}_(.*?)r{}'.format(x, i))
            counter = 0
            for k, v in pObject.valuesInLine_pair.items():
                if pattern.search(k):
                    counter += 1
                    output[x + '_R' + str(i)] = counter
                    if x + '_R' + str(i) in pObject.valuesInLine_pair_reference.keys():
                        prev_data = pObject.valuesInLine_pair_reference[x + '_R' + str(i)]
                        prev_data.extend([v])
                        pObject.valuesInLine_pair_reference[x + '_R' + str(i)] = prev_data
                    else:
                        pObject.valuesInLine_pair_reference[x + '_R' + str(i)] = [v]
    return output


def get_valuesInLine_data(line):
    output = {}
    index_dict = {}
    add_key(index_dict, pObject.valuesInLine_keys, line)
    if len(index_dict) == 1:
        key_name = list(index_dict.values())[0]
        pObject.valuesInLine_counter[key_name] += 1
        data = get_data(line, key_name, None)
        ref = key_name + '_R' + str(pObject.valuesInLine_counter[key_name])
        if len(data.split()) == pObject.valuesInLine_count[ref]:
            for x, y in zip(pObject.valuesInLine_pair_reference[ref], data.split()):
                output[key_name + '_' + x] = y
        else:
            pObject.valuesInLine_counter[key_name] -= 1
    return output


def check_pdfobject_cutting(file):
    pdf_file = PdfFileReader(pObject.workDir + file)
    total_pages = pdf_file.getNumPages()
    if int(total_pages)>100:
        parts = 100
        part_size = total_pages // parts
        number = part_size * 100  # replace with your required number
        increments = [50]
        series = []
        for inc in increments:
            i = 0
            while i < number:
                i += inc
                series.append(i)
        return True,series
    else:
        return False,None

def get_pages(data_list, pages_dict, ids_obj):
    num_label = None
    for id in ids_obj:
        if id in data_list[0].keys():
            num_label = id
            break
    page_output = {}
    for x in pages_dict.keys():
        emp_no = data_list[x-1][num_label]
        page_output[emp_no] = pages_dict[x]
    return page_output