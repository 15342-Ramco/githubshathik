import pdfplumber
import pandas as pd
import re
import os
from pdf_extractor.commonObject import pObject
import time
import pdfquery
from pdf_extractor.functions import *

def pdf_extractor_main_fun():
    pObject.baseFolderPath = os.getcwd()
    pObject.workDir = pObject.baseFolderPath + '/storage/'
    pObject.files = os.listdir(pObject.workDir)
    pObject.outputFile = pObject.workDir + '/' + [file for file in pObject.files if file.endswith('.xlsx') and file != 'Extracted Data.xlsx'][0]
    pObject.extractFile = pObject.workDir + '/Extracted Data.xlsx'
    
    t0 = time.time()
    print('Extraction Started....')

    # Reading Reference file-
    df = pd.read_excel(pObject.outputFile, sheet_name='keys')
    keys_list = df['Keys'].to_list()
    ref_df = pd.read_excel(pObject.outputFile, sheet_name='Emp_ref')
    ids = ref_df['IDS'].to_list()

    # Initialize value line / data type-
    filtered_df = df[df['Valueline'].notnull()]
    filter_keys_list = filtered_df["Keys"].to_list()
    value_line = filtered_df["Valueline"].to_list()
    valueline_dict = {filter_keys_list[i]: value_line[i] for i in range(len(filter_keys_list))}

    DataType = filtered_df["Data Type"].to_list()
    datatype_dict = {filter_keys_list[i]: DataType[i] for i in range(len(filter_keys_list))}

    if 'Skip Line' in df.columns:
        skip_df = df[df['Skip Line'].notnull()]
        skip_keys = skip_df['Keys'].to_list()
    else:
        skip_keys = []

    if 'Currency' in df.columns:
        currency_df = df[df['Currency'].notnull()]
        pObject.currency_keys = dict(zip(currency_df['Keys'], currency_df['Currency']))
        pObject.multirows_dict = getMultirow_data(keys_list)
        currency_multiRow_df = currency_df[currency_df['Keys'].str.lower().str.contains('_multirows')]
        pObject.multiRow_currency_keys = dict(zip(currency_multiRow_df['Keys'], currency_multiRow_df['Currency']))
    else:
        pObject.currency_keys = {}
        pObject.multirows_dict = {}
        pObject.multiRow_currency_keys = {}

    dataType_df = df[df['Data Type'].notnull()]
    pObject.dataType_keys = dict(zip(dataType_df['Keys'], dataType_df['Data Type']))

    if 'Page Break' in df.columns:
        pObject.pageBreak = df.loc[0, 'Page Break'].strip()
        if '{}' in pObject.pageBreak:
            pObject.pattern = re.compile(pObject.pageBreak.replace('{}', '(.*?)'))
        else:
            pObject.pattern = re.compile(pObject.pageBreak)

    if 'Data Split' in df.columns:
        split_df = df[df['Data Split'].notnull()]
        pObject.splitLines_keys = split_df['Keys'].to_list()
        pObject.trim_keys = split_df[split_df['Data Split'].str.lower() == 'yes-trim'].Keys.tolist()

    pObject.valuesInLine_list = df[df['Keys'].str.contains(r'(?i)[_]V[0-9]+R[0-9]+[{]', regex=True)].Keys.tolist()
    pObject.valuesInLine_keys = list(set([x.rsplit('_', 1)[0] for x in pObject.valuesInLine_list]))
    pObject.valuesInLine_pair = {x.rsplit('{', 1)[0]: x.rsplit('{', 1)[1][:-1] for x in pObject.valuesInLine_list}
    pObject.valuesInLine_count = valuesInLine_count()
    pObject.valuesInLine_counter = {x: 0 for x in pObject.valuesInLine_keys}

    # Store Sub / Super set-
    pObject.subset_superset = subset_superset(keys_list)

    # Store Table information-
    table_data = {}
    tables_present = [x for x in df['Keys'] if '_table' in x.lower()]
    storeTable_heads(keys_list, tables_present)
    storeTable_elements(table_data, keys_list, tables_present)
    pObject.table_data = table_data
    table_info = fetchTable_elements(table_data)
    pObject.table_info = table_info
    pObject.duplicateTable_elements = duplicateTable_elements(table_info)
    pObject.nonTabular_keys = get_nonTabular_keys(keys_list)

    # Processing pdf-
    data_list = []
    files = os.listdir(pObject.workDir)
    pdf_files = [file for file in files if file.endswith('.pdf')]
    for file in pdf_files:
        pdf = pdfplumber.open(pObject.workDir + file)
        pdfQuery = pdfquery.PDFQuery(pObject.workDir + file)
        PdfObject_Cutting, Object_Cutting_ranges = check_pdfobject_cutting(file)
        entry_index = 0
        for page_no, i in enumerate(range(len(pdf.pages))):
            if PdfObject_Cutting:
                if i in Object_Cutting_ranges:
                    del pdfQuery
                    del pdf
                    pdf = pdfplumber.open(pObject.workDir + file)
                    pdfQuery = pdfquery.PDFQuery(pObject.workDir + file)

            page = pdf.pages[i]
            pdfQuery.load(i)
            text = page.extract_text()
            pdf_lines = text.splitlines()

            skip_list = skip_lines(pdf_lines, skip_keys)
            if pObject.pageBreak is not None and page_no != 0:
                if pObject.pattern.search(pdf_lines[0].strip()):
                    entry_index += 1
                    lhs = pObject.employee_pages[entry_index-1]
                    pObject.employee_pages[entry_index-1] = lhs + '-' + str(page_no)
                    pObject.employee_pages[entry_index] = str(page_no + 1)
                    pObject.skipAdd = False
                    pObject.store_dict = {}
                    pObject.gTable_headers = {}
                    for table in pObject.raw_headers.keys():
                        getTable_header(pdfQuery, table, keys_list, pdf_lines)
                else:
                    if page_no == len(pdf.pages)-1:
                        lhs = pObject.employee_pages[entry_index]
                        pObject.employee_pages[entry_index] = lhs + '-' + str(page_no+1)
                    pObject.skipAdd = True
            else:
                entry_index += 1
                pObject.employee_pages[entry_index] = str(page_no + 1)
                pObject.skipAdd = False
                pObject.store_dict = {}
                pObject.gTable_headers = {}
                for table in pObject.raw_headers.keys():
                    getTable_header(pdfQuery, table, keys_list, pdf_lines)
            pObject.tableIteration = {}
            pObject.tableIteration_noSuffix = {}
            pObject.current_tables = []
            pObject.needed_table = ''
            tableFlag = False
            alignFlag = False
            multiRow_flag = False
            for index, line in enumerate(pdf_lines):
                addOns_start = False
                line = line.strip()

                if len(pObject.valuesInLine_keys) > 1:
                    valuesInLine_output = get_valuesInLine_data(line)
                    pObject.store_dict.update(valuesInLine_output)

                if multiRow_flag:
                    if multiRow_stopCheck(line):
                        multiRow_flag = False
                        pObject.multiRow_range = 0
                        pObject.multiRows_exit = None
                    else:
                        multiRowBox_outputDict = getData_multiRowBox(line, pdfQuery)
                        pObject.store_dict.update(multiRowBox_outputDict)
                        continue

                if multiRow_check(line):
                    multiRow_flag = True
                    pObject.multiRows_headCoordinate_dict = getMultiRow_head_coordinate(pdfQuery)
                    pObject.multiRows_exitCoordinate = getMultiRow_exit_coordinate(pdfQuery)
                    pObject.boundingBox_dict = generateMultirow_boundingBox(pObject.multiRows_headCoordinate_dict)
                    continue

                if tableFlag:
                    tableFlag, alignFlag = checkTable_end(line, table_info, skip_list, index)
                    if not tableFlag:
                        pObject.tableIteration = {}
                        pObject.tableIteration_noSuffix = {}
                        pObject.current_tables = []
                        pObject.needed_table = ''

                if table_check(line, pdf_lines, index):
                    tableFlag = True
                    duplicateTable_occurrence = get_occurrence(line)
                    if duplicateTable_occurrence != None:
                        update_getTable_header(pdfQuery, duplicateTable_occurrence, keys_list)
                    pObject.needed_table = neededTable()
                    tableHeadLine_data = get_tableHeadLine_data(line)
                    pObject.store_dict.update(tableHeadLine_data)
                    continue

                if alignFlag:
                    index_dict = {}
                    add_key(index_dict, keys_list, line)
                    sorted_keys = list(sorted(index_dict.keys()))
                    for j in range(len(sorted_keys)):
                        if j == len(sorted_keys) - 1:
                            data = get_data(line, index_dict[sorted_keys[j]], None)
                            pObject.store_dict[index_dict[sorted_keys[j]]] = data
                        else:
                            data = get_data(line, index_dict[sorted_keys[j]], index_dict[sorted_keys[j + 1]])
                            pObject.store_dict[index_dict[sorted_keys[j]]] = data

                elif tableFlag:
                    index_dict = {}
                    temp_keys_list = filterTable_keys_list(keys_list)
                    addTable_key(index_dict, line, temp_keys_list)
                    sorted_keys = list(sorted(index_dict.keys()))
                    for j in range(len(sorted_keys)):
                        if j == len(sorted_keys) - 1:
                            data = get_data(line, index_dict[sorted_keys[j]], None)
                            dataCount = len(data.split())
                            tableName = getTable_name(index_dict[sorted_keys[j]])
                            if tableName == 'Non tabular element':
                                pObject.store_dict[index_dict[sorted_keys[j]]] = data
                                continue
                            headCount = len(pObject.raw_headers[tableName])
                            if dataCount == headCount:
                                elementName = index_dict[sorted_keys[j]].rsplit('_', 1)[0]
                                for indexPos, head in enumerate(pObject.raw_headers[tableName]):
                                    if elementName + '_' + head in pObject.currency_keys.keys():
                                        if pObject.deduction_currency_list is None:
                                            pObject.store_dict[tableName + '_' + elementName + '_' + head] = pObject.currency_keys[elementName + '_' + head] + ' ' + data.split()[indexPos]
                                        else:
                                            data_ref = data.split()[indexPos]
                                            if data_ref in pObject.deduction_currency_list:
                                                pObject.store_dict[tableName + '_' + elementName + '_' + head] = '-' + pObject.currency_keys[elementName + '_' + head] + ' ' + data_ref
                                            else:
                                                pObject.store_dict[tableName + '_' + elementName + '_' + head] = pObject.currency_keys[elementName + '_' + head] + ' ' + data_ref
                                    else:
                                        pObject.store_dict[tableName + '_' + elementName + '_' + head] = data.split()[indexPos]
                            else:
                                # Use coordinates
                                elementName = index_dict[sorted_keys[j]].rsplit('_', 1)[0]
                                output_list = []
                                pObject.value_coordinate = {}
                                for head in pObject.raw_headers[tableName]:
                                    output = getData_by_query(pdfQuery, tableName, head, elementName, data.split())
                                    output_list.append(output)
                                outputCheck_list = [x for x in output_list if x != '']
                                if dataCount == len(outputCheck_list):
                                    for indexPos, head in enumerate(pObject.raw_headers[tableName]):
                                        if elementName + '_' + head in pObject.currency_keys.keys():
                                            if pObject.deduction_currency_list is None:
                                                pObject.store_dict[tableName + '_' + elementName + '_' + head] = pObject.currency_keys[elementName + '_' + head] + ' ' + output_list[indexPos]
                                            else:
                                                data_ref = output_list[indexPos]
                                                if data_ref in pObject.deduction_currency_list:
                                                    pObject.store_dict[tableName + '_' + elementName + '_' + head] = '-' + pObject.currency_keys[elementName + '_' + head] + ' ' + data_ref
                                                else:
                                                    pObject.store_dict[tableName + '_' + elementName + '_' + head] = pObject.currency_keys[elementName + '_' + head] + ' ' + data_ref
                                        else:
                                            pObject.store_dict[tableName + '_' + elementName + '_' + head] = output_list[indexPos]
                                else:
                                    # Use bounding box coordinates
                                    bounding_box = generate_boundingBox(tableName)
                                    output_BB = getData_by_BB(bounding_box)
                                    for ckey in pObject.currency_keys.keys():
                                        if ckey in output_BB.keys():
                                            output_BB[ckey] = pObject.currency_keys[ckey] + ' ' + output_BB[ckey]
                                    output_BB = {tableName + '_' + k: v for k, v in output_BB.items()}
                                    pObject.store_dict.update(output_BB)

                        else:
                            data = get_data(line, index_dict[sorted_keys[j]], index_dict[sorted_keys[j + 1]])
                            dataCount = len(data.split())
                            tableName = getTable_name(index_dict[sorted_keys[j]])
                            if tableName == 'Non tabular element':
                                pObject.store_dict[index_dict[sorted_keys[j]]] = data
                                continue
                            headCount = len(pObject.raw_headers[tableName])
                            if dataCount == headCount:
                                elementName = index_dict[sorted_keys[j]].rsplit('_', 1)[0]
                                for indexPos, head in enumerate(pObject.raw_headers[tableName]):
                                    if elementName + '_' + head in pObject.currency_keys.keys():
                                        if pObject.deduction_currency_list is None:
                                            pObject.store_dict[tableName + '_' + elementName + '_' + head] = pObject.currency_keys[elementName + '_' + head] + ' ' + data.split()[indexPos]
                                        else:
                                            data_ref = data.split()[indexPos]
                                            if data_ref in pObject.deduction_currency_list:
                                                pObject.store_dict[tableName + '_' + elementName + '_' + head] = '-' + pObject.currency_keys[elementName + '_' + head] + ' ' + data_ref
                                            else:
                                                pObject.store_dict[tableName + '_' + elementName + '_' + head] = pObject.currency_keys[elementName + '_' + head] + ' ' + data_ref
                                    else:
                                        pObject.store_dict[tableName + '_' + elementName + '_' + head] = data.split()[indexPos]
                            else:
                                # Use coordinates
                                elementName = index_dict[sorted_keys[j]].rsplit('_', 1)[0]
                                output_list = []
                                pObject.value_coordinate = {}
                                for head in pObject.raw_headers[tableName]:
                                    output = getData_by_query(pdfQuery, tableName, head, elementName, data.split())
                                    output_list.append(output)
                                outputCheck_list = [x for x in output_list if x != '']
                                if dataCount == len(outputCheck_list):
                                    for indexPos, head in enumerate(pObject.raw_headers[tableName]):
                                        if elementName + '_' + head in pObject.currency_keys.keys():
                                            if pObject.deduction_currency_list is None:
                                                pObject.store_dict[tableName + '_' + elementName + '_' + head] = pObject.currency_keys[elementName + '_' + head] + ' ' + output_list[indexPos]
                                            else:
                                                data_ref = output_list[indexPos]
                                                if data_ref in pObject.deduction_currency_list:
                                                    pObject.store_dict[tableName + '_' + elementName + '_' + head] = '-' + pObject.currency_keys[elementName + '_' + head] + ' ' + data_ref
                                                else:
                                                    pObject.store_dict[tableName + '_' + elementName + '_' + head] = pObject.currency_keys[elementName + '_' + head] + ' ' + data_ref
                                        else:
                                            pObject.store_dict[tableName + '_' + elementName + '_' + head] = output_list[indexPos]
                                else:
                                    # Use bounding box coordinates
                                    bounding_box = generate_boundingBox(tableName)
                                    output_BB = getData_by_BB(bounding_box)
                                    for ckey in pObject.currency_keys.keys():
                                        if ckey in output_BB.keys():
                                            output_BB[ckey] = pObject.currency_keys[ckey] + ' ' + output_BB[ckey]
                                    output_BB = {tableName + '_' + k: v for k, v in output_BB.items()}
                                    pObject.store_dict.update(output_BB)

                else:
                    index_dict = {}
                    add_key(index_dict, keys_list, line)
                    sorted_keys = list(sorted(index_dict.keys()))
                    for j in range(len(sorted_keys)):
                        if j == len(sorted_keys) - 1:
                            data = get_data(line, index_dict[sorted_keys[j]], None)
                            if len(pObject.splitLines_keys) != 0:
                                if index_dict[sorted_keys[j]] in pObject.splitLines_keys:
                                    data_addOn = get_dataAddon(pdfQuery, data, index_dict[sorted_keys[j]])
                                    data = data_addOn
                                    addOns_start = True

                            if addOns_start:
                                pass
                            else:
                                if pObject.addOns_counter > 0:
                                    data = update_data(data)
                                    pObject.addOns_counter -= 1
                                elif pObject.addOns_counter == 0:
                                    pObject.stored_addOns = []

                            if index_dict[sorted_keys[j]] in pObject.dataType_keys.keys():
                                output_type = pObject.dataType_keys[index_dict[sorted_keys[j]]]
                                pObject.store_dict[index_dict[sorted_keys[j]]] = output_data(output_type, data)
                            else:
                                pObject.store_dict[index_dict[sorted_keys[j]]] = data
                        else:
                            data = get_data(line, index_dict[sorted_keys[j]], index_dict[sorted_keys[j + 1]])
                            if len(pObject.splitLines_keys) != 0:
                                if index_dict[sorted_keys[j]] in pObject.splitLines_keys:
                                    data_addOn = get_dataAddon(pdfQuery, data, index_dict[sorted_keys[j]])
                                    data = data_addOn
                                    addOns_start = True

                            if addOns_start:
                                pass
                            else:
                                if pObject.addOns_counter > 0:
                                    data = update_data(data)
                                    pObject.addOns_counter -= 1
                                elif pObject.addOns_counter == 0:
                                    pObject.stored_addOns = []

                            if index_dict[sorted_keys[j]] in pObject.dataType_keys.keys():
                                output_type = pObject.dataType_keys[index_dict[sorted_keys[j]]]
                                pObject.store_dict[index_dict[sorted_keys[j]]] = output_data(output_type, data)
                            else:
                                pObject.store_dict[index_dict[sorted_keys[j]]] = data

                occurence, filter_index_dict = pair_keys(line, valueline_dict, filter_keys_list)
                if not filter_index_dict:
                    continue
                pair = pair_data(occurence, datatype_dict, filter_index_dict, index, pdf_lines, pdfQuery)
                pObject.store_dict.update(pair)

            if pObject.skipAdd:
                pass
            else:
                data_list.append(pObject.store_dict)
            print('Scraping data from pdf file {} , page: '.format(file), page_no+1, 'of', len(pdf.pages))

    pdf_df = pd.DataFrame.from_dict(data_list)
    pObject.page_details = get_pages(data_list, pObject.employee_pages, ids)
    if len(pObject.currency_keys) != 0:
        pdf_df = remove_currency(pdf_df, list(pObject.currency_keys.values())[0])
    pdf_df.to_excel(pObject.extractFile, sheet_name='PDF Data', index= False)
    print('Extraction Completed')
    t1 = time.time()
    print("Time taken: ", "%d hours : %d minutes : %.2f seconds" % execution_time(t1-t0))


def asserting_directly_in_xml(pdf_name_with_path,dict_with_emp_page_splitup,emp_count,mismatch_value):
    assertion_passed_flag_list = []
    page_to_check = dict_with_emp_page_splitup[emp_count]
    page_iterating_list = page_to_check.split("-")
    if len(page_iterating_list) > 0:
        if len(page_iterating_list) == 1:
            # page_iterating_list = int(page_iterating_list[0])
            pass
        else:
            page_iterating_list = list(range(int(page_iterating_list[0]),int(page_iterating_list[1])+1))
            print(page_iterating_list,"*****************************")
    print("pdf_name_with_path : ", pdf_name_with_path)
    pdf = pdfquery.PDFQuery(pdf_name_with_path)
    page = 1
    for each_page in page_iterating_list:
        pdf.load(int(each_page)-1)
        item = pdf.pq('LTTextLineHorizontal:contains("{}")'.format(mismatch_value))
        print(len(item))
        try:
            print(item.items('LTTextLineHorizontal'))
            print(len(item))
            print(item.text())
            if len(item) == 0:
                if len(page_iterating_list) == page: 
                    status = "Fail"
                # break
            else:
                for i in item.items('LTTextLineHorizontal'):
                    if str(i.text()) == mismatch_value:
                        print("Assertion Passed")
                        assertion_passed_flag_list.append(True)
                    else:
                        assertion_passed_flag_list.append(False)
                if True in assertion_passed_flag_list:
                    status = "Pass"
                    break                               
        except Exception as error:
            print(str(error))
        page = page + 1
    return status