import json
from API.utils.constants import API_INFO_FOLDER_PATH

def get_info_file(file_name: str):
    with open(f"{API_INFO_FOLDER_PATH}\\{file_name}", 'r') as file:
        data = dict(json.load(file))
    return data
