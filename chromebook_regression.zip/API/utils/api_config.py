import pandas as pd
import xlwings as xw
from openpyxl import load_workbook
from openpyxl.utils.dataframe import dataframe_to_rows

from API.utils.constants import API_CONFIG_SHEET, API_MASTER_FILE_PATH
from common_object import Variable_not_resettable

def get_api_config(config_id: int, ):
    df = pd.read_excel(API_MASTER_FILE_PATH, sheet_name="APIConfig", header=None, dtype="str")
    data_records = df.to_dict("records")
    current_config = {}
    is_current_config_capture = False
    for each_data_record in data_records:
        key = each_data_record.get(0)
        value = each_data_record.get(1)
        if key == "API_Config_ID" and value == str(config_id):
            is_current_config_capture = True
        if str(key) == "nan" and str(value) == "nan":
            is_current_config_capture = False
        if is_current_config_capture == True:
            current_config.update({key: value})
    return current_config



def update_api_config(config_id, config_key, config_value_new):
    file_path = API_MASTER_FILE_PATH
    sheet_name = API_CONFIG_SHEET
    df = pd.read_excel(file_path, sheet_name= sheet_name)
    df = pd.concat([df.columns.to_frame().T, df.reset_index(drop=True)], axis=0)
    data_list = df.values.tolist()
    row_index = None
    is_current_config_capture = False
    for index, each_data_list in enumerate(data_list):
        key = each_data_list[0]
        value = each_data_list[1]
        if key == "API_Config_ID" and int(value) == int(config_id):
            is_current_config_capture = True
        if str(key) == "nan" and str(value) == "nan":
            is_current_config_capture = False
        if is_current_config_capture == True:
            if config_key == key:
                row_index = index
    if row_index:
        column_address = "B"
        app1 = xw.App()
        app1.visible = False
        app1.display_alerts = False
        wb_1 = app1.books.open(file_path, update_links=False, ignore_read_only_recommended=True)    
        ws_1 = wb_1.sheets[sheet_name]
        ws_1.range(column_address+str(row_index+1)).value = config_value_new
        wb_1.save()
        wb_1.close()
        app1.quit()
        app1.kill()

    Variable_not_resettable.logger.info("Data saved...")

