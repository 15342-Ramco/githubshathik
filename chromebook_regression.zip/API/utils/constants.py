import os

BASE_FOLDER_PATH = os.getcwd()
API_FOLDER_PATH = f"{BASE_FOLDER_PATH}\\Files\\API"
API_INFO_FOLDER_PATH = f"{API_FOLDER_PATH}\\InfoFiles"
API_MASTER_FILE_PATH = f"{API_FOLDER_PATH}\\APIMaster.xlsx"
API_CONFIG_SHEET = f"APIConfig"
API_REQUEST_OUTPUT_PATH = f"{BASE_FOLDER_PATH}\\Files\\API\\Request_output"
API_RESPONSE_OUTPUT_PATH = f"{BASE_FOLDER_PATH}\\Files\\API\\Response_output"


STATUS_DESCRIPTION = {
    200:"OK", 201:"Created", 202:"Accepted", 203:"Non-Authoritative Information", 204:"No Content",
    400: "Bad Request", 401: "Unauthorized",  403: "Forbidden",  404: "Not Found", 405: "Method Not Allowed", 406: "Not Acceptable",
    500: "Internal Server Error", 501: "Not Implemented", 502: "Bad Gateway", 503: "Service Unavailable", 504: "Gateway Timeout", 505: "HTTP Version Not Supported"
}
