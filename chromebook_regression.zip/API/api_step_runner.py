import pandas as pd
import json, os
from API.builder.body.form_urlencoded import get_form_urlencoded
from API.builder.body.raw.rwa_json import get_raw_json
from API.builder.header.get_header import get_header_params
from API.builder.response.save_data import do_save_data
from API.client.make_request import request_handler
from dataGenerator import dataGenerator
from API.utils.api_config import get_api_config
from API.utils.api_utils import get_info_file
from API.utils.constants import API_REQUEST_OUTPUT_PATH, API_RESPONSE_OUTPUT_PATH
from common_object import Common_object, Common_step, Variable_not_resettable
import re


def extract_and_process_key(endpoint_url_path, api_config_data, dataGenerator):
    # Regular expression to capture the key after ${dataSheet:
    pattern = r'\${dataSheet:(.*?)}'

    # Search for the pattern in the string
    match = re.search(pattern, endpoint_url_path)

    # If a match is found, extract the key
    if match:
        extracted_key = match.group(1)  # This will capture the key (e.g., 'Username')
        print(f'Extracted key: {extracted_key}')

        # Check if the extracted key is present in api_config_data and has the "EXECUTE" keyword
        if "EXECUTE" in api_config_data.get(extracted_key, ''):
            api_config_data[extracted_key] = dataGenerator(api_config_data.get(extracted_key))

    else:
        print('No match found')

    return api_config_data

# Function to replace placeholder with dictionary value only if pattern exists
def replace_placeholder(input_string, data_dict):
    # Find the pattern like "${dataSheet:Username}"
    pattern = r'\${dataSheet:(.*?)}'
    
    # Check if the pattern exists in the input string
    if re.search(pattern, input_string):
        # Function to get the replacement from dictionary
        def replace_match(match):
            key = match.group(1)  # Extract the key (e.g., 'Username')
            return data_dict.get(key, key)  # Use the key to get value or return key if not found
        
        # Replace all occurrences of the pattern using the replace_match function
        return re.sub(pattern, replace_match, input_string)
    
    # If no pattern exists, return the original string
    return input_string





def run_api_request(data_file_path, sheet_name, loop_count, api_id):

    
    os.makedirs(API_REQUEST_OUTPUT_PATH, exist_ok=True)
    os.makedirs(API_RESPONSE_OUTPUT_PATH, exist_ok=True)

    if str(loop_count) == "None":
        loop_count = 0
    api_datasheet_data: dict = pd.read_excel(data_file_path, sheet_name= sheet_name, dtype="str", keep_default_na=False ).to_dict("records")[loop_count]
    api_reference_data = [each_row for each_row in pd.read_excel("Files\\API\\APIMaster.xlsx", sheet_name= "APIReference", dtype="str").to_dict("records") if each_row["API_ID"] == api_id][0]
    
    Variable_not_resettable.logger.info(f"api_reference_data: {api_reference_data}")

    api_config_data: dict= get_api_config(int(api_reference_data["API_CONFIG_ID"]))
    json_file_data: dict = get_info_file(api_reference_data['API_Info_file'])

    base_url = api_config_data.get("base_url")
    if base_url[-1] == "/":
        base_url = base_url[:-1]

    endpoint_url_path: dict = json_file_data.get("endpoint_url_path")
    # Call the function and update api_config_data
    api_datasheet_data = extract_and_process_key(endpoint_url_path, api_datasheet_data, dataGenerator)
    # Replace the placeholder in the input string
    endpoint_url_path = replace_placeholder(endpoint_url_path, api_datasheet_data)
    if endpoint_url_path[0] != "/":
        endpoint_url_path = f"/{endpoint_url_path}"

    full_url: str = f"{base_url}{endpoint_url_path}"
    api_request_method = api_reference_data["API_Method"]
    header: dict = json_file_data.get("header")
    body: dict = json_file_data.get("body")
    response: dict = json_file_data.get("response")

    if header:
        header_data = get_header_params(header, api_config_data, api_datasheet_data)

    if body:
        payload_data = None
        x_www_form_urlencoded: dict = body.get("x-www-form-urlencoded")
        if x_www_form_urlencoded:
            x_www_form_urlencoded_params = get_form_urlencoded(x_www_form_urlencoded, api_config_data, api_datasheet_data)
            log_payload_data = x_www_form_urlencoded_params
            payload_data = x_www_form_urlencoded_params
        
        raw = body.get("raw")
        if raw:
            raw_json: dict = raw.get("json")
            if raw_json:
                if type(raw_json) == list:
                    tmp_list = []
                    for raw_data in raw_json:
                        raw_json_params = get_raw_json(raw_data, api_config_data, api_datasheet_data)
                        tmp_list.append(raw_json_params)
                    raw_json_params = tmp_list
                elif type(raw_json) == dict:
                    raw_json_params = get_raw_json(raw_json, api_config_data, api_datasheet_data)

                log_payload_data = raw_json_params
                payload_data = json.dumps(raw_json_params)
       

        request_log_data = {
            "url" : full_url,
            "method" : api_request_method,
            "headers" : header_data,
            "body" : log_payload_data
        }
    else:
        payload_data=None

        request_log_data = {
            "url" : full_url,
            "method" : api_request_method,
            "headers" : header_data
        }
        

    Variable_not_resettable.logger.info(f"Request url: {full_url}")
    Variable_not_resettable.logger.info(f"Request method: {api_request_method}")
    Variable_not_resettable.logger.info(f"Headers data: {header_data}")
    Variable_not_resettable.logger.info(f"Payload data: {payload_data}")
    
    request_log_data_json = json.dumps(request_log_data, indent=4)
   # print(request_log_data_json)
    Common_step.Request_log_file_name = f"{endpoint_url_path[1:].replace('/','_')}_{Common_object.scenarios_meta.get('SCENARIO_ID')}_{Common_step.step_id}_{int(loop_count)+1}.json"

    # Example of replacing invalid characters with an underscore
    Common_step.Request_log_file_name = re.sub(r'[<>:"/\\|?*]', '_', Common_step.Request_log_file_name)

    with open(f"{API_REQUEST_OUTPUT_PATH}\\{Common_step.Request_log_file_name}", "w") as request_log_file:
        request_log_file.write(request_log_data_json)

    response_data = request_handler(full_url, api_request_method, payload_data, header_data)

    Variable_not_resettable.logger.info(f"API Response {response_data}")

    response_log_data_json = json.dumps(response_data, indent=4)

    #print(response_log_data_json)

    Common_step.Response_log_file_name = f"{endpoint_url_path[1:].replace('/','_')}_{Common_object.scenarios_meta.get('SCENARIO_ID')}_{Common_step.step_id}_{int(loop_count)+1}.json"
    # Example of replacing invalid characters with an underscore
    Common_step.Response_log_file_name  = re.sub(r'[<>:"/\\|?*]', '_', Common_step.Response_log_file_name )
    with open(f"{API_RESPONSE_OUTPUT_PATH}\\{Common_step.Response_log_file_name }", "w") as response_log_file:
        response_log_file.write(response_log_data_json)

    
    response_status_code = response_data.get("status").get("code")
    response_headers = response_data.get("headers")
    
    if response_status_code:
        unauthorized_status_code_given = str(api_config_data.get("unauthorized_status_code"))
        unauthorized_status_code_given = unauthorized_status_code_given.split(",")
        if str(response_status_code) not in unauthorized_status_code_given and int(response_status_code) >= 400 and int(response_status_code) <= 600:
            if "application/json" in response_headers.get("Content-Type"):
                raise Exception(f"Status Code : {response_status_code} and Response : {str(response_data.get('body'))}")
            
            if "text/plain" in response_headers.get("Content-Type"):
                raise Exception(f"Status Code : {response_status_code} and Response : {str(response_data.get('body'))}")
        else:
            if Common_step.api_unauthorized_loop_count == 1 and str(response_status_code) in unauthorized_status_code_given:
                raise Exception(f"Status Code : {response_status_code} and Response : {str(response_data.get('body'))}")


     
    if response_data.get("Error") == None:
        if response:
            save_data: dict = response.get("saveData")
            if save_data:
                config_id = api_reference_data.get("API_CONFIG_ID")
                do_save_data(save_data, response_data.get("body"), config_id, loop_count, data_file_path=data_file_path, data_sheet_name=sheet_name)

        try:
            unauthorized_status_code_given = str(api_config_data.get("unauthorized_status_code"))
            # if "," in unauthorized_status_code_given:
            unauthorized_status_code_given = unauthorized_status_code_given.split(",")
        except Exception as error:
            Variable_not_resettable.logger.info("Error on unauthorized_status_code")
            raise Exception(str(error))
        if str(response_data.get("status").get("code")) in unauthorized_status_code_given:
            if str(api_reference_data.get("AuthAPI_ID")) != "nan":
                auth_api_id = api_reference_data.get("AuthAPI_ID")
                if Common_step.api_unauthorized_loop_count < 1:
                    Common_step.api_unauthorized_loop_count = Common_step.api_unauthorized_loop_count + 1
                    run_api_request(data_file_path, sheet_name, loop_count, auth_api_id)
                    run_api_request(data_file_path, sheet_name, loop_count, api_id)
    else:
        raise Exception(f"API request Error: {response_data.get('Error')}")

