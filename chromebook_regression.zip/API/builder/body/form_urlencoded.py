import re

from dataGenerator import dataGenerator


def get_form_urlencoded(x_www_form_urlencoded_data: dict, api_config_data: dict, api_datasheet_data:dict):
    print(api_config_data)
    x_www_form_urlencoded_params = ""
    for key, value in x_www_form_urlencoded_data.items():
        original_value = value
        if re.search(r"\${.*}", value):
            value = str(re.findall(r'\${(.*?)}', value)[0])
            replace_pattern = "${"+value+"}"
            value = value.split(":")
            if len(value) == 2 and "config" in value:
                replace_value = api_config_data.get(value[1])
                if 'EXECUTE:' in replace_value:
                    replace_value = dataGenerator(replace_value)
                    if str(replace_value) == "nan":
                        replace_value = ""
                if replace_value:
                    value = original_value.replace(replace_pattern, replace_value)
                else:
                    pass
            elif len(value) == 2 and "dataSheet" in value:
                replace_value = api_datasheet_data.get(value[1])
                if 'EXECUTE:' in replace_value:
                    replace_value = dataGenerator(replace_value)
                    if str(replace_value) == "nan":
                        replace_value = ""  
                value = original_value.replace(replace_pattern, replace_value)

        x_www_form_urlencoded_params = x_www_form_urlencoded_params + f"{key}={value}&"
    x_www_form_urlencoded_params = x_www_form_urlencoded_params[:-1]
    return x_www_form_urlencoded_params