import re

def get_header_params(header_data: dict, api_config_data: dict, api_datasheet_data: dict):
    formate_header = {}
    for key, value in header_data.items():
        key, value = str(key), str(value)
        original_value = value
        if re.search(r"\${.*}", value):
            value = str(re.findall(r'\${(.*?)}', value)[0])
            replace_pattern = "${"+value+"}"
            value = value.split(":")
            if len(value) == 2 and "config" in value:
                replace_value = api_config_data.get(value[1])
                if str(replace_value) == "nan":
                    replace_value = ""
                if replace_value and str(replace_value) != "nan":
                    value = original_value.replace(replace_pattern, replace_value)
                else:
                    if str(replace_value) == "nan":
                        value = original_value.replace(replace_pattern, "")
            if len(value) == 2 and "dataSheet" in value:
                replace_value = api_datasheet_data.get(value[1])
                if str(replace_value) == "nan":
                    replace_value = ""
                value = original_value.replace(replace_pattern, replace_value)
        formate_header.update({key: value})
    return formate_header
