import re
from API.utils.api_config import update_api_config
import pandas as pd
from common_object import Common_object, Common_path, Common_step, Variable_not_resettable
from utils import get_alphabet
import xlwings as xw

def saveDataToExcel(file_path, sheet_name, row_index, column_name, value):
    try:
        df = pd.read_excel(file_path, sheet_name=sheet_name)
        column_index = list(df.columns)
        column_index = [str(column).lower() for column in column_index]
        column_index = column_index.index(str(column_name).lower())
        column_address = get_alphabet(column_index)

        app1 = xw.App()
        app1.visible = False
        app1.display_alerts = False

        wb_1 = app1.books.open(file_path, update_links=False, ignore_read_only_recommended=True)    
        ws_1 = wb_1.sheets[sheet_name]
        ws_1.range(column_address+str(row_index+2)).value = value
        wb_1.save()
        wb_1.close()
        app1.quit()
        app1.kill()
    except Exception as error:
        # print(error)
        app1.quit()
        app1.kill()




def do_save_data(save_data: dict, response_data: dict, config_id: str | int, row_index: int = None, data_file_path = None,  data_sheet_name = None):
    for key, value in save_data.items():
        original_value = value
        if re.search(r"\${.*}", value):
            value = str(re.findall(r'\${(.*?)}', value)[0])
            replace_pattern = "${"+value+"}"
            value = value.split(":")
            if len(value) == 2 and "config" in value:            
                config_key = value[1]
                response_value = response_data.get(key)
                if response_value and str(response_value) != "nan":
                    response_value = original_value.replace(replace_pattern, response_value)
                else:
                    if str(response_value) == "nan":
                        response_value = original_value.replace(replace_pattern, "")
                update_api_config(config_id, config_key, response_value)

            elif len(value) == 2 and "dataSheet" in value:
                
                column_name = value[1] 
                save_value = response_data.get(key)
                saveDataToExcel(data_file_path, data_sheet_name, row_index, column_name, save_value)
                