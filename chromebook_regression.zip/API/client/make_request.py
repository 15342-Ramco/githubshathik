import json
import requests
from requests.structures import CaseInsensitiveDict

from API.utils.constants import STATUS_DESCRIPTION

def request_handler(url: str, method:str, payload:str, headers: str):
    try:
        response = requests.request(method=method,url=url, headers=headers, data=payload)
        headers = dict(response.headers)
        content_type = response.headers.get("Content-Type")
        status_code = response.status_code
        response_time = f"{int(response.elapsed.total_seconds()*1000)} ms"
        body_size = f"{len(response.content)} B"
        header_size = f"{len(str(response.headers))} B"
        total_size = f"{len(response.content) + len(str(response.headers))} B"
        response_size = {
            "body" : body_size,
            "header": header_size,
            "total": total_size
        }
        status_des = STATUS_DESCRIPTION.get(status_code)
    
        if "text/plain" in content_type:
            response = response.text
        if "application/json" in content_type:
            response = response.json()
        
        response_details = {"status": {"code":int(status_code), "description": status_des}, "time": response_time, "size": response_size, "headers": headers, "body": response}
        return response_details
    except Exception as error:
        return {"Error": str(error), "status": {"code":None, "description": None}}
