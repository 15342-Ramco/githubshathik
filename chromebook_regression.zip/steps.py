from datetime import date, datetime
import os
import time
from API.api_step_runner import run_api_request
from Rtask_ticket import rtask_raise_ticket
from common_object import Common_DB, Common_config, Common_config_step, Common_controls, Common_data, Common_main_object, Common_object, Common_path, Common_scenario, Common_scenario_loops_list, Common_step, Common_preConfig, Parallel_common_object, Variable_not_resettable
from configuration import read_config_step_return_step_dict, read_configScenarioMaster_return_scenario_dict
from dataGenerator import dataGenerator
from db_query import db_query_config
from auto_jira import jira_raise_ticket
from loops import loop_wrapper
from reset_common_object import reset_Common_scenario_loops_list, reset_step_dict, reset_variables
from utils import remove_folder,check_action_available, error_popup_message_customization, get_date_with_right_formate, log_list, make_directory, read_properties_file, split_by_colon, split_by_dash, join_path_and_file, writing_html_log
from excel_utils import advance_debug_log, read_excel_return_dictionary_for_row_based_for_step_sheet
from pre_config import pre_config_variables
from navigation import navigation_elements
from control_sheet import controlSheet_dictionary, controlSheet_dictionary_config, controlSheet_element_value
from data_sheet import Assert_Excel_Column, dataSheet_dictionary,get_data_values
from page_object_wrapper import get_locator
from play_code import *
from page_action import page_action
import pandas as pd

def execute_step(page, context, loop_count):
    check_action_available(Common_step.ACTION)
    if "Assert Error Popup" in Common_step.BASE_ACTION and Common_step.action_completed_assert_error_popup == True:
        Variable_not_resettable.logger.info(f"Action already completed")
    # Variable_not_resettable.logger.info("Loop Count : "+ str(loop_count))
    elif str(Common_step.PAGE_NAME).lower() != "nan" and Common_step.PAGE_NAME != None and Common_step.PAGE_NAME != "":
        if Common_step.BASE_ACTION == "Enter Date":
            Common_data.data_value = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num, Common_step.DATA_REFERENCE)
            # print("Enter data value from excel : ", str(Common_data.data_value))
            Variable_not_resettable.logger.info("Data value : "+ str(Common_data.data_value))
            if 'EXECUTE:' in str(Common_data.data_value):
                Common_data.data_value = dataGenerator(Common_data.data_value)
                page_action(page,context, Common_step.ACTION, get_locator(page,Common_step.ACTION, Common_controls.control_Value, loop_count), str(Common_data.data_value))
                if Variable_not_resettable.APP_TYPE == "Studio":
                    popuphandler_for_studio(page)            
            else:
                if str(Common_data.data_value) == "" or str(Common_data.data_value) == "nan" or str(Common_data.data_value) == None:
                    Common_data.data_value = ""
                    page_action(page,context, Common_step.ACTION, get_locator(page,Common_step.ACTION, Common_controls.control_Value, loop_count), str(Common_data.data_value))
                    if Variable_not_resettable.APP_TYPE == "Studio":
                        popuphandler_for_studio(page)
                else:
                    Common_data.data_value = get_date_with_right_formate(Common_step.DATA_FILE, Common_step.DATA_SHEET,Common_step.DATA_REFERENCE, Common_scenario.data_provider_num)
                    page_action(page,context, Common_step.ACTION, get_locator(page,Common_step.ACTION, Common_controls.control_Value, loop_count), str(Common_data.data_value))
                    if Variable_not_resettable.APP_TYPE == "Studio":
                        popuphandler_for_studio(page) 
        else:
            if Common_step.DATA_REFERENCE1!=None and Common_step.DATA_REFERENCE2!=None:
                Common_data.data_value1,Common_data.data_value2=get_data_values(Common_scenario.data_provider_num)
            Common_data.data_value = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num, Common_step.DATA_REFERENCE)
            # print("Enter data value from excel : ", str(Common_data.data_value))
            Variable_not_resettable.logger.info("Data value : "+ str(Common_data.data_value))
            if str(Common_data.data_value) == "" or str(Common_data.data_value) == "nan" or str(Common_data.data_value) == None:        
                Common_data.data_value = ""
                page_action(page,context, Common_step.ACTION, get_locator(page,Common_step.ACTION, Common_controls.control_Value, loop_count), str(Common_data.data_value))
                if Variable_not_resettable.APP_TYPE == "Studio":
                    popuphandler_for_studio(page)
            elif 'EXECUTE:' in str(Common_data.data_value):
                # Common_data.data_value = dataGenerator(Common_data.data_value)
                # page_action(page,context, Common_step.ACTION, get_locator(page,Common_step.ACTION, Common_controls.control_Value, loop_count), str(Common_data.data_value))
                if Variable_not_resettable.APP_TYPE == "Rapids":
                    if ("|" in Common_data.data_value) and ('EXECUTE:' in str(Common_data.data_value)):
                        page_action(page,context, Common_step.ACTION, get_locator(page,Common_step.ACTION, Common_controls.control_Value, loop_count), str(Common_data.data_value))
                        if Variable_not_resettable.APP_TYPE == "Studio":
                            popuphandler_for_studio(page)
                    else:
                        Common_data.data_value = dataGenerator(Common_data.data_value)
                        page_action(page,context, Common_step.ACTION, get_locator(page,Common_step.ACTION, Common_controls.control_Value, loop_count), str(Common_data.data_value))
                        if Variable_not_resettable.APP_TYPE == "Studio":
                            popuphandler_for_studio(page)
                else:
                    Common_data.data_value = dataGenerator(Common_data.data_value)
                    page_action(page,context, Common_step.ACTION, get_locator(page,Common_step.ACTION, Common_controls.control_Value, loop_count), str(Common_data.data_value))
                    if Variable_not_resettable.APP_TYPE == "Studio":
                        popuphandler_for_studio(page)
            else:
                page_action(page,context, Common_step.ACTION, get_locator(page,Common_step.ACTION, Common_controls.control_Value, loop_count), str(Common_data.data_value))
                if Variable_not_resettable.APP_TYPE == "Studio":
                    popuphandler_for_studio(page)
    else:
        if Common_step.BASE_ACTION == "Enter Date":
            Common_data.data_value = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num, Common_step.DATA_REFERENCE)
            # print("Enter data value from excel : ", str(Common_data.data_value))
            Variable_not_resettable.logger.info("Data value : "+ str(Common_data.data_value))
            if 'EXECUTE:' in str(Common_data.data_value):
                Common_data.data_value = dataGenerator(Common_data.data_value)
                page_action(page,context, Common_step.ACTION, None, str(Common_data.data_value))
                if Variable_not_resettable.APP_TYPE == "Studio":
                    popuphandler_for_studio(page)
            else:
                if str(Common_data.data_value) == "" or str(Common_data.data_value) == "nan" or str(Common_data.data_value) == None:
                    Common_data.data_value = ""
                    page_action(page,context, Common_step.ACTION, None, str(Common_data.data_value))
                    if Variable_not_resettable.APP_TYPE == "Studio":
                        popuphandler_for_studio(page)
                else:
                    Common_data.data_value = get_date_with_right_formate(Common_step.DATA_FILE, Common_step.DATA_SHEET,Common_step.DATA_REFERENCE, Common_scenario.data_provider_num)
                    page_action(page,context, Common_step.ACTION, None, str(Common_data.data_value))
                    if Variable_not_resettable.APP_TYPE == "Studio":
                        popuphandler_for_studio(page)
        else:
            Common_data.data_value = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num, Common_step.DATA_REFERENCE)
            # print("Enter data value from excel : ", str(Common_data.data_value))
            if Common_step.DATA_REFERENCE1!=None and Common_step.DATA_REFERENCE2!=None:
                Common_data.data_value1,Common_data.data_value2=get_data_values(Common_scenario.data_provider_num)
            Variable_not_resettable.logger.info("Data value : "+ str(Common_data.data_value))
            if str(Common_data.data_value) == "" or str(Common_data.data_value) == "nan" or str(Common_data.data_value) == None:        
                Common_data.data_value = ""
                page_action(page,context, Common_step.ACTION, None, str(Common_data.data_value))
                if Variable_not_resettable.APP_TYPE == "Studio":
                    popuphandler_for_studio(page)
            elif 'EXECUTE:' in str(Common_data.data_value):
                Common_data.data_value = dataGenerator(Common_data.data_value)
                page_action(page,context, Common_step.ACTION, None, str(Common_data.data_value))
                if Variable_not_resettable.APP_TYPE == "Studio":
                    popuphandler_for_studio(page)
            else:
                page_action(page,context, Common_step.ACTION, None, str(Common_data.data_value))
                if Variable_not_resettable.APP_TYPE == "Studio":
                    popuphandler_for_studio(page)
    if "Assert Error Popup" in Common_step.BASE_ACTION:
        Common_step.action_completed_assert_error_popup = True
        



def run_step(page,context,data_provider_num, loop_count, step, log_step_list, start_time):
        
        Common_step.ACTION = str(step['ACTION']).split(",")[0].strip()
        if ',' in str(step['ACTION']):
            Common_step.Second_Action=str(step['ACTION']).split(",")[1].strip()
        Common_step.BASE_ACTION = str(step['ACTION']).strip()


        if "Multi Select Search Combo" in Common_step.BASE_ACTION:
            Common_step.ACTION = str(step['ACTION']).split(":")[0].strip()
            if len(str(step['ACTION']).split(":")) == 2:
                if str(step['ACTION']).split(":")[1].strip().isdigit():
                    if int(str(step['ACTION']).split(":")[1].strip()) > 90:
                        Common_step.multi_select_search_combo_timeout = 90*1000
                    else:
                        Common_step.multi_select_search_combo_timeout = int(str(step['ACTION']).split(":")[1].strip()) * 1000
            else:
                Common_step.multi_select_search_combo_timeout = 5 * 1000

        if Common_step.ACTION == Variable_not_resettable.PREVIOUS_ACTION and Common_step.ACTION == "Click Button":
            time.sleep(1)
        if str(Common_step.ACTION).upper() == "LOGOUT":
            if step["STEP_ID"] >= int(Common_scenario.STEP_ID_START) and step["STEP_ID"] <= int(Common_scenario.STEP_ID_END):
                # print("[INFO] : Running step : ", step["STEP_ID"])
                Variable_not_resettable.logger.info("Running step : "+ str(step["STEP_ID"]))
                # print("[INFO] : Step action : ", Common_step.ACTION)
                Variable_not_resettable.logger.info(f"Action Name: {Common_step.BASE_ACTION}")
                Common_step.step_count = Common_step.step_count_per_execution
                Common_step.step_count_per_execution = Common_step.step_count_per_execution + 1
                Common_step.step_id, Common_step.STEP_DESC = step['STEP_ID'], step['STEP_DESC']
                Common_step.STEP_TYPE, Common_step.XRAY_TEST_CASE_ID = step["STEP_TYPE"], step["XRAY_TEST_CASE_ID"]

                if Common_scenario.xray_test_case_id:
                    Common_step.XRAY_TEST_CASE_ID = Common_scenario.xray_test_case_id

                Common_step.PAGE_NAME, Common_step.DATA_NAME = step['PAGE_NAME'], step['DATA_NAME']
                time.sleep(0.5)
                wait_unitil_please_wait(page, 100)
                wait_and_close_popup(page)
                for_logging_out(page)
                log_step_list.append(log_list('PASS'))
                
        
        elif str(Common_step.ACTION).upper() == "RELAUNCH_URL":
            if step["STEP_ID"] >= int(Common_scenario.STEP_ID_START) and step["STEP_ID"] <= int(Common_scenario.STEP_ID_END):
                time.sleep(10)
                launch_url(page, Common_object.test_config_dictionary["ApplicationURL"], 1200000)
        else:
            if step["STEP_TYPE"] == "UI_ACTION":
                try:
                    if str(Common_step.BASE_ACTION) != "nan" and step["STEP_ID"] >= int(Common_scenario.STEP_ID_START) and step["STEP_ID"] <= int(Common_scenario.STEP_ID_END):
                        Variable_not_resettable.logger.info("Running step : "+ str(step["STEP_ID"]))
                        Running_step="Running step : "+ str(step["STEP_ID"])
                        if Running_step=="Running step : 1007":
                            print("debug")
                        Common_step.step_count = Common_step.step_count_per_execution
                        Common_step.step_count_per_execution = Common_step.step_count_per_execution + 1
                        Variable_not_resettable.logger.info(f"Action Name: {Common_step.BASE_ACTION}")
                        Variable_not_resettable.logger.info("STEP Description : "+ str(step["STEP_DESC"]))
                        Common_step.step_id = step['STEP_ID']
                        if Common_step.step_id != None:
                            Common_step.PRE_NAV_CONFIG = step['STEP_CONFIG']
                            Common_step.STEP_TYPE, Common_step.XRAY_TEST_CASE_ID = step["STEP_TYPE"], step["XRAY_TEST_CASE_ID"]

                            if Common_scenario.xray_test_case_id:
                                Common_step.XRAY_TEST_CASE_ID = Common_scenario.xray_test_case_id

                            Common_step.PAGE_NAME, Common_step.DATA_NAME = step['PAGE_NAME'], step['DATA_NAME']

                            if "," in str(step['DATA_REFERENCE']):
                                Common_step.DATA_REFERENCE1 = str(step['DATA_REFERENCE']).split(",")[0].strip()
                                Common_step.DATA_REFERENCE2=str(step['DATA_REFERENCE']).split(",")[1].strip()

                            Common_step.ELEMENT_REFERENCE, Common_step.DATA_REFERENCE = step['ELEMENT_REFERENCE'], str(step['DATA_REFERENCE'])
                            Variable_not_resettable.logger.info("ELEMENT REF : "+ str(step["ELEMENT_REFERENCE"])+ "|| DATA REF : "+ str(step['DATA_REFERENCE']))
                            if str(Common_step.PAGE_NAME) != "nan":
                                Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET = tuple(split_by_colon(Common_step.PAGE_NAME))
                            else:
                                Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET = "nan", "nan"
                            Common_step.STEP_DESC = step['STEP_DESC']
                            if str(Common_step.DATA_NAME) != "nan":
                                data_name = split_by_colon(Common_step.DATA_NAME)
                                if len(data_name) <= 1:
                                    error_str = "Please check the Data Name in step sheet"
                                    Variable_not_resettable.logger.error(error_str)
                                    raise Exception(error_str)
                                if len(data_name) > 2:
                                    data_name = split_by_colon(Common_step.DATA_NAME)[:2]
                                    Common_step.DATA_FILE, Common_step.DATA_SHEET = tuple(data_name)
                                else:
                                    Common_step.DATA_FILE, Common_step.DATA_SHEET = tuple(data_name)
                            else:
                                Common_step.DATA_FILE, Common_step.DATA_SHEET = "nan", "nan"
                            Variable_not_resettable.logger.info("DATA_FILE || DATA_SHEET,  :"+ str(Common_step.DATA_FILE) +" || "+str(Common_step.DATA_SHEET))
                            if str(Common_step.PRE_NAV_CONFIG) != "nan":
                                PRE_NAV_CONFIG_LIST = str(Common_step.PRE_NAV_CONFIG).split(",")
                                PRE_NAV_CONFIG_LIST = [per_nav_config.strip() for per_nav_config in PRE_NAV_CONFIG_LIST]
                                if "PREREQ_CONFIG" in str(Common_step.PRE_NAV_CONFIG):
                                    Common_step.is_pre_config = True
                                    Variable_not_resettable.logger.info("DOING PRECONFIG")
                                    pre_config_variables(page,context, PRE_NAV_CONFIG_LIST, loop_count)
                                    if "NAV_ID" in str(Common_step.PRE_NAV_CONFIG) and "PREREQ_CONFIG" in str(Common_step.PRE_NAV_CONFIG):
                                        Common_step.is_nav_config = True
                                        Variable_not_resettable.logger.info("DOING NAVIGATION with NavigationConfigID :"+ str(PRE_NAV_CONFIG_LIST[1]))
                                        navigation_elements(PRE_NAV_CONFIG_LIST[1])
                                        time.sleep(1)
                                        wait_and_close_popup(page)
                                        navigation_runner(page, str(PRE_NAV_CONFIG_LIST[1]))
                                elif "SWITCH_CONTEXT" in Common_step.PRE_NAV_CONFIG or "CHANGE_CONTEXT" in Common_step.PRE_NAV_CONFIG:
                                    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                                        # time.sleep(15)
                                        # context = "//*[@class='x-btn-inner x-btn-inner-default-toolbar-small']"
                                        # Menu = "//*[@class='icon-wrap icon-s icon-left']"
                                        Menu = "//*[@id='MenuBar_Icon_toggleSideNav']"
                                        context = "//*[@id='btnContextSwitch_button_btnEl']"
                                        user_menu_icon = '//*[@id="userMenu_button_icon"]'
                                        for_click(page,user_menu_icon)
                                    else:
                                        Common_step.is_switch_context = True
                                        Variable_not_resettable.logger.info("DOING SWITCH CONTEXT")
                                        context = "//*[starts-with(@id,'userMenu-button')]//*[contains(@id, 'btnWrap')]"
                                        switch_context = "//*[@aria-expanded='true']//*[starts-with(@id,'menuitem')]//*[contains(@id, 'textEl')  and text()='Change Context']"
                                        for_click(page,context)
                                        for_click(page,switch_context)
                                else:
                                    if "NAV_ID" in Common_step.PRE_NAV_CONFIG:
                                        Common_step.is_nav_config = True
                                        Variable_not_resettable.logger.info("DOING NAVIGATION, NavigationConfigID :"+ str(PRE_NAV_CONFIG_LIST[0]))
                                        navigation_elements(PRE_NAV_CONFIG_LIST[0])
                                        wait_and_close_popup(page)
                                        navigation_runner(page, str(PRE_NAV_CONFIG_LIST[0]))
                            if str(Common_step.PAGE_NAME).lower() != "nan" and Common_step.PAGE_NAME != None and Common_step.PAGE_NAME != "":
                                if step.get("Client") != None:
                                    controlSheet_dictionary_config(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
                                else:
                                    controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
                                controlSheet_data = controlSheet_element_value(Common_step.ELEMENT_REFERENCE)
                                if controlSheet_data == None:
                                    Common_object.Custom_Error = "Control Element Reference is not present"
                                    raise Exception(Common_object.Custom_Error)
                                Common_controls.control_Element= controlSheet_data['Element']
                                Common_controls.control_Type = controlSheet_data['Type']
                                Common_controls.control_Identifier = controlSheet_data['Identifier']
                                Common_controls.control_Value = controlSheet_data['Value']
                                Variable_not_resettable.logger.info("CONTROL SHEET VALUE : "+ str(Common_controls.control_Value))
                            if str(Common_step.DATA_NAME) != "nan":
                                dataSheet_dictionary(Common_step.DATA_FILE, Common_step.DATA_SHEET)
                                Common_object_dataSheet_dictionary_1 = []
                                if Common_object.dataSheet_dictionary!=None:
                                    for i in range(len(Common_object.dataSheet_dictionary)):
                                        Common_object_dataSheet_dictionary_1.append({str(k).lower(): v for k, v in Common_object.dataSheet_dictionary[i].items()})
                                    
                                Common_object.dataSheet_dictionary = Common_object_dataSheet_dictionary_1
                                Common_step.DATA_REFERENCE = Common_step.DATA_REFERENCE.lower()
                                if loop_count == None:
                                    if len(Common_object.dataSheet_dictionary) >= data_provider_num:
                                        final_loop_count = (data_provider_num-1)
                                        Common_scenario.data_provider_num = final_loop_count
                                        execute_step(page, context, loop_count)
                                    else:
                                        final_loop_count = 0
                                        Common_scenario.data_provider_num = final_loop_count
                                        execute_step(page, context, loop_count)
                                if loop_count != None:
                                    if len(Common_object.dataSheet_dictionary) >= data_provider_num:
                                        check_loop_count = data_provider_num  + loop_count
                                        if len(Common_object.dataSheet_dictionary) >= check_loop_count:
                                            final_loop_count = (data_provider_num - 1) + loop_count
                                            Common_scenario.data_provider_num = final_loop_count
                                            execute_step(page, context, loop_count)
                                        else:
                                           
                                            final_loop_count = 0
                                            Common_scenario.data_provider_num = final_loop_count
                                            execute_step(page, context, loop_count)
                                    else:
                                        data_provider_num = 1
                                        check_loop_count = data_provider_num  + loop_count
                                        if len(Common_object.dataSheet_dictionary) >= check_loop_count:
                                            final_loop_count = (data_provider_num - 1) + loop_count
                                            Common_scenario.data_provider_num = final_loop_count
                                            execute_step(page, context, loop_count)
                                        else:
                                            final_loop_count = 0
                                            Common_scenario.data_provider_num = final_loop_count
                                            execute_step(page, context, loop_count)
                            else:
                                check_action_available(Common_step.ACTION)
                                page_action(page,context, Common_step.ACTION,  get_locator(page,Common_step.ACTION, Common_controls.control_Value, loop_count), "")
                                if Variable_not_resettable.APP_TYPE == "Studio":
                                    popuphandler_for_studio(page)
                                # end_time = datetime.now().replace(microsecond=0)
                                # Common_step.step_execution_time = end_time - start_time
                    if Variable_not_resettable.APP_TYPE != "Nebula co-existence":
                        if "save" in  str(Common_step.ELEMENT_REFERENCE).lower().strip():
                            wait_unitil_please_wait(page,3000)
                    if Common_step.step_id != None:
                        # Print current time with microseconds
                        current_time = datetime.now()
                        print(current_time.strftime("%Y-%m-%d %H:%M:%S.%f"))
                        wait_unitil_please_wait(page,100)
                        # Print current time with microseconds
                        current_time = datetime.now()
                        print(current_time.strftime("%Y-%m-%d %H:%M:%S.%f"))
                        wait_and_close_popup(page)
                        if Common_step.ACTION == "Click Link" or Common_step.ACTION == "Click Button Icon":
                            if str(Variable_not_resettable.test_properties.get("breadcrumb_log")).upper() == "TRUE": 
                                set_breadcrumb_value(page)
                        Common_main_object.test_result_log_info_dict.update({'RESULT': 'SUCCESS', 'ERROR SNAPSHOT': None})
                        Common_main_object.test_result_log_debug_dict.update({'RESULT': 'SUCCESS', 'ERROR SNAPSHOT': None, 'STEP ID': Common_step.step_id,
                            'XRAY TEST CASE ID': Common_step.XRAY_TEST_CASE_ID, 'PAGE OBJECT DATA': Common_controls.control_Element, 'ACTION': Common_step.BASE_ACTION, 'DATA VALUE': Common_data.data_value, 'Error_Raised': None, 'Custom_Error': None})
                        end_time = datetime.now().replace(microsecond=0)
                        Common_step.step_execution_time = end_time - start_time
                        log_step_list.append(log_list('PASS'))
                except Exception as error:
                    # print(error)
                    Variable_not_resettable.logger.info(str(error))
                    raise Exception(error)

            if step["STEP_TYPE"] == "DB_QUERY":
                if step["STEP_ID"] >= int(Common_scenario.STEP_ID_START) and step["STEP_ID"] <= int(Common_scenario.STEP_ID_END):
                    Variable_not_resettable.logger.info("Running step : "+ str(step["STEP_ID"]))
                    Common_step.step_count = Common_step.step_count_per_execution
                    Common_step.step_count_per_execution = Common_step.step_count_per_execution + 1
                    Common_step.step_id, Common_step.STEP_DESC = step['STEP_ID'], step['STEP_DESC']
                    Common_step.STEP_TYPE, Common_step.XRAY_TEST_CASE_ID = step["STEP_TYPE"], step["XRAY_TEST_CASE_ID"]

                    if Common_scenario.xray_test_case_id:
                        Common_step.XRAY_TEST_CASE_ID = Common_scenario.xray_test_case_id

                    Common_step.PAGE_NAME, Common_step.DATA_NAME = step['PAGE_NAME'], step['DATA_NAME']
                    wait_and_close_popup(page)
                    Variable_not_resettable.logger.info("Running step : "+ str(step["STEP_ID"]))
                    Variable_not_resettable.logger.info(f"Action Name: {Common_step.BASE_ACTION}")

                    if loop_count == None:
                        loop_count = 0
                        data_provider_num = data_provider_num - 1
                        final_loop_count = (data_provider_num + loop_count)
                        loop_count = None # resetting the loop count to previous value None
                        Common_scenario.data_provider_num = final_loop_count
                        Common_DB.db_query_output, Common_DB.db_query_value  = db_query_config(final_loop_count)
                        
                    if loop_count != None:
                        data_provider_num = data_provider_num - 1
                        final_loop_count = (data_provider_num + loop_count)
                        Common_scenario.data_provider_num = final_loop_count
                        Common_DB.db_query_output, Common_DB.db_query_value  = db_query_config(final_loop_count)

                    Variable_not_resettable.logger.info("DB output : "+ str(Common_DB.db_query_output))
                    end_time = datetime.now().replace(microsecond=0)
                    Common_step.step_execution_time = end_time - start_time
                    log_step_list.append(log_list('PASS'))

            if step["STEP_TYPE"] == "ASSERT":
                if str(Common_step.BASE_ACTION) != "nan" and step["STEP_ID"] >= int(Common_scenario.STEP_ID_START) and step["STEP_ID"] <= int(Common_scenario.STEP_ID_END):
                    Variable_not_resettable.logger.info("Running step : "+ str(step["STEP_ID"]))
                    Common_step.step_count = Common_step.step_count_per_execution
                    Common_step.step_count_per_execution = Common_step.step_count_per_execution + 1
                    Common_step.step_id, Common_step.STEP_DESC = step['STEP_ID'], step['STEP_DESC']
                    Common_step.STEP_TYPE, Common_step.XRAY_TEST_CASE_ID = step["STEP_TYPE"], step["XRAY_TEST_CASE_ID"]
                    Common_step.PAGE_NAME, Common_step.DATA_NAME = step['PAGE_NAME'], step['DATA_NAME']
                    Common_step.PRE_NAV_CONFIG = step['STEP_CONFIG']

                    Variable_not_resettable.logger.info(f"Action Name: {Common_step.BASE_ACTION}")
                    Variable_not_resettable.logger.info("STEP Description : "+ str(step["STEP_DESC"]))
                    if Common_step.step_id != None and Common_step.step_id != "nan" and Common_step.step_id != "" and Common_step.step_id != "Nan":
                        Common_step.ELEMENT_REFERENCE, Common_step.DATA_REFERENCE = step['ELEMENT_REFERENCE'], str(step['DATA_REFERENCE'])
                        Variable_not_resettable.logger.info("ELEMENT REF : " + str(step["ELEMENT_REFERENCE"]) + "|| DATA REF : " + str(step['DATA_REFERENCE']))                                                      
                        Assert_Excel_Column(Common_step.DATA_NAME, loop_count,data_provider_num,Common_step.DATA_REFERENCE)
                    end_time = datetime.now().replace(microsecond=0)
                    Common_step.step_execution_time = end_time - start_time
                    log_step_list.append(log_list('PASS'))
                
            if step["STEP_TYPE"] == "API_Request":
                Common_step.step_id, Common_step.STEP_TYPE, Common_step.STEP_DESC = step["STEP_ID"], step["STEP_TYPE"], step["STEP_DESC"]
                Common_step.XRAY_TEST_CASE_ID = step["XRAY_TEST_CASE_ID"]
                if Common_scenario.xray_test_case_id:
                    Common_step.XRAY_TEST_CASE_ID = Common_scenario.xray_test_case_id
                Common_step.DATA_NAME = step['DATA_NAME']
                Common_step.DATA_FILE, Common_step.DATA_SHEET = str(Common_step.DATA_NAME).split(":")
                Common_step.API_ID = str(Common_step.ACTION).split(":")[1]
                if str(Common_step.BASE_ACTION) != "nan" and step["STEP_ID"] >= int(Common_scenario.STEP_ID_START) and step["STEP_ID"] <= int(Common_scenario.STEP_ID_END):
                    Variable_not_resettable.logger.info("Running step : "+ str(step["STEP_ID"]))
                    data_file_path = Common_path.dataSheet_path+"/"+Common_object.test_config_dictionary["DataTag"]+"/"+Common_step.DATA_FILE+".xlsx"
                    run_api_request(data_file_path, Common_step.DATA_SHEET, loop_count, Common_step.API_ID)
                    log_step_list.append(log_list('PASS'))

        if "Assert Error Popup" in str(Common_step.BASE_ACTION):
            time.sleep(1)
            wait_unitil_please_wait(page,100)
            if Common_step.is_assert_error_popup_completed == False:
                raise Exception("Popup didn't appear in screen for the given assertion")
            wait_and_close_popup(page)
        if "On Availability" in Common_step.BASE_ACTION :
            wait_and_close_popup(page)
        if "Assert Popup" in str(Common_step.BASE_ACTION) :
            time.sleep(1)
            wait_unitil_please_wait(page,100)
            wait_and_close_popup(page)
        if "Skip Error" in str(Common_step.BASE_ACTION) :
            time.sleep(1)
            wait_unitil_please_wait(page,100)
            wait_and_close_popup(page)
        Variable_not_resettable.PREVIOUS_ACTION = step['ACTION']
    

def step_runner(page,context,data_provider_num, loop_count):
    Common_object.FIND_TYPE = Common_object.steps_dictionary[0]['FIND_TYPE']
    if str(Variable_not_resettable.APP_TYPE) == "Nebula co-existence":
        Common_step.PRE_NAV_CONFIG = Common_object.steps_dictionary[0]["STEP_CONFIG"]
        if str(Common_step.PRE_NAV_CONFIG).lower() not in ["nan", None]:
            PRE_NAV_CONFIG_LIST = str(Common_step.PRE_NAV_CONFIG).split(",")
            if ("SWITCH_CONTEXT" not in Common_step.PRE_NAV_CONFIG or "CHANGE_CONTEXT" not in Common_step.PRE_NAV_CONFIG) and "NAV_ID" in Common_step.PRE_NAV_CONFIG and "PREREQ_CONFIG" not in str(Common_step.PRE_NAV_CONFIG):
                PRE_NAV_CONFIG_LIST = [per_nav_config.strip() for per_nav_config in PRE_NAV_CONFIG_LIST]
                nav_config_id = [EACH_PRE_NAV_CONFIG_LIST for EACH_PRE_NAV_CONFIG_LIST in PRE_NAV_CONFIG_LIST if "NAV_ID" in EACH_PRE_NAV_CONFIG_LIST]
                if nav_config_id:
                    nav_config_id = nav_config_id[0]
                    nav_loop_count = 0
                    while 1:
                        try:
                            navigation_elements(nav_config_id)
                            navigation_runner(page, str(nav_config_id))
                            break
                        except Exception as error:
                            Variable_not_resettable.logger.error(str(error))
                            nav_loop_count +=1
                            if nav_loop_count == 3:
                                raise Exception(error)


    log_step_list = []
    for step in Common_object.steps_dictionary:
        if int(Common_scenario.STEP_ID_START) <= int(step["STEP_ID"]) <= int(Common_scenario.STEP_ID_END):
            try:
                start_time = datetime.now().replace(microsecond=0)
                run_step(page,context,data_provider_num, loop_count, step, log_step_list, start_time)
                reset_variables()
            except Exception as error:
                Variable_not_resettable.logger.info("1st Try Failed : "+str(error), exc_info= Variable_not_resettable.logger_exception_info)
                if Common_step.step_id != None:
                        try:
                            if Common_step.is_time_out != True:
                                wait_unitil_please_wait(page, 100)
                                Variable_not_resettable.logger.debug("Try1 coming to check popup *****************")
                                wait_and_close_popup(page)
                            Variable_not_resettable.logger.info("Page time out : " + str(Common_step.is_time_out))
                            Variable_not_resettable.logger.info("Click Done : " + str(Common_step.is_click_done))
                            if (step["STEP_TYPE"] == "DB_QUERY" or Common_step.is_time_out == True or Common_step.is_click_done == True or Common_step.skip_redo == True or step["STEP_TYPE"] == "API_Request" or Common_step.Assert_downloaded_excel_column == True) and (Common_step.is_pre_config==False and Common_step.is_nav_config ==False and Common_step.is_switch_context== False):
                                Variable_not_resettable.logger.info("Page time out raising exception or click already happened or DB query issue")
                                raise Exception(error)
                            # wait_unitil_please_wait(page, 100)
                            # wait_and_close_popup(page)
                            Common_step.step_count_per_execution = Common_step.step_count_per_execution - 1
                            run_step(page,context,data_provider_num, loop_count, step, log_step_list, start_time)
                            reset_variables()
                        except Exception as error:
                            Variable_not_resettable.logger.info("2nd Try Failed : "+str(error))
                            try:
                                if Common_step.is_time_out != True:
                                    wait_unitil_please_wait(page, 100)
                                    Variable_not_resettable.logger.debug("Try2 coming to check popup *****************")
                                    wait_and_close_popup(page)
                                if (step["STEP_TYPE"] == "DB_QUERY" or Common_step.is_time_out == True or Common_step.is_click_done == True or Common_step.skip_redo == True or step["STEP_TYPE"] == "API_Request" or Common_step.Assert_downloaded_excel_column == True) and (Common_step.is_pre_config==False and Common_step.is_nav_config==False and Common_step.is_switch_context== False):
                                    Variable_not_resettable.logger.info("Page time out raising exception or click already happened")
                                    raise Exception(error)
                                # wait_unitil_please_wait(page, 100)
                                # wait_and_close_popup(page)
                                Common_step.step_count_per_execution = Common_step.step_count_per_execution - 1
                                run_step(page,context,data_provider_num, loop_count, step, log_step_list, start_time)
                                reset_variables()
                            except Exception as error:
                                Variable_not_resettable.logger.info("3rd Try Failed : "+str(error))
                                try:
                                    if Common_step.is_time_out != True:
                                        wait_unitil_please_wait(page, 100)
                                        Variable_not_resettable.logger.debug("Try3 coming to check popup *****************")

                                        try:
                                            test_properties = read_properties_file("test.properties")
                                            if test_properties.get("html_writer") == "True":
                                                html_content = page.query_selector("html")
                                                data = html_content.inner_html()
                                                writing_html_log(data)
                                        except:
                                            pass

                                        wait_and_close_popup(page)
                                    if (step["STEP_TYPE"] == "DB_QUERY" or Common_step.is_time_out == True or Common_step.is_click_done == True or Common_step.skip_redo == True or step["STEP_TYPE"] == "API_Request" or Common_step.Assert_downloaded_excel_column == True) and (Common_step.is_pre_config==False and Common_step.is_nav_config ==False and Common_step.is_switch_context== False):
                                        Variable_not_resettable.logger.info("Page time out raising exception or click already happened")
                                        raise Exception(error)
                                    # wait_unitil_please_wait(page, 100)
                                    # wait_and_close_popup(page)
                                    Common_step.step_count_per_execution = Common_step.step_count_per_execution - 1
                                    run_step(page,context,data_provider_num, loop_count, step, log_step_list, start_time)
                                    reset_variables()
                                except Exception as error:
                                    error_str = error
                                    if Common_step.error_popup_message == None:
                                        Common_step.error_popup_message = str(error_str)
                                    error_popup_message_customization()
                                    Variable_not_resettable.logger.info("4th Try Failed : "+str(error))
                                    Common_scenario.error_snapshot_file_name = for_error_snapshot(page)
                                    end_time = datetime.now().replace(microsecond=0)
                                    Common_step.step_execution_time = end_time - start_time
                                    try:
                                        # if Common_object.test_config_dictionary["Rtrack"] == "ON":
                                        #     Variable_not_resettable.logger.info("Creating RTRACK issue via jira API")
                                        #     # We have to map the jira here for creating issue in rTrack
                                        #     jira_response: dict = jira_raise_ticket()
                                        #     Common_scenario.RTRACK_ID = jira_response
                                        
                                        if Common_object.test_config_dictionary["Rtrack"] == "ON":
                                            Variable_not_resettable.logger.info("Creating RTRACK issue via jira API")
                                            # We have to map the jira here for creating issue in rTrack
                                            jira_response: dict = jira_raise_ticket()
                                            Common_scenario.RTRACK_ID = jira_response
                                        elif str(Common_object.test_config_dictionary["Rtrack"]).lower() == "rtask":
                                            Variable_not_resettable.logger.info("Creating Rtask Issue")
                                            # We have to map the jira here for creating issue in rTrack
                                            jira_response: dict = rtask_raise_ticket()
                                            Common_scenario.RTRACK_ID = jira_response

                                    except Exception as error:
                                        Variable_not_resettable.logger.info("rTrack issue : "+str(error))
                                        Common_scenario.RTRACK_ID = "rTrack issue : "+str(error)

                                    # Common_object.Custom_Error = str(error)
                                    if Common_step.error_popup_message == None:
                                        Common_step.error_popup_message = str(error_str)
                                    
                                    log_step_list.append(log_list('FAIL'))
                                    advance_debug_log(log_step_list)
                                    Variable_not_resettable.logger.info(str(error_str))
                                    Common_main_object.test_result_log_info_dict.update({'RESULT': 'FAILURE', 'ERROR SNAPSHOT': Common_scenario.error_snapshot_file_name})
                                    Common_main_object.test_result_log_debug_dict.update({'RESULT': 'FAILURE', 'ERROR SNAPSHOT': Common_scenario.error_snapshot_file_name, 'STEP ID': Common_step.step_id,
                                        'XRAY TEST CASE ID': Common_step.XRAY_TEST_CASE_ID, 'PAGE OBJECT DATA': Common_controls.control_Element, 'ACTION': Common_step.BASE_ACTION, 'DATA VALUE': Common_data.data_value, 'Error_Raised': Common_object.Error_Raised, 'Custom_Error': Common_object.Custom_Error_1, 'ERROR_MESSAGE': Common_step.error_popup_message})
                                    reset_variables()
                                    raise Exception (f"[ERROR] : Exit step and then Exit the scenario {str(error_str)}")
    advance_debug_log(log_step_list)


def step_execution_based_on_loop(page,context, scenarios, loop_count, data_provider_num):
    # print("[INFO] : Running Scenario Step : ",scenarios['SCENARIO_STEP_ID'])
    Variable_not_resettable.logger.info("Running Scenario Step : "+ str(scenarios['SCENARIO_STEP_ID']))
    Running_step="Running Scenario Step : "+ str(scenarios['SCENARIO_STEP_ID'])
    
    try:
        Common_scenario.INPUT_TYPE = scenarios['INPUT_TYPE']

        Common_scenario.STEPS_FILE_REFERENCE = scenarios['STEPS_FILE_REFERENCE']
        Common_scenario.STEPS_ID_REFERENCE = scenarios["STEPS_ID_REFERENCE"]  
        # Common_scenario.DATA_PROVIDER = scenarios[str(list((Common_object.scenarios_dictionary[0]).keys())[5])]     
        Common_scenario.STEP_FILE, Common_scenario.STEP_SHEET = tuple(split_by_colon(Common_scenario.STEPS_FILE_REFERENCE))
        Common_scenario.STEP_ID_START, Common_scenario.STEP_ID_END = tuple(split_by_dash(Common_scenario.STEPS_ID_REFERENCE))
        if Common_config.client_name != None:
            if  scenarios["A"] == "START" and "(BASE)" in Common_scenario.STEP_FILE:
                # print("Client scenario with base")
                Common_scenario.STEP_FILE = str(Common_scenario.STEP_FILE).split(")")[1]
                excel_file = pd.ExcelFile(join_path_and_file(Common_path.steps_path, Common_scenario.STEP_FILE+".xlsx"))
                excel_sheets = excel_file.sheet_names
                sheet_name_new = [name for name in excel_sheets if name.lower() == Common_scenario.STEP_SHEET.lower()]
                Common_object.steps_dictionary = read_excel_return_dictionary_for_row_based_for_step_sheet(join_path_and_file(Common_path.steps_path, Common_scenario.STEP_FILE+".xlsx"), sheet_name_new[0])
                # print("steps_dict:",Common_object.steps_dictionary)
                if Common_scenario.INPUT_TYPE == "STEPS":
                    step_runner(page,context, data_provider_num, loop_count)

                elif Common_scenario.INPUT_TYPE == "DB_QUERY" or Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                    if Common_scenario.INPUT_TYPE == "DB_QUERY":
                        Common_scenario.FLOW_CONFIG_LIST = str(scenarios['FLOW_CONFIG']).split(";")
                        step_runner(page,context, data_provider_num, loop_count)
                    # if Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                    #     if Common_DB.db_query_output != None:
                    #         if Common_DB.db_query_output == str(scenarios['FLOW_CONFIG']):
                    #             step_runner(page,context, data_provider_num, loop_count)
                    #             Common_DB.db_query_output = None
                    if Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                        if Common_DB.db_query_output != None:
                            for i in range(len(Common_scenario.FLOW_CONFIG_LIST)):
                                flow_config = Common_scenario.FLOW_CONFIG_LIST[i][1:-1]
                                file_sheet_col_range = flow_config.split(":")
                                dataSheet_dictionary(file_sheet_col_range[0], file_sheet_col_range[1])
                                flow_config_col = file_sheet_col_range[2].split(",")[0]
                                # flow_config_value = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num, flow_config_col)
                                flow_config_value = Common_object.dataSheet_dictionary[0][flow_config_col]
                                flow_config_range = file_sheet_col_range[2].split(",")[1]
                                Common_scenario.STEP_ID_START, Common_scenario.STEP_ID_END = tuple(split_by_dash(flow_config_range)) 
                                if Common_DB.db_query_value == str(flow_config_value):
                                    step_runner(page,context, data_provider_num, loop_count)
                                    Common_DB.db_query_output = None
                                    Common_DB.db_query_value = None
                                    break
            elif  scenarios["A"] == "START" and "(BASE)" not in Common_scenario.STEP_FILE: 
                # print("Client scenario without base")
                base_path = os.getcwd()
                # print("Here it is Coming")
                client_step_path = base_path + "/Files/Steps/"+Common_config.client_name
                config_steps_path = base_path + "/Files/Config/"+Common_config.client_name+"/Page/"
                excel_file = pd.ExcelFile(join_path_and_file(Common_path.steps_path, Common_scenario.STEP_FILE+".xlsx"))
                excel_sheets = excel_file.sheet_names
                sheet_name_new = [name for name in excel_sheets if name.lower() == Common_scenario.STEP_SHEET.lower()]
                Common_object.steps_dictionary = read_excel_return_dictionary_for_row_based_for_step_sheet(join_path_and_file(client_step_path, Common_scenario.STEP_FILE+".xlsx"), sheet_name_new[0])
                # Common_object.steps_dictionary = read_config_step_return_step_dict(join_path_and_file(config_steps_path, Common_scenario.STEP_FILE+".xlsx"), Common_scenario.STEP_SHEET,Common_object.steps_dictionary)
                if Common_scenario.INPUT_TYPE == "STEPS":
                    step_runner(page,context, data_provider_num, loop_count)

                elif Common_scenario.INPUT_TYPE == "DB_QUERY" or Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                    if Common_scenario.INPUT_TYPE == "DB_QUERY":
                        Common_scenario.FLOW_CONFIG_LIST = str(scenarios['FLOW_CONFIG']).split(";")
                        step_runner(page,context, data_provider_num, loop_count)
                    # if Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                    #     if Common_DB.db_query_output != None:
                    #         if Common_DB.db_query_output == str(scenarios['FLOW_CONFIG']):
                    #             step_runner(page,context, data_provider_num, loop_count)
                    #             Common_DB.db_query_output = None
                    if Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                        if Common_DB.db_query_output != None:
                            for i in range(len(Common_scenario.FLOW_CONFIG_LIST)):
                                flow_config = Common_scenario.FLOW_CONFIG_LIST[i][1:-1]
                                file_sheet_col_range = flow_config.split(":")
                                dataSheet_dictionary(file_sheet_col_range[0], file_sheet_col_range[1])
                                flow_config_col = file_sheet_col_range[2].split(",")[0]
                                # flow_config_value = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num, flow_config_col)
                                flow_config_value = Common_object.dataSheet_dictionary[0][flow_config_col]
                                flow_config_range = file_sheet_col_range[2].split(",")[1]
                                Common_scenario.STEP_ID_START, Common_scenario.STEP_ID_END = tuple(split_by_dash(flow_config_range)) 
                                if Common_DB.db_query_value == str(flow_config_value):
                                    step_runner(page,context, data_provider_num, loop_count)
                                    Common_DB.db_query_output = None
                                    Common_DB.db_query_value = None
                                    break
            
            elif scenarios["A"] == "START_SCENARIO" or str(scenarios["A"]) == "nan":
                # print("Normal Scenario with added Client Steps or without added client steps")
                base_path = os.getcwd()
                client_step_path = base_path + "/Files/Steps/"+Common_config.client_name
                config_steps_path = base_path + "/Files/Config/"+Common_config.client_name+"/Page/"
                excel_file = pd.ExcelFile(join_path_and_file(Common_path.steps_path, Common_scenario.STEP_FILE+".xlsx"))
                excel_sheets = excel_file.sheet_names
                sheet_name_new = [name for name in excel_sheets if name.lower() == Common_scenario.STEP_SHEET.lower()]
                if len(Common_config.config_step_dict) != 0:
                    for config_step in Common_config.config_step_dict:
                        if str(config_step['PageID']) != "nan":
                            Common_config_step.step_file_reference = config_step['PageID']
                            Common_config_step.CONFIG_STEP_FILE, Common_config_step.CONFIG_STEP_SHEET = tuple(split_by_colon(Common_config_step.step_file_reference))
                            Common_object.steps_dictionary = read_excel_return_dictionary_for_row_based_for_step_sheet(join_path_and_file(Common_path.steps_path, Common_scenario.STEP_FILE+".xlsx"), sheet_name_new[0])
                            if str(Common_scenario.STEP_FILE) == str(Common_config_step.CONFIG_STEP_FILE) and str(sheet_name_new[0])== str(Common_config_step.CONFIG_STEP_SHEET):
                                Common_object.steps_dictionary = read_config_step_return_step_dict(join_path_and_file(config_steps_path, Common_config_step.CONFIG_STEP_FILE+".xlsx"),Common_config_step.CONFIG_STEP_SHEET,Common_object.steps_dictionary)
                                Variable_not_resettable.logger.info(Common_object.steps_dictionary)
                                break
                        else:
                            Common_object.steps_dictionary = read_excel_return_dictionary_for_row_based_for_step_sheet(join_path_and_file(Common_path.steps_path, Common_scenario.STEP_FILE+".xlsx"), sheet_name_new[0])   
                else:
                    Common_object.steps_dictionary = read_excel_return_dictionary_for_row_based_for_step_sheet(join_path_and_file(Common_path.steps_path, Common_scenario.STEP_FILE+".xlsx"), sheet_name_new[0])   
                if Common_scenario.INPUT_TYPE == "STEPS":
                    step_runner(page,context, data_provider_num, loop_count)

                elif Common_scenario.INPUT_TYPE == "DB_QUERY" or Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                    if Common_scenario.INPUT_TYPE == "DB_QUERY":
                        Common_scenario.FLOW_CONFIG_LIST = str(scenarios['FLOW_CONFIG']).split(";")
                        step_runner(page,context, data_provider_num, loop_count)
                    # if Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                    #     if Common_DB.db_query_output != None:
                    #         if Common_DB.db_query_output == str(scenarios['FLOW_CONFIG']):
                    #             step_runner(page,context, data_provider_num, loop_count)
                    #             Common_DB.db_query_output = None
                    if Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                        if Common_DB.db_query_output != None:
                            for i in range(len(Common_scenario.FLOW_CONFIG_LIST)):
                                flow_config = Common_scenario.FLOW_CONFIG_LIST[i][1:-1]
                                file_sheet_col_range = flow_config.split(":")
                                dataSheet_dictionary(file_sheet_col_range[0], file_sheet_col_range[1])
                                flow_config_col = file_sheet_col_range[2].split(",")[0]
                                # flow_config_value = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num, flow_config_col)
                                flow_config_value = Common_object.dataSheet_dictionary[0][flow_config_col]
                                flow_config_range = file_sheet_col_range[2].split(",")[1]
                                Common_scenario.STEP_ID_START, Common_scenario.STEP_ID_END = tuple(split_by_dash(flow_config_range)) 
                                if Common_DB.db_query_value == str(flow_config_value):
                                    step_runner(page,context, data_provider_num, loop_count)
                                    Common_DB.db_query_output = None
                                    Common_DB.db_query_value = None
                                    break
        else:
            if str(scenarios["A"]) == "START_SCENARIO" or str(scenarios["A"]) == "nan":
                # print("Normal scenario")
                excel_file = pd.ExcelFile(join_path_and_file(Common_path.steps_path, Common_scenario.STEP_FILE+".xlsx"))
                excel_sheets = excel_file.sheet_names
                sheet_name_new = [name for name in excel_sheets if name.lower() == Common_scenario.STEP_SHEET.lower()]
                if not sheet_name_new:
                    raise Exception(f"Given step sheet: {Common_scenario.STEP_SHEET.lower()} not found.")
                Common_scenario.DATA_PROVIDER = scenarios[str(list((Common_object.scenarios_dictionary[0]).keys())[5])]
                Common_object.steps_dictionary = read_excel_return_dictionary_for_row_based_for_step_sheet(join_path_and_file(Common_path.steps_path, Common_scenario.STEP_FILE+".xlsx"), sheet_name_new[0])
                if Common_scenario.INPUT_TYPE == "STEPS":
                    step_runner(page,context, data_provider_num, loop_count)

                elif Common_scenario.INPUT_TYPE == "DB_QUERY" or Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                    if Common_scenario.INPUT_TYPE == "DB_QUERY":
                        Common_scenario.FLOW_CONFIG_LIST = str(scenarios['FLOW_CONFIG']).split(";")
                        step_runner(page,context, data_provider_num, loop_count)
                    # if Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                    #     if Common_DB.db_query_output != None:
                    #         if Common_DB.db_query_output == str(scenarios['FLOW_CONFIG']):
                    #             step_runner(page,context, data_provider_num, loop_count)
                    #             Common_DB.db_query_output = None
                    if Common_scenario.INPUT_TYPE == "STEP_OPTIONS":
                        if Common_DB.db_query_output != None:
                            for i in range(len(Common_scenario.FLOW_CONFIG_LIST)):
                                flow_config = Common_scenario.FLOW_CONFIG_LIST[i][1:-1]
                                file_sheet_col_range = flow_config.split(":")
                                dataSheet_dictionary(file_sheet_col_range[0], file_sheet_col_range[1])
                                flow_config_col = file_sheet_col_range[2].split(",")[0]
                                # flow_config_value = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num, flow_config_col)
                                flow_config_value = Common_object.dataSheet_dictionary[0][flow_config_col]
                                flow_config_range = file_sheet_col_range[2].split(",")[1]
                                Common_scenario.STEP_ID_START, Common_scenario.STEP_ID_END = tuple(split_by_dash(flow_config_range)) 
                                if Common_DB.db_query_value == str(flow_config_value):
                                    step_runner(page,context, data_provider_num, loop_count)
                                    Common_DB.db_query_output = None
                                    Common_DB.db_query_value = None
                                    break
        
        reset_step_dict()   
    except Exception as error:
        reset_step_dict()     
        Variable_not_resettable.logger.debug(str(error))
        raise Exception (f"Exiting the step_execution_based_on_loop: {str(error)}")
        



def scenario_step(scenarios_file, num):
    #  Common_object.scenarios_meta, Common_object.scenarios_dictionary = scenario_sheet_filter_steps(scenarios_file)
    #  data_provider_header = str(list((Common_object.scenarios_dictionary[0]).keys())[5])
    #  data_provider_count = data_provider(data_provider_header)
    #  #print("[INFO] : Data Provider : ", data_provider_count)
    #  #print("scenarios_dictionary : ", Common_object.scenarios_dictionary)
    #  if select_scenario_tags(Common_object.scenarios_meta["SCENARIO_TAGS"]):
    #     for num in data_provider_count:
    #         # print("[INFO] : Running Data provider "+ Common_object.scenarios_meta["SCENARIO_ID"]+"_"+str(num))
            try:
                temp_log_list = []
                is_browser_launched = False
                if Common_object.test_config_dictionary["ParallelExecution"] == "ON":
                    video_file_name=Common_object.scenarios_meta["SCENARIO_ID"] + "_" + str(num) + "_" + str(datetime.now()).replace(":", "_")+"_"+ str(Parallel_common_object.process_id) +".webm"
                else:
                    video_file_name=Common_object.scenarios_meta["SCENARIO_ID"] + "_" + str(num) + "_" + str(datetime.now()).replace(":", "_")+".webm"
                Common_object.ERROR_VIDEO_PATH=Common_main_object.advance_debug_log_folder + "/Error_video/"+video_file_name
                currentDate = date.today()
                customname = currentDate.strftime('%Y/%m/%d')
                Common_object.VIDEO_PATH=customname+"/Error_video/"+video_file_name


                make_directory(Variable_not_resettable.user_data_dir)

                if Common_object.test_config_dictionary.get("Browser") == "chrome-persistent-context" or Common_object.test_config_dictionary.get("Browser") == "msedge-persistent-context" or Common_object.test_config_dictionary.get("Browser") =='driver-chrome': 

                    browser, context, page = get_browser_context_page_persistent_context()

                else:
                    browser, context, page = get_browser_context_page()
                launch_url(page, Common_object.test_config_dictionary["ApplicationURL"], 1200000)
                is_browser_launched = True
                max_retries = 5
                for attempt in range(max_retries):
                    try:
                        # Try to wait for the page to load
                        wait_unitil_load(page, 3000)
                        print("Page loaded successfully.")
                        break  # Break out of the loop if the page loads successfully
                    except Exception as pageload_error:
                        # Handle page load error
                        print(f"Attempt {attempt + 1}: Page load error: {pageload_error}")

                        # Attempt to relaunch the URL
                        try:
                            launch_url(page, Common_object.test_config_dictionary["ApplicationURL"], 1200000)
                        except Exception as url_launch_error:
                            # Handle URL launch error separately
                            print(f"Attempt {attempt + 1}: URL launch error: {url_launch_error}")

                        # Wait before retrying, except for the final attempt
                        if attempt < max_retries - 1:
                            time.sleep(2)
                        else:
                            print("Failed to load the page after 5 attempts.")
                
                wait_unitil_please_wait(page, 1000)
                data_provider_num = num
                if Common_config.config_scenario_dict != None:
                    if len(Common_config.config_scenario_dict) != 0:
                        for config_scenario in Common_config.config_scenario_dict:
                            config_scenarioID = config_scenario['ConfigScenarioID']
                            if str(config_scenarioID) == str(Common_object.scenarios_meta["SCENARIO_ID"]):
                                scenario_config_filePath = "./Files/Config/"+Common_config.client_name+"/Scenario/" + scenarios_file
                                config_scenario_sheetName = "Scenario"
                                read_configScenarioMaster_return_scenario_dict(scenario_config_filePath,config_scenario_sheetName, Common_object.scenarios_dictionary)
                                break
                    scenarios_dictionary = loop_wrapper(Common_object.scenarios_dictionary)
                    Variable_not_resettable.logger.info(scenarios_dictionary)
                    # exit()
                    for scenario_step in scenarios_dictionary: 
                        Common_scenario.xray_test_case_id  = None
                        if str(scenario_step["SCENARIO_STEP_ID"]) != "nan": # this line added because team give empty line in scenario's file 
                           
                            data_sheet_row = scenario_step.get("DATA_SHEET_ROW")
                            if data_sheet_row:
                                if data_sheet_row != "" and str(data_sheet_row).lower() != "nan" and data_sheet_row != "na" and data_sheet_row != "NA" and data_sheet_row != "NAN":
                                    data_provider_num = int(data_sheet_row)
                            
                            xray_test_case_id = scenario_step.get("XRAY_TEST_CASE_ID")
                            if xray_test_case_id:
                                if xray_test_case_id != "" and str(data_sheet_row).lower() != "nan" and xray_test_case_id != "na" and xray_test_case_id != "NA" and xray_test_case_id != "NAN":
                                    Common_scenario.xray_test_case_id =  xray_test_case_id

                           
                            step_execution_based_on_loop(page,context, scenario_step, scenario_step["loop_count_no"], data_provider_num) 
                else:
                    scenarios_dictionary = loop_wrapper(Common_object.scenarios_dictionary)
                    # print(scenarios_dictionary)
                    # exit()
                    for scenario_step in scenarios_dictionary:
                        Common_scenario.xray_test_case_id  = None
                        data_sheet_row = scenario_step.get("DATA_SHEET_ROW")
                        if data_sheet_row:
                            if data_sheet_row != "" and str(data_sheet_row).lower() != "nan" and data_sheet_row != "na" and data_sheet_row != "NA" and data_sheet_row != "NAN":
                                data_provider_num = int(data_sheet_row)

                        xray_test_case_id = scenario_step.get("XRAY_TEST_CASE_ID")
                        if xray_test_case_id:
                            if xray_test_case_id != "" and str(data_sheet_row).lower() != "nan" and xray_test_case_id != "na" and xray_test_case_id != "NA" and xray_test_case_id != "NAN":
                                Common_scenario.xray_test_case_id =  xray_test_case_id


                        if str(scenario_step["SCENARIO_STEP_ID"]) != "nan": # this line added because team give empty line in scenario's file 
                            step_execution_based_on_loop(page,context, scenario_step, scenario_step["loop_count_no"], data_provider_num)
                Common_object.SUCCESS_VIDEO_PATH=Common_main_object.advance_debug_log_folder + "/Success_video/"+video_file_name
                # print(Common_object.SUCCESS_VIDEO_PATH)
                reset_Common_scenario_loops_list()
                # page.pause()
                close_page(page)
                # print("page closed")
                Variable_not_resettable.logger.info("page closed")
                if Common_object.test_config_dictionary["VIDEOS"] == "SUCCESS" or  Common_object.test_config_dictionary["VIDEOS"] == "ALL":
                    # print("Success_video_inside")
                    # Variable_not_resettable.logger.info("Success_video_inside")
                    success_video_save_as(page)
                    paths= "Success_video/"+video_file_name
                    scenario = Common_object.scenarios_meta["SCENARIO_ID"] + "_Video"
                    hyper = '=HYPERLINK("%s", "%s")' % (paths, scenario)
                    Common_main_object.test_result_log_info_dict.update({'EXECUTION_VIDEO': hyper})
                    Common_main_object.test_result_log_debug_dict.update({'EXECUTION_VIDEO': hyper})
                Common_object.SUCCESS_VIDEO_PATH=None
                video_delete(page)
                if Common_object.test_config_dictionary.get("Browser") == "chrome-persistent-context" or Common_object.test_config_dictionary.get("Browser") == "msedge-persistent-context":
                    close_persistent_context(context, browser)
                    time.sleep(1)
                    try:
                        remove_folder(Variable_not_resettable.user_data_dir)
                    except Exception as remove_error:
                        count = 0
                        while 1:
                            if count == 3:
                                break
                            close_persistent_context(context, browser)
                            time.sleep(1)
                            try:
                                remove_folder(Variable_not_resettable.user_data_dir)
                                break
                            except Exception as remove_error:
                                print("RemoveError:"+str(remove_error))
                            count +=1
                    # remove_folder(Variable_not_resettable.user_data_dir)
                else:
                    close_browser_context(context, browser)
                
            except Exception as error:
                Variable_not_resettable.logger.error(str(error))
                # print(Common_main_object.test_result_log_debug_dict.get("ERROR_MESSAGE"), Common_scenario.error_snapshot_file_name)
                if Common_main_object.test_result_log_debug_dict.get("ERROR_MESSAGE") == None:
                    if Common_scenario.error_snapshot_file_name == None:
                        Common_scenario.error_snapshot_file_name = for_error_snapshot(page)
                    Common_main_object.test_result_log_info_dict.update({'ERROR SNAPSHOT': Common_scenario.error_snapshot_file_name})
                    Common_main_object.test_result_log_debug_dict.update({'ERROR_MESSAGE': str(error), 'ERROR SNAPSHOT': Common_scenario.error_snapshot_file_name})
                reset_Common_scenario_loops_list()
                try:
                    inspector = read_properties_file("test.properties")
                    if inspector["play_inspector"] == "True":
                        page.pause()
                except:
                    pass
                # page.pause()
                
                close_page(page)
             

                if Common_object.test_config_dictionary["VIDEOS"] == "FAILURE" or  Common_object.test_config_dictionary["VIDEOS"] == "ALL":
                    error_video_save_as(page)
                    scenario = Common_object.scenarios_meta["SCENARIO_ID"] + "_Video"
                    paths = "Error_video/"+video_file_name
                    hyper = '=HYPERLINK("%s", "%s")' % (paths, scenario)
                    Common_main_object.test_result_log_info_dict.update({'EXECUTION_VIDEO': hyper})
                    Common_main_object.test_result_log_debug_dict.update({'EXECUTION_VIDEO': hyper})
                Common_object.ERROR_VIDEO_PATH= None
                Common_object.VIDEO_PATH=None
                video_delete(page)
                
                if Common_object.test_config_dictionary.get("Browser") == "chrome-persistent-context" or Common_object.test_config_dictionary.get("Browser") == "msedge-persistent-context":
                    close_persistent_context(context, browser)
                    time.sleep(1)
                    try:
                        remove_folder(Variable_not_resettable.user_data_dir)
                    except Exception as remove_error:
                        count = 0
                        while 1:
                            if count == 3:
                                break
                            close_persistent_context(context, browser)
                            time.sleep(1)
                            try:
                                remove_folder(Variable_not_resettable.user_data_dir)
                                break
                            except Exception as remove_error:
                                print("RemoveError:"+str(remove_error))
                            count +=1
                    # remove_folder(Variable_not_resettable.user_data_dir)
                else:
                    close_browser_context(context, browser)

                if is_browser_launched == False:
                    Common_object.Error_Raised = str(error)
                    temp_log_list.append(log_list('FAIL'))
                    advance_debug_log(temp_log_list)
                

                raise Exception("Exception from Scenario step function")