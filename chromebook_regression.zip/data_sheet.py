from excel_utils import read_dataFrame_return_dictionary_for_row_based, read_excel_return_dataFrame_for_data_sheet
from common_object import Common_object, Common_path, Common_scenario, Common_step, Variable_not_resettable
import pandas as pd
# import win32com.client as win32
import openpyxl


def dataSheet_dictionary(file_name: str, sheet_name: str):
    sheet_name = str(sheet_name).strip()
    if str(Common_step.BASE_ACTION)!="Validate Output Files":
    # Variable_not_resettable.logger.info("Data sheet_name : "+ str(sheet_name))
        excel_file = pd.ExcelFile(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx")
        excel_sheets = excel_file.sheet_names
        sheet_name_new = [name for name in excel_sheets if name.lower() == sheet_name.lower()]

        if len(sheet_name_new) == 0:
            error_str = "Data file sheet name '"+ str(sheet_name)+"' not present in refereed excel workbook '"+str(Common_step.DATA_FILE)+".xlsx'"
            Variable_not_resettable.logger.error(error_str)
            raise Exception(error_str)

        # Variable_not_resettable.logger.info("Data sheet_name_new : "+ str(sheet_name_new))
        data_frame= read_excel_return_dataFrame_for_data_sheet(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx", sheet_name_new[0])
        dictionary_data = read_dataFrame_return_dictionary_for_row_based(data_frame)
        Common_object.dataSheet_dictionary = dictionary_data
    # Variable_not_resettable.logger.info(
    # Common_object.dataSheet_dictionary)


def get_date_from_data_sheet(file_name: str, sheet_name: str, column_name: str, loop_count: int):
    # Open the Excel workbook
    file_path = f"{Common_path.dataSheet_path}/{Common_object.test_config_dictionary['DataTag']}/{file_name}.xlsx"
    wb = openpyxl.load_workbook(file_path)
    
    # Get the sheet by name (case-insensitive search)
    sheet = None
    for sheet_in_wb in wb.sheetnames:
        if sheet_in_wb.lower() == sheet_name.lower():
            sheet = wb[sheet_in_wb]
            break
    
    if not sheet:
        raise ValueError(f"Sheet {sheet_name} not found.")
    
    # Find the column index for the given column name
    header = [cell.value for cell in sheet[1]]
    try:
        column_index = header.index(column_name) + 1  # 1-based index
    except ValueError:
        raise ValueError(f"Column {column_name} not found.")
    
    # Get the value from the specified row and column
    data_value = sheet.cell(row=loop_count + 1, column=column_index).value
    wb.close()
    return data_value

# def get_date_from_data_sheet_win32(file_name: str, sheet_name: str, column_name: str, loop_count: int):
#     excel = win32.gencache.EnsureDispatch("Excel.Application")
#     excel.DisplayAlerts = False
#     excel.Visible = True
#     wb = excel.Workbooks.Open(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx", UpdateLinks=False)
#     wb.AskToUpdateLinks = False
#     wb.DisplayAlerts = False
#     excel_sheets = [sheet.Name for sheet in wb.Sheets]
#     sheet_name_new = [name for name in excel_sheets if name.lower() == sheet_name.lower()]
#     ws = wb.Worksheets(sheet_name_new[0])
#     excel.DisplayAlerts = False
#     find = ws.Rows("1").Find(What=column_name, LookAt = 1)
#     address_obj = find.Address
#     address = address_obj.replace("$", "")
#     column_ref = ws.Range(address).Column
#     column_index = address_obj.split("$")[1]
#     ws.Columns(column_index + ':' + column_index).TextToColumns(Destination=ws.Range(column_index + "1"), DataType=1, TextQualifier=1, FieldInfo=(column_ref, 2))
#     data_value = ws.Cells(loop_count + 2,column_ref).Value
#     wb.Close()
#     return data_value

def dataSheet_element_value(element:str):
    return Common_object.dataSheet_dictionary[0][element]


def get_data_value(data_dict,final_loop_count,reference):
    data_reference = reference.lower()
    if len(data_dict)!=0:
        column_names = data_dict[final_loop_count].keys()
        for column in column_names:
            if data_reference == column.lower():
                data_value = data_dict[final_loop_count][column]
                data_value = str(data_value).replace("\u200b", "")
                return data_value
    

def final_loop_count(loop_count,data_provider_num, dataSheet_dictionary):
    if loop_count == None:
        if len(dataSheet_dictionary) >= data_provider_num:
            final_loop_count = (data_provider_num-1)
            Common_scenario.data_provider_num = final_loop_count
        else:
            final_loop_count = 0
            Common_scenario.data_provider_num = final_loop_count
    if loop_count != None:
        if len(dataSheet_dictionary) >= data_provider_num:
            check_loop_count = data_provider_num  + loop_count
            if len(dataSheet_dictionary) >= check_loop_count:
                final_loop_count = (data_provider_num - 1) + loop_count
                Common_scenario.data_provider_num = final_loop_count
            else:                
                final_loop_count = 0
                Common_scenario.data_provider_num = final_loop_count
        else:
            data_provider_num = 1
            check_loop_count = data_provider_num  + loop_count
            if len(dataSheet_dictionary) >= check_loop_count:
                final_loop_count = (data_provider_num - 1) + loop_count
                Common_scenario.data_provider_num = final_loop_count
            else:
                final_loop_count = 0
                Common_scenario.data_provider_num = final_loop_count
    return Common_scenario.data_provider_num


def Assert_Excel_Column(data_file_name, loop_count,data_provider_num, data_ref):
    try:
        data_file_names = data_file_name.split(",")
        data_file_1 = (data_file_names[0]).split(":")
        data_file_2 = (data_file_names[1]).split(":")
        data_refs = data_ref.split(",")  
        data1 = read_excel_return_dataFrame_for_data_sheet(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+data_file_1[0]+".xlsx", data_file_1[1])
        dict_data1 = data1.to_dict("records")
        final_loop_count1 = final_loop_count(loop_count, data_provider_num, dict_data1)
        value_1 = get_data_value(dict_data1,final_loop_count1,data_refs[0])
        data2 = read_excel_return_dataFrame_for_data_sheet(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+data_file_2[0]+".xlsx", data_file_2[1])
        dict_data2 = data2.to_dict("records")
        final_loop_count2 = final_loop_count(loop_count,data_provider_num, dict_data2)
        value_2 = get_data_value(dict_data2,final_loop_count2,data_refs[1])
        Variable_not_resettable.logger.info("value_1 : " + str(value_1) + "||" + " value_2 : " + str(value_2))
        if value_1 == value_2:
            Variable_not_resettable.logger.info("values matched")
            return True
        else:
            raise Exception("Excel Assert value not match")
    except Exception as error:
        Variable_not_resettable.logger.info(str(error))
        raise Exception(str(error))
    
def get_data_values(final_loop_count):
    data_value1=""
    data_value2=""
    data_reference1 = Common_step.DATA_REFERENCE1.lower()
    data_reference2 = Common_step.DATA_REFERENCE2.lower()
    column_names = Common_object.dataSheet_dictionary[final_loop_count].keys()
    for column in column_names:
        if data_reference1 == column.lower():
            data_value1 = Common_object.dataSheet_dictionary[final_loop_count][column]
            data_value1 = str(data_value1).replace("\u200b", "")
        elif data_reference2 == column.lower():
            data_value2 = Common_object.dataSheet_dictionary[final_loop_count][column]
            data_value2 = str(data_value2).replace("\u200b", "")
    return data_value1,data_value2