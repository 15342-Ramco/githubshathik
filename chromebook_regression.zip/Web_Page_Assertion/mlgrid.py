import json
import os
import urllib
from datetime import datetime
from xml import etree
from lxml import etree
import pandas as pd
from Web_Page_Assertion.mlgridtagdelete import *
import urllib.request
from common_object import Variable_not_resettable,Common_object

update_excel = []
extra_child_list = []
missing_at_path = []
attribute_missing_list = []
extra_attribute_list = []
verification_list = []
def compare_xml_files(original_xml_file, updated_xml_file):
    # Parse the original XML
    tree_original = ET.parse(original_xml_file)
    root_original = tree_original.getroot()

    # Parse the updated XML
    tree_updated = ET.parse(updated_xml_file)
    root_updated = tree_updated.getroot()


    # Function to compare elements recursively
    def compare_elements(original_element, updated_element, path):
        Variable_not_resettable.logger.info("Assertion In progress ")
        Variable_not_resettable.logger.info("oooooooooooooo>>>>>Please Wait<<<<<<<<<<oooooooooooooooooo")
        # Compare the tags of the elements
        Attribute_status,differences = attribute_differences(original_element.attrib, updated_element.attrib)

        if (original_element.tag != updated_element.tag) or (original_element.text != updated_element.text) or Attribute_status:

            data_dict={"Path":path,"Original tag":original_element.tag,"Original text":original_element.text,"Original attrib": original_element.attrib,
                              "Updated tag":updated_element.tag,"Updated text":updated_element.text,"Updated attrib":updated_element.attrib,"Attribute_differences":differences,
                       "Tag Differences": ""
                       }
            if (original_element.tag != updated_element.tag):
                data_dict.update({"Tag Differences":original_element.tag+"||"+updated_element.tag})
            update_excel.append(data_dict)


        # Compare the attributes of the elements
        original_attrib = original_element.attrib
        updated_attrib = updated_element.attrib

        for index,attrib_name in enumerate(original_attrib):
            if attrib_name not in updated_attrib:

                attribute_missing_dict={f"Original value": original_attrib[attrib_name],f"Attribute Missing":f"Attribute '{attrib_name}' missing at path: {path}"}
                attribute_missing_list.append(attribute_missing_dict)
        for num,attrib_name in enumerate(updated_attrib):
            if attrib_name not in original_attrib:

                extra_attribute_dict={f"Extra attribute":f"Extra attribute '{attrib_name}' at path: {path}",f"Updated value": updated_attrib[attrib_name]}
                extra_attribute_list.append(extra_attribute_dict)


        # Compare the child elements recursively
        original_children = list(original_element)
        updated_children = list(updated_element)

        for i in range(min(len(original_children), len(updated_children))):
            compare_elements(original_children[i], updated_children[i], f"{path}/{original_children[i].tag}")

        if len(original_children) < len(updated_children):
            for i in range(len(original_children), len(updated_children)):
                Extra_child={f"Extra child element tag":f"Extra child element '{updated_children[i].tag}' at path: {path}/{updated_children[i].tag}",
                             f"Extra child element text":f"Extra child element text '{updated_children[i].text}' at path: {path}/{updated_children[i].text}",
                             f"Extra child element attrib":f"Extra child element attrib '{updated_children[i].attrib}' at path: {path}/{updated_children[i].attrib}"}
                extra_child_list.append(Extra_child)
                Extra = {f"Extra child element tag": updated_children[i].tag,
                               f"Extra child element text": updated_children[i].text,
                               f"Extra child element attrib": updated_children[i].attrib}
                verification_list.append(Extra)


        if len(original_children) > len(updated_children):

            for i in range(len(updated_children), len(original_children)):
                Child_element ={f"Child element missing tag":f"Child element '{original_children[i].tag}' missing at path: {path}/{original_children[i].tag}",
                                f"Child element missing text":f"Child element '{original_children[i].text}' missing at path: {path}/{original_children[i].text}",
                                f"Child element missing attrib":f"Child element '{original_children[i].attrib}' missing at path: {path}/{original_children[i].attrib}"}
                missing_at_path.append(Child_element)



    # Start the comparison from the root elements
    compare_elements(root_original, root_updated, "/")



def WebpageAssertion(page):
    try:
        timestamp = datetime.now().strftime("%d-%m-%Y %H-%M-%S").replace(":", "_")
        project_path = os.getcwd() + "\\Web_Page_Assertion"
        css_directory="css"
        html_directory="html"
        json_directory="json store"
        Source_xml_store="Source XML Store"
        Compare_xml_store="Compare XML Store"
        if Common_object.test_config_dictionary["WebPageAssertionMode"].lower()!="scrap":
            create_directory_only(project_path, css_directory)
            create_directory_only(project_path, html_directory)
            create_directory_only(project_path, json_directory)
            create_directory_only(project_path, Compare_xml_store)
        create_directory_only(project_path, Source_xml_store)



        html = page.content()
        html_path='html_'+timestamp
        if Common_object.test_config_dictionary["WebPageAssertionMode"].lower() != "scrap":
            with open(project_path+'\\html\\'+html_path+'.html', 'w', encoding='utf-8') as f:
                f.write(html)
        # Parse the HTML content using lxml
        parser = etree.HTMLParser()
        tree = etree.fromstring(html, parser)

        # Extract the XML data from the parsed HTML tree, including CSS styling and HTML positioning
        xml_data = etree.tostring(tree, pretty_print=True, method="xml", encoding="utf-8")
        root_for_name_construction=etree.fromstring(xml_data)
        name = ""

        # Build the XPath expression
        xpath_expression = f"//span[starts-with(@id,'txtIlboTitle-button') and contains(@id,'btnWrap')]//span[starts-with(@id,'txtIlboTitle-button') and contains(@id,'btnInnerEl')]/text()"
        # Evaluate the XPath expression
        results = root_for_name_construction.xpath(xpath_expression)
        # Print the extracted text
        zoompopupxpath_expression = f"//div[starts-with(@id,'uigridzoom') and contains(@id, 'header-innerCt')]//div[starts-with(@id,'uigridzoom') and contains(@id, 'header-title-textEl')]"
        zoompopupxpath_expression_text = f"//div[starts-with(@id,'uigridzoom') and contains(@id, 'header-innerCt')]//div[starts-with(@id,'uigridzoom') and contains(@id, 'header-title-textEl')]/text()"
        exists = bool(root_for_name_construction.xpath(zoompopupxpath_expression))
        gridoption = f"//div[starts-with(@id,'tabbar') and contains(@id,'targetEl')]//a[@aria-selected='true']//span[@data-ref='btnInnerEl']"
        gridoptiontext = f"//div[starts-with(@id,'tabbar') and contains(@id,'targetEl')]//a[@aria-selected='true']//span[@data-ref='btnInnerEl']/text()"
        gridoptionexist = bool(root_for_name_construction.xpath(gridoption))

        if exists:
            zoomname = root_for_name_construction.xpath(zoompopupxpath_expression_text)
        if gridoptionexist:
            grid_name = root_for_name_construction.xpath(gridoptiontext)

        if results[0] == "login":
            for result in results:
                name += result
        elif exists == True:
            dic = {"process": "btnComponent-button", "component": "btnActivity-button",
                   "activity": "txtIlboTitle-button"}
            namelist = ["process", "component", "activity"]
            name = ""
            for ids in namelist:
                target_value = "btnInnerEl"
                target = "btnWrap"
                xpath_expression = f"//span[starts-with(@ id,'{dic[ids]}') and contains(@id,'{target}')]//span[starts-with(@id,'{dic[ids]}') and contains(@id,'{target_value}')]/text()"
                # Evaluate the XPath expression
                results = root_for_name_construction.xpath(xpath_expression)

                # Print the extracted text
                if results:
                    for result in results:
                        name += result + "-"
                else:
                    print("No matching elements found in the XML.")
            name = name + "zoompopup" + zoomname[0]

        elif gridoptionexist:
            dic = {"process": "btnComponent-button", "component": "btnActivity-button",
                   "activity": "txtIlboTitle-button"}
            namelist = ["process", "component", "activity"]
            name = ""
            for ids in namelist:
                target_value = "btnInnerEl"
                target = "btnWrap"
                xpath_expression = f"//span[starts-with(@ id,'{dic[ids]}') and contains(@id,'{target}')]//span[starts-with(@id,'{dic[ids]}') and contains(@id,'{target_value}')]/text()"
                # Evaluate the XPath expression
                results = root_for_name_construction.xpath(xpath_expression)

                # Print the extracted text
                if results:
                    for result in results:
                        name += result + "-"
                else:
                    print("No matching elements found in the XML.")
            name = name + grid_name[0]
        else:
            dic = {"process": "btnComponent-button", "component": "btnActivity-button",
                   "activity": "txtIlboTitle-button"}
            namelist = ["process", "component", "activity"]
            name = ""
            for ids in namelist:
                target_value = "btnInnerEl"
                target = "btnWrap"
                xpath_expression = f"//span[starts-with(@ id,'{dic[ids]}') and contains(@id,'{target}')]//span[starts-with(@id,'{dic[ids]}') and contains(@id,'{target_value}')]/text()"
                # Evaluate the XPath expression
                results = root_for_name_construction.xpath(xpath_expression)

                # Print the extracted text
                if results:
                    for result in results:
                        name += result + "-"
                else:
                    print("No matching elements found in the XML.")

        logfoldername = name+"_"+ timestamp



        if Common_object.test_config_dictionary["WebPageAssertionMode"].lower() == "scrap":
            with open(project_path+"\\Source XML Store\\"+name+".xml", "wb") as file:
                file.write(xml_data)
                Variable_not_resettable.logger.info("[Download Information] :Source XML Generated for this web page and stored it in to the Source xml store//"+name+".xml")
                #exit()
                Overall_Status = "[Result Information ]: Action called for download a Source webpage details"
        else:
            logfolder = create_directory(project_path + '\\Output', logfoldername)
            cssfilefoldername = name + '_' + timestamp
            jsonstore = name + '_' + timestamp
            cssfolder = create_directory(project_path + '\\css', cssfilefoldername)
            jsonfolder = create_directory(project_path + '\\json store', jsonstore)
            with open(project_path+"\\Compare XML Store\\"+name+".xml", "wb") as file:
                file.write(xml_data)
                Variable_not_resettable.logger.info("[Download Information] :XML Generated for this web page and stored it in to the Compare XML store//"+name+".xml")
            styles = page.evaluate(
                """() => {
                    const elements = Array.from(document.querySelectorAll('[class]'));
                    const styles = {};
                    for (const el of elements) {
                        const className = el.getAttribute('class');
                        styles[className] = window.getComputedStyle(el);
                    }
                    return styles;
                }"""
            )
            # Get the CSS document of the web page
            css_doc = page.evaluate("() => Array.from(document.styleSheets).map(ss => ss.ownerNode.textContent).join('\\n')")
            # Get all the CSS styles on the page
            css_styles = page.evaluate('''
                Array.from(document.querySelectorAll('link[rel="stylesheet"], style'))
                    .map(element => element.textContent)
                    .join('\\n');
            ''')
            #css_styles_path="styles"+timestamp
            # Save CSS styles to a text file
            with open(cssfolder+"\\" +'style.css', 'w') as file:
                file.write(css_styles)
                Variable_not_resettable.logger.info("[Download Information] :Extraction of css styling completed")

            # Save the CSS document to a JSON file
            with open(jsonfolder+"//CSS document to a JSON file.json", "w") as f:
                json.dump(css_doc, f, indent=4)
            Variable_not_resettable.logger.info(f"[Download Information] : {len(css_doc)} styles stored @ path =json store//CSS document to a JSON file.json")
            # Save the styles to a JSON file
            with open(jsonfolder+"//styles.json", "w") as f:
                json.dump(styles, f, indent=4)

            Variable_not_resettable.logger.info(f"[Download Information] : {len(styles)} styles stored @ path =jsonstore//styles.json")
            js_files = page.eval_on_selector_all(
                "script[src]", "urls => urls.map(url => url.href)"
            )
            css_files = page.eval_on_selector_all(
                "link[href][rel=stylesheet]", "urls => urls.map(url => url.href)"
            )

            Variable_not_resettable.logger.info(f"[Files found information]:Total {len(js_files)} javascript files found")
            Variable_not_resettable.logger.info(f"[Files found information]:Total {len(css_files)} CSS files found")

            for css_file in css_files:
                # Get the filename from the URL
                file_name = os.path.basename(css_file)
                #print(file_name)
                # Remove any invalid characters from the filename
                file_name = re.sub(r"[^\w.]", "", file_name)

                urllib.request.urlretrieve(css_file, cssfolder+"\\" + file_name)
                Variable_not_resettable.logger.info(f"[Download Information] :Downloaded {file_name} path @"+cssfolder + file_name)

            # Close the browser
            #browser.close()
            Variable_not_resettable.logger.info("-------------->>>>>Tag Counts checking for Source and Current<<<<<<<--------------")
            # Load the original and updated XML documents
            with open(project_path+"\\Source XML Store\\"+name+".xml", 'r') as f:
                original_xml = f.read()
            original_root = ET.fromstring(original_xml)

            with open(project_path+"\\Compare XML Store\\"+name+".xml", 'r') as f:
                updated_xml = f.read()
            updated_root = ET.fromstring(updated_xml)
            # Initialize a counter
            tag_count_original = 0

            # Iterate over the elements and increment the counter for each tag
            for element in original_root.iter():
                tag_count_original += 1

            # Print the total count of tags
            Variable_not_resettable.logger.info(f"Total count of tags Original: {tag_count_original}")

            # Initialize a counter
            tag_count_updated = 0

            # Iterate over the elements and increment the counter for each tag
            for element in updated_root.iter():
                tag_count_updated += 1

            # Print the total count of tags
            Variable_not_resettable.logger.info(f"------------------->>>>>>>>>>Total count of tags Updated: {tag_count_updated}<<<<<----------")
            Variable_not_resettable.logger.info("-------------------->>>>>>>>>>Tags Count checking completed<<<<<<<<<<<<----------------------")


            Overall_Status = "[Result Information ]: Assertion Failed Please check the output folder for the details"

            Variable_not_resettable.logger.info("------------------>>>>>>>>>>Assertion between two files started<<<<<<<<<-------------------")

            original_xml_file = project_path+"\\Source XML Store\\"+name+".xml"
            updated_xml_file = project_path+"\\Compare XML Store\\"+name+".xml"
            # Parse the original XML
            tree_original = ET.parse(original_xml_file)
            root_original = tree_original.getroot()

            # Parse the updated XML
            tree_updated = ET.parse(updated_xml_file)
            root_updated = tree_updated.getroot()
            # data_dict=[]
            if ET.tostring(root_original) == ET.tostring(root_updated):
                Variable_not_resettable.logger.info("[Info]: Both XML files are exactly matching")
                Overall_Status = "[Result Information ]: Assertion Pass XML files are exactly matching"
            else:
                compare_xml_files(original_xml_file, updated_xml_file)
                contains_gridview = False
                ids = [element['Extra child element attrib']['id'] for element in verification_list if
                       'id' in element['Extra child element attrib']]


                if len(ids) != 0:
                    contains_gridview = all("gridview" in item for item in ids)
                if contains_gridview:
                    Variable_not_resettable.logger.info("[Info]: The updated xml has ML grid view datas please check the output")
                else:
                    Variable_not_resettable.logger.info("[Info]: web page has changes in the backend,please check the output")

                Compare_the_tagsof_the_elements = pd.DataFrame.from_dict(update_excel)
                Extra_child_element = pd.DataFrame.from_dict(extra_child_list)
                Child_element_missing_tag = pd.DataFrame.from_dict(missing_at_path)
                attribute_missing = pd.DataFrame.from_dict(attribute_missing_list)
                # print(attribute_missing)
                Extra_attribute = pd.DataFrame.from_dict(extra_attribute_list)
                # print(df)
                Compare_tag_path = os.path.join(logfolder, "Compare the tags of the elements_" + (
                    str(datetime.now().replace(microsecond=0))).replace(":", "_") + ".xlsx")
                Extra_child_element_path = os.path.join(logfolder, "Extra_child_elements_" + (
                    str(datetime.now().replace(microsecond=0))).replace(":", "_") + ".xlsx")
                Child_element_missing_tag_path = os.path.join(logfolder, "Child_element_missing_tag_" + (
                    str(datetime.now().replace(microsecond=0))).replace(":", "_") + ".xlsx")
                attribute_missing_path = os.path.join(logfolder, "Attribute_missing_tag_" + (
                    str(datetime.now().replace(microsecond=0))).replace(":", "_") + ".xlsx")
                Extra_attribute_path = os.path.join(logfolder,"Extra_attribute_tag_" + (str(datetime.now().replace(microsecond=0))).replace(":", "_") + ".xlsx")
                textfile=os.path.join(logfolder,"Overallstatus_" + (str(datetime.now().replace(microsecond=0))).replace(":", "_") + ".txt")
                if not Compare_the_tagsof_the_elements.empty:
                    all_empty = (Compare_the_tagsof_the_elements['Attribute_differences'] == '').all() and (
                                Compare_the_tagsof_the_elements['Tag Differences'] == '').all()

                    if all_empty and contains_gridview:
                        Overall_Status = "[Result Information ]: Assertion Pass XML files are exactly matching"
                        Variable_not_resettable.logger.info("[Info]: All values in both columns are empty strings.")
                    elif len(extra_child_list)==0 and all_empty:
                        Overall_Status = "[Result Information ]: Assertion Pass XML files are exactly matching, Some Inner texts are there please verify the logs"
                    else:
                        Variable_not_resettable.logger.info("[Info]: Not all values in both columns are empty strings. in the Compare the tags of the elements")

                    Compare_the_tagsof_the_elements.to_excel(Compare_tag_path)
                if not Extra_child_element.empty:
                    Extra_child_element.to_excel(Extra_child_element_path)
                if not Child_element_missing_tag.empty:
                    Child_element_missing_tag.to_excel(Child_element_missing_tag_path)
                if not attribute_missing.empty:
                    attribute_missing.to_excel(attribute_missing_path)
                if not Extra_attribute.empty:
                    Extra_attribute.to_excel(Extra_attribute_path)

        if Common_object.test_config_dictionary["WebPageAssertionMode"].lower() != "scrap":
            with open(textfile, 'w') as file:
                file.write(Overall_Status)
    except Exception as error:
        print(error)







