from atlassian import Jira
from common_object import Common_controls, Common_data, Common_nav_path, Common_navigation, Common_object, Common_scenario, Common_step, Variable_not_resettable
from dataGenerator import dataGenerator
from excel_utils import read_excel_return_dictionary_for_row_based


def description_builder(params_value, new_rTrack_params, summary_str):
    description_text = params_value
    empty_text = ""
    if "summary" in description_text:
        if str(new_rTrack_params.get("summary")[0].get("Value")).lower() == "nan" or str(new_rTrack_params.get("summary")[0].get("Value")).lower() == "none":
            summary_str = str(Common_object.scenarios_meta["SCENARIO_ID"])+" - "+ str(Common_step.error_popup_message)[0:230]
        else:
             summary_str = str(Common_object.scenarios_meta["SCENARIO_ID"])+" - "+str(new_rTrack_params.get("summary")[0].get("Value"))+" - "+ str(Common_step.error_popup_message)[0:230]
        empty_text = empty_text +"Summary: "+ str(summary_str)+"-"
    if "stepID" in description_text:
        empty_text = empty_text +" Step ID: "+  str(Common_step.step_id)+" - "
    if "stepType" in description_text:
        empty_text = empty_text +" Step Type: "+  str(Common_step.STEP_TYPE)+" - "
    if "stepAction" in description_text:
        empty_text = empty_text +" Step Action: "+  str(Common_step.BASE_ACTION)+" - "
    if "pageName" in description_text:
        empty_text = empty_text +" Page Name: "+  str(Common_step.PAGE_NAME)+" - "
    if "dataName" in description_text:
        empty_text = empty_text +" Data Name: "+  str(Common_step.DATA_NAME)+" - "
    if "elementReference" in description_text:
        empty_text = empty_text +" Element Reference: "+  str(Common_step.ELEMENT_REFERENCE)+" - "
    if "dataReference" in description_text:
        empty_text = empty_text +" Data Reference: "+  str(Common_step.DATA_REFERENCE)+" - "
    if "customErrorMsg" in description_text:
        Custom_Error_1="Error occurred while executing - Filename:{}; SheetName:{}; STEP_ID:{}; PAGE_NAME:{}; ELEMENT_REFERENCE:{}; ELEMENT_VALUE:{}; ACTION:{}; DATA_NAME:{}; DATA_REFERENCE:{}; DATA_VALUE:{}".format(Common_scenario.STEP_FILE,Common_scenario.STEP_SHEET,int(Common_step.step_id),Common_step.PAGE_NAME,Common_step.ELEMENT_REFERENCE,Common_controls.control_Value,Common_step.ACTION,Common_step.DATA_NAME,Common_step.DATA_REFERENCE,Common_data.data_value).replace("nan", "").replace('None', '')
        empty_text = empty_text + str(Custom_Error_1)+" - "
    return empty_text.strip()
def jira_raise_ticket():
    try:
        rTrack_credential = read_excel_return_dictionary_for_row_based("Files\TestRunner\RTrackConfig.xlsx", "credential")
        new_rTrack_credential = {}
        _ = {new_rTrack_credential.update({credential['Name']:credential['Value']}) for credential in rTrack_credential}

        rTrack_params = read_excel_return_dictionary_for_row_based("Files\TestRunner\RTrackConfig.xlsx", "params")
        new_rTrack_params = {}
        _ = {new_rTrack_params.update({params['Id']:[{ "type":params['type'], "Value":params['Value']}]}) for params in rTrack_params}

        for key, value in new_rTrack_credential.items():
            if value == None or str(value) == "nan" or str(value) == "nan":
                raise Exception(f"{key} field in rTrackConfig should not be empty")


        url = new_rTrack_credential.get('url')
        username = new_rTrack_credential.get('username')
        password = new_rTrack_credential.get('password')
        project_name = new_rTrack_credential.get('project name')
        issue_type = new_rTrack_credential.get('issue type')
        check_list = [url, username, password, project_name, issue_type]
        for check in check_list:
            if check == None:
                raise Exception(f"Please check the {check} field in rTrackConfig, it may missing or incorrect")
        issue_fields = {"project": {'key': project_name}, 'issuetype': {"name": issue_type}}

        for params_key, params_value in new_rTrack_params.items():
            # print(params_key, params_value)
            if params_value[0].get("type") == "textbox":
                if params_key == "summary":
                    if str(params_value[0].get("Value")).lower() == "nan" or str(params_value[0].get("Value")).lower() == "none" or str(params_value[0].get("Value")).lower() == "":
                        summary_str = str(Common_object.scenarios_meta["SCENARIO_ID"])+" - "+ str(Common_step.error_popup_message)[0:230]
                        issue_fields.update({params_key : summary_str})
                    else:
                        summary_str = str(Common_object.scenarios_meta["SCENARIO_ID"])+" - "+str(params_value[0].get("Value"))+" - "+ str(Common_step.error_popup_message)[0:230]
                        issue_fields.update({params_key : summary_str})
                elif params_key == "description":
                    issue_fields.update({params_key : description_builder(params_value[0].get("Value"), new_rTrack_params, summary_str)})
                elif params_value[0].get("Value") == "xrayTestCaseID":
                    issue_fields.update({params_key : str(Common_step.XRAY_TEST_CASE_ID)})
                elif params_value[0].get("Value") == "ScenarioID":
                    issue_fields.update({params_key : str(Common_object.scenarios_meta["SCENARIO_ID"])})
                elif "EXECUTE:" in params_value[0].get("Value"):
                    rtrack_data_gen = dataGenerator((params_value[0]).get("Value"))
                    Variable_not_resettable.logger.debug("rtrack_data_gen : ",rtrack_data_gen)
                    issue_fields.update({params_key : str(rtrack_data_gen)})
                elif params_value[0].get("Value") == "URL":
                    issue_fields.update({params_key : str(Common_object.test_config_dictionary["ApplicationURL"])})
                else:
                    issue_fields.update({params_key : params_value[0].get("Value")})
            elif params_value[0].get("type") == "dropdown":
                issue_fields.update({params_key : {"value":params_value[0].get("Value")}})
            elif params_value[0].get("type") == "dropdowndynamic":
                if str(params_value[0].get("Value")) == "Process":
                    issue_fields.update({params_key : Common_navigation.Process})
                elif str(params_value[0].get("Value")) == "Component":
                    issue_fields.update({params_key : Common_navigation.Component})
                elif str(params_value[0].get("Value")) == "Activity":
                    issue_fields.update({params_key : Common_navigation.Activity})
                else:
                    issue_fields.update({params_key : params_value[0].get("Value")})


                Common_nav_path.Process_path
        Variable_not_resettable.logger.debug(f"issue fields to create rTrack: {issue_fields}")
        jira = Jira(url=url, username= username, password= password)
        resp = jira.issue_create(fields=issue_fields)
        Variable_not_resettable.logger.debug(f"rTrack API Response: {resp}")
        return resp["key"]
    except Exception as error:
        Variable_not_resettable.logger.debug(error, exc_info= Variable_not_resettable.logger_exception_info)
        return f"No Ticket ID - {str(error)}"