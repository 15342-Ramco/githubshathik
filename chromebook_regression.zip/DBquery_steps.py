import pandas as pd
import os
from projectObject import projectVariable
from DBQuery import dbQueryConfig


def openStepsSheet(path, sheetname):
    stepsDriver = pd.read_excel(os.path.abspath(path), sheet_name=sheetname)
    projectVariable.stepsDriver = stepsDriver
    return stepsDriver


def executeEachStep(path, sheetname):
    stepsDriver = openStepsSheet(path, sheetname)
    for row in (stepsDriver.shape[0]):
        getStepsDetails(row)
        executeStep()


def getStepsDetails(row):
    projectVariable.step_id = projectVariable.stepsDriver.iloc[row, 'STEP_ID']
    projectVariable.step_type = projectVariable.stepsDriver.iloc[row, 'STEP_TYPE']
    projectVariable.step_desc = projectVariable.stepsDriver.iloc[row, 'STEP_DESC']
    projectVariable.action = projectVariable.stepsDriver.iloc[row, 'ACTION']


def executeStep():
    if projectVariable.step_type == "DB_QUERY":
        dbQueryConfig()
