import os
import pandas as pd
from datetime import datetime

from Validators.Validator_utils import get_test_runner_config_data

def control_sheet_validator():
    empty_list = []
    base_path = os.getcwd()+"\\Files"
    step_path = base_path+"\\ControlSheets"
    step_files = os.listdir(step_path)
    Execution_start_time=datetime.now().replace(microsecond=0)
    for k in range(len(step_files)):
        try:
            excel_file = pd.ExcelFile(step_path+"\\"+step_files[k])
            excel_sheets = excel_file.sheet_names
            for excel_sheet in excel_sheets:
                print((str(k+1)+"/"+str(len(step_files))+" validating filename",step_files[k]+" and sheet_name",excel_sheet))
                step_df = pd.read_excel(step_path+"\\"+step_files[k], excel_sheet)
                step_df=step_df[step_df.Element.notnull()]
                check_duplicates=step_df[step_df['Element'].duplicated()==True]
                if len(check_duplicates)>0:
                    words=check_duplicates['Element'].tolist()
                    dictionary = {}
                    for item in words:
                        dictionary[item] = dictionary.get(item, 0) + 1
                    dictList=[]
                    for key, value in dictionary.items():
                        dictList.append([str(key)+"-"+str(value)])
                        flatList = [element for innerList in dictList for element in innerList]
                    # print("Duplicate values are there in control sheet",step_files[k]+"sheet_name",excel_sheet)
                    print(("Duplicate values are there in control sheet",step_files[k]+"sheet_name",excel_sheet), 'green')
                    temp_dict = {"Contorlfilename":step_files[k],"Sheet_name":excel_sheet,"Count_Of_duplicates":len(flatList),"List_of_duplicate_elements":flatList}
                    empty_list.append(temp_dict)
                else:
                    print("There are no duplicate values")
        except Exception as error:
            print(error)
            pass
    Execution_End_time=datetime.now().replace(microsecond=0)
    duration=Execution_End_time-Execution_start_time
    print("Time taken for validation",duration)
    make_csv_from_list(empty_list , Execution_start_time)

def make_csv_from_list(list_data, Execution_start_time):
    csv_file = pd.DataFrame(list_data)
    csv_file.to_csv("validator-output\\"+get_test_runner_config_data("ProductLine")+"_Controlevent_ID_Duplicates_validation_result_"+str(Execution_start_time).replace(":", "_")+".csv")
    


