import openpyxl
import pandas as pd
from openpyxl.utils.dataframe import dataframe_to_rows
import os


base_path = os.getcwd()
scenarios_path = base_path + "/Files/Scenarios"
def read_excel_return_dataFrame(file_name: str, sheet_name: str) -> pd.DataFrame:
    data_frame = pd.read_excel(file_name, sheet_name=sheet_name)
    return data_frame

def split_by_colon(file_sheet_name):
    splitted_list = str(file_sheet_name).split(":")
    splitted_list = [element.strip() for element in splitted_list]
    return splitted_list

def join_path_and_file(path:str, filename:str):
    return os.path.join(path, filename)

def read_excel_return_dictionary_for_colum_based(file_name: str, sheet_name: str):
    data_frame = read_excel_return_dataFrame(file_name, sheet_name)
    return read_dataFrame_return_dictionary_for_colum_based(data_frame)

def read_excel_return_dictionary_for_row_based(file_name: str, sheet_name: str):
    data_frame = read_excel_return_dataFrame(file_name, sheet_name)
    return read_dataFrame_return_dictionary_for_row_based(data_frame)

def read_dataFrame_return_dictionary_for_colum_based(data_frame) -> dict:
    dict_temp = {}
    _ = [dict_temp.update({str(data[1]).strip(): str(data[2]).strip()}) for data in data_frame.to_records()]
    return dict_temp

def read_dataFrame_return_dictionary_for_row_based(data_frame: pd.DataFrame):
    return data_frame.to_dict("records")

def get_scenarios_file_list_parallel(test_config_dictionary, base_path):
    scenarios_path = base_path + "/Files/Scenarios"
    testConfig_dictionary = test_config_dictionary
    scenarios_folder_list = get_scenarios_folder_list_parallel(test_config_dictionary, base_path, scenarios_path)
    scenarios_file_list = []
    file_include = []
    file_exclude = []
    scenarios_file_list_final = []
    for scenarios_folder in scenarios_folder_list:
        files = os.listdir(scenarios_path + "/" + scenarios_folder)
        temp_var = [scenarios_file_list.append(scenarios_folder + "/" + f) for f in files]

    if testConfig_dictionary["FilesNameInclude"] != "nan":
        files = [file_include.append(f.strip()) for f in testConfig_dictionary["FilesNameInclude"].split(",") if
                 f != ""]

    if testConfig_dictionary["FilesNameExclude"] != "nan":
        file = [file_exclude.append(f.strip()) for f in testConfig_dictionary["FilesNameExclude"].split(",") if f != ""]
    if testConfig_dictionary["FilesNameExclude"] != "nan":
        for file in scenarios_file_list_final:
            for f in file_exclude:
                if f in file:
                    scenarios_file_list.remove(file)
    if testConfig_dictionary["FilesNameInclude"] != "nan":
        for file in scenarios_file_list:
            for f in file_include:
                if f in file:
                    scenarios_file_list_final.append(file)
    if testConfig_dictionary["FilesNameInclude"] == "nan":
        for f in scenarios_file_list:
            scenarios_file_list_final.append(f)
    if testConfig_dictionary["FilesNameExclude"] != "nan":
        for file in scenarios_file_list_final:
            for f in file_exclude:
                if f in file:
                    scenarios_file_list_final.remove(file)
    return scenarios_file_list_final

def reading_required_files_for_parallel():
    base_path = os.getcwd()
    test_config_path = base_path + "/Files/TestRunner"
    navigation_path = base_path + "/Files/PreConfig"
    # Reading process for properties file and storing in Common Object
    properties = {'navigation_config_file_sheet_name': 'NavigationConfig.xlsx:NavConfig',
                  'pre_req_config_file_sheet_name': 'PreReqConfig.xlsx:PreReqConfig',
                  'test_runner_config_file_sheet_name': 'TestRunnerConfig.xlsx:RunnerConfig',
                  'browser_headless': 'False'}
    # Reading process for testConfig file and storing in Common Object
    testConfig_file_name, testConfig_sheet_name = split_by_colon(properties["test_runner_config_file_sheet_name"])
    test_config_dictionary = read_excel_return_dictionary_for_colum_based(
        join_path_and_file(test_config_path, testConfig_file_name), testConfig_sheet_name)
    # Reading process for Navigation file and storing in Common Object
    navigation_file_name, navigation_sheet_name = split_by_colon(properties["navigation_config_file_sheet_name"])
    navigation_dictionary = read_excel_return_dictionary_for_row_based(
        join_path_and_file(navigation_path, navigation_file_name), navigation_sheet_name)
    # Reading process Scenario file and storing in Common object
    scenarios_file_list = get_scenarios_file_list_parallel(test_config_dictionary, base_path)
    if len(scenarios_file_list) > 0:
        return scenarios_file_list, test_config_dictionary
    else:
        return scenarios_file_list, test_config_dictionary



def get_scenarios_folder_list_parallel(test_config_dictionary, base_path, scenarios_path):
    testConfig_dictionary = test_config_dictionary
    folder_list = []
    try:
        if testConfig_dictionary["FoldersInclude"] != "nan":
            folders = [folder_list.append(
                f.strip()) for f in testConfig_dictionary["FoldersInclude"].split(",")]
        if testConfig_dictionary["FoldersInclude"] == "nan":
            folders = [folder_list.append(f.strip()) for f in os.listdir(
                scenarios_path)]
        if testConfig_dictionary["FoldersExclude"] != "nan":
            folders = [folder_list.remove(
                f.strip()) for f in testConfig_dictionary["FoldersExclude"].split(",")]
    except Exception as error:
        print(error)
        exit()
    return folder_list








def add_row_to_excel_parallel(file_path, sheet_name, data: dict):
    dic = {}
    for k, v in data.items():
        dic[k] = [v]
    df = pd.DataFrame(dic)
    if os.path.isfile(file_path):  # if file already exists append to existing file
        workbook = openpyxl.load_workbook(file_path)  # load workbook if already exists
        sheet = workbook[sheet_name]  # declare the active sheet
        for row in dataframe_to_rows(df, header=False, index=False):
            sheet.append(row)
        workbook.save(file_path)  # save workbook
        workbook.close()  # close workbook
    else:  # create the excel file if doesn't already exist
        with pd.ExcelWriter(path=file_path, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name=sheet_name)

def scenario_sheet_filter_steps(scenario_file_name: str):
    base_path = os.getcwd()
    scenarios_path: str = base_path + "/Files/Scenarios"
    scenario_data_frame = read_excel_return_dataFrame(
        scenarios_path+"/"+scenario_file_name, "Scenario")
    scenario_metadata_dictionary = read_dataFrame_return_dictionary_for_colum_based(
        scenario_data_frame[0:3])
    last_row = len(scenario_data_frame)
    scenario_list_data_frame = scenario_data_frame[3:last_row]
    scenario_list_data_frame = scenario_list_data_frame.rename(
        columns=scenario_list_data_frame.iloc[0]).drop(scenario_list_data_frame.index[0])
    scenario_list_data_frame = scenario_list_data_frame[0:]
    scenario_list_data_frame = scenario_list_data_frame.reset_index(
        inplace=False, drop=True)
    scenario_list_data_frame.columns = scenario_list_data_frame.columns.fillna(
        'A')
    data_frame_dictionary = scenario_list_data_frame.to_dict('records')
    Scenario_start = []
    Flag = False
    for i in range(len(data_frame_dictionary)):
        if str(data_frame_dictionary[i]['A']) == 'END_SCENARIO':
            Flag = False
        if Flag == True:
            Scenario_start.append(data_frame_dictionary[i])
        if str(data_frame_dictionary[i]['A']) == 'START_SCENARIO':
            Flag = True
            Scenario_start.append(data_frame_dictionary[i])
    return (scenario_metadata_dictionary, Scenario_start)


scenarios_file_list, test_config_dictionary=reading_required_files_for_parallel()


def start_test():
    l=[]
    for scenarios_file in scenarios_file_list:
        scenarios_list=scenario_step(scenarios_file)
        l.append(scenarios_list)
    return l
def select_scenario_tags(scenario_tag: str):
    flag = False
    scenario_tag = scenario_tag.split(",")
    scenario_tag = [tag.strip() for tag in  scenario_tag]

    if str(test_config_dictionary['TagsInclude'][0]) == "nan":
        flag = True
    if str(test_config_dictionary['TagsExclude'][0]) == "nan":
        flag = True
    if str(test_config_dictionary['TagsInclude'][0]) != "nan":
        if  any(item in test_config_dictionary['TagsInclude'] for item in scenario_tag):
            flag = True
        else:
            flag = False
    if str(test_config_dictionary['TagsExclude'][0]) != "nan":
        if  any(item in test_config_dictionary['TagsInclude'] for item in scenario_tag):
            flag = False
        else:
            flag = True
    # print(flag)
    return flag

def scenario_step(scenarios_file):
     scenarios_meta, scenarios_dictionary = scenario_sheet_filter_steps(scenarios_file)
     if select_scenario_tags(scenarios_meta["SCENARIO_TAGS"]):
         return scenarios_file

files=start_test()
print("scenarios_file_list_final : ", files)
with open('filestoexecute.txt', 'w') as fp:
    for item in files:
        fp.write("%s\n" % item)
    print('Done')