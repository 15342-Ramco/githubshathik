import os
import pandas as pd
from datetime import datetime
import openpyxl
import collections

from Validators.Validator_utils import get_test_runner_config_data

def data_sheet_column_duplicate_validator():
    empty_list = []
    base_path = os.getcwd()+"/Files"
    step_path = base_path+"/DataSheets/" + get_test_runner_config_data("DataTag")
    step_files = os.listdir(step_path)
    Execution_start_time=datetime.now().replace(microsecond=0)
    for k in range(len(step_files)):
        try:
            print(step_path+"/"+step_files[k])
            excel_file=openpyxl.load_workbook(step_path+"/"+step_files[k])
            excel_sheets = excel_file.sheetnames
            for excel_sheet in excel_sheets:
                print(str(k+1)+"/"+str(len(step_files))+" validating filename",step_files[k]+" and sheet_name",excel_sheet)
                step_df =excel_file[excel_sheet]
                rows = step_df.iter_rows(min_row=1, max_row=1) # returns a generator of rows
                first_row = next(rows) # get the first row
                headings = [c.value for c in first_row]
                filtered_list = list(filter(None,headings))
                g=[x.lower() for x in filtered_list]
                check_duplicates=([item for item, count in collections.Counter(g).items() if count > 1])
                if len(check_duplicates)>0:
                    print("Duplicate values are there in data_sheet",step_files[k]+"sheet_name",excel_sheet)
                    y=[]
                    for i in check_duplicates:
                        if i in g:
                            y.append(str(i)+"-"+str(g.count(i)))
                    temp_dict = {"Datasheetfilename":step_files[k],"Sheet_name":excel_sheet,"Count_Of_duplicates":len(y),"List_of_duplicate_elements":y}
                    empty_list.append(temp_dict)
                else:
                    print("There are no duplicate values")
        except Exception as error:
            print(error)
    Execution_End_time=datetime.now().replace(microsecond=0)
    duration=Execution_End_time-Execution_start_time
    print("Time taken for validation",duration)
    make_csv_from_list(empty_list, Execution_start_time)

def make_csv_from_list(list_data, Execution_start_time):
    csv_file = pd.DataFrame(list_data)
    csv_file.to_csv("validator-output/"+get_test_runner_config_data("ProductLine")+"_Data_sheet_column_Duplicates_validation_result_"+str(Execution_start_time).replace(":", "_")+".csv")

