import os
import pandas as pd
from datetime import datetime

from Validators.Validator_utils import get_test_runner_config_data


def is_data_reference_available():
    empty_list = []
    base_path = os.getcwd()+"\\Files"
    step_path = base_path+"\\Steps"
    data_path= base_path+"\\DataSheets\\" + get_test_runner_config_data("DataTag")
    step_files = os.listdir(step_path)
    Execution_start_time=datetime.now().replace(microsecond=0)
    for step_file in range(len(step_files)):
        try:
            excel_file = pd.ExcelFile(step_path+"\\"+step_files[step_file])
            excel_sheets = excel_file.sheet_names
            for excel_sheet in excel_sheets:
                print(str(step_file+1)+"/"+str(len(step_files))+" validating filename",step_files[step_file]+" and sheet_name",excel_sheet)
                step_df = pd.read_excel(step_path+"\\"+step_files[step_file],excel_sheet)
                controlid=step_df[['DATA_NAME', 'DATA_REFERENCE']]
                filtered_df = controlid[controlid['DATA_NAME'].notnull()]
                filtered=filtered_df.set_index('DATA_REFERENCE').to_dict()['DATA_NAME']
                outdict=dict((k.lower(), v.lower()) for k,v in filtered.items())
                data_files = os.listdir(data_path)
                data_lower=[element.lower() for element in data_files]
                for element,page in outdict.items():
                    pages,sheet=page.split(":")
                    if pages+".xlsx" in data_lower:
                        data_index=data_lower.index(pages+".xlsx")
                        excel_file = pd.ExcelFile(data_path+"\\"+data_files[data_index])
                        excel_sheets = excel_file.sheet_names
                        sheet_lower=[element.lower() for element in excel_sheets]
                        if sheet in sheet_lower:
                            sheet_index=sheet_lower.index(sheet)
                            data_df = pd.read_excel(data_path+"\\"+data_files[data_index], excel_sheets[sheet_index])
                            column_list=data_df.columns.tolist()
                            column_lower=[element.lower() for element in column_list]
                        else:
                            raise Exception
                        if element in column_lower:
                            status="Pass"
                            print("the element "+ element+" is available in the Data sheets")
                        else:
                            status="Fail"
                            print("The element "+element+" is not available in the Data sheet") 
                    temp_dict = {"Stepfilename":step_files[step_file],"Sheet_name":excel_sheet,"PageReference":page,"Element":element,"Availability":status}
                    empty_list.append(temp_dict)
                            
        except Exception as error:
            print(error)
            if str(error).find("None of [Index(['DATA_NAME', 'DATA_REFERENCE']")!=-1:
                status="stepfile sheet does not contains the Data name and data reference"
                page=""
                element=""
            else:
                status=error
            temp_dict = {"Stepfilename":step_files[step_file],"Sheet_name":excel_sheet,"PageReference":page,"Element":element,"Availability":status}
            empty_list.append(temp_dict)
            
    Execution_End_time=datetime.now().replace(microsecond=0)
    duration=Execution_End_time-Execution_start_time
    print("Time taken for validation",duration)
    make_csv_from_list(empty_list, Execution_start_time)


def make_csv_from_list(list_data, Execution_start_time):
    csv_file = pd.DataFrame(list_data)
    csv_file.to_csv("validator-output\\"+get_test_runner_config_data("ProductLine")+"_stepsheet_data_reference_availability_in_datasheet_validation_result_"+str(Execution_start_time).replace(":", "_")+".csv")





