from Validators.Data_sheet_column_Duplicates_validator import data_sheet_column_duplicate_validator
from Validators.Stepsheet_element_availability_in_controlsheet_validator import is_element_reference_available
from Validators.Stepsheet_element_availability_in_datasheet_validator import is_data_reference_available
from Validators.Validator_utils import Common_validator_object, make_directory, read_test_runner_config
from Validators.control_id_duplication_validator import control_sheet_validator

def validator_runner(input_params):
    # print(input_params)
    make_directory(Common_validator_object.validator_folder_path)
    Common_validator_object.test_runner_config_data = read_test_runner_config()

    input_params = input_params[1:]
    input_params = [input.upper() for input in input_params]
    # print(input_params)
    if len(input_params) > 0:
        if input_params[0] == "HELP":
            print("COMMANDS                         Description")
            print("--------                         ------------")
            print("CONTROL_ID_VALIDATOR             validate the duplicate control id.")
            print("DATASHEET_REFERENCE_VALIDATOR    validate the duplicate data sheet reference column name.")
            print("IS_ELEMENT_REFERENCE_AVAILABLE   validate the element reference available in control sheet or not.")
            print("IS_DATA_REFERENCE_AVAILABLE      validate the data reference  available in data sheet or not.")
            print("ALL                              To run all validators mentioned above.")

        elif input_params[0] == "CONTROL_ID_DUPLICATION_VALIDATOR":
            print("Running control id duplication validator")
            control_sheet_validator()

        elif input_params[0] == "DATASHEET_REFERENCE_DUPLICATION_VALIDATOR":
            print("Running Datasheet reference column name duplication validator")
            data_sheet_column_duplicate_validator()

        elif input_params[0] == "IS_ELEMENT_REFERENCE_AVAILABLE":
            print("Running Datasheet reference column name duplication validator")
            is_element_reference_available()

        elif input_params[0] == "IS_DATA_REFERENCE_AVAILABLE":
            print("Running Datasheet reference column name duplication validator")
            is_data_reference_available()
        elif input_params[0] == "ALL":
            print("Running all validator")
            control_sheet_validator()
            data_sheet_column_duplicate_validator()
            is_element_reference_available()
            is_data_reference_available()
        
        else:
            print("")
            print(f"'{input_params[0]}' is not recognized as command")
            print("Use the below listed commands")
            print("")
            print("COMMANDS                         Description")
            print("--------                         ------------")
            print("CONTROL_ID_VALIDATOR             validate the duplicate control id.")
            print("DATASHEET_REFERENCE_VALIDATOR    validate the duplicate data sheet reference column name.")
            print("IS_ELEMENT_REFERENCE_AVAILABLE   validate the element reference available in control sheet or not.")
            print("IS_DATA_REFERENCE_AVAILABLE      validate the data reference  available in data sheet or not.")
            print("ALL                              To run all validators mentioned above.")
    else:
        pass
