import os
import pandas as pd

class Common_validator_object:
    current_working_directory = os.getcwd()
    validator_folder_path = current_working_directory+"\\validator-output"
    test_runner_config_path = current_working_directory+"\\Files\\TestRunner\\TestRunnerConfig.xlsx"
    test_runner_config_data = None


def make_directory(directory_path):
    try:
        os.makedirs(directory_path)
        return True
    except Exception as error:
        return False


def read_test_runner_config() -> list[dict]:
    df = pd.read_excel(Common_validator_object.test_runner_config_path, sheet_name="RunnerConfig")
    data = df.to_dict("records")
    return data

def get_test_runner_config_data(key: str) -> str:
    data_sheet_folder = [test_runner_config_data for test_runner_config_data in Common_validator_object.test_runner_config_data if test_runner_config_data["TEST_CONFIG_KEY"]==key][0]
    return str(data_sheet_folder["TEST_CONFIG_VALUE"])