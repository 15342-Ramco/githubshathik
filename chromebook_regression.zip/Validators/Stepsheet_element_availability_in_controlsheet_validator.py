import pandas as pd
from datetime import datetime
import os

from Validators.Validator_utils import get_test_runner_config_data

def is_element_reference_available():
    empty_list = []
    base_path = os.getcwd()+"\\Files"
    step_path = base_path+"\\Steps"
    control_path= base_path+"\\ControlSheets"
    step_files = os.listdir(step_path)
    Execution_start_time=datetime.now().replace(microsecond=0)
    for step_file in range(len(step_files)):
        try:
            excel_file = pd.ExcelFile(step_path+"\\"+step_files[step_file])
            excel_sheets = excel_file.sheet_names
            for excel_sheet in excel_sheets:
                print(str(step_file+1)+"/"+str(len(step_files))+" validating filename",step_files[step_file]+" and sheet_name",excel_sheet)
                step_df = pd.read_excel(step_path+"\\"+step_files[step_file],excel_sheet)
                controlid=step_df[['PAGE_NAME', 'ELEMENT_REFERENCE']]
                filtered_df = controlid[controlid['ELEMENT_REFERENCE'].notnull()]
                filtered=filtered_df.set_index('ELEMENT_REFERENCE').to_dict()['PAGE_NAME']
                outdict=dict((k, v.lower()) for k,v in filtered.items())
                control_files = os.listdir(control_path)
                control_lower=[element.lower() for element in control_files]
                for element,page in outdict.items():
                    pages,sheet=page.split(":")
                    if pages+".xlsx" in control_lower:
                        control_index=control_lower.index(pages+".xlsx")
                        excel_control_file = pd.ExcelFile(control_path+"\\"+control_files[control_index])
                        excel_control_sheet = excel_control_file.sheet_names
                        sheet_lower=[element.lower() for element in excel_control_sheet]
                        if sheet in sheet_lower:
                            sheet_index=sheet_lower.index(sheet)
                            control_df = pd.read_excel(control_path+"\\"+control_files[control_index], excel_control_sheet[sheet_index])
                        else:  
                            raise Exception
                        if element in control_df["Element"].values:
                            status="Pass"
                            print("the element "+ element+" is available in the control sheets")
                        else:
                            status="Fail"
                            print("The element "+element+" is not available in the control sheet") 
                    temp_dict = {"Stepsheetfilename":step_files[step_file],"Sheet_name":excel_sheet,"PageReference":page,"Element":element,"Availability":status}
                    empty_list.append(temp_dict)
                            
        except Exception as error:
            print(error)
            if str(error).find("not enough values to unpack (expected 2, got 1)"):
                status="stepfile/sheet name can be hide or page reference does not contain proper value"
            elif str(error).find("None of [Index(['PAGE_NAME', 'ELEMENT_REFERENCE']")!=-1:
                status="stepfile sheet name does not contains the Page name and element reference"
                page=""
                element=""
            else:
                status=error
            temp_dict = {"Stepsheetfilename":step_files[step_file],"Sheet_name":excel_sheet,"PageReference":page,"Element":element,"Availability":status}
            empty_list.append(temp_dict)
    Execution_End_time=datetime.now().replace(microsecond=0)
    duration=Execution_End_time-Execution_start_time
    print("Time taken for validation",duration)
    make_csv_from_list(empty_list, Execution_start_time)
    
def make_csv_from_list(list_data, Execution_start_time):
    csv_file = pd.DataFrame(list_data)
    csv_file.to_csv("validator-output\\"+get_test_runner_config_data("ProductLine")+"_Stepsheet_element_reference_availability_in_controlsheet_validation_result_"+str(Execution_start_time).replace(":", "_")+".csv")
        


























