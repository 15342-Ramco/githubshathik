from common_object import Common_object, Variable_not_resettable
import time

def highlight_element(page, selector, highlight_color):
    try:
        element = page.query_selector(selector)
        if element:
            page.evaluate('element => { element.style.backgroundColor  = "'+highlight_color+'"; }', element)
            
    except Exception as error_str:
        Variable_not_resettable.logger.error(error_str)

def replace_highlight_element(page, selector, old_color):
    try:
        element = page.query_selector(selector)
        if element:
            action_interval(Variable_not_resettable.test_properties.get("action_interval"))
            page.evaluate('element => { element.style.backgroundColor  = "'+old_color+'"; }', element)
    except Exception as error_str:
        Variable_not_resettable.logger.error(error_str)

def get_element_bg_color(page, selector):
    try:
        element = page.query_selector(selector)
        if element:
            background_color = page.evaluate('(element) => window.getComputedStyle(element).backgroundColor', element)
            return background_color
    except Exception as error_str:
        Variable_not_resettable.logger.error(error_str)


def get_element_highlighter_color(test_properties):
    if test_properties.get("element_highlighter_color") == None or test_properties.get("element_highlighter_color") == "":
        element_highlighter_color = "yellow"
    else:
        element_highlighter_color = test_properties.get("element_highlighter_color")
    print(element_highlighter_color)
    return element_highlighter_color


def action_interval(interval_text):
    if interval_text == "null":
        pass
    elif interval_text == "half":
        time.sleep(0.5)
    elif interval_text == "one":
        time.sleep(1)
    elif interval_text == "two":
        time.sleep(2)
    elif interval_text == "three":
        time.sleep(3)
    elif interval_text == "four":
        time.sleep(4)
    elif interval_text == "five":
        time.sleep(5)
    else:
        Variable_not_resettable.logger.warning(f"Give action_interval '{interval_text}' is not valid...")


def timeout_customisation(test_properties):
    if test_properties.get("wait_time_for_timeout") == "default":
        Common_object.Timeout = 3000

    else:
        custom_time = test_properties.get("wait_time_for_timeout")
        Common_object.Timeout = int(custom_time)