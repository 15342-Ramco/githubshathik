import os, random
import string
from screeninfo import get_monitors
screen_width = get_monitors()[0].width
screen_height = get_monitors()[0].height-120 # browser height reduce to set the footer visible on screen.


def execution_version_number_generator(size=4, chars=string.ascii_lowercase + string.digits):
    temp_string = ""
    temp_string = temp_string + ''.join(random.choice(chars) for _ in range(size))
    for loop_count in range(5):
        temp_string = temp_string +"-"+ ''.join(random.choice(chars) for _ in range(size))
    return temp_string

class Variable_not_resettable:
    PREVIOUS_ACTION :str = None
    FRAME_WORK_VERSION: str = "SwifTest-Regression_V5.0.1.94"
    logger = None
    logger_exception_info = False
    db_connection_time_out_in_sec_for_sp = 600 # 300 # 180
    db_connection_time_out_in_sec_for_direct_query = 180
    APP_TYPE = None
    test_properties = None
    re_run_flag = False
    is_fail = False
    user_data_dir = os.path.join(os.getcwd(), "tmp/playwright")
    browser_type = None
    


class Parallel_common_object:
    process_id : str = None

class draftbill_common_object:
    draftflag:bool=False


class Common_main_object:
    advance_debug_log_folder: str = None
    advance_debug_log_file_name : str = None
    advance_debug_log_file_path: str = None
    test_result_log_file_path: str = None
    test_result_log_info_dict: dict = None
    test_result_log_debug_dict: dict = None
    scenario_execution_start_time = None
    scenario_execution_end_time = None
    system_date_format = "%d-%m-%Y"


class Common_object:
    test_config_dictionary : dict = None
    pre_config_dictionary: tuple = None
    navigation_dictionary : dict = None
    scenarios_file_list: list = None
    scenarios_meta: dict = None
    scenarios_dictionary : list[dict]= None
    steps_dictionary : list[dict]= None
    controls_dictionary : dict= None
    dataSheet_dictionary : dict= None
    properties : dict = None
    FIND_TYPE : str = None
    Timeout : int = 3000
    Timeout_select_combo : int = 3000 # This select combo timeout working only in error case for stability.
    Timeout_pop_up : int = 100
    saasy_Timeout_pop_up : int = 1000
    screen_resolution : dict = {"width": 1366, "height": 700} 
    system_screen_resolution : dict = {"width": screen_width, "height": screen_height} 
    video_resolution : dict = {"width": 1366, "height": 700}
    ignore_https_errors : bool = False
    data_provider_list : list = None
    Custom_Error : str = None
    Custom_Error_1 : str = None
    PATCH_ID: str = None 
    ImageToString: str = None
    ERROR_VIDEO_PATH:str=None
    VIDEO_PATH: str = None
    EXECUTION_VERSION_NUMBER : str = execution_version_number_generator()
    Error_Raised:str=None
    SCENARIO_FILE_NAME:str=None
    SUCCESS_VIDEO_PATH:str=None
    Error_Popup:str = None
    scenario_list_filter = None
    Macros_filter_enabled = False
    firstkill=False
    Keyfor_pid=None
    log_foldername: str = None
    advance_debug_log_header: list[str] = [
        'S_NO', 
        'TEST_CONFIG_ID', 
        'APPLICATION_URL', 
        'APP_VERSION', 
        'CUSTOMER_CODE', 
        'PRODUCT_LINE',
        'CU_VERSION',
        'RT_VERSION',
        'PRODUCT_ENVIRONMENT',
        'GUID',
        'MODULE_NAME',
        'BROWSER',
        'FOLDERS_INCLUDE',
        'FOLDERS_EXCLUDE',
        'FILES_PATTERN_INCLUDE',
        'FILES_PATTERN_EXCLUDE',
        'TAGS_INCLUDE',
        'TAGS_EXCLUDE',
        'DATA_TAG',
        'LOGFOLDER_NAME',
        'RESOLUTION',
        'CLIENT_NAME',
        'BUILD_NUMBER',
        'SCENARIO_FILE_NAME',
        'SCENARIO_ID',
        'SCENARIO_TAGS',
        'STEPS_FILE_REFERENCE',
        'STEPS_ID_REFERENCE',
        'STEP_DATA_FILE_NAME',
        'STEP_DATA_REFERENCE',
        'STEP_FILE_NAME', 
        'STEP_SHEET_NAME', 
        'STEP_ID', 'STEP_TYPE', 
        'XRAY_TESTCASE_ID', 
        'STEP_DESC', 
        'PAGE_NAME', 
        'STEP_ELEMENT_REFERENCE', 
        'STEP_ACTION', 
        'CONTROL_FILE_NAME', 
        'CONTROL_SHEET_NAME', 
        'CONTROL_DATA_TYPE', 
        'CONTROL_IDENTIFIER', 
        'CONTROL_VALUE', 
        'DATA_FILE_NAME', 
        'DATA_SHEET_NAME', 
        'DATA_VALUE', 
        'PROCESS_NAME', 
        'COMPONENT_NAME', 
        'ACTIVITY_NAME', 
        'FIND_TYPE', 
        'PRECONFIG_FILE_NAME', 
        'PRECONFIG_SHEET_NAME', 
        'DB_SERVER',
        'DB_PORT',
        'DB_PROVIDER',
        'DB_NAME',
        'TEST_STEP_STATUS',
        'CURRENT_TIME',
        'TIMEZONE',
        'STEP_EXECUTION_TIME',
        'EXECUTION_VERSION_NUMBER',
        'CPU_USAGE(%)',
        'MEMORY_USAGE(%)', 
        'Error_Raised', 
        'Custom_Error', 
        'ERROR_MESSAGE', 
        'RTRACK_ID', 
        'PATCH_ID',
        'ERROR_SNAPSHOT_FILENAME',
        'ERROR_SNAPSHOT',
        "FRAMEWORK_VERSION",
        'EXECUTION_VIDEO',
        "BROWSER_NO",
        "PRODUCT_CODE",
        "API_RESPONSE_FILENAME",
        "RVWRTQS_DISPATCH",
        "ECR_VERSION"]
    test_result_log_header_DEBUG: list[str] = ['SCENARIO ID', 'SCENARIO NAME', 'RESULT', 'ERROR SNAPSHOT', 'STEP ID',
       'XRAY TEST CASE ID', 'PAGE OBJECT DATA', 'ACTION', 'DATA VALUE',
       'EXECUTION TIME (sec)', 'Error_Raised', 'Custom_Error',
       'ERROR_MESSAGE', 'Solution_Suggestion', "EXECUTION_VIDEO"]
    test_result_log_header_INFO: list[str] =['SCENARIO ID', 'SCENARIO NAME', 'RESULT', 'ERROR SNAPSHOT',
       'EXECUTION_START_TIME', 'EXECUTION_END_TIME', "EXECUTION_VIDEO"]
    

    

class Common_scenario_loops:
    start_loop_flag = False
    end_loop_flag = False
    loop_name :str = None
    loop_count : int = None

class Common_config:
    client_name: str = None
    config_scenario_dict:list = None
    config_step_dict:list = None


class Common_config_step:
    Common_config_step: str = None
    CONFIG_STEP_FILE: str = None
    CONFIG_STEP_SHEET:str = None
    step_file_reference:str = None


class Common_scenario_loops_list:
    loop_name_dict = {}
    scenarios_in_loop = []

class Common_DB:
    db_query_output = None
    db_query_value = None
    
class Common_path:
    base_path = os.getcwd()
    error_snapshot_path : str = base_path + "/ErrorSnapshot"
    test_config_path : str = base_path + "/Files/TestRunner"
    pre_config_file = "/PreReqConfig.xlsx"
    pre_config_sheet = "PreReqConfig"
    pre_config_path : str = base_path + "/Files/PreConfig"+pre_config_file
    navigation_path : str = base_path + "/Files/PreConfig"
    control_sheet_path : str = base_path + "/Files/ControlSheets"
    steps_path : str = base_path + "/Files/Steps"
    scenarios_path : str = base_path + "/Files/Scenarios"
    dataSheet_path : str = base_path + "/Files/DataSheets"
    input_document: str = base_path + "/Files/Input_Documents"
    
class Common_scenario:
    STEPS_FILE_REFERENCE: str = None
    STEPS_ID_REFERENCE: str = None
    DATA_PROVIDER:str = None
    STEP_FILE: str = None
    STEP_SHEET: str = None
    STEP_ID_START : int = None
    STEP_ID_END : int = None
    data_provider_num : int = 0
    INPUT_TYPE : str = None
    FLOW_CONFIG_LIST: list = None
    RTRACK_ID : str = None
    error_snapshot_file_name: str = None
    success_snapshot_file_name: str = None
    data_provider_count_for_scenario : int = None
    is_advance_log_done: bool = False
    xray_test_case_id : str = None
    

class Common_step:
    ACTION: str = None
    PAGE_NAME: str = None
    DATA_NAME: str = None
    STEP_CONFIG: str = None
    ELEMENT_REFERENCE: str = None
    DATA_REFERENCE: str = None
    CONTROL_FILE: str = None
    CONTROL_SHEET = None
    DATA_FILE: str = None 
    DATA_SHEET: str = None
    PRE_NAV_CONFIG: list= None
    STEP_DESC : str = None
    step_id : int = None
    step_count :int = 0
    step_execution_time : str = None
    STEP_TYPE: str = None
    XRAY_TEST_CASE_ID: str = None
    step_count_per_execution: int = 1
    error_popup_message: str = None
    BASE_ACTION : str = None
    SKIP_NAVIGATION : str = False
    SKIP_PRE_CONFIG : str = False
    ERROR_SNAPSHOT_FILENAME : str = None
    Pre_config_filename:str=None
    Pre_config_sheet_name:str=None
    is_time_out: bool = False
    is_click_done: bool = False
    is_pre_config: bool = False
    is_nav_config: bool = False
    is_switch_context: bool = False
    skip_redo: bool = False
    multi_select_search_combo_timeout: int = 10000
    is_password_text_first_time = False
    multi_short_done_list = None
    action_completed_assert_error_popup = None
    is_assert_error_popup_completed = False
    popup_loop_count = 0
    API_ID = None
    Request_log_file_name = None
    Response_log_file_name = None
    api_unauthorized_loop_count = 0
    Assert_downloaded_excel_column = False
    Second_Action:str=None
    DATA_REFERENCE1: str = None
    DATA_REFERENCE2: str = None

    

class Common_controls:
    control_Element :str = None
    control_Type : str = None
    control_Identifier : str = None
    control_Value : str = None

class Common_data:
    data_value : str = None
    data_value1 : str = None
    data_value2 : str = None

class Common_preConfig:
    PRECONF_PAGE_NAME: str = None
    PRECONF_ELEMENT_REFERENCE: str = None
    PRECONF_ACTION: str = None
    PRECONF_DATA_NAME: str = None
    PRECONF_DATA_REFERENCE: str = None
    PRECONF_ACTION: str = None
    PRECONF_CONTROL_FILE: str = None
    PRECONF_CONTROL_SHEET: str = None
    PRECONF_DATA_FILE: str = None
    PRECONF_DATA_SHEET: str = None
    pre_config_control_elementId: str = None
    dataSheet_reference_value: str = None

class Common_nav_path:
    menu_path: str = None
    Process_path: str = None
    Component_path: str = None
    Activity_path: str = None

class Common_navigation:
    Process: str = None
    Component: str = None
    Activity: str = None
    process_breadcrumb_value = None
    component_breadcrumb_value = None
    activity_breadcrumb_value = None
    # process_breadcrumb_xpath = None
    # component_breadcrumb_xpath = None
    # activity_breadcrumb_xpath = None
    process_breadcrumb_xpath = "//*[starts-with(@id,'btnComponent-button')]//*[starts-with(@id,'btnComponent-button') and contains(@id, 'btnInnerEl')]"
    component_breadcrumb_xpath = "//*[starts-with(@id,'btnActivity-button')]//*[starts-with(@id,'btnActivity-button') and contains(@id, 'btnInnerEl')]"
    activity_breadcrumb_xpath = "//*[starts-with(@id,'txtIlboTitle-button')]//*[starts-with(@id,'txtIlboTitle-button') and contains(@id, 'btnInnerEl')]"
    previous_process = None 
    previous_Component = None
    previous_Activity = None
    Previous_Process_and_component = None
        
class Wrapper_variables:
    elementData : str = None
    startsWithId : str = None
    containsId : str = None
    lastIndex: str = None
    patternMatch: str = None
    tiles: str = None
    propType: str = None
    inputValue: str = None
    dataValue1: str = None
    dataValue2: str = None
    dataValue3: str = None
    dataValue4: str = None
    dataValue5: str = None
    objectValue: str = None
    objectValue1: str = None
    objectValue2: str = None
    rowinput1 : str = None
    numberPart: int = 0
    tree: str = "NO"
    frame: str = None
    downloadDefaultPath : str = None
    loopNumber : str = None
    XpathPattern: str = None

class Common_db_objects:
    DB_SERVER :str = None
    DB_PORT :str = None
    DB_PROVIDER :str = None
    DB_NAME :str = None

class Event_capture_var:
    RVWRTQS_COMPONENT_PARENT_1 : str = None
    RVWRTQS_ACTIVITY_PARENT_1 : str = None
    RVWRTQS_ILBO_PARENT_1 : str = None
    RVWRTQS_EVENTNAME_PARENT_1 : str = None
    RVWRTQS_REQID_PARENT_1 : str = None
    RVWRTQS_COMPONENT_CHILD_1 : str = None
    RVWRTQS_ACTIVITY_CHILD_1 : str = None
    RVWRTQS_ILBO_CHILD_1 : str = None
    RVWRTQS_EVENTNAME_CHILD_1 : str = None
    RVWRTQS_REQID_CHILD_1 : str = None

    ECR_VERSION: str = None

    Event_turn_count:int = 0 

class Common_action_list:
    all_action: list[str] = ["Enter Text", "Password Text", "Click Button", "Select Combo", "Multi Select Combo", 
    "Click Checkbox", "Edit And Enter", "Enter Text Area", "Enter Number", "Clear Text", "Click Link", "Close Dialog", 
    "Close Dialog2", "Click Help", "Enter Date", "Click Toggle", "Click Tab", "Click Radio Button", "List Edit Enter", 
    "List Set Enter", "Enter Grid Page", "Smart Search", "Grid Smart Search1", "Grid Smart Search", "Grid Text", 
    "Grid Text Enter", "Display Block", "Enter Time", "Assert Text", "Assert Label Text", "Assert Link Text", 
    "Assert Button Text", "Assert Object", "Assert Not Object", "Click Theme", "Click Button Icon", "Assert Combo Selection", 
    "Assert Non-editable", "Assert Non-Visible", "Assert Visible", "Click TrailBar", "Click Recent Activities", 
    "Attach Document", "Scroll To Element", "Import File", "Export File", "Click ID With Text", "Click Wizard", 
    "Click Link with Class", "Click OK Button", "Click Show Help", "Click UserMenu Option", "Select Button Combo", 
    "Click Hub DisplayBlock Icon", "Click Hub DisplayBlock Text", "List Edit Select", "Click Tile Bottom Left Link", 
    "Grid Tool Bar", "Grid Search Link", "Grid Search Select", "Grid Search Single Select", "Grid Search Zoom Edit", 
    "Click Tile Bottom Right Link", "Click Tile Header", "Click Tree Grid", "Click Tree Item", "Assert Tile Body", 
    "Assert Tile Bottom Left Data", "Assert Tile Header", "Display Block Link", "Expand Child Tree", "Expand Tree", 
    "Assert Grid Table", "Save Data", "Custom Wait Sec", "Click Data Hyperlink", "Grid Attach Document", 
    "Click Ganttchart Checkbox", "Click Ganttchart Expand", "Grid Zoom Insert Row","Grid Search Edit Grid", "Assert Grid Status", 
    "Click Tree Checkbox", "Assert PDF", "Checkbox Check", "Checkbox Uncheck", "Click Template Toolbar", "Assert Combo List",
    "Assert Sort Table Asc", "Assert Sort Table Dsc", "Grid XML Compare", "Assert Checkbox", "Checkbox With Data", "Grid Search Correlate Link",
    "PDF Validation", "Assert Enumerate Combo List", "Assert UI Grid Asc", "Assert UI Grid Dsc", "Validate Grid Negative Values",
    "Assert Grid Search Focus", "Assert Display Block Value", "Assert Grid Display Block", "Save Data In Input Docs","Assert Style",
    "Assert Excel", "Assert Grid Disable", "Custom Wait Minutes", "Assert Grid Search Value", "Assert Docs", "Assert CSV",
    "Assert Grid Icon Status", "MultiSort Drag and Drop", "Dynamic Grid Uncheck", "Assert Enumerated Grid Smart Search",
    "Assert Grid Smart Search", "On Availability", "Assert Grid UI Values", "Click nth Display Block", "Click nth Grid Column",
    "Assert Downloaded Excel Column", "Click By Xpath", "Assert Page CSS Styling","Assert Object Inbetween", "Drag and Drop Grid Column",
    "Document Assertion", "List Set Enter - Saasy", "Wait for Status", "Hover And Click", "Autosave Multi Select Combo", 
    "Multi Select Creatable","Assert Colour","SaveData Row Wise","Assert Icon", "Dynamic Click Using Data","Nebula Custom Wait Sec",
    "Round Off", "Enter Text Rapids","Attach Document Rapids", "Assert Text Rapids", "Save Data Rapids", "Edit json",
    "Validate Output Files", "Copy Files","Page Search for An Element","Json To Json","Response Binding","Request Binding","Parameter Binding","Enter Text:Wait:Esc", 
    "Assert Data", "Click Action", "Enter Data", "Edit Enter Data", "Assert Radio Button", "Assert Multi Select Combo",
    "Assert Combo Options", "Grid Search Click", "Drag And Drop","Create Service Method","Create Service Method Params","Create Statements","Create Process Section","Service Creation","Dataitem Creation","Segment Creation","Service Method Mapping",# "Multi Select Search Combo"
    "Double Click","Select Combo Option"]

# print(len(Common_action_list.all_action))