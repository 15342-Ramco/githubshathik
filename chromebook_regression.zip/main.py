from multiprocessing import freeze_support
from datetime import datetime
import multiprocessing
from ParallelExecution.parallel import get_config ,read_config_file
from ParallelExecution.parallel_main import Concatenate_logs, parallel_main
from common_object import Common_object, Parallel_common_object, Variable_not_resettable
from element_highlighter import timeout_customisation
from excel_utils import quit_excel_application_by_os
from func.scenario_re_run import fail_scenarios_folder_cleanup, fail_scenarios_folder_rename, original_scenarios_folder_rename
from sub_main import reading_required_files, start_test
from utils import remove_folder,create_folder_not_exist, get_cmd_input_params, make_directory, read_properties_file
from Logger.setting_logger import set_logger
import sys, os

print(os.getpid())

make_directory("temp/log")
remove_folder(Variable_not_resettable.user_data_dir)
make_directory(Variable_not_resettable.user_data_dir)
Variable_not_resettable.logger = set_logger("temp/log/log_"+str(datetime.now().replace(microsecond=0)).replace(":", "_")+".log")  # type: ignore
Variable_not_resettable.test_properties = read_properties_file("test.properties")
execution_count = 0
is_Prerequisites = False
if __name__ == "__main__":
    multiprocessing.freeze_support()
    quit_excel_application_by_os()
    def main():
        global execution_count
        global is_Prerequisites
        try:
            timeout_customisation(Variable_not_resettable.test_properties)
            cmd_input_parameters = sys.argv
            Variable_not_resettable.logger.info(f"All parameters : {cmd_input_parameters}")
            if len(cmd_input_parameters) > 1:
                user_input_params = cmd_input_parameters[1:]
                get_cmd_input_params(user_input_params)
                Variable_not_resettable.logger.info(f"Required parameters : {user_input_params}")
            parallel_execution_config_file_data = read_config_file("config.properties")
            test_config_dictionary =get_config()
            if "Prerequisites" in test_config_dictionary and test_config_dictionary["Prerequisites"] and test_config_dictionary["Prerequisites"] != 'OFF' and 'nan' not in str(test_config_dictionary["Prerequisites"]).lower():
                if execution_count == 0:
                    Variable_not_resettable.logger.info("inside Prerequisites")
                    is_Prerequisites = True
                    Variable_not_resettable.logger.info("Running single Execution ")
                    Parallel_common_object.process_id = 0  # only for AdvanceDebugLog purpose, we utilizing this parallel variable here also.
                    if reading_required_files(Variable_not_resettable.re_run_flag):
                        start_test(is_Prerequisites)
                        execution_count = execution_count + 1
                        is_Prerequisites  = False
            if test_config_dictionary["ParallelExecution"] == "ON" or test_config_dictionary["ParallelExecution"] == "ON-FILTER":
                Variable_not_resettable.logger.info("Running parallel execution")
                create_folder_not_exist("Output")
                if parallel_execution_config_file_data['Grid_mode'] == "Local":
                    freeze_support()
                    if len(cmd_input_parameters) > 1:
                        parallel_main(test_config_dictionary,parallel_execution_config_file_data, user_input_params)
                    else:
                        parallel_main(test_config_dictionary,parallel_execution_config_file_data, None)
                    Concatenate_logs()
                        
            else:
                Variable_not_resettable.logger.info("Running single Execution ")
                Parallel_common_object.process_id = 0  # only for AdvanceDebugLog purpose, we utilizing this parallel variable here also.
                if reading_required_files(Variable_not_resettable.re_run_flag):
                #if reading_required_files():
                    start_test(is_Prerequisites)
                else:
                    Variable_not_resettable.logger.error("Please check all required files")
                    sys.exit()
        except Exception as error:
            if "'ParallelExecution'" == str(error):
                error = "ParallelExecution filed is missing or incorrect in TestRunnerConfig.xlsx"
            Variable_not_resettable.logger.error(str(error))
        quit_excel_application_by_os()
    if reading_required_files(Variable_not_resettable.re_run_flag):
    # if reading_required_files():
        if str(Common_object.test_config_dictionary.get("FailRerun")).upper() == "ON":
            fail_scenarios_folder_cleanup()
        main()
        if str(Common_object.test_config_dictionary.get("FailRerun")).upper() == "ON":
            fail_scenarios_folder_rename()
    else:
        Variable_not_resettable.logger.error("Please check all required files")
        sys.exit()
    
    if str(Common_object.test_config_dictionary.get("FailRerun")).upper() == "ON":
        Variable_not_resettable.re_run_flag = True
        if Variable_not_resettable.is_fail == True:
            main()
        original_scenarios_folder_rename()
