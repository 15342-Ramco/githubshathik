import os, shutil, pathlib
from common_object import  Variable_not_resettable
import time
# from common_object import Variable_not_resettable

def fail_scenario_collector(fail_scenario_file_path: str):

    fail_scenario_file_path_default = fail_scenario_file_path
    fail_scenario_file_path_new = fail_scenario_file_path.replace(f"\\Scenarios\\", f"\\fail_Scenarios\\")
    fail_scenario_file_path_new_split = fail_scenario_file_path_new.split("\\")[:-1]
    fail_scenario_file_path_new_join = "\\".join(fail_scenario_file_path_new_split)
    pathlib.Path(os.path.dirname(fail_scenario_file_path_new_join+"\\")).mkdir(parents=True, exist_ok=True)

    if os.path.exists(fail_scenario_file_path_new):
        os.remove(fail_scenario_file_path_new)
    shutil.copy(fail_scenario_file_path_default, fail_scenario_file_path_new)


def fail_scenarios_folder_cleanup():
    scenarios_folder = "Files"
    scenario_folders_list = os.listdir(scenarios_folder)
    for each_folder_name in scenario_folders_list:
        if "fail_" in each_folder_name:
            shutil.rmtree(f"{scenarios_folder}\\{each_folder_name}")


def fail_scenarios_folder_rename():
    scenarios_folder = "Files"
    scenario_folders_list = os.listdir(scenarios_folder)

    for each_folder_name in scenario_folders_list:
        if "fail_" in each_folder_name:
            Variable_not_resettable.is_fail = True
            exist_folder = each_folder_name.replace("fail_", "")
            exist_folder_path = os.path.join(scenarios_folder, exist_folder)
            rename_exist_folder_path = os.path.join(scenarios_folder, f"original_{exist_folder}")

            retries = 3
            for attempt in range(retries):
                try:
                    # Rename the existing folder if it exists
                    if os.path.exists(exist_folder_path):
                        if not os.path.exists(rename_exist_folder_path):
                            os.rename(exist_folder_path, rename_exist_folder_path)
                        else:
                            print(f"Warning: '{rename_exist_folder_path}' already exists. Skipping rename.")
                    
                    # Rename the fail folder to the original folder name
                    os.rename(os.path.join(scenarios_folder, each_folder_name), exist_folder_path)
                    print(f"Renamed '{each_folder_name}' to '{exist_folder}'.")
                    break  # Exit loop on success
                
                except PermissionError as e:
                    print(f"PermissionError: {e}. Retrying in 1 second...")
                    time.sleep(1)  # Wait before retrying
                except FileNotFoundError as e:
                    print(f"FileNotFoundError: {e}. The folder may have been moved or deleted.")
                    break  # Exit on this error
                except Exception as e:
                    print(f"Error renaming folders: {e}")
                    break  # Exit on other errors

def original_scenarios_folder_rename():
    scenarios_folder = "Files"
    scenario_folders_list = os.listdir(scenarios_folder)
    
    for each_folder_name in scenario_folders_list:
        if "original_" in each_folder_name:
            exist_folder = each_folder_name.replace("original_", "")
            exist_folder_path = os.path.join(scenarios_folder, exist_folder)
            rename_exist_folder_path = os.path.join(scenarios_folder, f"fail_{exist_folder}")

            retries = 3
            for attempt in range(retries):
                try:
                    # Rename the existing folder if it exists
                    if os.path.exists(exist_folder_path):
                        print(f"Renaming '{exist_folder_path}' to '{rename_exist_folder_path}'...")
                        os.rename(exist_folder_path, rename_exist_folder_path)

                    # Rename the original folder back to the original name
                    print(f"Renaming '{each_folder_name}' to '{exist_folder_path}'...")
                    os.rename(os.path.join(scenarios_folder, each_folder_name), exist_folder_path)
                    print(f"Successfully renamed '{each_folder_name}' to '{exist_folder_path}'.")
                    break  # Exit loop on success

                except PermissionError as e:
                    print(f"PermissionError: {e}. Retrying in 1 second...")
                    time.sleep(1)  # Wait before retrying
                except FileNotFoundError as e:
                    print(f"FileNotFoundError: {e}. The folder may have been moved or deleted.")
                    break  # Exit on this error
                except Exception as e:
                    print(f"Error renaming folders: {e}")
                    break  # Exit on other errors

