from common_object import Variable_not_resettable


def check_db_connection_info(db_connection_info):
    error_variable = ""
    try:
        error_variable = "DRIVER"
        driver = db_connection_info["DRIVER"]
        error_variable = "SERVER"
        server = db_connection_info["SERVER"]
        error_variable = "PORT"
        port = db_connection_info["PORT"]
        error_variable = "DBNAME"
        dbname = db_connection_info["DBNAME"]
        error_variable = "USERNAME"
        username = db_connection_info["USERNAME"]
        error_variable = "PASSWORD"
        password = db_connection_info["PASSWORD"]
    except Exception as error:
        Variable_not_resettable.logger.error(f"Please check DBMaster, {error_variable} is missing or incorrect")