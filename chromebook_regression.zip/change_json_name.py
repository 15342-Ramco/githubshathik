import json


def modify_json_tag_single_file(json_file_path, tag_path,title_value):
    """
    Modify a specific tag in a single JSON file by appending a random string to its value, and save the modified JSON to the same file.
    
    Args:
        json_file_path (str): The path to the input JSON file.
        tag_path (str): The path to the tag to be modified, separated by dots (e.g., 'info.title').
    
    Returns:
        bool: True if the modification is successful, False otherwise.
    """
    try:
        # Read the JSON file
        with open(json_file_path, 'r') as file:
            json_data = json.load(file)
    except FileNotFoundError:
        print(f"Error: File not found {json_file_path}")
        return False
    except json.JSONDecodeError:
        print(f"Error: Failed to decode JSON from {json_file_path}")
        return False

    try:
        # Extract the tag value
        tag_path_elements = tag_path.split('.')
        tag_value = json_data
        for element in tag_path_elements:
            tag_value = tag_value[element]

        # Modify the tag value
        tag_value += title_value

        # Update the JSON data
        tag_pointer = json_data
        for element in tag_path_elements[:-1]:
            tag_pointer = tag_pointer[element]
        tag_pointer[tag_path_elements[-1]] = tag_value

        # Write the modified JSON to the same file
        with open(json_file_path, 'w') as file:
            json.dump(json_data, file, indent=4)

        return True
    except KeyError:
        print(f"Error: Tag path '{tag_path}' not found in JSON structure.")
        return False
    except Exception as e:
        print(f"An error occurred while modifying the JSON file: {e}")
        return False


# Example usage for modifying a tag in a single file
# json_file_path = 'D:/Utillities/json_file_rename/input_folder/api_res_param_spec_1 1.json'
# tag_path = 'info.title'
# title_value="_random_string"



# if modify_json_tag_single_file(json_file_path, tag_path,title_value):
#     print("Tag successfully modified in single file.")
# else:
#     print("Failed to modify tag in single file.")
