import os
import sys
import time
from playwright.sync_api import sync_playwright, expect, TimeoutError as PlaywrightTimeoutError
from common_object import Common_controls, Common_data, Common_main_object, Common_navigation, Common_object, Common_nav_path, Common_path, Common_scenario, Common_step, Parallel_common_object, Variable_not_resettable, Wrapper_variables
from datetime import date, datetime
from PIL import Image
import base64
from data_sheet import get_data_value
from element_highlighter import action_interval, get_element_bg_color, get_element_highlighter_color, highlight_element, replace_highlight_element
from utils import Kill_running_browsers, create_folder_not_exist,get_final_date, handle_response, make_directory, read_properties_file, xpath_text_quotes_handler
import pandas as pd
from pathlib import Path
import stat
import json
import platform




test_properties = read_properties_file("test.properties")

play = sync_playwright().start()
def start_browser(input_browser: str, head_less: bool | None = False):
    channel_browser = input_browser.lower().strip()
    Variable_not_resettable.browser_type = channel_browser
    if channel_browser == "chrome" or channel_browser == "msedge" or channel_browser == "opera":
        browser = play.chromium.launch(headless=head_less,channel=channel_browser, timeout=Common_object.Timeout, args=["--window-position=-7,0", "--set-maximize"])
    elif channel_browser == "firefox":
        browser = play.firefox.launch(headless=head_less,channel=channel_browser, timeout=Common_object.Timeout)
    elif channel_browser == "safari":
        browser = play.webkit.launch(headless=head_less,channel=channel_browser, timeout=Common_object.Timeout)
    elif channel_browser == "chrome-headless":
        Variable_not_resettable.logger.info(f"Running Chrome in headless mode")
        channel_browser = "chrome"
        head_less = True
        browser = play.chromium.launch(headless=head_less,channel=channel_browser, timeout=Common_object.Timeout, args=["--window-position=-7,0", "--set-maximize"])
    
    
    elif str(channel_browser).lower() == "chrome-persistent-context":
        Variable_not_resettable.browser_type = "chrome"
        browser = play.chromium.launch_persistent_context(user_data_dir=Variable_not_resettable.user_data_dir, channel="chrome", timeout=30000, headless=head_less, args=["--window-position=-7,0", "--set-maximize"], record_video_dir= "temp\\videos\\")
    elif str(channel_browser).lower() == "msedge-persistent-context":
        Variable_not_resettable.browser_type = "msedge"
        browser = play.chromium.launch_persistent_context(user_data_dir=Variable_not_resettable.user_data_dir, channel="msedge", timeout=30000, headless=head_less, args=["--window-position=-7,0", "--set-maximize"], record_video_dir= "temp\\videos\\")
    elif str(channel_browser).lower() =='driver-chrome':
        browser = play.chromium.launch_persistent_context(user_data_dir=Variable_not_resettable.user_data_dir, headless=False,executable_path="Drivers\\chromium\\chrome-win\\chrome.exe",record_video_dir="temp\\videos\\")
            
        
    else:
        Variable_not_resettable.logger.info("Given Browser is not supported :", channel_browser)
        sys.exit()
    return browser

def close_page(page):
    page.close()
    
def close_browser_context(context, browser):
    if str(Variable_not_resettable.test_properties["HAR"]).lower()=="on":
           # Common_object.system_screen_resolution
        har_folder = "./hars/"
        scenario_name = har_folder + Common_object.SCENARIO_FILE_NAME+" "+str(datetime.now().replace(microsecond=0)).replace(":", "_")
        create_folder_not_exist(har_folder)
        create_folder_not_exist(scenario_name)
        har_file_path = os.path.join(scenario_name, "trace.zip")
        # Stop HAR recording and save the file
        context.tracing.stop(path=har_file_path)
    if str(Common_object.test_config_dictionary.get("Browser")).lower() != "driver-chrome":
        context.close()
        browser.close()
    else:
        context.close()
    # Kill_running_browsers()

def close_persistent_context(context, browser):
    #context.close()
    Kill_running_browsers()


def get_new_tab(context, index):
    if str(Variable_not_resettable.APP_TYPE) == "Nebula co-existence":
        if len(context.pages) > 1:
            new_page = context.pages[index]
            return new_page
        else:
            context.wait_for_event("page")
            new_page = context.pages[index]
            return new_page
    else:
        context.wait_for_event("page")
        new_page = context.pages[index]
        return new_page


def start_context(browser):
    context= browser.new_context(record_video_dir= "temp\\videos\\", record_video_size= Common_object.video_resolution, ignore_https_errors= Common_object.ignore_https_errors)
    if str(Variable_not_resettable.test_properties["HAR"]).lower()=="on":
        Variable_not_resettable.logger.info("Setting viewport done")
        # Enable HAR recording
        context.tracing.start(screenshots=True, snapshots=True)
    return context  

def start_page(context):
    page = context.new_page()
    page.on("response", lambda response: handle_response(response))
    return page

def get_browser_context_page_persistent_context():
    browser = None
    context  = start_browser(Common_object.test_config_dictionary['Browser'])
    if str(Variable_not_resettable.test_properties["HAR"]).lower()=="on":
        Variable_not_resettable.logger.info("Setting viewport done")
        # Enable HAR recording
        context.tracing.start(screenshots=True, snapshots=True)
    page = start_page(context)
    # Openpages = page.context.pages
    # Openpages[1].close()
    # page = Openpages[0]
    return browser,context,page

def get_browser_context_page():
    browser  = start_browser(Common_object.test_config_dictionary['Browser'])
    context = start_context(browser)
    page = start_page(context)
    return browser, context, page

# properties = read_properties_file("test.properties")
def launch_url(page, url, time_out:float):
    # print("Launching URL")
    Variable_not_resettable.logger.info("Launching URL")
    page.set_viewport_size(Common_object.screen_resolution)   # Common_object.system_screen_resolution
    
        
    # print("Setting viewport done")
    Variable_not_resettable.logger.info("Setting viewport done")
    # page.on('console', lambda msg: print(msg.text))
    # page.on('pageerror', lambda exc: print(f"Page error: {exc}"))
    

    if str(Variable_not_resettable.APP_TYPE).lower() == "rapids":
        max_retries = 5
        for attempt in range(max_retries):
            try:
                page.goto(url, wait_until="networkidle")
                page.wait_for_selector('body', timeout=10000)
                page.wait_for_selector("//button[text()='Sign in']",timeout=10000) # Adjust the selector and timeout as needed
                print("Page loaded successfully.")
                break  # If the page loads successfully, break out of the loop
            except PlaywrightTimeoutError as timeout_error:
                print(f"Attempt {attempt + 1}: TimeoutError: {timeout_error}")
            except Exception as pageload_error:
                print(f"Attempt {attempt + 1}: Page load error: {pageload_error}")
                if attempt < max_retries - 1:
                    time.sleep(2)  # Wait for 2 seconds before trying again
                else:
                    print("Failed to load the page after 5 attempts.")
    else:
        page.goto(url, timeout= time_out)
    # if properties["play_inspector"] == "True":
    #     page.pause()

# def video_save_as(page, path_name, file_name):
#     path = path_name + file_name
#     page.video.save_as(path=path)
#     return path, file_name
def wait_for_file(file_path, timeout=30):
    start_time = time.time()
    while True:
        if Path(file_path).exists():
            return
        elif time.time() - start_time > timeout:
            raise TimeoutError(f"Timeout waiting for file {file_path}")
        time.sleep(1)

def success_video_save_as(page):
    page.video.save_as(path=Common_object.SUCCESS_VIDEO_PATH)


def error_video_save_as(page):
    page.video.save_as(path=Common_object.ERROR_VIDEO_PATH)

def video_delete(page):
    page.video.delete()



    
def for_download(page, selector):
    with page.expect_download() as download_info:
        # Perform the action that initiates download
        page.click(selector)
    download = download_info.value
    file_name = download.suggested_filename
    destination_folder_path = "./Downloads/"
    # Wait for the download process to complete
    path = download.path()
    download.save_as(os.path.join(destination_folder_path, file_name))
    # print("Downloaded Done")


def wait_for_file_complete(file_path, timeout=60, check_interval=1):
    """Wait for the file to be completely written by checking its size over time."""
    start_time = time.time()
    previous_size = -1
    
    while True:
        # Check if file exists
        if Path(file_path).exists():
            current_size = os.path.getsize(file_path)
            # If the file size remains the same for consecutive checks, assume it's fully written
            if current_size == previous_size and current_size > 0:
                return True
            previous_size = current_size
        
        # Check for timeout
        if time.time() - start_time > timeout:
            raise TimeoutError(f"Timeout waiting for file to be completely saved: {file_path}")
        
        time.sleep(check_interval) 


def for_download_and_assert_grid(page, selector,download_xlsx_2_xpath):
    with page.expect_download(timeout=60000) as download_info:
        # Perform the action that initiates download
        try:
            page.click(selector, timeout=3000)
        except Exception as error:
            page.click(download_xlsx_2_xpath, timeout=3000)
    download = download_info.value
    file_name = download.suggested_filename
    download_folder_path = "./Files/Input_Documents/"
    # Wait for the download process to complete
    path = download.path()
    # Check if the file is accessible and not locked
    file_stat = os.stat(path)
    if not file_stat.st_mode & stat.S_IWRITE:
        raise PermissionError(f"File {path} is not writable")
    save_in_path = os.path.join(download_folder_path, file_name)
    # Wait for the download process to complete
    wait_for_file(path)
    try:
        download.save_as(save_in_path)
        wait_for_file_complete(save_in_path)
    except Exception as saveerror:
        Variable_not_resettable.logger.error(saveerror)
        try:
            download.save_as(save_in_path)
            wait_for_file_complete(save_in_path)
        except Exception as saveerror:
            Variable_not_resettable.logger.error(saveerror)
        # Verify that the file has been completely written
        
    download_sheet = file_name.split(".")[0]
    # print("Downloaded Done")
    return save_in_path,download_sheet

def for_download_and_assert_grid_direct_click(page, selector):
    
    with page.expect_download(timeout=60000) as download_info:
        # Perform the action that initiates download
        try:
            page.click(selector, timeout=3000)
        except Exception as error:
            # page.click(download_xlsx_2_xpath, timeout=3000)
            Variable_not_resettable.logger.info(str(error))
            raise Exception(str(error))
    download = download_info.value
    file_name = download.suggested_filename
    download_folder_path = "./Files/Input_Documents/"
    # Wait for the download process to complete
    path = download.path()
    # Check if the file is accessible and not locked
    file_stat = os.stat(path)
    if not file_stat.st_mode & stat.S_IWRITE:
        raise PermissionError(f"File {path} is not writable")
    save_in_path = os.path.join(download_folder_path, file_name)
    # Wait for the download process to complete
    wait_for_file(path)
    try:
        download.save_as(save_in_path)
        wait_for_file_complete(save_in_path)
    except Exception as saveerror:
        Variable_not_resettable.logger.error(saveerror)
        try:
            download.save_as(save_in_path)
            wait_for_file_complete(save_in_path)
        except Exception as saveerror:
            Variable_not_resettable.logger.error(saveerror)
    download_sheet = file_name.split(".")[0]
    # print("Downloaded Done")
    return save_in_path,download_sheet
    

def check_grid_row(page):
    try:
        page.wait_for_selector(Common_nav_path.menu_path, timeout=500)
        return True
    except:
        return False


def navigation_runner(page, nav_config_id):
    is_doing = "Navigation"
    is_menu_clicked = False
    try:
        if Common_step.SKIP_NAVIGATION != True:
            if Variable_not_resettable.APP_TYPE == "Openworks":
                is_doing = "Click Menu Button"
                page.wait_for_selector(Common_nav_path.menu_path, timeout=Common_object.Timeout)

                if test_properties.get("element_highlighter") == "True":
                    menu_element_bg_color = get_element_bg_color(page, Common_nav_path.menu_path)
                    highlight_element(page, Common_nav_path.menu_path, get_element_highlighter_color(test_properties))
                page.click(Common_nav_path.menu_path)

                # try:
                #     div_element = page.wait_for_selector("//div[contains(@id,'window') and @aria-hidden='false']", timeout=5000)
                #     if div_element.is_visible():
                #         pass
                #     else:
                #         raise Exception("Element not visible")
                # except Exception as e:
                #     print("Element not found or not visible. Clicking the menu button.")
                #     page.click(Common_nav_path.menu_path,timeout=5000)

                try:
                    expander="//li[contains(@class,'expanded')]"
                    try:
                        elements = page.query_selector_all(expander)
                        if len(elements)>2:
                            raise Exception("More than two expnded items")
                        if elements:
                            for rev_ind, element in enumerate(reversed(elements)):
                                ind = len(elements) - 1 - rev_ind
                                text = element.inner_text()
                                if len(Common_navigation.Previous_Process_and_component)!=0:
                                    if (Common_navigation.Previous_Process_and_component)[ind] in text:
                                        page.click("//li[contains(@class,'expanded')]//div[@class='x-treelist-item-text' and text()='"+str((Common_navigation.Previous_Process_and_component)[ind])+"']")
                        else:
                            print(f"No elements found for selector '{expander}'")
                    except Exception as error:
                        print(str(error))    
                        # print(f"No elements found for selector '{expander}'")
                except Exception as expander_error:
                    print(f"Timeout: No elements found for selector '{expander}' within the given time")
                
                if test_properties.get("element_highlighter") == "True":
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                    replace_highlight_element(page, Common_nav_path.menu_path, menu_element_bg_color)

                Variable_not_resettable.logger.info("Menu Clicked")
                is_menu_clicked = True
                is_doing = "Process : '"+Common_navigation.Process+"'"
                page.wait_for_selector(Common_nav_path.Process_path, timeout=Common_object.Timeout)
                page.click(Common_nav_path.Process_path)
                if test_properties.get("element_highlighter") == "True":
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                Variable_not_resettable.logger.info(f"Process: {Common_navigation.Process} Clicked")
                is_doing = "Component : '"+Common_navigation.Component+"'"
                page.wait_for_selector(Common_nav_path.Component_path, timeout=Common_object.Timeout)
                page.click(Common_nav_path.Component_path)
                if test_properties.get("element_highlighter") == "True":
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                Variable_not_resettable.logger.info(f"Component: {Common_navigation.Component} Clicked")
                is_doing = "Activity : '"+Common_navigation.Activity+"'"
                page.wait_for_selector(Common_nav_path.Activity_path, timeout=Common_object.Timeout)
                if test_properties.get("element_highlighter") == "True":
                    menu_element_bg_color = get_element_bg_color(page, Common_nav_path.menu_path)
                    highlight_element(page, Common_nav_path.Activity_path, get_element_highlighter_color(test_properties))
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                    replace_highlight_element(page, Common_nav_path.Activity_path, menu_element_bg_color)
                page.click(Common_nav_path.Activity_path)
            
                Common_step.SKIP_NAVIGATION = True
                Common_navigation.previous_process = Common_navigation.Process 
                Common_navigation.previous_Component = Common_navigation.Component
                Common_navigation.previous_Activity = Common_navigation.Activity
                Common_navigation.Previous_Process_and_component =[str(Common_navigation.Process),str(Common_navigation.Component)]

            elif Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                
                if str(Common_navigation.previous_process)   == str(Common_navigation.Process) and  str(Common_navigation.previous_Component) == str(Common_navigation.Component) and  str(Common_navigation.previous_Activity)  == str(Common_navigation.Activity):
                    return
                
                # time.sleep(20)
                Variable_not_resettable.logger.info("Waiting for menu...")
                page.wait_for_selector(Common_nav_path.menu_path, timeout=20000)
                Variable_not_resettable.logger.info("Menu found...")


                
                is_doing = "Click Menu Button"
                page.wait_for_selector(Common_nav_path.menu_path, timeout=Common_object.Timeout)
                page.click(Common_nav_path.menu_path)
                Variable_not_resettable.logger.info("Menu Clicked")
                is_menu_clicked = True
                # is_doing = "Process : '"+Common_navigation.Process+"'"
                # page.wait_for_selector(Common_nav_path.Process_path, timeout=Common_object.Timeout)
                # page.click(Common_nav_path.Process_path)
                # Variable_not_resettable.logger.info(f"Process: {Common_navigation.Process} Clicked")
                is_doing = "Component : '"+Common_navigation.Component+"'"
                page.wait_for_selector(Common_nav_path.Component_path, timeout=Common_object.Timeout)
                page.click(Common_nav_path.Component_path)
                Variable_not_resettable.logger.info(f"Component: {Common_navigation.Component} Clicked")
                
                if str(Common_navigation.Activity) == "nan":
                    pass
                else:
                    is_doing = "Activity : '"+Common_navigation.Activity+"'"
                    page.wait_for_selector(Common_nav_path.Activity_path, timeout=Common_object.Timeout)
                    page.click(Common_nav_path.Activity_path)
                    Variable_not_resettable.logger.info(f"Activity: {Common_navigation.Activity} Clicked")
                    
                Common_step.SKIP_NAVIGATION = True
                wait_unitil_please_wait(page, 2000)
                Common_step.error_popup_message = None

                Common_step.SKIP_NAVIGATION = True
                Common_navigation.previous_process = Common_navigation.Process 
                Common_navigation.previous_Component = Common_navigation.Component
                Common_navigation.previous_Activity = Common_navigation.Activity

            elif str(Variable_not_resettable.APP_TYPE).lower() == "epubs":
                wait_unitil_please_wait(page,500)                   
                wait_and_close_popup(page)
                is_doing = "Click Menu Button"
                sidemenu = page.locator("//*[@id='mySidenav' and @style='display: block;']").count()
                if sidemenu != 0:
                    page.click(Common_nav_path.menu_path, timeout=Common_object.Timeout)
                page.wait_for_selector(Common_nav_path.menu_path, timeout=Common_object.Timeout)

                if test_properties.get("element_highlighter") == "True":
                    menu_element_bg_color = get_element_bg_color(page, Common_nav_path.menu_path)
                    highlight_element(page, Common_nav_path.menu_path, get_element_highlighter_color(test_properties))
                page.click(Common_nav_path.menu_path)
                if test_properties.get("element_highlighter") == "True":
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                    replace_highlight_element(page, Common_nav_path.menu_path, menu_element_bg_color)

                Variable_not_resettable.logger.info("Menu Clicked")
                is_menu_clicked = True
                is_doing = "Process : '"+Common_navigation.Process+"'"
                ComponentList_open = page.locator("//*[@id='mySidenav']/div/h4/a[text()='" + Common_navigation.Process + "']/following::div[1][@class='panel-collapse collapse in']/a[text()='" + Common_navigation.Component + "']").count()
                if ComponentList_open == 0:
                    page.click(Common_nav_path.Process_path,  timeout=Common_object.Timeout)
                
                if test_properties.get("element_highlighter") == "True":
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                Variable_not_resettable.logger.info(f"Process: {Common_navigation.Process} Clicked")
                is_doing = "Component : '"+Common_navigation.Component+"'"
                page.wait_for_selector(Common_nav_path.Component_path, timeout=Common_object.Timeout)
                page.click(Common_nav_path.Component_path)
                if test_properties.get("element_highlighter") == "True":
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                Variable_not_resettable.logger.info(f"Component: {Common_navigation.Component} Clicked")
                

                Common_step.SKIP_NAVIGATION = True
                wait_unitil_please_wait(page, 2000)
                Common_step.error_popup_message = None
                
                if str(Variable_not_resettable.test_properties.get("breadcrumb_log")).upper() == "TRUE": 
                    set_breadcrumb_value(page)

            else:
                wait_unitil_please_wait(page,500)                   
                wait_and_close_popup(page)
                is_doing = "Click Menu Button"
                page.wait_for_selector(Common_nav_path.menu_path, timeout=Common_object.Timeout)

                if test_properties.get("element_highlighter") == "True":
                    menu_element_bg_color = get_element_bg_color(page, Common_nav_path.menu_path)
                    highlight_element(page, Common_nav_path.menu_path, get_element_highlighter_color(test_properties))
                page.click(Common_nav_path.menu_path)
                if test_properties.get("element_highlighter") == "True":
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                    replace_highlight_element(page, Common_nav_path.menu_path, menu_element_bg_color)

                Variable_not_resettable.logger.info("Menu Clicked")
                is_menu_clicked = True
                is_doing = "Process : '"+Common_navigation.Process+"'"
                page.wait_for_selector(Common_nav_path.Process_path, timeout=Common_object.Timeout)
                page.click(Common_nav_path.Process_path)
                if test_properties.get("element_highlighter") == "True":
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                Variable_not_resettable.logger.info(f"Process: {Common_navigation.Process} Clicked")
                is_doing = "Component : '"+Common_navigation.Component+"'"
                page.wait_for_selector(Common_nav_path.Component_path, timeout=Common_object.Timeout)
                page.click(Common_nav_path.Component_path)
                if test_properties.get("element_highlighter") == "True":
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                Variable_not_resettable.logger.info(f"Component: {Common_navigation.Component} Clicked")
                is_doing = "Activity : '"+Common_navigation.Activity+"'"
                page.wait_for_selector(Common_nav_path.Activity_path, timeout=Common_object.Timeout)
                if test_properties.get("element_highlighter") == "True":
                    menu_element_bg_color = get_element_bg_color(page, Common_nav_path.menu_path)
                    highlight_element(page, Common_nav_path.Activity_path, get_element_highlighter_color(test_properties))
                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                    replace_highlight_element(page, Common_nav_path.Activity_path, menu_element_bg_color)
                page.click(Common_nav_path.Activity_path)
                    
                Common_step.SKIP_NAVIGATION = True
                wait_unitil_please_wait(page, 2000)
                Common_step.error_popup_message = None
                
                if str(Variable_not_resettable.test_properties.get("breadcrumb_log")).upper() == "TRUE": 
                    set_breadcrumb_value(page)

    except Exception as error:
        if is_menu_clicked == False:
            Variable_not_resettable.logger.info("Checking Loading. please wait...")
            wait_unitil_load(page,3000)
        elif is_menu_clicked == True:
            menu_open_xpath = "//div[@role='menu' and @aria-hidden='false']"
            if for_check_obj(page, menu_open_xpath, 1000):
                Variable_not_resettable.logger.info("Menu already open")
                page.click(Common_nav_path.menu_path)
                Variable_not_resettable.logger.info("Menu closed")
        Common_step.error_popup_message = f"Scenario failed in Navigation, while doing {is_doing} and the navigation config id: {nav_config_id}"
        raise Exception(str(error))
    time.sleep(0.05)

def set_breadcrumb_value(page):
    try:
        Common_navigation.process_breadcrumb_value = page.locator(Common_navigation.process_breadcrumb_xpath).inner_text(timeout=3000)
        Common_navigation.component_breadcrumb_value = page.locator(Common_navigation.component_breadcrumb_xpath).inner_text(timeout=3000)
        Common_navigation.activity_breadcrumb_value = page.locator(Common_navigation.activity_breadcrumb_xpath).inner_text(timeout=3000)

        if str(Variable_not_resettable.test_properties.get("breadcrumb_log")).upper() == "TRUE": 
            Variable_not_resettable.logger.info(f"Breadcrumb : {Common_navigation.process_breadcrumb_value} / {Common_navigation.component_breadcrumb_value} / {Common_navigation.activity_breadcrumb_value}")
            Common_navigation.Process = Common_navigation.process_breadcrumb_value
            Common_navigation.Component = Common_navigation.component_breadcrumb_value
            Common_navigation.Activity = Common_navigation.activity_breadcrumb_value

    except Exception as error:
        Variable_not_resettable.logger.error(str(error))
        pass

def for_time_out(page_object, time_out):
    page_object.wait_for_timeout(time_out)

def for_click(page_object, selector):
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    page_object.click(selector, timeout= Common_object.Timeout)

def for_click_tab(page_object, selector):
    page_object.focus(selector, strict= True, timeout=Common_object.Timeout)
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    page_object.click(selector, timeout= Common_object.Timeout)

def for_click_button_combo(page_object, selector):
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    page_object.click(selector, timeout= Common_object.Timeout, force=True)

def for_click_child_tree(page_object, selector):
    page_object.locator("//div/a[@name = 'mainMenu_button']").hover()
    time.sleep(.5)
    page_object.locator(selector).scroll_into_view_if_needed(timeout= Common_object.Timeout)
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    page_object.click(selector, timeout= Common_object.Timeout)
            
def for_click_tree_checkbox_(page_object, selector):
    page_object.locator("//div/a[@name = 'mainMenu_button']").hover()
    time.sleep(.5)
    page_object.locator(selector).scroll_into_view_if_needed(timeout= Common_object.Timeout)
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    page_object.click(selector, timeout= Common_object.Timeout)


def for_click_toggle(page_object, selector):
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    page_object.click(selector, timeout= Common_object.Timeout)

def for_click_link(page_object, selector): # common for click link and Click button icon
    try:
        page_object.hover(selector)
        time.sleep(1)
        Variable_not_resettable.logger.info("**********************Inside function Click Button Icon page Action***************************")
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        Variable_not_resettable.logger.info("**********************Click link element found***************************")
        
        if ("grid" in selector) and ("cell" in selector) and ("row" in selector) and ("col" in selector):
            page_object.click(selector, timeout= Common_object.Timeout)
            Variable_not_resettable.logger.info("Inside grid link")
            # if page_object.locator(selector).is_visible() and page_object.locator(selector).is_enabled():
            #     Variable_not_resettable.logger.info("Link visible and enabled")
            #     page_object.click(selector, timeout= Common_object.Timeout)
            #     Variable_not_resettable.logger.info("Link Clicked")
        else: #if selector != "//*[@id='pre_mlhr_earning_grid_cell_colrn_row1']":
            page_object.click(selector, timeout= Common_object.Timeout)
            
        # Variable_not_resettable.logger.debug("**********************Inside function Click Button Icon page Action***************************")
        # page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        # Variable_not_resettable.logger.debug("**********************Click link element found***************************")
        # page_object.click(selector, timeout= Common_object.Timeout)


        # element_handle = page_object.query_selector(selector)
        # element_handle.scroll_into_view_if_needed(timeout= Common_object.Timeout)
        # box = element_handle.bounding_box()
        # page_object.mouse.click(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)


        Variable_not_resettable.logger.debug("**********************Clicked successfully***************************")
        Common_step.is_click_done = True
        # time.sleep(2)
        # print("[INFO] : Clicked successfully")
    except Exception as error:
        Variable_not_resettable.logger.debug(f"{str(error)}")
        if "ml" in selector and "cell" in selector and "row" in selector:
            try:
                Variable_not_resettable.logger.info("**********************Click Link Done checked with zoom***************************")
                dialog_xpath = "//*[@role='dialog' and @aria-hidden='false']//*[@data-qtip='Close dialog'][starts-with(@id,'tool')]//*[contains(@id, 'toolEl')]"
                page_object.wait_for_selector(dialog_xpath, timeout= Common_object.Timeout)
            except Exception as error_2:
                raise Exception(str(error))
        
        else:
            # print("[INFO] :Exception in  click link")
            # print(error)
            Variable_not_resettable.logger.debug(f"**********************popup function return: {check_is_popup(page_object, 1000)}***************************")
            if check_is_popup(page_object, 1000) == False and check_is_zoom_popup(page_object, 1000) == False: # line added 2-09-2022
                Variable_not_resettable.logger.debug("**********************Inside Popup False Condition***************************")
                page_object.keyboard.press("Escape")
                # print("[INFO] :Escape key pressed")
                Variable_not_resettable.logger.debug("**********************Inside function Click Button Icon page Action***************************")
                time.sleep(0.25)
                page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
                page_object.click(selector, timeout= Common_object.Timeout)
                Common_step.is_click_done = True
            else:
                raise Exception(str(error))
    Variable_not_resettable.logger.debug("**********************click link function completed***************************")


def for_click_checkbox(page_object, selector):
    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
        Variable_not_resettable.logger.info("Click Checkbox in Nebula running...")
        page_object.click(selector, timeout= Common_object.Timeout)
    else:
        wait_unitil_please_wait(page_object,100)
        wait_and_close_popup(page_object)
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        try:
            page_object.click(selector, timeout= Common_object.Timeout)
        except Exception as error:
            error_str = error
            Variable_not_resettable.logger.info(str(error))
            try:
                loc = page_object.locator(selector)
                loc.click(timeout= Common_object.Timeout)
            except Exception as error:
                raise Exception("Click Check Box failed because : "+ str(error_str))

def for_click_Grid_Search_Zoom_Edit(page_object, selector):
    try:
        page_object.wait_for_selector(selector, timeout= 200)
        page_object.click(selector, timeout= 1000)
    except Exception as error:
        raise Exception("Grid Search Zoom Edit failed because : "+ str(error))

def check_element_handler(page_object, element_handler):
    try:
        page_object.wait_for_selector(element_handler, timeout= 500)
        return True
    except:
        return False


def for_click_button(page_object, selector):
    try:
        element = page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        element.scroll_into_view_if_needed(timeout= Common_object.Timeout)
        element.click()
        Variable_not_resettable.logger.info("Element clicked successfully.")
        Variable_not_resettable.logger.info("Button found")
        Common_step.is_click_done = True
        Variable_not_resettable.logger.debug("Click button SUCCESS")
    except Exception as error:
        Variable_not_resettable.logger.error(f"###################### Click Button Error ######################")
        Variable_not_resettable.logger.error(f"Failed to click element: {str(error)}")
        Variable_not_resettable.logger.error("Click button ERROR")
        Variable_not_resettable.logger.info("Click Button failed because : "+ str(error))
        raise Exception("Click Button failed because : "+ str(error))
    
def Doubleclick(page_object, selector):
    try:
        element = page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        element.scroll_into_view_if_needed(timeout= Common_object.Timeout)
        # Double-click on the element
        element.dblclick()
        Variable_not_resettable.logger.info("Element Double clicked successfully.")
        Variable_not_resettable.logger.info("Button found")
        Common_step.is_click_done = True
        Variable_not_resettable.logger.debug("Double Click button SUCCESS")
    except Exception as error:
        Variable_not_resettable.logger.error(f"###################### Double Click Button Error ######################")
        Variable_not_resettable.logger.error(f"Failed to Double click element: {str(error)}")
        Variable_not_resettable.logger.error("Double Click button ERROR")
        Variable_not_resettable.logger.info("Double Click Button failed because : "+ str(error))
        raise Exception("Double Click Button failed because : "+ str(error))


# def for_click_button(page_object, selector):
#     try:
#         #time.sleep(1)
#         page_object.locator(selector).scroll_into_view_if_needed(timeout= Common_object.Timeout)
#         page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
#         Variable_not_resettable.logger.info("Button found")
#         page_object.click(selector, timeout= Common_object.Timeout)

#         # element_handle = page_object.query_selector(selector)
#         # element_handle.scroll_into_view_if_needed(timeout= Common_object.Timeout)
#         # box = element_handle.bounding_box()
#         # page_object.mouse.click(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)

#         Common_step.is_click_done = True
#         Variable_not_resettable.logger.debug("Click button SUCCESS")
#         #time.sleep(2)
#         # print("[INFO] : Clicked successfully")
#         # Variable_not_resettable.logger.info("Button Clicked successfully")
#     except Exception as error:
#         # print(str(error))
#         Variable_not_resettable.logger.debug("Click button ERROR")
#         Variable_not_resettable.logger.info("Click Button failed because : "+ str(error))
#         raise Exception("Click Button failed because : "+ str(error))
    
def for_select_combo(page_object, selector, data):
    time.sleep(0.25)
    try:
        page_object.scroll_into_view_if_needed()
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    except Exception as error:
        wait_unitil_please_wait(page_object, 100)
        wait_and_close_popup(page_object)
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)

    page_object.click(selector, timeout= Common_object.Timeout)
    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
    if str(data).lower() != "nan" and str(data).lower() != "na" and str(data) != "":
        combo_value = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, 'picker-listEl') and @aria-hidden='false']//li[text()="+xpath_text_quotes_handler(str(data))+"]"
        check_picker_list = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, 'picker-listEl') and @aria-hidden='false']"
        Variable_not_resettable.logger.info("combo value Xpath : "+ str(combo_value))
        try:
            page_object.click(combo_value, timeout= Common_object.Timeout_select_combo)
        except:
            try:
                Variable_not_resettable.logger.info("2 nd for select combo")
                try:
                    page_object.wait_for_selector(check_picker_list, timeout= 2000)
                except:
                    page_object.click(selector, timeout= Common_object.Timeout)

                page_object.click(combo_value, timeout= Common_object.Timeout_select_combo)
            except:
                fill = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, 'inputEl')]"
                attribute = page_object.query_selector(fill).get_attribute("readonly")
                if str(attribute).strip() == "readonly":
                    try:
                        page_object.click(combo_value, timeout= Common_object.Timeout_select_combo, position={"x": 0.0, "y": 0.0})
                    except:
                        set_focus_to_element(page_object,combo_value)
                        page_object.click(combo_value, timeout= Common_object.Timeout_select_combo, position={"x": 0.0, "y": 0.0})
                else:
                    page_object.keyboard.press("Control+A")
                    page_object.keyboard.press("Delete")
                    page_object.keyboard.type(str(data), delay=100)
                    time.sleep(0.25)
                    try:
                        page_object.click(combo_value, timeout= Common_object.Timeout_select_combo, position={"x": 0.0, "y": 0.0})
                    except Exception as error:                        
                        try:
                            page_object.wait_for_selector(check_picker_list, timeout= 2000)
                            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
                        except:
                            pass
                        raise Exception(str(error))
    else:
        Variable_not_resettable.logger.info("empty selection")

        empty_selection = "//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, 'picker-listEl') and @aria-hidden='false']//li[string-length(text()) = 0]"
        Variable_not_resettable.logger.info("combo value empty_selection Xpath : "+ str(empty_selection))
        try:
            page_object.click(empty_selection, timeout= Common_object.Timeout_select_combo)
            Variable_not_resettable.logger.info("element is present")
        except:
            Variable_not_resettable.logger.info("Element is not present")
            page_object.click(empty_selection, timeout= Common_object.Timeout_select_combo, position={"x": 0.0, "y": 0.0})


def for_fill(page_object, selector, data):
    if Variable_not_resettable.APP_TYPE == "Studio":
        try:
            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            page_object.click(selector, timeout= Common_object.Timeout)
            if str(data).lower() != "nan" and str(data) != "" and str(data) != None:
                page_object.fill(selector, str(data))
            else:
                page_object.fill(selector, "")
        except :
            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            page_object.click(selector, timeout= Common_object.Timeout)
            
            is_mac = platform.system() == 'Darwin'
            if is_mac:
                page_object.keyboard.press('Command+A')  # macOS
            else:
                page_object.keyboard.press('Control+A')  # Windows/Linux
            
            page_object.keyboard.press('Backspace')   # Delete the selected text

            # Optionally, you can add a wait time to see the action
            time.sleep(1)
            # Use XPath to set the value in the CodeMirror editor
            page_object.evaluate(f"""
                (function() {{
                    var xpath = "{selector}";
                    var editor = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                    if (editor) {{
                        editor.CodeMirror.setValue(`{data}`);
                    }} else {{
                        console.error("CodeMirror editor not found");
                    }}
                }})();
            """)
    else:
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        page_object.click(selector, timeout= Common_object.Timeout)
        if str(data).lower() != "nan" and str(data) != "" and str(data) != None:
            page_object.fill(selector, str(data))
        else:
            page_object.fill(selector, "")
    

def for_list_set_enter(page_object, selector, data):
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    page_object.click(selector)
    if str(data).lower() != "nan" and str(data) != "" and str(data) != None:
        page_object.fill(selector, str(data))
    else:
        page_object.fill(selector, "")


def for_fill_time(page_object, selector, data):
    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
        Variable_not_resettable.logger.info("Enter Time in Nebula Running...")
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        page_object.click(selector)
        # data = data.replace(":","")
        if str(data).lower() != "nan" and str(data) != "":
            page_object.type(selector, data, delay=100)
        else:
            page_object.fill(selector, "")
        page_object.keyboard.press("Enter")
        # tt_closing = "//*[@class='ep-arrow  rmdp-ep-arrow rmdp-ep-shadow  ']"
        # page_object.click(tt_closing)
    else:
        data_for_verification = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num , Common_step.DATA_REFERENCE)
        if 'EXECUTE:' in str(data_for_verification):
            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            Variable_not_resettable.logger.info(f"Formatted time : {str(Common_data.data_value)}")
            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            page_object.click(selector)
            if str(Common_data.data_value).lower() != "nan" and str(Common_data.data_value) != "":
                page_object.fill(selector, str(Common_data.data_value))
            else:
                page_object.fill(selector, "")
            page_object.click(selector)
        else:
            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            enter_txt_title_att = page_object.locator(selector).get_attribute("title")
            Variable_not_resettable.logger.debug(str(enter_txt_title_att))
            time_formatted  = get_final_date(enter_txt_title_att, str(data))
            Variable_not_resettable.logger.info(f"Formatted time : {time_formatted}")
            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            page_object.click(selector)
            if str(time_formatted).lower() != "nan" and str(time_formatted) != "" and str(time_formatted) != "None" and str(time_formatted) != None:
                page_object.fill(selector, str(time_formatted))
            else:
                page_object.fill(selector, "")
            page_object.click(selector)
    












def for_fill_Grid_Search_Zoom_Edit(page_object, selector, data):
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    element_handler = page_object.locator(selector)
    element_handler.scroll_into_view_if_needed()
    time.sleep(.25)
    if str(data).lower != "nan" and str(data) != "":
        page_object.fill(selector, str(data))
    else:
        page_object.fill(selector, "")


def for_fill_date(page_object, selector, data): 
    if Common_scenario.data_provider_num != None:
        data_for_verification = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num , Common_step.DATA_REFERENCE)
        if 'EXECUTE:' in str(data_for_verification):
            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            element_handler = page_object.query_selector(selector)
            element_text = element_handler.get_attribute("title")
            Variable_not_resettable.logger.info(str(element_text))
            page_object.click(selector, timeout= Common_object.Timeout)
            page_object.fill(selector, data)
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                page_object.keyboard.press("Enter")
        else:
                if str(data).lower() != "nan" and data != "" and data != None and str(data) != str(None):
                    try:
                        Variable_not_resettable.logger.info("Date before formatting"+ str(data))
                        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
                        element_handler = page_object.query_selector(selector)
                        
                        if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                            element_text = element_handler.get_attribute("placeholder")
                        else:
                            element_text = element_handler.get_attribute("title")
                        # element_text = element_handler.get_attribute("title")
                        Variable_not_resettable.logger.info(str(element_text))
                        final_date = get_final_date(element_text, data)
                        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
                        page_object.click(selector, timeout= Common_object.Timeout)
                        page_object.fill(selector, str(final_date))
                    except:
                        page_object.fill(selector, str(final_date))
                    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                        page_object.keyboard.press("Enter")
                else:
                    if data_for_verification != "nan" and data_for_verification != "" and data_for_verification != None and str(data_for_verification) != str(None):
                        raise Exception(f"Data sheet have Enter Date Value but data coming as : {str(data)}")
                    page_object.click(selector, timeout= Common_object.Timeout)
                    page_object.fill(selector, "")
                    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                        page_object.keyboard.press("Enter")
        if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
            pass
        else:
            page_object.click(selector, timeout= Common_object.Timeout)
    else:
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        page_object.click(selector, timeout= Common_object.Timeout)
        page_object.fill(selector, data)
        page_object.click(selector, timeout= Common_object.Timeout)
        if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                page_object.keyboard.press("Enter")



def for_fill_grid_text(page_object, selector, data):
    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
        set_focus_to_element(page_object, selector)
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        for_click(page_object,selector)
        time.sleep(1)
        page_object.keyboard.press("Control+A")
        page_object.keyboard.press("Backspace")
        page_object.keyboard.type(str(data))
    else:
        page_object.hover(selector)
        time.sleep(0.5)
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        for_click(page_object,selector)
        page_object.keyboard.press("Control+A")
        page_object.keyboard.press("Backspace")
        page_object.keyboard.type(str(data))

# def for_fill_grid_text_enter(page_object, selector, data):
#     if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
#         set_focus_to_element(page_object, selector)
#         Variable_not_resettable.logger.info("Enter Grid Text in Nebula running...")
#         page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
#         for_click(page_object,selector)
#         time.sleep(1)
#         page_object.keyboard.press("Control+A")
#         page_object.keyboard.press("Backspace")
#         # time.sleep(3)
#         page_object.keyboard.type(str(data))
#         page_object.keyboard.press('Enter')
#     else:
#         page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
#         page_object.locator(selector).scroll_into_view_if_needed(timeout= Common_object.Timeout)
#         for_click(page_object,selector)
#         page_object.keyboard.press("Control+A")
#         page_object.keyboard.press("Backspace")
#         page_object.keyboard.type(str(data))
#         page_object.keyboard.press('Enter')

# Use Playwright's `locator` to select by XPath directly

def for_fill_grid_text_enter(page_object, selector, data):
    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
        set_focus_to_element(page_object, selector)
        Variable_not_resettable.logger.info("Enter Grid Text in Nebula running...")
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        for_click(page_object,selector)
        time.sleep(1)
        page_object.keyboard.press("Control+A")
        page_object.keyboard.press("Backspace")
        # time.sleep(3)
        page_object.keyboard.type(str(data))
        page_object.keyboard.press('Enter')
     
    else:
        page_object.wait_for_selector(selector, timeout=Common_object.Timeout)
        page_object.locator(selector).scroll_into_view_if_needed(timeout=Common_object.Timeout)
        
        # Double-click to activate editable field
        page_object.locator(selector).dblclick()
        time.sleep(1)

        page_object.keyboard.press("Control+A")
        page_object.keyboard.press("Backspace")
        page_object.keyboard.type(str(data))
        time.sleep(0.5)

        page_object.keyboard.press('Enter')
        Variable_not_resettable.logger.info(f"Attempted entry of data: {data}")




def set_focus_to_element(page_object,selector):
    page_object.locator(selector).scroll_into_view_if_needed(timeout=Common_object.Timeout)

def for_assert_text_combo(page_object,selector, data):
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    set_focus_to_element(page_object,selector)
    text_box_data = page_object.locator(selector).input_value()
    Variable_not_resettable.logger.debug(f"text_box_data : {text_box_data}")
    if "Round-off" in Common_step.BASE_ACTION:
        new_data = round(float(data))
        new_text_box_data = round(float(text_box_data))
        if new_data == new_text_box_data:
            # print("[INFO] : Text is Present")
            Variable_not_resettable.logger.info("Assert Text Round-off Success for: '" + str(data) +f"', Text in application '{text_box_data}' ")
        else:
            Common_object.Custom_Error = "Assert Text Round-off Failed for: '" + str(data)+f"' , Text in application '{text_box_data}' "
            raise Exception(Common_object.Custom_Error)
    else:
        if data == text_box_data:
            # print("[INFO] : Text is Present")
            Variable_not_resettable.logger.info("Assert Text Success for: '" + str(data) +f"', Text in application '{text_box_data}' ")
        else:
            Common_object.Custom_Error = "Assert Text Failed for: '" + str(data)+f"' , Text in application '{text_box_data}' "
            raise Exception(Common_object.Custom_Error)
        

def for_assert_text_page_navigation(page_object, selector, data):
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    elements = page_object.query_selector_all(selector)
    for i, element in enumerate(elements):
        try:
            text_in_app = element.inner_text()
            if str(text_in_app).strip()==str(data).strip():
                Variable_not_resettable.logger.info("Asserting Text for : '" + str(data)+ "' is SUCCESS")
                break
            if i==len(elements)-1:
                raise Exception
        except:
            Common_object.Custom_Error = "Assert Text page navigation for: '" + str(data)+f"' , Text in application '{text_in_app}' "
            raise Exception(Common_object.Custom_Error)



def for_assert_text(page_object, selector, data):
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    set_focus_to_element(page_object,selector)
    # text_in_app = page_object.locator(selector).scroll_into_view_if_needed(timeout=3000)
    text_in_app = page_object.locator(selector).inner_text(timeout=3000)
    try:
        if "Round-off" in Common_step.BASE_ACTION:
            try:
                text_box_data = page_object.locator(selector).input_value()
            except Exception as error:
                text_box_data = page_object.locator(selector).inner_text(timeout=3000)
            try:
                new_data = round(float(data))
                original_text_box_data = text_box_data
                text_box_data = text_box_data.replace(",", "")
                new_text_box_data = round(float(text_box_data))
            except:
                if " " in data:
                    split_data = (data.strip()).split(" ")
                    if len(split_data) == 2:
                        new_data = " ".join([str(round(float(split_data[0]))),split_data[1]])
                        split_text_box_data = text_box_data.split(" ")
                        new_text_box_data = " ".join([str(round(float(split_text_box_data[0]))),split_text_box_data[1]])
                        Variable_not_resettable.logger.info(f"new_data : {new_data}")
                        Variable_not_resettable.logger.info(f"new_text_box_data : {new_text_box_data}")
                else:
                    Variable_not_resettable.logger.info(f"Please check the data value : {str(data)}")
                    raise Exception(Common_object.Custom_Error)
            if new_data == new_text_box_data:
                Variable_not_resettable.logger.info("Assert Label Text Round-off Success for: '" + str(data) +f"', Text in application '{original_text_box_data}' ")
            elif str(new_data) == str(new_text_box_data):
                Variable_not_resettable.logger.info("Assert Label Text Round-off Success for: '" + str(data) +f"', Text in application '{original_text_box_data}' ")
            else:
                Common_object.Custom_Error = "Assert Label Text Round-off Failed for: '" + str(data)+f"' , Text in application '{original_text_box_data}' "
                raise Exception(Common_object.Custom_Error)
        else:
            # expect(page_object.locator(selector)).to_have_text(str(data))
            # Variable_not_resettable.logger.info("Asserting Text for : '" + str(data)+ "' is SUCCESS")

            try:
                expect(page_object.locator(selector)).to_have_text(str(data))
                Variable_not_resettable.logger.info("Asserting Text for : '" + str(data)+ "' is SUCCESS")
            except:
                text_in_app = page_object.locator(selector).inner_text(timeout=3000)
                if str(text_in_app) == str(data):
                    Variable_not_resettable.logger.info("Asserting Text for : '" + str(data)+ "' is SUCCESS")
                else:
                    Common_object.Custom_Error = "Assert Label Text Round-off Failed for: '" + str(data)+f"' , Text in application '{text_in_app}' "
                    raise Exception(Common_object.Custom_Error)


    except Exception as error:
        text_in_app = page_object.locator(selector).inner_text(timeout=3000)
        if text_in_app in ["", " ", "  ", "   " , "   "]:
            text_in_app == "empty"
        Common_object.Custom_Error = "Asserting Text for : '" + str(data)+ "' is failed because text in application : '"+ str(text_in_app)+"'"
        Variable_not_resettable.logger.error(str(Common_object.Custom_Error))
        raise Exception(Common_object.Custom_Error)

def assert_locator(page_object, selector):
    try:
        page_object.wait_for_selector(selector,timeout = 100)
        set_focus_to_element(page_object,selector)
        return True
    except:
        return False


def for_assert_object(page_object, selector):
    # print(expect(page_object.locator(selector)))
    # print("[INFO] : Object is Present")
    set_focus_to_element(page_object,selector)
    Common_object.Custom_Error = "Object is Present"
 

def for_assert_visible(page_object, selector):
    # expect(page_object.locator(selector)).to_be_visible()
    # print("[INFO] : Object is Present")
    # Common_object.Custom_Error = "Object is Visible"

    locator = page_object.locator(selector)
    flag = locator.is_visible()
    if flag == True:
        set_focus_to_element(page_object,selector)
        Variable_not_resettable.logger.info("Assertion success, Element is Visible")
    elif flag == False:
        raise Exception("Assertion Failed. Element is Non-Visible, but expecting Visible")
        


def for_assert_non_visible(page_object, selector):
    # expect(page_object.locator(selector)).not_to_be_visible()
    # print("[INFO] : Object is not visible")
    # Common_object.Custom_Error = "Object is not visible"

    locator = page_object.locator(selector)
    flag = locator.is_visible()
    if flag == True:
        raise Exception("Assertion Failed. Element is Visible, but expecting Non-Visible")
    elif flag == False:
        # set_focus_to_element(page_object,selector)
        Variable_not_resettable.logger.info("Assertion success, Element is Non-Visible")


def for_assert_non_editable(page_object, selector):
    # expect(page_object.locator(selector)).not_to_be_editable()

    locator = page_object.locator(selector)
    flag = locator.is_disabled()
    if flag == False:
        raise Exception("Assertion Failed. Element is editable, but expecting non editable")
    elif flag == True:
        set_focus_to_element(page_object,selector)
        Variable_not_resettable.logger.info("Assertion success, Element is Non-editable")

def scroll_to_element(page_object, selector):
    loc = page_object.locator(selector).first
    loc.scroll_into_view_if_needed(timeout= Common_object.Timeout)


def for_attach(page_object, selector, data_input):
    if Variable_not_resettable.APP_TYPE == "Studio":
        path = "Downloads\\"
        
        # Check if data_input is valid
        if data_input and str(data_input).lower() not in ['nan', '']:
            data = str(data_input).replace('"', '').replace("'", "")
            file_path = os.path.join(path, data)
        else:
            # Get the most recently downloaded file from the path
            files = [os.path.join(path, f) for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]
            if not files:
                raise FileNotFoundError("No files found in the directory for attaching.")
            file_path = max(files, key=os.path.getctime)  # Get the most recently created/modified file
        
        with page_object.expect_file_chooser() as fc_info:
            page_object.locator(selector).click()
        file_chooser = fc_info.value
        file_chooser.set_files(file_path)

    else:
        data = str(data_input).replace('"', '').replace("'", "")
        path = "Files\\Input_Documents\\"
        file_path = os.path.join(path, data)
        with page_object.expect_file_chooser() as fc_info:
            page_object.locator(selector).click()
        file_chooser = fc_info.value
        file_chooser.set_files(file_path)


def for_grid_attach(page_object, selector, data):
    path = "Files\\Input_Documents\\"
    file_path = path + str(data)
    with page_object.expect_file_chooser() as fc_info:
        page_object.locator(selector).click()
    file_chooser = fc_info.value
    file_chooser.set_files(file_path)

def for_hover(page_object, selector):
    page_object.hover(selector)


# def for_get_input_value(page_object, selector):
#     try:
#         time.sleep(0.5)
#         loc = page_object.locator(selector).first
#         loc.scroll_into_view_if_needed()
#         data = page_object.input_value(selector, timeout= Common_object.Timeout)
#         # element_handler = page_object.query_selector(selector)
#         # data = element_handler.inner_text()
#         # print("from playwright :",data)
#         return data
#     except Exception as error:
#         # print("Exception for_get_input_value : ", error)
#         loc = page_object.locator(selector).first
#         loc.scroll_into_view_if_needed()
#         element_handler = page_object.query_selector(selector)
#         data = element_handler.inner_text()
#         # print("from playwright :",data)
#         return data

def for_get_input_value(page_object, selector):
    try:
        time.sleep(0.5)
        loc = page_object.locator(selector).first
        loc.scroll_into_view_if_needed()
        data = page_object.input_value(selector, timeout= Common_object.Timeout)
        # element_handler = page_object.query_selector(selector)
        # data = element_handler.inner_text()
        # print("from playwright :",data)
        return data
    except Exception as error:
        # print("Exception for_get_input_value : ", error)
        loc = page_object.locator(selector).first
        loc.scroll_into_view_if_needed()
        element_handler = page_object.query_selector(selector)
        data = element_handler.inner_text()
        # print("from playwright :",data)
        return data


# def for_get_input_value(page_object, selector):
#     try:
#         time.sleep(0.5)
#         loc = page_object.locator(selector).first
#         loc.scroll_into_view_if_needed()
#         data = page_object.input_value(selector, timeout=Common_object.Timeout)
#         # Check if data is empty
#         if not data or str(data).strip() == "" or str(data).lower() == "nan" or data is None:
#             print("Screen value is empty")
#             time.sleep(0.5)
#             loc = page_object.locator(selector).first
#             loc.scroll_into_view_if_needed()
#             data = page_object.input_value(selector, timeout=Common_object.Timeout)
#         return data
#     except Exception as error:
#         # Handle exceptions
#         print("Exception:", error)
#         loc = page_object.locator(selector).first
#         loc.scroll_into_view_if_needed()
#         element_handler = page_object.query_selector(selector)
#         data = element_handler.inner_text()
#         # Check if data is empty
#         if not data or str(data).strip() == "" or str(data).lower() == "nan" or data is None:
#             print("Screen value is empty")
#             time.sleep(0.5)
#             loc = page_object.locator(selector).first
#             loc.scroll_into_view_if_needed()
#             data = page_object.input_value(selector, timeout=Common_object.Timeout)
#         return data
    

def for_get_text(page_object, selector):
    location = page_object.query_selector(selector)
    data = location.inner_text()
    # print("from playwright :",data)
    return data

def for_get_text_content(page_object, selector):
    locator = page_object.query_selector(selector)
    data = locator.all_inner_contents()
    return data

# def for_error_snapshot(page_object):
#         # print("[INFO] : Taking snapshot...")
#         file_name = Common_object.scenarios_meta["SCENARIO_ID"] +"_"+ str(datetime.now()).replace(":","_")
#         file_name = file_name.replace("-","_")
#         page_object.screenshot(path= Common_path.error_snapshot_path +"\\"+file_name+".png")
#         return str(Common_path.error_snapshot_path +"\\"+file_name+".png")

def for_error_snapshot(page_object):
        # print("[INFO] : Taking snapshot...")
        timestampcom = str(datetime.now()).replace(":", "_")
        currentDate = date.today()
        customname = currentDate.strftime('%Y/%m/%d')
        if Common_object.test_config_dictionary["ParallelExecution"] == "ON":
            file_name = Common_object.scenarios_meta["SCENARIO_ID"] +"_"+ timestampcom +"_"+ str(Parallel_common_object.process_id)
            Common_step.ERROR_SNAPSHOT_FILENAME = customname +"/"+file_name+ ".png"
            error_snapshot_file_path = Common_main_object.advance_debug_log_folder + "\\" + file_name + ".png"
            page_object.screenshot(path=error_snapshot_file_path)
            paths = file_name + ".png"
            scenario = Common_object.scenarios_meta["SCENARIO_ID"] + "_Error"
            hyper = '=HYPERLINK("%s", "%s")' % (paths, scenario)
            image_file = Image.open(error_snapshot_file_path)
            rgb_im = image_file.convert('RGB')
            error_snapshot_file_path1= Common_main_object.advance_debug_log_folder + "\\" + file_name + "_Compressed.jpg"
            rgb_im.save(error_snapshot_file_path1, quality=10)
            with open(error_snapshot_file_path1, "rb") as imagetostring:
                converted_string = base64.b64encode(imagetostring.read())
                Common_object.ImageToString = converted_string.decode('utf-8')
        else:
            file_name = Common_object.scenarios_meta["SCENARIO_ID"] +"_"+ timestampcom
            Common_step.ERROR_SNAPSHOT_FILENAME = customname +"/"+ file_name + ".png"
            error_snapshot_file_path = Common_main_object.advance_debug_log_folder + "\\" + file_name + ".png"
            page_object.screenshot(path=error_snapshot_file_path)
            paths = file_name + ".png"
            scenario=Common_object.scenarios_meta["SCENARIO_ID"]+"_Error"
            hyper='=HYPERLINK("%s", "%s")' % (paths,scenario)
            #hyper='=HYPERLINK("{}","{}")'.format(paths,scenario)
            image_file = Image.open(error_snapshot_file_path)
            rgb_im = image_file.convert('RGB')
            error_snapshot_file_path1 = Common_main_object.advance_debug_log_folder + "\\" + file_name+"_Compressed.jpg"
            rgb_im.save(error_snapshot_file_path1, quality=10)
            with open(error_snapshot_file_path1, "rb") as imagetostring:
                converted_string = base64.b64encode(imagetostring.read())
                Common_object.ImageToString = converted_string.decode('utf-8')
            #hyper = "=HYPERLINK("+Common_path.base_path+"\\"+error_snapshot_file_path+",Click for report")
            #hyper='=HYPERLINK("%s",%s")' %(Common_path.base_path+"\\"+error_snapshot_file_path,"Click for report")
            #Common_main_object.test_result_log_info_dict.update({'ERROR SNAPSHOT':hyper})
        return hyper


# def for_error_snapshot(page_object):
#         # print("[INFO] : Taking snapshot...")
#         file_name = Common_object.scenarios_meta["SCENARIO_ID"] +"_"+ str(datetime.now()).replace(":","_")
#         file_name = file_name.replace("-","_")
#         if Common_object.test_config_dictionary["ParallelExecution"] == "ON":
#             file_name = file_name + "_" + Parallel_common_object.process_id
#             error_snapshot_file_path = Common_main_object.advance_debug_log_folder + "\\Snapshot\\Error_snapshot\\" + file_name + ".png"
#             page_object.screenshot(path=error_snapshot_file_path)
#         else:
#             error_snapshot_file_path = Common_main_object.advance_debug_log_folder + "\\Snapshot\\Error_snapshot\\" + file_name + ".png"
#             page_object.screenshot(path=error_snapshot_file_path)
#         return str(error_snapshot_file_path)

def for_success_snapshot(page_object):
        Variable_not_resettable.logger.info("Taking snapshot...")
        file_name = Common_object.scenarios_meta["SCENARIO_ID"] +"_"+ str(datetime.now()).replace(":","_")
        file_name = file_name.replace("-","_")
        if Common_object.test_config_dictionary["ParallelExecution"] == "ON":
            file_name = file_name + "_" + str(Parallel_common_object.process_id)
            error_snapshot_file_path= Common_main_object.advance_debug_log_folder +"\\"+file_name+".png"
            page_object.screenshot(path= error_snapshot_file_path)
        else:
            error_snapshot_file_path = Common_main_object.advance_debug_log_folder + "\\" + file_name + ".png"
            page_object.screenshot(path=error_snapshot_file_path)
        return str(error_snapshot_file_path)

def check_is_popup(page_object, Timeout_pop_up):
    try:
        popup_xpath = "//div[@name='undefined_messagebox' and @aria-hidden='false']"
        page_object.wait_for_selector(popup_xpath, timeout= Timeout_pop_up)
        # print(True)
        Variable_not_resettable.logger.info(str(True))
        return True
    except:
        # print(False)
        Variable_not_resettable.logger.info(str(False))
        return False

def check_is_zoom_popup(page_object, Timeout_pop_up):
    try:
        popup_xpath = "//*[@name='undefined_uigridzoom' and @aria-hidden='false']"
        page_object.wait_for_selector(popup_xpath, timeout= Timeout_pop_up)
        # print(True)
        Variable_not_resettable.logger.info(str(True))
        return True
    except:
        # print(False)
        Variable_not_resettable.logger.info(str(False))
        return False

def assertion_for_error_popup(popup_query):
    Variable_not_resettable.logger.debug(f"error assert pop up inside  ***********************************")
    excel_input = str(Common_object.Error_Popup).split(";")
    data_value_1 = str(excel_input[0]).strip()
    data_value_2 = str(excel_input[1]).strip() if len(excel_input) > 1 else ""
    popup_text_value = popup_query.inner_text()
    if data_value_1 and str(data_value_1) in str(popup_text_value):
        Variable_not_resettable.logger.info(f"Data_value: {data_value_1}, popup_text_value: {popup_text_value}")
        Variable_not_resettable.logger.info("Assertion passed")
    else:
        Variable_not_resettable.logger.info(f"Assertion Failed")
        Variable_not_resettable.logger.debug(f"error assert pop up return false  ***********************************")
        return False
    if data_value_2 != "":
        if str(data_value_2) in str(popup_text_value):
            pass
        else:
            Variable_not_resettable.logger.info(f"Assertion Failed")
            Variable_not_resettable.logger.debug(f"error assert pop up return false  ***********************************")
            return False
    Variable_not_resettable.logger.debug(f"error assert pop up completed  ***********************************")
    return True


def popuphandler_for_studio(page_object):
    
    
    Variable_not_resettable.logger.info("Entered in to the Studio popup")
    studio_success_popup_element = "//div[contains(@class, 'Toastify__toast--success')]"
    studio_error_popup_element = "//div[contains(@class, 'Toastify__toast--error')]"
    studio_error_popup_close_icon="//*[contains(@class,'Toastify__close-button')]"
    
    if "Assert Error Popup" in Common_step.BASE_ACTION and (Common_step.is_assert_error_popup_completed == False):           
        Variable_not_resettable.logger.debug("********************Inside Assert Error Popup*********************")
        if "||" not in Common_data.data_value:
            Common_object.Error_Popup = Common_data.data_value
        
        if page_object.query_selector(studio_error_popup_element):
            try:
                page_object.wait_for_selector(studio_error_popup_element, timeout= Common_object.Timeout_pop_up)
                popup_query = page_object.query_selector(studio_error_popup_element)
                # Common_step.is_assert_error_popup_completed = True
                if assertion_for_error_popup(popup_query):
                    Variable_not_resettable.logger.info(f"Assertion passed")
                    for_success_snapshot(page_object)
                    page_object.click(studio_error_popup_close_icon)
                    Common_step.is_assert_error_popup_completed = True
                    Variable_not_resettable.logger.info("close icon clicked...********************************")
                    Variable_not_resettable.logger.debug("close icon clicked...********************************")
                    return True
                else:
                    Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                    Common_step.error_popup_message = Common_object.Custom_Error
                    raise Exception(Common_object.Custom_Error)
            except Exception as error:
                Variable_not_resettable.logger.info((str(error)))
                for_error_snapshot(page_object)
                raise Exception (str("Assertion on popup failed, for given data value."))
            
    elif "Assert Success Popup" in Common_step.BASE_ACTION and (Common_step.is_assert_error_popup_completed == False):           
        Variable_not_resettable.logger.info("Entered in to the Studio Assert Success popup")
        Variable_not_resettable.logger.debug("********************Inside Assert Success Popup*********************")
        if "||" not in Common_data.data_value:
            Common_object.Error_Popup = Common_data.data_value
        
        try:
            page_object.wait_for_selector(studio_success_popup_element, timeout= Common_object.Timeout_pop_up)
            popup_query = page_object.query_selector(studio_success_popup_element)
            # Common_step.is_assert_error_popup_completed = True
            if assertion_for_error_popup(popup_query):
                Variable_not_resettable.logger.info(f"Assertion passed")
                for_success_snapshot(page_object)
                page_object.click(studio_success_popup_element)
                Variable_not_resettable.logger.info("close icon clicked...********************************")
                Variable_not_resettable.logger.debug("close icon clicked...********************************")
                return True
            else:
                Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                Common_step.error_popup_message = Common_object.Custom_Error
                raise Exception(Common_object.Custom_Error)
        except Exception as error:
            Variable_not_resettable.logger.info((str(error)))
            for_error_snapshot(page_object)
            raise Exception (str(error))
    else:
        errorpopupBox = page_object.locator(studio_error_popup_element).count()    
        success_popup_box=page_object.locator(studio_success_popup_element).count()
        try:
            if success_popup_box!=0:
                page_object.wait_for_selector(studio_success_popup_element, timeout= Common_object.Timeout_pop_up)
                studio_success_popup_element_flag = True
                Variable_not_resettable.logger.info("studio success Pop up found")
                Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                page_object.click(studio_error_popup_close_icon)
                return True
            elif errorpopupBox!=0 :
                if "Skip Error" in Common_step.BASE_ACTION :
                    # page_object.click(down_arrow_in_popup)
                    page_object.click(studio_error_popup_close_icon)
                    Variable_not_resettable.logger.info("close icon clicked...")
                    return True
                else:
                    page_object.wait_for_selector(studio_error_popup_element, timeout= Common_object.Timeout_pop_up)
                    studio_error_popup_element_flag = True
                    Variable_not_resettable.logger.info("studio error Pop up found")
                    raise Exception
        except Exception as error:
            Variable_not_resettable.logger.info((str(error)))
            for_error_snapshot(page_object)
            raise Exception (str(error))

                        
            


def wait_and_close_popup(page_object):
    Variable_not_resettable.logger.info(f"Checking Pop-up starting")
    Variable_not_resettable.logger.debug("Checking Pop-up starting *******************************************************")
    
    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
        
        saasy_success_popup_element_flag = False
        saasy_error_popup_element_flag =  False
        coexistence_popup_element_flag = False
        
        error_popup_xpath = "//*[@class='nb-icon nb-error']"
        popup_element = "//*[@id='messagebox']"
        yes_btn = "//*[starts-with(@id,'yes-button')]//*[contains(@id, 'btnInnerEl')]"
        # success_popup_xpath ="//*[@class='nb-icon nb-success']"
        success_popup_xpath ="//*[@class='nb-icon nb-info']"
        # warning_popup_xpath ="//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-warning']"
        # questionmark_popup_xpath = "//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-question']"
        # is_nb_success_popup = "//*[@class='nb_message']//*[@class='nb-strip nb-success']"
        # is_nb_failure_popup = "//*[@class='nb_message']//*[@class='nb-strip nb-error']"
        down_arrow_in_popup = "//*[@class='nb_message']//*[@class='nb-body']//*[@class='nb_showmore']"
        popup_ok = "//*[@class='custom-table']//button[text()='Ok']"
        popup_message_xpath = "//*[@class='nb-detail-desc']"

        #saasy_success
        #saasy_success_popup_element = "//*[@class='Toastify__toast Toastify__toast--success']"
        saasy_success_popup_element = "//*[contains(@class, 'Toastify__toast') and contains(@class, 'Toastify__toast--success')]"
        saasy_success_inner_message = "//*[@id='Toast_Success']"

        #saasy_failure
        saasy_error_popup_element = "//*[@class='r-nb_message r-nb-error pb-0']"
        
        saasy_error_msg_icon = "//*[@id='nbicon_container_id']"
        saasy_error_inner_message = "//*[@class='font-m']"
        saasy_error_popup_close_icon = "//*[@class='icon-wrap icon-m flex-shrink-0 flex-grow-0']"
        nb_close="//*[@class='nb_close']"
        crxd_success_window="//*[contains(@class,'crxd-message-info')]"
        crxd_error_window="//*[contains(@class,'crxd-message-error')]"
        crxd_innertext="//*[@class='crxd-display-title']"
        crxd_close_icon="//*[@class='crxd-error-window-close']"
        
       
        if ("Assert Error Popup" in str(Common_step.BASE_ACTION)) and (Common_step.action_completed_assert_error_popup == True):# and (Common_step.is_assert_error_popup_completed == False):           
            Variable_not_resettable.logger.debug("********************Inside Assert Error Popup*********************")
            Variable_not_resettable.logger.info("********************Inside Assert Error Popup*********************")
            if "||" not in Common_data.data_value:
                Common_object.Error_Popup = Common_data.data_value
            if Common_step.is_assert_error_popup_completed == False:
                timeout = 5  # Timeout duration in seconds
                start_time = time.time()
                while time.time() - start_time < timeout:
                    if page_object.query_selector(error_popup_xpath) or page_object.query_selector(saasy_error_popup_element) or page_object.query_selector(crxd_error_window):
                        Variable_not_resettable.logger.info("Found error popup")
                        break  # If either element is found, break the loop
                    time.sleep(0.5)
                if page_object.query_selector(error_popup_xpath):
                    try:
                        page_object.wait_for_selector(popup_message_xpath, timeout= Common_object.Timeout_pop_up)
                        popup_query = page_object.query_selector(popup_message_xpath)
                        # Common_step.is_assert_error_popup_completed = True
                        if assertion_for_error_popup(popup_query):
                            Common_step.is_assert_error_popup_completed = True
                            Variable_not_resettable.logger.info(f"Assertion passed")
                            for_success_snapshot(page_object)
                            page_object.click(nb_close)
                            Variable_not_resettable.logger.info("close icon clicked...********************************")
                            Variable_not_resettable.logger.debug("close icon clicked...********************************")
                            return True
                        else:
                            Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                            Common_step.error_popup_message = Common_object.Custom_Error
                            raise Exception(Common_object.Custom_Error)
                    except Exception as error:
                        Variable_not_resettable.logger.info((str(error)))
                        for_error_snapshot(page_object)
                        raise Exception (str(error))

                elif page_object.query_selector(saasy_error_popup_element):
                    try:
                        popup_query = page_object.query_selector(saasy_error_popup_element)
                        # Common_step.is_assert_error_popup_completed = True
                        if assertion_for_error_popup(popup_query):
                            Common_step.is_assert_error_popup_completed = True
                            Variable_not_resettable.logger.info(f"Assertion passed")
                            for_success_snapshot(page_object)
                            page_object.click(saasy_error_popup_close_icon)
                            Variable_not_resettable.logger.info("close icon clicked...********************************")
                            Variable_not_resettable.logger.debug("close icon clicked...********************************")
                            return True
                        else:
                            Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                            Common_step.error_popup_message = Common_object.Custom_Error
                            raise Exception(Common_object.Custom_Error)
                    except Exception as error:
                        Variable_not_resettable.logger.info((str(error)))
                        for_error_snapshot(page_object)
                        raise Exception (str(error))
                    
                elif page_object.query_selector(crxd_error_window):
                    try:
                        page_object.wait_for_selector(crxd_innertext, timeout= Common_object.Timeout_pop_up)
                        popup_query = page_object.query_selector(crxd_innertext)
                        # Common_step.is_assert_error_popup_completed = True
                        if assertion_for_error_popup(popup_query):
                            Common_step.is_assert_error_popup_completed = True
                            Variable_not_resettable.logger.info(f"Assertion passed")
                            for_success_snapshot(page_object)
                            page_object.click(crxd_close_icon)
                            Variable_not_resettable.logger.info("close icon clicked...********************************")
                            Variable_not_resettable.logger.debug("close icon clicked...********************************")
                            return True
                        else:
                            Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                            Common_step.error_popup_message = Common_object.Custom_Error
                            raise Exception(Common_object.Custom_Error)
                    except Exception as error:
                        Variable_not_resettable.logger.info((str(error)))
                        for_error_snapshot(page_object)
                        raise Exception (str(error))

                
        elif "Assert Success Popup" in str(Common_step.BASE_ACTION):
            Variable_not_resettable.logger.info(f"********************Inside Assert Success Popup*********************")
            Variable_not_resettable.logger.debug("********************Inside Assert Success Popup*********************")

            if "||" not in Common_data.data_value:
                Common_object.Error_Popup = Common_data.data_value

            if Common_step.is_assert_error_popup_completed == False:
                timeout = 5  # Timeout duration in seconds
                start_time = time.time()
                while time.time() - start_time < timeout:
                    if page_object.query_selector(saasy_success_popup_element) or page_object.query_selector(crxd_success_window) :
                        Variable_not_resettable.logger.info("Found Success popup")
                        break  # If either element is found, break the loop
                    time.sleep(0.5)
                if page_object.query_selector(saasy_success_popup_element):
                    # First check for 'saasy_success_popup_element'
                    try:
                        popup_query = page_object.query_selector(saasy_success_popup_element)
                        if for_assert_success_popup(popup_query):
                            Common_step.is_assert_error_popup_completed = True
                            Variable_not_resettable.logger.info("Assertion passed for saasy_success_popup_element")
                            for_success_snapshot(page_object)
                            page_object.click(saasy_success_popup_element)
                            Variable_not_resettable.logger.info("saasy_success_popup_element close icon clicked...")
                            return True
                        else:
                            Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                            Common_step.error_popup_message = Common_object.Custom_Error
                            raise Exception(Common_object.Custom_Error)
                    except Exception as error:
                        Variable_not_resettable.logger.info((str(error)))
                        for_error_snapshot(page_object)
                        raise Exception (str(error))
                elif page_object.query_selector(crxd_success_window):      
                    # Then check for 'crxd_success_window'
                    try:
                        popup_query = page_object.query_selector(crxd_innertext)
                        if for_assert_success_popup(popup_query):
                            Common_step.is_assert_error_popup_completed = True
                            Variable_not_resettable.logger.info("Assertion passed for crxd_success_window")
                            for_success_snapshot(page_object)
                            page_object.click(crxd_close_icon)
                            Variable_not_resettable.logger.info("crxd_success_window close icon clicked...")
                            return True
                        else:
                            Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                            Common_step.error_popup_message = Common_object.Custom_Error
                            raise Exception(Common_object.Custom_Error)
                    except Exception as error:
                        Variable_not_resettable.logger.info((str(error)))
                        for_error_snapshot(page_object)
                        raise Exception (str(error))
                 
                
        
            
        try:
            page_object.wait_for_selector(crxd_success_window, timeout= Common_object.Timeout_pop_up)
            Variable_not_resettable.logger.info("crxd success Pop up found **********************************************************************************")
            if "Assert Popup" in str(Common_step.BASE_ACTION) :
                Variable_not_resettable.logger.info("------------------- Assert Popup ----------------")
                popup_query = page_object.query_selector(crxd_innertext)
                if for_assert_success_popup(popup_query):
                    Variable_not_resettable.logger.info("Assertion for success pop passed...")
                    Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                    page_object.click(crxd_close_icon)
                    Variable_not_resettable.logger.info("Ok clicked...")
                    return True
                else:
                    Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                    Common_step.error_popup_message = Common_object.Custom_Error
                    raise Exception(Common_object.Custom_Error)
            Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
            page_object.click(crxd_close_icon)
            return True   
        
        except Exception as error:
            if "Assertion on popup failed, for given data value." in str(error):
                raise Exception("Assertion on popup failed, for given data value.")
            try:
                page_object.wait_for_selector(crxd_error_window, timeout= Common_object.Timeout_pop_up)
                saasy_error_popup_element_flag = True
                Variable_not_resettable.logger.info("crxd error Pop up found")
                if "Assert Popup" in str(Common_step.BASE_ACTION) :
                    Variable_not_resettable.logger.info("------------------- Assert Popup ----------------")
                    popup_query = page_object.query_selector(crxd_innertext)
                    if for_assert_fail_popup(popup_query):
                        Common_step.is_assert_error_popup_completed = True
                        Variable_not_resettable.logger.info("Assertion passed for crxd_error_window")
                        for_success_snapshot(page_object)
                        page_object.click(crxd_close_icon)
                        Variable_not_resettable.logger.info("crxd_error_window close icon clicked...")
                        return True
                    else:
                        Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                        Common_step.error_popup_message = Common_object.Custom_Error
                        raise Exception(Common_object.Custom_Error)
                elif "Skip Error" in Common_step.BASE_ACTION :
                    page_object.click(crxd_close_icon)
                    Variable_not_resettable.logger.info("Ok clicked...")
                    return True
                else:
                    Common_object.Custom_Error = "Scenario failed at action : "+Common_step.ACTION +" because of error popup"
                    Variable_not_resettable.logger.info(Common_object.Custom_Error)
                    raise Exception ("Error Popup Exception raised")
            except Exception as error:
                if "Popup Exception" in str(error) or "Assertion on popup failed" in str(error):
                    Variable_not_resettable.logger.debug(f"{str(error)} ***********************************")
                    raise Exception (error)
                else:
                    Variable_not_resettable.logger.debug(f"{str(error)} ***********************************")
          
         

        try:
            try:
                try:
                    page_object.wait_for_selector(saasy_success_popup_element, timeout= Common_object.Timeout_pop_up)
                    saasy_success_popup_element_flag = True
                    Variable_not_resettable.logger.info("saasy success Pop up found **********************************************************************************")
                except:
                    page_object.wait_for_selector(saasy_error_popup_element, timeout= Common_object.Timeout_pop_up)
                    saasy_error_popup_element_flag = True
                    Variable_not_resettable.logger.info("saasy error Pop up found")
            except:
                page_object.wait_for_selector(popup_element, timeout= Common_object.Timeout_pop_up)
                coexistence_popup_element_flag = True
                Variable_not_resettable.logger.info("co exitence Pop up found")
            try:
                try:
                # if saasy_success_popup_element_flag:             
                    page_object.wait_for_selector(saasy_success_popup_element, timeout= Common_object.saasy_Timeout_pop_up)
                    Variable_not_resettable.logger.info("saasy success Popup -----------------------------------")
                    if "Assert Popup" in str(Common_step.BASE_ACTION) :
                        Variable_not_resettable.logger.info("------------------- Assert Popup ----------------")
                        popup_query = page_object.query_selector(saasy_success_popup_element)
                        if for_assert_success_popup(popup_query):
                            Variable_not_resettable.logger.info("Assertion for success pop passed...")
                            Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                            page_object.click(saasy_success_popup_element)
                            Variable_not_resettable.logger.info("Ok clicked...")
                            return True
                        else:
                            Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                            Common_step.error_popup_message = Common_object.Custom_Error
                            raise Exception(Common_object.Custom_Error)
                    Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                    page_object.click(saasy_success_popup_element)
                    return True
                except Exception as error:
                    if "Assertion on popup failed, for given data value." in str(error):
                        raise Exception("Assertion on popup failed, for given data value.")
                # elif coexistence_popup_element_flag:
                    page_object.wait_for_selector(success_popup_xpath, timeout= Common_object.Timeout_pop_up)
                    Variable_not_resettable.logger.info("success Popup")
                    if "Assert Popup" in str(Common_step.BASE_ACTION) :
                        popup_query = page_object.query_selector(popup_message_xpath)
                        if for_assert_success_popup(popup_query):
                            Variable_not_resettable.logger.info("Assertion for success pop passed...")
                            Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                            page_object.click(down_arrow_in_popup)
                            page_object.click(popup_ok)
                            Variable_not_resettable.logger.info("Ok clicked...")
                            return True
                        else:
                            Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                            Common_step.error_popup_message = Common_object.Custom_Error
                            raise Exception(Common_object.Custom_Error)
                    Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                    page_object.click(down_arrow_in_popup)
                    page_object.click(popup_ok)
                    Variable_not_resettable.logger.info("Ok clicked...")
                    return True
            except Exception as error:
                if "Assertion on popup failed, for given data value." in str(error):
                    raise Exception("Assertion on popup failed, for given data value.")
                try:
                    if saasy_error_popup_element_flag:
                        if "Assertion on popup failed" in str(error):
                            raise Exception (error)
                        page_object.wait_for_selector(saasy_error_popup_element, timeout= Common_object.Timeout_pop_up)
                        Variable_not_resettable.logger.info("Error Popup")
                        if "Assert Popup" in str(Common_step.BASE_ACTION) :
                            popup_query = page_object.query_selector(saasy_error_inner_message)
                            if for_assert_fail_popup(popup_query):
                                Variable_not_resettable.logger.info("Assertion for error popup passed...")
                                Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                                if "Skip Error" in Common_step.BASE_ACTION :
                                    # page_object.click(down_arrow_in_popup)
                                    page_object.click(saasy_error_popup_close_icon)
                                    Variable_not_resettable.logger.info("Ok clicked...")
                                    return True
                                else:
                                    # page_object.click(down_arrow_in_popup)
                                    page_object.click(saasy_error_popup_close_icon)
                                    Variable_not_resettable.logger.info("Ok clicked...")
                                    return True
                            else:
                                Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                                Common_step.error_popup_message = Common_object.Custom_Error
                                raise Exception(Common_object.Custom_Error)
                        # popup_message_xpath = "//div[starts-with(@id,'messagebox')]//*[contains(@id, 'msg')]"
                        popup_message_query = page_object.query_selector(saasy_error_inner_message)
                        Common_step.error_popup_message = "Application Error Message : "+str(popup_message_query.inner_text())
                        
                        if "Skip Error" in Common_step.BASE_ACTION :
                            # page_object.click(down_arrow_in_popup)
                            page_object.click(saasy_error_popup_close_icon)
                            Variable_not_resettable.logger.info("Ok clicked...")
                            return True
                        Common_object.Custom_Error = "Scenario failed at action : "+Common_step.ACTION +" because of error popup"
                        Variable_not_resettable.logger.info(Common_object.Custom_Error)
                        raise Exception ("Error Popup Exception raised")
                    
                    elif coexistence_popup_element_flag:
                        if "Assertion on popup failed" in str(error):
                            raise Exception (error)
                        page_object.wait_for_selector(error_popup_xpath, timeout= Common_object.Timeout_pop_up)
                        Variable_not_resettable.logger.info("Error Popup")
                        if "Assert Popup" in str(Common_step.BASE_ACTION) :
                            popup_query = page_object.query_selector(popup_message_xpath)
                            if for_assert_fail_popup(popup_query):
                                Variable_not_resettable.logger.info("Assertion for error popup passed...")
                                Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                                if "Skip Error" in Common_step.BASE_ACTION :
                                    page_object.click(down_arrow_in_popup)
                                    page_object.click(popup_ok)
                                    Variable_not_resettable.logger.info("Ok clicked...")
                                    return True
                                else:
                                    page_object.click(down_arrow_in_popup)
                                    page_object.click(popup_ok)
                                    Variable_not_resettable.logger.info("Ok clicked...")
                                    return True
                            else:
                                Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                                Common_step.error_popup_message = Common_object.Custom_Error
                                raise Exception(Common_object.Custom_Error)
                        # popup_message_xpath = "//div[starts-with(@id,'messagebox')]//*[contains(@id, 'msg')]"
                        popup_message_query = page_object.query_selector(popup_message_xpath)
                        Common_step.error_popup_message = "Application Error Message : "+str(popup_message_query.inner_text())
                        
                        if "Skip Error" in Common_step.BASE_ACTION :
                            page_object.click(down_arrow_in_popup)
                            page_object.click(popup_ok)
                            Variable_not_resettable.logger.info("Ok clicked...")
                            return True
                        Common_object.Custom_Error = "Scenario failed at action : "+Common_step.ACTION +" because of error popup"
                        Variable_not_resettable.logger.info(Common_object.Custom_Error)
                        raise Exception ("Error Popup Exception raised")
                except Exception as error:
                    raise Exception (str(error))
        except Exception as error:
            if "Popup Exception" in str(error) or "Assertion on popup failed" in str(error):
                raise Exception (error)
            elif "Assertion on popup failed, for given data value." in str(error):
                raise Exception("Assertion on popup failed, for given data value.")
            else:
                pass

    elif str(Variable_not_resettable.APP_TYPE).lower() == "epubs":
        Variable_not_resettable.logger.info("Entered into the Epubs popup")
        epubs_success = "//*[@id='successPopup']"
        epubs_success_innertext = "//*[@id='lblSuccess']"
        epubs_success_ok_button = "//*[@id='btnSucOk']"

        epubs_error = "//*[@id='errorPopUp']"
        epubs_error_innertext = "//*[@id='lblError']"
        epubs_error_ok_button = "//*[@id='btnErrOk']"

        if "Assert Error Popup" in str(Common_step.BASE_ACTION) and not Common_step.is_assert_error_popup_completed:
            Variable_not_resettable.logger.debug("********************Inside Assert Error Popup*********************")
            if "||" not in Common_data.data_value:
                Common_object.Error_Popup = Common_data.data_value

            if page_object.locator(epubs_error).is_visible():
                try:
                    page_object.wait_for_selector(epubs_error_innertext, timeout=Common_object.Timeout)
                    popup_query = page_object.query_selector(epubs_error_innertext)
                    if assertion_for_error_popup(popup_query):
                        Variable_not_resettable.logger.info("Assertion passed")
                        for_success_snapshot(page_object)
                        page_object.click(epubs_error_ok_button)
                        Common_step.is_assert_error_popup_completed = True
                        Variable_not_resettable.logger.info("Close icon clicked")
                        return True
                    else:
                        Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                        Common_step.error_popup_message = Common_object.Custom_Error
                        raise Exception(Common_object.Custom_Error)
                except Exception as error:
                    Variable_not_resettable.logger.info(str(error))
                    for_error_snapshot(page_object)
                    raise Exception("Assertion on popup failed, for given data value.")
        
        elif "Assert Success Popup" in str(Common_step.BASE_ACTION) and not Common_step.is_assert_error_popup_completed:
            #time.sleep(3)
            Variable_not_resettable.logger.info("Entered into the Epubs Assert Success popup")
            Variable_not_resettable.logger.debug("********************Inside Assert Success Popup*********************")
            if "||" not in Common_data.data_value:
                Common_object.Error_Popup = Common_data.data_value

            try:
                if page_object.locator(epubs_success).is_visible():
                    page_object.wait_for_selector(epubs_success_innertext, timeout=Common_object.Timeout_pop_up)
                    popup_query = page_object.query_selector(epubs_success_innertext)
                    if assertion_for_error_popup(popup_query):
                        Variable_not_resettable.logger.info("Assertion passed")
                        for_success_snapshot(page_object)
                        page_object.click(epubs_success_ok_button)
                        Variable_not_resettable.logger.info("Close icon clicked")
                        return True
                    else:
                        Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                        Common_step.error_popup_message = Common_object.Custom_Error
                        raise Exception(Common_object.Custom_Error)
            except Exception as error:
                Variable_not_resettable.logger.info(str(error))
                for_error_snapshot(page_object)
                raise Exception(str(error))

        else:
            try:
                if page_object.locator(epubs_success).is_visible():
                    page_object.wait_for_selector(epubs_success_innertext, timeout=Common_object.Timeout_pop_up)
                    Variable_not_resettable.logger.info("Epubs success popup found")
                    Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                    page_object.click(epubs_success_ok_button)
                    return True
                elif page_object.locator(epubs_error).is_visible():
                    if "Skip Error" in Common_step.BASE_ACTION:
                        page_object.click(epubs_error_ok_button)
                        Variable_not_resettable.logger.info("Close icon clicked")
                        return True
                    else:
                        page_object.wait_for_selector(epubs_error, timeout=Common_object.Timeout_pop_up)
                        Variable_not_resettable.logger.info("Epubs error popup found")
                        raise Exception
            except Exception as error:
                Variable_not_resettable.logger.info(str(error))
                for_error_snapshot(page_object)
                raise Exception(str(error))

            
    elif Variable_not_resettable.APP_TYPE == "Rapids":
        if "Assert Popup" in str(Common_step.BASE_ACTION) or "Skip Error" in str(Common_step.BASE_ACTION) or "Assert Error Popup" in str(Common_step.BASE_ACTION):
            Variable_not_resettable.logger.debug((str("Delay 1 sec...")))
            time.sleep(1)
        success_popup_element = "//*[@class='alert alert-dismissible alert-success ']"
        error_popup_element = "//*[@class='alert alert-dismissible alert-danger ']"
        popup_close_icon = "//*[@class='btn-close']"
        Variable_not_resettable.logger.debug(f"coming inside the pop up checking ***********************************")
        is_popup_found = False
        Common_step.popup_loop_count = Common_step.popup_loop_count + 1
        try:

            try:
                page_object.wait_for_selector(success_popup_element, timeout= Common_object.Timeout_pop_up)
                is_popup_found = True
                # Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                Variable_not_resettable.logger.info("Rapids success Pop up found")
            except:
                page_object.wait_for_selector(error_popup_element, timeout= Common_object.Timeout_pop_up)
                is_popup_found = True
                # Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                Variable_not_resettable.logger.info("Rapids error Pop up found")

            try:
                page_object.wait_for_selector(success_popup_element, timeout= Common_object.Timeout_pop_up)
                is_popup_found = False
                Variable_not_resettable.logger.debug(f"success Popup found  ***********************************")
                Variable_not_resettable.logger.info("success Popup")
                if "Assert Popup" in str(Common_step.BASE_ACTION) :
                    popup_query = page_object.query_selector(success_popup_element)
                    if for_assert_success_popup(popup_query):
                        return True
                    else:
                        Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                        Common_step.error_popup_message = Common_object.Custom_Error
                        raise Exception(Common_object.Custom_Error)
                Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)

                if test_properties.get("element_highlighter") == "True":
                        element_bg_color = get_element_bg_color(page_object, popup_close_icon)
                        highlight_element(page_object, popup_close_icon, get_element_highlighter_color(test_properties))
                        action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                page_object.click(popup_close_icon)
                if test_properties.get("element_highlighter") == "True":  
                        replace_highlight_element(page_object, popup_close_icon, element_bg_color)


                Variable_not_resettable.logger.debug("popup closed ...********************************")
                Variable_not_resettable.logger.info("popup closed...")
                return True
            except Exception as error:
                Variable_not_resettable.logger.error(str(error))
                try:
                    if "Assertion on popup failed" in str(error):
                        raise Exception (error)
                    page_object.wait_for_selector(error_popup_element, timeout= Common_object.Timeout_pop_up)
                    is_popup_found = False
                    # for_error_snapshot(page_object)
                    Variable_not_resettable.logger.debug(f"Error Popup found  ***********************************")
                    Variable_not_resettable.logger.info("Error Popup")
                    if "Assert Popup" in str(Common_step.BASE_ACTION) :
                        popup_query = page_object.query_selector(error_popup_element)
                        if for_assert_fail_popup(popup_query):
                            Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                            if "Skip Error" in Common_step.BASE_ACTION :
                                Variable_not_resettable.logger.debug(f"Popup skipped  ***********************************")

                                if test_properties.get("element_highlighter") == "True":
                                    element_bg_color = get_element_bg_color(page_object, popup_close_icon)
                                    highlight_element(page_object, popup_close_icon, get_element_highlighter_color(test_properties))
                                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                                page_object.click(popup_close_icon)
                                if test_properties.get("element_highlighter") == "True":
                                    replace_highlight_element(page_object, popup_close_icon, element_bg_color)

                                Variable_not_resettable.logger.debug("Ok clicked...********************************")
                                return True
                            else:

                                if test_properties.get("element_highlighter") == "True":
                                    element_bg_color = get_element_bg_color(page_object, popup_close_icon)
                                    highlight_element(page_object, popup_close_icon, get_element_highlighter_color(test_properties))
                                    action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                                page_object.click(popup_close_icon)
                                if test_properties.get("element_highlighter") == "True":
                                    replace_highlight_element(page_object, popup_close_icon, element_bg_color)

                                Variable_not_resettable.logger.debug("popup closed...********************************")
                                return True
                        else:
                            Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                            Common_scenario.error_snapshot_file_name = for_error_snapshot(page_object)
                            Common_step.error_popup_message = Common_object.Custom_Error
                            raise Exception(Common_object.Custom_Error)
                    # popup_message_xpath = "//div[starts-with(@id,'messagebox')]//*[contains(@id, 'msg')]"
                    popup_message_query = page_object.query_selector(error_popup_element)
                    Common_step.error_popup_message = "Application Error Message : "+str(popup_message_query.inner_text())
                    
                    if "Skip Error" in Common_step.BASE_ACTION :
                        Variable_not_resettable.logger.debug(f"Popup skipped  ***********************************")

                        if test_properties.get("element_highlighter") == "True":
                            element_bg_color = get_element_bg_color(page_object, popup_close_icon)
                            highlight_element(page_object, popup_close_icon, get_element_highlighter_color(test_properties))
                            action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                        page_object.click(popup_close_icon)
                        if test_properties.get("element_highlighter") == "True":
                            replace_highlight_element(page_object, popup_close_icon, element_bg_color)

                        Variable_not_resettable.logger.debug("popup closed...********************************")
                        return True
                    Common_object.Custom_Error = "Scenario failed at action : "+Common_step.ACTION +" because of error popup"
                    Variable_not_resettable.logger.info(Common_object.Custom_Error)
                    raise Exception ("Error Popup Exception raised")
                except Exception as error:
                    Variable_not_resettable.logger.debug(f"{str(error)} ***********************************")
                    raise Exception (str(error))
        except Exception as error:
            if "Popup Exception" in str(error) or "Assertion on popup failed" in str(error):
                Variable_not_resettable.logger.debug(f"{str(error)} ***********************************")
                raise Exception (error)
            else:
                Variable_not_resettable.logger.debug(f"{str(error)} ***********************************")
        if is_popup_found == True and Common_step.popup_loop_count == 1:
            wait_and_close_popup(page_object)
            Variable_not_resettable.logger.debug(f"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Again checking Popup $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
    elif Variable_not_resettable.APP_TYPE == "Studio":
        Variable_not_resettable.logger.info("Popup handled")
    
   
    else:
        if "Assert Popup" in str(Common_step.BASE_ACTION) or "Skip Error" in str(Common_step.BASE_ACTION) or "Assert Error Popup" in str(Common_step.BASE_ACTION):
            Variable_not_resettable.logger.debug((str("Delay 1 secs...")))
            time.sleep(1)
        popup_element = "//div[@name='undefined_messagebox' and @aria-hidden='false']"
        popup_ok = "//*[starts-with(@id,'ok-button')]//*[contains(@id, 'btnInnerEl')]"
        yes_btn = "//*[starts-with(@id,'yes-button')]//*[contains(@id, 'btnInnerEl')]"
        success_popup_xpath ="//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-info']"
        info_popup_xpath = "x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-info"
        error_popup_xpath ="//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-error']"
        warning_popup_xpath ="//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-warning']"
        questionmark_popup_xpath = "//div[@class='x-component x-message-box-icon x-box-item x-ltr x-component-default x-dlg-icon x-message-box-question']"
        Variable_not_resettable.logger.debug(f"coming inside the pop up checking ***********************************")
        is_popup_found = False
        Common_step.popup_loop_count = Common_step.popup_loop_count + 1
        # print(Common_step.action_completed_assert_error_popup)
        if ("Assert Error Popup" in Common_step.BASE_ACTION) and (Common_step.action_completed_assert_error_popup == True):# and (Common_step.is_assert_error_popup_completed == False):           
            Variable_not_resettable.logger.debug("********************Inside Assert Error Popup*********************")
            if "||" not in Common_data.data_value:
                Common_object.Error_Popup = Common_data.data_value
            if Common_step.is_assert_error_popup_completed == False:
                try:
                    page_object.wait_for_selector(popup_element, timeout= Common_object.Timeout_pop_up)
                    popup_query = page_object.query_selector(popup_element)
                    # Common_step.is_assert_error_popup_completed = True
                    if assertion_for_error_popup(popup_query):
                        Common_step.is_assert_error_popup_completed = True
                        Variable_not_resettable.logger.info(f"Assertion passed")
                        for_success_snapshot(page_object)

                        if test_properties.get("element_highlighter") == "True":
                            element_bg_color = get_element_bg_color(page_object, popup_ok)
                            highlight_element(page_object, popup_ok, get_element_highlighter_color(test_properties))
                            action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                        page_object.click(popup_ok)
                        if test_properties.get("element_highlighter") == "True":
                            replace_highlight_element(page_object, popup_ok, element_bg_color)

                        Variable_not_resettable.logger.debug("Ok clicked...********************************")
                        return True
                    else:
                        Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                        Common_step.error_popup_message = Common_object.Custom_Error
                        raise Exception(Common_object.Custom_Error)
                except Exception as error:
                    Variable_not_resettable.logger.info((str(error)))
                    for_error_snapshot(page_object)
                    raise Exception (str(error))
        try:
            page_object.wait_for_selector(popup_element, timeout= Common_object.Timeout_pop_up)
            is_popup_found = True
            Variable_not_resettable.logger.debug(f"pop up found  ***********************************")
            Variable_not_resettable.logger.info("Pop up found")
            if "On Availability" in Common_step.BASE_ACTION :
                try:

                    if test_properties.get("element_highlighter") == "True":
                            element_bg_color = get_element_bg_color(page_object, yes_btn)
                            highlight_element(page_object, yes_btn, get_element_highlighter_color(test_properties))
                            action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                    page_object.click(yes_btn)
                    if test_properties.get("element_highlighter") == "True":
                            replace_highlight_element(page_object, yes_btn, element_bg_color)

                except:
                    pass
            else:
                try:
                    page_object.wait_for_selector(success_popup_xpath, timeout= Common_object.Timeout_pop_up)
                    is_popup_found = False
                    Variable_not_resettable.logger.debug(f"success Popup found  ***********************************")
                    Variable_not_resettable.logger.info("success Popup")
                    if "Assert Popup" in str(Common_step.BASE_ACTION) :
                        popup_query = page_object.query_selector(popup_element)
                        if for_assert_success_popup(popup_query):
                            return True
                        else:
                            Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                            Common_step.error_popup_message = Common_object.Custom_Error
                            raise Exception(Common_object.Custom_Error)
                    Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)

                    if test_properties.get("element_highlighter") == "True":
                            element_bg_color = get_element_bg_color(page_object, popup_ok)
                            highlight_element(page_object, popup_ok, get_element_highlighter_color(test_properties))
                            action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                    page_object.click(popup_ok)
                    if test_properties.get("element_highlighter") == "True":  
                            replace_highlight_element(page_object, popup_ok, element_bg_color)


                    Variable_not_resettable.logger.debug("Ok clicked...********************************")
                    Variable_not_resettable.logger.info("Ok clicked...")
                    return True
                except Exception as error:
                    Variable_not_resettable.logger.error(str(error))
                    try:
                        if "Assertion on popup failed" in str(error):
                            raise Exception (error)
                        page_object.wait_for_selector(error_popup_xpath, timeout= Common_object.Timeout_pop_up)
                        is_popup_found = False
                        Variable_not_resettable.logger.debug(f"Error Popup found  ***********************************")
                        Variable_not_resettable.logger.info("Error Popup")
                        if "Assert Popup" in str(Common_step.BASE_ACTION) :
                            popup_query = page_object.query_selector(popup_element)
                            if for_assert_fail_popup(popup_query):
                                Common_scenario.success_snapshot_file_name = for_success_snapshot(page_object)
                                if "Skip Error" in Common_step.BASE_ACTION :
                                    Variable_not_resettable.logger.debug(f"Popup skipped  ***********************************")

                                    if test_properties.get("element_highlighter") == "True":
                                        element_bg_color = get_element_bg_color(page_object, popup_ok)
                                        highlight_element(page_object, popup_ok, get_element_highlighter_color(test_properties))
                                        action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                                    page_object.click(popup_ok)
                                    if test_properties.get("element_highlighter") == "True":
                                        replace_highlight_element(page_object, popup_ok, element_bg_color)

                                    Variable_not_resettable.logger.debug("Ok clicked...********************************")
                                    return True
                                else:

                                    if test_properties.get("element_highlighter") == "True":
                                        element_bg_color = get_element_bg_color(page_object, popup_ok)
                                        highlight_element(page_object, popup_ok, get_element_highlighter_color(test_properties))
                                        action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                                    page_object.click(popup_ok)
                                    if test_properties.get("element_highlighter") == "True":
                                        replace_highlight_element(page_object, popup_ok, element_bg_color)

                                    Variable_not_resettable.logger.debug("Ok clicked...********************************")
                                    return True
                            else:
                                Common_object.Custom_Error = "Assertion on popup failed, for given data value."
                                Common_step.error_popup_message = Common_object.Custom_Error
                                raise Exception(Common_object.Custom_Error)
                        popup_message_xpath = "//div[starts-with(@id,'messagebox')]//*[contains(@id, 'msg')]"
                        popup_message_query = page_object.query_selector(popup_message_xpath)
                        Common_step.error_popup_message = "Application Error Message : "+str(popup_message_query.inner_text())
                        
                        if "Skip Error" in Common_step.BASE_ACTION :
                            Variable_not_resettable.logger.debug(f"Popup skipped  ***********************************")

                            if test_properties.get("element_highlighter") == "True":
                                element_bg_color = get_element_bg_color(page_object, popup_ok)
                                highlight_element(page_object, popup_ok, get_element_highlighter_color(test_properties))
                                action_interval(Variable_not_resettable.test_properties.get("action_interval"))
                            page_object.click(popup_ok)
                            if test_properties.get("element_highlighter") == "True":
                                replace_highlight_element(page_object, popup_ok, element_bg_color)

                            Variable_not_resettable.logger.debug("Ok clicked...********************************")
                            return True
                        Common_object.Custom_Error = "Scenario failed at action : "+Common_step.ACTION +" because of error popup"
                        Variable_not_resettable.logger.info(Common_object.Custom_Error)
                        raise Exception ("Error Popup Exception raised")
                    except Exception as error:
                        Variable_not_resettable.logger.debug(f"{str(error)} ***********************************")
                        raise Exception (str(error))
        except Exception as error:
            if "Popup Exception" in str(error) or "Assertion on popup failed" in str(error):
                Variable_not_resettable.logger.debug(f"{str(error)} ***********************************")
                raise Exception (error)
            else:
                Variable_not_resettable.logger.debug(f"{str(error)} ***********************************")
        if is_popup_found == True and Common_step.popup_loop_count == 1:
            wait_and_close_popup(page_object)
            Variable_not_resettable.logger.debug(f"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Again checking Popup $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
    Variable_not_resettable.logger.debug(f"pop up checking completed ***********************************")
      

# def wait_until_loading_complete(page, selector, timeout=180):
#     """
#     Waits until the specified loading element is no longer visible on the screen.

#     Args:
#         page: The Playwright page object.
#         selector: The XPath or selector of the loading element.
#         timeout: Maximum time to wait in seconds (default is 180).

#     Raises:
#         TimeoutError: If the loading element remains visible beyond the timeout period.
#     """
#     count = 0
#     polling_interval = 0.5  # Interval in seconds
#     max_retries = int(timeout / polling_interval)
    
#     while count < max_retries:
#         try:
#             # Check if the element is still visible
#             if not page.locator(selector).is_visible():
#                 # Exit if the loading element is no longer visible
#                 return
#             # Log the loading state
#             Variable_not_resettable.logger.info("Nebula crxd - loading bar...")
#         except Exception as e:
#             Variable_not_resettable.logger.warning(f"Loading check encountered an issue: {e}")
        
#         # Wait for the next polling interval
#         page.wait_for_timeout(polling_interval * 1000)
#         count += 1

#     raise TimeoutError(f"Page load timeout: Element '{selector}' remained visible after {timeout} seconds.")

def for_check_obj(page_object, selector, time_out):
    try:
        page_object.wait_for_selector(selector, timeout= time_out)
        return True
    except:
        return False

def wait_unitil_please_wait(page_object, time_out):
    if str(Variable_not_resettable.APP_TYPE) == "Nebula co-existence" or str(Variable_not_resettable.APP_TYPE) == "Studio":

        selector_circular_loading= "//div[@class='loader-wrapper full-page']//*[text()='Loading...']"
        Saasy_loading = "//*[@class='r-loader-stroke']"
        circular_wait_element = for_check_obj(page_object, selector_circular_loading,time_out)
        circular_Saasy_loading = for_check_obj(page_object, Saasy_loading,time_out)
        # if circular_wait_element:
        Variable_not_resettable.logger.info("Nebula - wait until please wait")

        if circular_Saasy_loading:
            count = 0
            while circular_Saasy_loading == True:
                Variable_not_resettable.logger.info("SAASY - circular loading...")
                time.sleep(0.5)
                count = count+1
                if count == 360:
                    raise Exception("Page load timeout")
                circular_Saasy_loading = for_check_obj(page_object, Saasy_loading,time_out)

        if circular_wait_element:
            count = 0
            while circular_wait_element == True:
                Variable_not_resettable.logger.info("Nebula - circular loading...")
                time.sleep(0.5)
                count = count+1
                if count == 360:
                    raise Exception("Page load timeout")
                circular_wait_element = for_check_obj(page_object, selector_circular_loading,time_out)


        #loading_circular_progress

        selector = "//*[@id='loadingbar' and @style='display:block']"
        wait_element = for_check_obj(page_object, selector,time_out)
        if wait_element:
            Variable_not_resettable.logger.info("Nebula - wait until please wait")
        if wait_element:
            count = 0
            while wait_element == True:
                Variable_not_resettable.logger.info("Nebula - loading bar...")
                time.sleep(0.5)
                count = count+1
                if count == 360:
                    raise Exception("Page load timeout")
                wait_element = for_check_obj(page_object, selector,time_out)
        # Example Usage
        nebual_window_loading_bar="//*[@id='windowloadingbar' and @style='display:block']"
        nebula_windw_locator=for_check_obj(page_object, nebual_window_loading_bar,time_out)

        if nebula_windw_locator:
            count = 0
            while nebula_windw_locator == True:
                Variable_not_resettable.logger.info("Crxd - 'windowloadingbar...")
                time.sleep(0.5)
                count = count+1
                if count == 360:
                    raise Exception("Page load timeout")
                nebula_windw_locator=for_check_obj(page_object, nebual_window_loading_bar,time_out)
        # crxd_loading="//div[contains(@class,'r-loader-wrapper')]"
        # crxd_load_wrapper="//div[contains(@class,'crxd-loader-wrapper')]"
        # crxd_wait_element = for_check_obj(page_object, crxd_loading,time_out)
        # crxd_wait_wrapper = for_check_obj(page_object, crxd_load_wrapper,time_out)
        # print(crxd_wait_element)
        # # if circular_wait_element:
        # Variable_not_resettable.logger.info("Nebula_crxd - wait until please wait")

        # if crxd_wait_element:
        #     count = 0
        #     while crxd_wait_element == True:
        #         Variable_not_resettable.logger.info("Crxd - circular loading...")
        #         time.sleep(0.5)
        #         count = count+1
        #         if count == 360:
        #             raise Exception("Page load timeout")
        #         crxd_wait_element = for_check_obj(page_object, crxd_loading,time_out)
        # if crxd_wait_wrapper:
        #     count = 0
        #     while crxd_wait_wrapper == True:
        #         Variable_not_resettable.logger.info("Crxd - circular loading...")
        #         time.sleep(0.5)
        #         count = count+1
        #         if count == 360:
        #             raise Exception("Page load timeout")
        #         crxd_wait_wrapper = for_check_obj(page_object, crxd_load_wrapper,time_out)
     
    elif Variable_not_resettable.APP_TYPE == "Rapids":
        selector = "//*[@class='loading-spinner']"
        wait_element = for_check_obj(page_object, selector,time_out)
        if wait_element:
            Variable_not_resettable.logger.info("Rapids - wait until please wait")
        if wait_element:
            count = 0
            while wait_element == True:
                Variable_not_resettable.logger.info("Rapids Loading - Loading Spinner")
                time.sleep(0.5)
                count = count+1
                if count == 360:
                    raise Exception("Page load timeout")
                wait_element = for_check_obj(page_object, selector,time_out)
    elif str(Variable_not_resettable.APP_TYPE).lower() =="studio":
        print("Studio Please wait Not handled") 
    elif str(Variable_not_resettable.APP_TYPE).lower() =="epubs":
        print("Studio Please wait Not handled") 
             
    else:
        # Variable_not_resettable.logger.info("Checking please wait...")
        if ((Common_step.ACTION == "Click Button") or (Common_step.ACTION == "Grid Search Link") or (Common_step.ACTION == "Enter Text") or (Common_step.ACTION == "Select Combo") or (Common_step.ACTION == "Click Link") or (Common_step.ACTION == "Click Link with Class") or (Common_step.ACTION == "Click Help") or (Common_step.ACTION == "Click Checkbox") or (Common_step.ACTION == "List Edit Enter") or (Common_step.ACTION == "List Set Enter") or (Common_step.ACTION == "Smart Search") or (Common_step.ACTION == "Edit And Enter") or (Common_step.ACTION == "Close Dialog") or (Common_step.ACTION == "Click Toggle") or (Common_step.ACTION == "Click Radio Button") or (Common_step.ACTION == "Grid Text Enter") or (Common_step.ACTION == "Click Tab") or (Common_step.ACTION == "Display Block") or (Common_step.ACTION == "Select Button Combo") or (Common_step.ACTION == "Expand Tree") or (Common_step.ACTION == "Expand Child Tree") or (Common_step.ACTION == "Click Tree Item") or (Common_step.ACTION == "Download File") or (Common_step.ACTION == "Attach Document") or (Common_step.ACTION == "Click Hub DisplayBlock Icon") or (Common_step.ACTION == "Attach Document") or (Common_step.ACTION == "Click Button Icon")):
            time_out = time_out + 100
        if ((Common_step.ACTION == "List Edit Enter") or (Common_step.ACTION == "List Set Enter") or (Common_step.ACTION == "Smart Search") or (Common_step.ACTION == "Edit And Enter") or (Common_step.ACTION == "Grid Text Enter") or (Common_step.ACTION == "Download File") or (Common_step.ACTION == "Attach Document")):
            time_out = time_out + 300
        selector = "//div[@name='undefined_loadmask' and @aria-hidden='false']"
        waitelement = for_check_obj(page_object, selector,time_out)
        if waitelement:
            # Variable_not_resettable.logger.info("Please wait found")
            Variable_not_resettable.logger.debug("please wait found captured *****************")
            count = 0
            while waitelement == True:
                time.sleep(1)
                count = count+1
                if count == 360: #360
                    Common_step.is_time_out = True
                    raise Exception(f"Page load timeout : {int(count/2)} secs")
                waitelement = for_check_obj(page_object, selector,time_out)
            # Variable_not_resettable.logger.info("Exiting from please wait found")
            time.sleep(1)
        body_xpath = "//body"
        body_element = for_check_obj(page_object, body_xpath,time_out)
        if body_element == False:
            Variable_not_resettable.logger.debug("Body missing found")
            body_count = 0
            while body_element == False:
                time.sleep(0.5)
                body_count = body_count + 1
                if body_count == 120: #120
                    Common_step.is_time_out = True
                    raise Exception(f"Page load timeout : {int(body_count/2)} secs")
                body_element = for_check_obj(page_object, body_xpath,time_out)
                Variable_not_resettable.logger.debug("Body missing.........")
            Variable_not_resettable.logger.debug("Exiting from body missing found")
            time.sleep(1)
            wait_unitil_please_wait(page_object, time_out)
    Variable_not_resettable.logger.info("Please wait function surpassed")

def wait_unitil_load(page_object, time_out):
    # selector = "//span[@id='progresstxt' and @class='progresstxt' and text()='Loading. Please wait...']"
    # try:
    #     page_element = True
    #     while page_element == True:
    #         page_element = for_check_obj(page_object, selector, time_out)
    #     # print("Loading please wait here")
    # except:
    #     pass
    #     # print("Except Loading please wait here")

    selector = "//span[@id='progresstxt' and @class='progresstxt' and text()='Loading. Please wait...']"
    try:
        page_element = True
        count = 0
        while page_element == True:
            Variable_not_resettable.logger.info("Loading...")
            time.sleep(1)
            count = count+1
            if count == 180:
                raise Exception("Page load timeout")
            page_element = for_check_obj(page_object, selector, time_out)
        # print("Loading please wait here")
    except Exception as error:
        Variable_not_resettable.logger.info(str(error))
        raise Exception(error)

def for_logging_out(page_object):
    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
        # logout_xpath = '//*[@class="bx--header__action" and @aria-label="Search"]//*[@class="MuiSvgIcon-root"]'
        # logout_yes_xpath = '//*[@class="MuiButtonBase-root MuiButton-root MuiButton-contained   MuiButton-containedPrimary MuiButton-containedSizeSmall MuiButton-sizeSmall"]//span[text()="Yes"]'
        # logout_xpath = '//*[@id="userMenu_button"]'
        # logout_btn_xpath = " //*[@id='btnLogout_button']"
        # logout_yes_xpath = "//*[@class='MuiButton-label' and  text()='Yes']"
        logout_xpath = '//*[@id="userMenu_button_icon"]'
        logout_btn_xpath = " //*[@id='btnLogout_button']"
        logout_yes_xpath = "//*[@id='LogoutConfirmatio_SubmitBtn_caption']"
        for_click(page_object , logout_xpath)
        for_click(page_object , logout_btn_xpath)
        for_click(page_object , logout_yes_xpath)
        # time.sleep(10)
    else:
        context = "//*[starts-with(@id,'userMenu-button')]//*[contains(@id, 'btnWrap')]"
        sign_out = "//*[@aria-expanded='true']//*[starts-with(@id,'menuitem')]//*[contains(@id, 'textEl')  and text()='Signout']"
        for_click(page_object,context)
        for_click(page_object,sign_out)

# def for_assert_success_popup(popup_query):
#     if "||" in str(Common_data.data_value):
#         split_with_pipe = str(Common_data.data_value).split("||")
#         if len(split_with_pipe) != 2:
#             raise Exception("Please check the given data value")
#         data_to_assert= split_with_pipe[1]
#         Variable_not_resettable.logger.debug(f"success assert pop up inside  ***********************************")
#         excel_input = str(data_to_assert).split(";")
#     else:
#         Variable_not_resettable.logger.debug(f"success assert pop up inside  ***********************************")
#         excel_input = str(Common_data.data_value).split(";")
#     data_value_1 = str(excel_input[0]).strip()
#     data_value_2 = str(excel_input[1]).strip() if len(excel_input) > 1 else ""
#     popup_text_value = popup_query.inner_text()
#     Variable_not_resettable.logger.debug(f"popup text value: {popup_text_value}")
#     if str(data_value_1) in str(popup_text_value):
#         pass
#     else:
#         Variable_not_resettable.logger.debug(f"error assert pop up return false  ***********************************")
#         return False
#     if data_value_2 != "":
#         if str(data_value_2) in str(popup_text_value):
#             pass
#         else:
#             Variable_not_resettable.logger.debug(f"error assert pop up return false  ***********************************")
#             return False
#     Variable_not_resettable.logger.debug(f"success assert pop up completed  ***********************************")
#     return True


def for_assert_success_popup(popup_query):
   
    try:
        if "||" in str(Common_data.data_value):
            split_with_pipe = str(Common_data.data_value).split("||")
            if len(split_with_pipe) != 2:
                raise Exception("Please check the given data value")
            data_to_assert= split_with_pipe[1]
            Variable_not_resettable.logger.debug(f"success assert pop up inside  ***********************************")
            excel_input = str(data_to_assert).split(";")
        else:
            Variable_not_resettable.logger.debug(f"success assert pop up inside  ***********************************")
            excel_input = str(Common_data.data_value).split(";")
        
        # Check if excel_input is empty or contains only empty strings
        if not excel_input or all(not value.strip() for value in excel_input):
            raise ValueError("Input from Common_data.data_value is empty or null.")
        
        # Extract data values
        data_value_1 = str(excel_input[0]).strip()
        data_value_2 = str(excel_input[1]).strip() if len(excel_input) > 1 else ""
        
        # Get the popup text value
        popup_text_value = popup_query.inner_text()
        Variable_not_resettable.logger.debug(f"popup text value: {popup_text_value}")

        if str(data_value_1) in str(popup_text_value):
            pass
        else:
            Variable_not_resettable.logger.debug(f"error assert pop up return false  ***********************************")
            return False
        if data_value_2 != "":
            if str(data_value_2) in str(popup_text_value):
                pass
            else:
                Variable_not_resettable.logger.debug(f"error assert pop up return false  ***********************************")
                return False

    except Exception as e:
        Variable_not_resettable.logger.error(f"Exception occurred: {str(e)}")
        return False

    Variable_not_resettable.logger.debug(f"success assert pop up completed  ***********************************")
    return True

def for_assert_fail_popup(popup_query):
    try:
        if "||" in str(Common_data.data_value):
            split_with_pipe = str(Common_data.data_value).split("||")
            if len(split_with_pipe) != 2:
                raise Exception("Please check the given data value")
            data_to_assert= split_with_pipe[1]
            Variable_not_resettable.logger.debug(f"error assert pop up inside  ***********************************")
            excel_input = str(data_to_assert).split(";")
        else:
            Variable_not_resettable.logger.debug(f"error assert pop up inside  ***********************************")
            excel_input = str(Common_data.data_value).split(";")

          
        # Check if excel_input is empty or contains only empty strings
        if not excel_input or all(not value.strip() for value in excel_input):
            raise ValueError("Input from Common_data.data_value is empty or null.")
        
        data_value_1 = str(excel_input[0]).strip()
        data_value_2 = str(excel_input[1]).strip() if len(excel_input) > 1 else ""
        popup_text_value = popup_query.inner_text()
        if  str(data_value_1) in str(popup_text_value):
            pass
        else:
            Variable_not_resettable.logger.debug(f"error assert pop up return false  ***********************************")
            return False
        if data_value_2 != "":
            if str(data_value_2) in str(popup_text_value):
                pass
            else:
                Variable_not_resettable.logger.debug(f"error assert pop up return false  ***********************************")
                return False
    except Exception as e:
        Variable_not_resettable.logger.error(f"Exception occurred: {str(e)}")
        return False
    Variable_not_resettable.logger.debug(f"error assert pop up completed  ***********************************")
    return True


def for_select_combo_nebula(page_object, selector, data):
    if str(data).lower() != "nan" and str(data).lower() != "na" and str(data) != "":
        if ";" not in data:
            if page_object.locator("//*[@id='btnRefresh_button']").is_visible():
                page_object.wait_for_selector(selector, timeout= 5000)
                page_object.locator(selector).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                page_object.click(selector, timeout= Common_object.Timeout)
                # Define both possible combo values
                selectValue = f"//ul[@role='listbox']//li[text()='{data}']"
                UATCombo = f"{selector}//parent::*/following-sibling::*/*/*[text()='{data}']"
                element = page_object.locator(UATCombo)
                # page_object.locator(selectValue).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                print("Visible:",  element.is_visible())
                # Check which one is visible and clickable
                if page_object.locator(selectValue).is_visible():
                    page_object.click(selectValue, timeout=Common_object.Timeout)
                elif page_object.locator(UATCombo).is_visible():
                    page_object.click(UATCombo, timeout=Common_object.Timeout)
                else:
                    print("No clickable combo value found.")
            else:
                try:
                    if str(Common_step.Second_Action).lower()=="list select":
                        Variable_not_resettable.logger.info("************************#try#**********************")
                        Variable_not_resettable.logger.info("")
                        Variable_not_resettable.logger.info("************************##**********************")
                        selectValue=selector+"//*[contains(@id,'"+data+"')]"
                        page_object.wait_for_selector(selector, timeout= 5000)
                        page_object.click(selector, timeout= Common_object.Timeout)
                        page_object.click(selectValue, timeout= Common_object.Timeout)
                    else:
                        Variable_not_resettable.logger.info("************************#try#**********************")
                        Variable_not_resettable.logger.info("")
                        Variable_not_resettable.logger.info("************************##**********************")
                        page_object.wait_for_selector(selector, timeout= 5000)
                        page_object.click(selector, timeout= Common_object.Timeout)
                        selectValue = "//ul//li[text()='"+data+"']"
                        page_object.click(selectValue, timeout= Common_object.Timeout)
                except Exception as error:
                    Variable_not_resettable.logger.info("************************#Except#**********************")
                    Variable_not_resettable.logger.error(str(error))
                    Variable_not_resettable.logger.info("************************##**********************")
                    # page_object.wait_for_selector(selector, timeout= 5000)
                    # page_object.click(selector, timeout= Common_object.Timeout)
                    # selectValue = "//ul//li//*[text()='"+data+"']"
                    # page_object.click(selectValue, timeout= Common_object.Timeout)
                    if str(Common_step.Second_Action).lower()=="list select":
                        Variable_not_resettable.logger.info("************************#try#**********************")
                        Variable_not_resettable.logger.info("")
                        Variable_not_resettable.logger.info("************************##**********************")
                        page_object.locator(selectValue).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                        page_object.wait_for_selector(selectValue, timeout= 5000)                    
                        page_object.click(selectValue, timeout= Common_object.Timeout)
                    else:
                        selectValue = "//ul//li//*[text()='"+data+"']"
                        page_object.locator(selectValue).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                        page_object.wait_for_selector(selectValue, timeout= 5000)                    
                        page_object.click(selectValue, timeout= Common_object.Timeout)
                    

        else:
            page_object.wait_for_selector(selector, timeout= 5000)
            page_object.click(selector, timeout= Common_object.Timeout)
            split_data = data.split(";")
            # pickerlist_id = ((Common_controls.control_Value).split("trigger_picker"))[0]+"picker_listEl"
            pickerlist_id = ((Common_controls.control_Value).split("arrow"))[0]+"dropdown"
            selectValue = "//*[@id='"+pickerlist_id+"']//ul//li//div//div[text()='"+split_data[0]+"']//..//*[text()='"+split_data[1]+"']"
            Variable_not_resettable.logger.info(selectValue)
            page_object.click(selectValue, timeout= Common_object.Timeout)
    else:
        page_object.wait_for_selector(selector, timeout= 5000)
        page_object.click(selector, timeout= Common_object.Timeout)
        pickerlist_id_starts = ((Common_controls.control_Value).split("trigger_picker"))[0]+"picker_listEl"
        pickerlist_id = "//*[@id='"+pickerlist_id_starts+"']//li"
        # print("______________________________________")
        Variable_not_resettable.logger.info(pickerlist_id)
        combo_list_elements = page_object.query_selector_all(pickerlist_id)
        for combo_element in combo_list_elements:
            combo_li_text = combo_element.inner_text()
            if combo_li_text =="":
                combo_element.click()
                break
        # print("______________________________________")
def update_locators(locators_template, values_dict):
    updated_locators = {}
    
    for key, xpath in locators_template.items():
        updated_xpath = xpath.format(**values_dict)
        updated_locators[key] = updated_xpath

    return updated_locators

def checkbox_check(page_object, selector):
    wait_unitil_please_wait(page_object,100)
    wait_and_close_popup(page_object)
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    try:
        is_checked_flag = page_object.query_selector(selector).is_checked()
        Variable_not_resettable.logger.info(f"{is_checked_flag}")
        if is_checked_flag == False:
            page_object.click(selector, timeout= Common_object.Timeout)
        else:
            Variable_not_resettable.logger.info("Checkbox already checked, Skip to check again")
    except Exception as error:
        error_str = error
        raise Exception("Click Check Box failed because : "+ str(error_str))

def checkbox_uncheck(page_object, selector):
    wait_unitil_please_wait(page_object,100)
    wait_and_close_popup(page_object)
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    try:
        is_checked_flag = page_object.query_selector(selector).is_checked()
        Variable_not_resettable.logger.info(f"{is_checked_flag}")
        if is_checked_flag == True:
            page_object.click(selector, timeout= Common_object.Timeout)
        else:
            Variable_not_resettable.logger.info("Checkbox already unchecked, Skip to uncheck again")
    except Exception as error:
        error_str = error
        raise Exception("Click Check Box failed because : "+ str(error_str))

def for_assert_checkbox(page_object, selector, data):
        
        if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
            wait_unitil_please_wait(page_object,100)
            wait_and_close_popup(page_object)
            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            is_checked_flag = page_object.query_selector(selector).is_checked()
            if data == "CHECKED":
                if is_checked_flag == True:
                    Variable_not_resettable.logger.info("Assertion Success, Checkbox- Checked")
                else:
                    error_str = "Assertion Failed, Checkbox Unchecked"
                    Variable_not_resettable.logger.info(error_str)
                    raise Exception(error_str)
            elif data == "UNCHECKED":
                if is_checked_flag == False:
                    Variable_not_resettable.logger.info("Assertion Success, Checkbox- UnChecked")
                else:
                    error_str = "Assertion Failed, Checkbox checked"
                    Variable_not_resettable.logger.info(error_str)
                    raise Exception(error_str)
            else:
                error_str = "Assertion not work, Check the data sheet "
                Variable_not_resettable.logger.error(error_str)
                raise Exception(error_str)

        else:
            wait_unitil_please_wait(page_object,100)
            wait_and_close_popup(page_object)
            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            data_temp = data # Data should (Checked or Unchecked) before the next line of code
            data = str(data).upper()
            if Wrapper_variables.patternMatch == "NO":
                try:
                    selector = "(//*[@id='"+Common_controls.control_Value+"'])[2]"
                    if data == "CHECKED":
                        is_checked_flag = (page_object.query_selector(selector)).get_attribute("class")
                        if is_checked_flag == "x-grid-checkcolumn x-grid-checkcolumn-checked":
                            Variable_not_resettable.logger.info("Assertion Success, Checkbox Checked")
                        elif is_checked_flag == "x-grid-checkcolumn":
                            error_str = "Assertion Failed, Checkbox Unchecked"
                            Variable_not_resettable.logger.info(error_str)
                            raise Exception(error_str)
                    elif data == "UNCHECKED":
                        is_checked_flag = (page_object.query_selector(selector)).get_attribute("class")
                        if is_checked_flag == "x-grid-checkcolumn":
                            Variable_not_resettable.logger.info("Assertion Success, Checkbox Unchecked")
                        elif is_checked_flag == "x-grid-checkcolumn x-grid-checkcolumn-checked":
                            error_str = "Assertion Failed, Checkbox Checked"
                            Variable_not_resettable.logger.info(error_str)
                            raise Exception(error_str)
                    else:
                        raise Exception(f"Incorrect Data given '{data_temp}' in data sheet")
                        
                except Exception as error:
                    error_str = error
                    Variable_not_resettable.logger.info(str(error))
                    raise Exception(str(error_str))
            else:
                try:
                    if data == "CHECKED":
                        is_checked_flag = page_object.query_selector(selector).is_checked()
                        if is_checked_flag == True:
                            Variable_not_resettable.logger.info("Assertion Success, Checkbox Checked")
                        elif is_checked_flag == False:
                            error_str = "Assertion Failed, Checkbox Unchecked"
                            Variable_not_resettable.logger.info(error_str)
                            raise Exception(error_str)
                    elif data == "UNCHECKED":
                        is_checked_flag = page_object.query_selector(selector).is_checked()
                        if is_checked_flag == False:
                            Variable_not_resettable.logger.info("Assertion Success, Checkbox Unchecked")
                        elif is_checked_flag == True:
                            error_str = "Assertion Failed, Checkbox Checked"
                            Variable_not_resettable.logger.info(error_str)
                            raise Exception(error_str)
                    else:
                        raise Exception(f"Incorrect Data given '{data_temp}' in data sheet")
                        
                except Exception as error:
                    error_str = error
                    Variable_not_resettable.logger.info(str(error))
                    raise Exception(str(error_str))

def assert_negative_values(page, selector):
    
    with page.expect_download() as download_info:
        try:
            page.click(selector)
        except Exception as error:
            page.click(selector)
    download = download_info.value
    file_name = download.suggested_filename
    download_folder_path = "./Files/Input_Documents/"
    path = download.path()
    save_in_path = os.path.join(download_folder_path, file_name)
    download.save_as(save_in_path)
    download_sheet = file_name.split(".")[0]
    return save_in_path,download_sheet
                
def for_download_and_assert_pdf(page, selector,context):    
    is_page2_opened = False
    is_page2_closed = False
    save_btn_xpath = "//*[@id='save']"
    i_frame_xpath = "//iframe[@id='report_iframe']"
    try:
        page.wait_for_selector(selector, timeout= Common_object.Timeout)
        with context.expect_page() as new_page:
            page.click(selector, timeout= Common_object.Timeout)
            page2 = new_page.value
        Variable_not_resettable.logger.info(str(page2))
        is_page2_opened = True
        page2.wait_for_selector(i_frame_xpath, timeout= 30000)
        frame_element = page2.frame_locator(i_frame_xpath)
        save_btn = frame_element.locator(save_btn_xpath)
        with page2.expect_download(timeout=60000) as download_info:
            save_btn.click()
        download = download_info.value
        file_name = download.suggested_filename
        Variable_not_resettable.logger.debug(f"file_name: {file_name}")
        pdf_destination = Common_path.base_path+"\\storage"
        destination_file_path = os.path.join(pdf_destination, file_name)
        download.save_as(destination_file_path)
        Variable_not_resettable.logger.info(f"file save in {destination_file_path}")
        time.sleep(1)
        page2.close()
        is_page2_closed = True
        return destination_file_path
    except Exception as error:
        if is_page2_opened == True and is_page2_closed == False:
            page2.close()
            Variable_not_resettable.logger.info("page2 closed...")
        raise Exception(str(error))
    

def assert_locator_for_smart_search(page_object, selector):
    try:
        page_object.wait_for_selector(selector,timeout = 100)
        # set_focus_to_element(page_object,selector)
        return True
    except:
        return False
    
def for_download_and_assert_all_grid_values(page, selector):
    Variable_not_resettable.logger.info(f"selector_for_export : {selector}")
    output_folder = "./Downloads"
    make_directory(output_folder)
    with page.expect_download() as download_info:
        # Perform the action that initiates download
        page.click(selector)
    download = download_info.value
    file_name = download.suggested_filename
    Variable_not_resettable.logger.info(f"file_name : {file_name}")
    destination_folder_path = "./Downloads/"
    # Wait for the download process to complete
    path = download.path()
    save_in_path = os.path.join(destination_folder_path, file_name)
    download.save_as(save_in_path)
    download_sheet = file_name.split(".")[0]
    Variable_not_resettable.logger.info(f"download_sheet : {download_sheet}")
    Variable_not_resettable.logger.info("Downloaded Done")
    return save_in_path,file_name


def total_row_count(page_object):
    splitted_col_header = (Common_controls.control_Value).split("_tbr")
    path_for_total_rows = "//*[starts-with(@id,'"+splitted_col_header[0]+"')]//*[contains(@id, '_tbr_dspRow')]"
    Variable_not_resettable.logger.debug(f"path_for_total_rows : {path_for_total_rows}")
    getting_inner_text = page_object.query_selector(path_for_total_rows)            
    Total_row_count = ((getting_inner_text.inner_text()).split("/"))[1]
    Variable_not_resettable.logger.info(f"Total_row_count : {Total_row_count}")
    return Total_row_count

def xlsm_to_xlsx_conversion(xlsm_file_name,sheet):
    file_name = f"{xlsm_file_name}".split(".")[0]
    file_name_xlsx = f"{file_name}.xlsx"
 
    file_xlsm = f"{Common_path.base_path}\Downloads\{xlsm_file_name}"
    file_path = f"{Common_path.base_path}\Downloads\{file_name_xlsx}"
    df = pd.read_excel(file_xlsm,sheet_name=sheet, index_col=0)
    new_header  = df.iloc[0]
    df = df[1:]
    df.columns = new_header
    df.to_excel(file_path,sheet_name = sheet)
    time.sleep(1)
    converted_excel_df = pd.read_excel(file_path,sheet_name=sheet,dtype="str")
    converted_excel_df = converted_excel_df.fillna("")
    excel_dict = converted_excel_df.to_dict("records")
    rows_in_converted_excel = len(excel_dict)
    return rows_in_converted_excel,excel_dict,file_path

def for_download_and_assert_excel(page, selector,context):
    is_page2_opened = False
    is_page2_closed = False
    save_btn_xpath = "//*[@id='save']"
    i_frame_xpath = "//iframe[@id='report_iframe']"
    try:
        page.wait_for_selector(selector, timeout= Common_object.Timeout)
        with context.expect_page() as new_page:
            page.click(selector, timeout= Common_object.Timeout)
            Common_step.Assert_downloaded_excel_column = True
            page2 = new_page.value
        Variable_not_resettable.logger.info(str(page2))
        is_page2_opened = True
        page2.wait_for_selector(i_frame_xpath, timeout= 30000)
        frame_element = page2.frame_locator(i_frame_xpath)
        save_btn = frame_element.locator(save_btn_xpath)
        with page2.expect_download(timeout=60000) as download_info:
            # save_btn.click()
            page2.wait_for_selector(i_frame_xpath, timeout= 30000)
        download = download_info.value
        file_name = download.suggested_filename
        Variable_not_resettable.logger.debug(f"file_name: {file_name}")
        pdf_destination = Common_path.base_path+"\\Downloads"
        destination_file_path = os.path.join(pdf_destination, file_name)
        download.save_as(destination_file_path)
        Variable_not_resettable.logger.info(f"file save in {destination_file_path}")
        time.sleep(1)
        page2.close()
        is_page2_closed = True
        return destination_file_path
    except Exception as error:
        if is_page2_opened == True and is_page2_closed == False:
            page2.close()
            Variable_not_resettable.logger.info("page2 closed...")
        raise Exception(str(error))
    
def for_click_xpath(page_object, selector):
    try:
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        page_object.locator(selector).scroll_into_view_if_needed(timeout= Common_object.Timeout)
        Variable_not_resettable.logger.info("Element found")
        page_object.click(selector, timeout= Common_object.Timeout)
        Common_step.is_click_done = True
        Variable_not_resettable.logger.debug("Click SUCCESS")
    except Exception as error:
        Variable_not_resettable.logger.debug("Click ERROR")
        Variable_not_resettable.logger.info("Click failed because : "+ str(error))
        raise Exception("Click failed because : "+ str(error))
    
def for_click_radio(page_object, selector):
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    page_object.hover(selector, timeout= Common_object.Timeout)
    is_checked_flag = page_object.query_selector(selector).is_checked()
    Variable_not_resettable.logger.info(f"Before : {is_checked_flag}")
    page_object.click(selector, timeout= Common_object.Timeout)
    is_checked_flag = page_object.query_selector(selector).is_checked()
    Variable_not_resettable.logger.info(f"After : {is_checked_flag}")
    count = 0
    while is_checked_flag != True:
        count = + 1
        page_object.click(selector, timeout= Common_object.Timeout)
        Variable_not_resettable.logger.info(f"Attempting to click : {count}")
        if page_object.query_selector(selector).is_checked():
            break
        if count == 5:
            Variable_not_resettable.logger.info("Maximum attempts tried unable to check")
            raise Exception("Maximum attempts tried unable to check")
        


def get_nested_value(data, keys):
    """Extracts the value from a nested dictionary using a list of keys."""
    for key in keys:
        data = data.get(key, None)
        if data is None:
            return None
    return data

def set_nested_value(data, keys, value):
    """Sets the value in a nested dictionary using a list of keys."""
    for key in keys[:-1]:
        data = data.setdefault(key, {})
    data[keys[-1]] = value

def map_keys(source_path, destination_path, key_mapping):
    # Load the source JSON file
    with open(source_path, 'r') as source_file:
        source_data = json.load(source_file)

    # Load the destination JSON file
    with open(destination_path, 'r') as destination_file:
        destination_data = json.load(destination_file)

    # Map the keys
    for source_key, destination_key in key_mapping.items():
        source_keys = source_key.split('.')
        destination_keys = destination_key.split('.')

        # Extract the value from the source JSON
        value = get_nested_value(source_data, source_keys)
        if value is not None:
            # Set the value in the destination JSON
            set_nested_value(destination_data, destination_keys, value)

    # Write the updated destination JSON back to the file
    with open(destination_path, 'w') as destination_file:
        json.dump(destination_data, destination_file, indent=4)


def find_header_row(df):
    for index, row in df.iterrows():
        if 'Array Type' in row.values:  # Replace 'Category' with a specific column name you're expecting
            return index

def for_fill_date(page_object, selector, data): 
    if Common_scenario.data_provider_num != None:
        data_for_verification = get_data_value(Common_object.dataSheet_dictionary, Common_scenario.data_provider_num , Common_step.DATA_REFERENCE)
        if 'EXECUTE:' in str(data_for_verification):
            page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            element_handler = page_object.query_selector(selector)
            element_text = element_handler.get_attribute("title")
            Variable_not_resettable.logger.info(str(element_text))
            page_object.click(selector, timeout= Common_object.Timeout)
            page_object.fill(selector, data)
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                page_object.keyboard.press("Enter")
        else:
                if str(data).lower() != "nan" and data != "" and data != None and str(data) != str(None):
                    try:
                        Variable_not_resettable.logger.info("Date before formatting"+ str(data))
                        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
                        element_handler = page_object.query_selector(selector)
                        

                        if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                            element_text = element_handler.get_attribute("placeholder")
                        else:
                            element_text = element_handler.get_attribute("title")
                        # element_text = element_handler.get_attribute("title")
                        Variable_not_resettable.logger.info(str(element_text))
                        final_date = get_final_date(element_text, data)
                        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
                        page_object.click(selector, timeout= Common_object.Timeout)
                        page_object.fill(selector, str(final_date))
                    except:
                        page_object.fill(selector, str(final_date))
                    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                        page_object.keyboard.press("Enter")
                else:
                    if data_for_verification != "nan" and data_for_verification != "" and data_for_verification != None and str(data_for_verification) != str(None):
                        raise Exception(f"Data sheet have Enter Date Value but data coming as : {str(data)}")
                    page_object.click(selector, timeout= Common_object.Timeout)
                    page_object.fill(selector, "")
                    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                        page_object.keyboard.press("Enter")
        if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
            pass
        else:
            page_object.click(selector, timeout= Common_object.Timeout)
    else:
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        page_object.click(selector, timeout= Common_object.Timeout)
        page_object.fill(selector, data)
        page_object.click(selector, timeout= Common_object.Timeout)
        if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                page_object.keyboard.press("Enter")



def for_assert_data(page_object, selector, data):
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    set_focus_to_element(page_object,selector)
    assert_data_text = None
    element = page_object.locator(selector)
    if "@placeholder" in selector.lower():
        assert_data_text = page_object.locator(selector).get_attribute("placeholder")
    elif "@value" in selector.lower():
        assert_data_text = page_object.locator(selector).get_attribute("value")
    else:
        assert_data_text = page_object.locator(selector).inner_text(timeout=3000)

    if assert_data_text:
        assert_data_text = assert_data_text.strip()
        data = data.strip()
        if assert_data_text == data:
            Variable_not_resettable.logger.info("Assert Data Success for: '" + str(data) +f"' and text in application '{assert_data_text}' ")
        else:
            Common_object.Custom_Error = f"Assert Data failed for '{str(data)}' and text in application '{assert_data_text}'"
            raise Exception(Common_object.Custom_Error)
    else:
        data = data.strip()
        Common_object.Custom_Error = f"Assert Data failed for '{str(data)}' and text in application {assert_data_text}"
        raise Exception(Common_object.Custom_Error)


def for_assert_radio_button(page_object, selector, data):
    wait_unitil_please_wait(page_object,100)
    wait_and_close_popup(page_object)
    page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
    data = str(data).upper()
    
    element = page_object.locator(selector)
    isChecked = "CHECKED" if element.is_checked() else "UNCHECKED"
    
    if data == isChecked:
        success_str = f"Assertion successful for Radio Button - {data}"
        Variable_not_resettable.logger.info(success_str)
    else:
        error_str = f"Assertion Failed for Radio Button - {data}"
        Variable_not_resettable.logger.error(error_str)
        raise Exception(error_str)

def assert_multi_select_combo(page_object, selector, data):
    selected_element = page_object.locator(selector)
    parent_element = selected_element.locator('..')
    grandparent_element = parent_element.locator('..')
    
    children = grandparent_element.locator('.list-select__multi-value')
    selected_text = []

    for child in children.element_handles():
        label_div = child.query_selector('.list-select__multi-value__label')
        label_text = label_div.inner_text()
        selected_text.append(label_text.strip())

    data = [each.strip() for each in data.split(";")]
    if sorted(selected_text) == sorted(data):
        success_str = f"Assertion successful for Multi Select Combo data - {data}"
        Variable_not_resettable.logger.info(success_str)
    else:
        error_str = f"Assertion Failed for Multi Select Combo data - {data}"
        Variable_not_resettable.logger.error(error_str)
        raise Exception(error_str)

def assert_select_combo_options(page_object, selector, data):
    page_object.click(selector, timeout= Common_object.Timeout)
    tmp_selector = selector
    selector = tmp_selector.replace("_input", "_dropdown").replace("_arrow", "_dropdown")
    selected_element = page_object.locator(selector)
    ul_element = selected_element.locator("ul")
    li_elements = ul_element.locator("li").element_handles()

    if len(li_elements) == 0:
        selector = tmp_selector.replace("_inputEl", "_picker_listEl") + "//li"
        li_elements = page_object.query_selector_all(selector)

    combo_options = []
    for each_li_element in li_elements:
        li_text = each_li_element.inner_text()
        combo_options.append(li_text.strip())

    Variable_not_resettable.logger.info(f"Combo options from application: {combo_options}")
    
    data = [each.strip() for each in data.split(";")]


    is_present = all(elem in combo_options for elem in data)

    if is_present:
        success_str = f"Assertion successful for Select Combo options - {data}"
        Variable_not_resettable.logger.info(success_str)
    else:
        error_str = f"Assertion Failed for Select Combo options - {data}"
        Variable_not_resettable.logger.error(error_str)
        raise Exception(error_str)
    

    
    
def Mapping_process_section_statements(page_object,locators_dictionary,filtered_methodname_df):
    filter_column_in_out = "In_Out"
    in_rows = []
    out_rows = []
    for index, row in filtered_methodname_df.iterrows():
        if row[filter_column_in_out] == 'IN' or row[filter_column_in_out] == 'IN/OUT':
            in_rows.append(row)
        elif row[filter_column_in_out] == 'OUT':
            out_rows.append(row)
    In_df = pd.DataFrame(in_rows)
    Out_df = pd.DataFrame(out_rows)
    
    if not In_df.empty:
        switchtab_MethodParameterMap = "//a[@id='MethodParameterMap']"
        for_click(page_object,switchtab_MethodParameterMap)
        wait_and_close_popup(page_object)
        # for index, row in In_df.iterrows():
        #     Method_Param_Name_data = row["MethodParamName"]
        #     Segment_Name_data = row["SegmentName"]
        #     Segment_Param_Name_data = row["SegmentParam_Name"]                                 
            #Method Parameter Map
        pagination_intable_xpath=locators_dictionary['pagination_in_table']
        while True:
            try:
                # Wait for selector to appear before querying elements
                page_object.wait_for_selector(pagination_intable_xpath, timeout=5000)
                elements_array = page_object.query_selector_all(pagination_intable_xpath)

                # Iterate over the elements
                for i, element in enumerate(elements_array):
                    try:
                        text_in_app_array = element.inner_text()
                        extracted_terms = []
                        column_name = 'MethodParamName'  # replace with actual column name

                        Segment_name_value = In_df.loc[In_df[column_name] == text_in_app_array, 'SegmentName'].iloc[0]
                        Dataitem_name_value = In_df.loc[In_df[column_name] == text_in_app_array, 'SegmentParam_Name'].iloc[0]
                        Param_name_value = In_df.loc[In_df[column_name] == text_in_app_array, 'MethodParamName'].iloc[0]

                        # Check if Param_name_value matches
                        if str(Param_name_value) == str(text_in_app_array):
                            MethodParameterMap_Segment_Name_dropdown = locators_dictionary['MethodParameterMap_Segment_Name_dropdown'].format(MethodParamName=Param_name_value)
                            MethodParameterMap_Segment_Value_Selection = locators_dictionary['MethodParameterMap_Segment_Value_Selection'].format(SegmentName=Segment_name_value)
                            MethodParameterMap_dataitem_Name_dropdown = locators_dictionary['MethodParameterMap_dataitem_Name_dropdown'].format(MethodParamName=Param_name_value)
                            MethodParameterMap_dataitem_value = locators_dictionary['MethodParameterMap_dataitem_value'].format(SegmentParam_Name=Dataitem_name_value)
                            MethodParameterMap_Save = locators_dictionary['MethodParameterMap_Save']

                            time.sleep(.5)
                            for_click(page_object, MethodParameterMap_Segment_Name_dropdown)
                            wait_and_close_popup(page_object)
                            time.sleep(.5)
                            for_click(page_object, MethodParameterMap_Segment_Value_Selection)
                            wait_and_close_popup(page_object)
                            time.sleep(.5)
                            for_click(page_object, MethodParameterMap_dataitem_Name_dropdown)
                            wait_and_close_popup(page_object)
                            time.sleep(.5)
                            for_click(page_object, MethodParameterMap_dataitem_value)
                            wait_and_close_popup(page_object)
                            # time.sleep(.5)
                            # for_click(page_object, MethodParameterMap_Save)

                            # Variable_not_resettable.logger.info(f"Parameter : {Param_name_value} was mapped")
                            # wait_and_close_popup(page_object)

                    except Exception as elementerror:
                        Variable_not_resettable.logger.error(f"Error processing element: {elementerror}")
                        continue  # Continue to next element in case of an error in the current one
                try:
                    for_click(page_object, MethodParameterMap_Save)  # Save the current page
                    Variable_not_resettable.logger.info(f"Overall save for page")
                    wait_and_close_popup(page_object)
                except:
                    Variable_not_resettable.logger.info(f"Error captured in Save of the Method parameter map table")
                    continue


                # Handle page forwarding
                try:
                    pageforwardbutton = locators_dictionary['in_pageforwardbutton']

                    # Forward to the next page
                    for_click(page_object, pageforwardbutton)
                    wait_and_close_popup(page_object)
                    Variable_not_resettable.logger.info(f"Forward arrow clicked")
                    time.sleep(.5)

                except Exception as forward_request_array_error:
                    Variable_not_resettable.logger.error(f"Reached last page or error occurred: {forward_request_array_error}")
                    break  # Break the loop if we can't click forward (i.e., last page reached)

            except Exception as main_loop_error:
                Variable_not_resettable.logger.error(f"Error in the main loop: {main_loop_error}") # Break the loop if a critical error occurs outside the element processing


    if not Out_df.empty:                                
        switchtab_MethodResultSetMap = locators_dictionary['switchtab_MethodResultSet']
        for_click(page_object,switchtab_MethodResultSetMap)                                    
        wait_and_close_popup(page_object)
        filter_rscolumn = 'ResultsetName'
        unique_resultsetname = Out_df[filter_rscolumn].unique()
        # for value in unique_resultsetname:
        #     filtered_out_df = Out_df[Out_df[filter_rscolumn] == value]
        #     method_name_data=filtered_out_df['MethodName'].iloc[0]
        #     Segment_Name_data = filtered_out_df["SegmentName"].iloc[0]
        #     Instance_data = filtered_out_df["Instance"].iloc[0]
        #     Resultset_Name_data = filtered_out_df["ResultsetName"].iloc[0]
        pagination_resultsettable_xpath=locators_dictionary['pagination_resultset_table']
        while True:
            try:
                page_object.wait_for_selector(pagination_resultsettable_xpath, timeout= 5000)
                rs_elements_array = page_object.query_selector_all(pagination_resultsettable_xpath)
                for i, element in enumerate(rs_elements_array):
                    try:
                        text_in_app_array = element.inner_text()
                        extracted_terms = []
                        column_name = 'ResultsetName'  # replace with your actual column name
                        Resultset_Name_data=Out_df.loc[Out_df [column_name] == text_in_app_array, 'ResultsetName'].iloc[0]
                        Segment_Name_data=Out_df.loc[Out_df [column_name] == text_in_app_array, 'SegmentName'].iloc[0]
                        Instance_data=Out_df.loc[Out_df [column_name] == text_in_app_array, 'Instance'].iloc[0]
                        if str(Resultset_Name_data)==str(text_in_app_array):
                                Loop_segment_dropdown =locators_dictionary['Loop_segment_dropdown'].format(ResultsetName=Resultset_Name_data)
                                Loop_segment_Value = locators_dictionary['Loop_segment_Value'].format(SegmentName=Segment_Name_data)
                                MethodResultSetMap_Save =locators_dictionary['MethodResultSetMap_Save']
                                if str(Instance_data) == "Single":
                                    pass
                                elif str(Instance_data) == "Multiple":
                                    for_click(page_object,Loop_segment_dropdown)
                                    wait_and_close_popup(page_object)
                                    time.sleep(0.2)
                                    for_click(page_object,Loop_segment_Value)
                                    wait_and_close_popup(page_object)
                                else:
                                    Variable_not_resettable.logger.error("Kindly check the instance type")
                    except Exception as elementerror:
                        Variable_not_resettable.logger.error(f"Error processing element: {elementerror}")
                        continue 
                try:
                    for_click(page_object,MethodResultSetMap_Save)  # Save the current page
                    Variable_not_resettable.logger.info(f"Overall save for page")
                    wait_and_close_popup(page_object)
                except:
                    Variable_not_resettable.logger.info(f"Error captured in Save of the Methodresultset table")
                    continue

                try:
                    rs_pageforwardbutton=locators_dictionary['rs_pageforwardbutton']
                    for_click(page_object,rs_pageforwardbutton)
                    wait_and_close_popup(page_object)
                    Variable_not_resettable.logger.info(f"forward_arrow clicked")
                    time.sleep(.5)
                except Exception as forward_request_array_error:
                    Variable_not_resettable.logger.error(f"Reached last page of Resultsetparametermap or error occurred: {forward_request_array_error}")
                    break # Break the loop if we can't click forward (i.e., last page reached)

            except Exception as main_loop_error:
                Variable_not_resettable.logger.error(f"Error in the Resultset main loop: {main_loop_error}") # Break the loop if a critical error occurs outside the element processing


        switchtab_MethodResultSetParameterMap = locators_dictionary['switchtab_MethodResultSetParameterMap']
        for_click(page_object,switchtab_MethodResultSetParameterMap)
        wait_and_close_popup(page_object)         
        for value in unique_resultsetname:
            filtered_out_df = Out_df[Out_df[filter_rscolumn] == value]
            Resultset_Name_data = filtered_out_df["ResultsetName"].iloc[0]
            MethodResultSetParameter_resultset_dropdown =  locators_dictionary['MethodResultSetParameter_resultset_dropdown']
            MethodResultSetParameter_resultset_option =  locators_dictionary['MethodResultSetParameter_resultset_option'].format(ResultsetName=Resultset_Name_data)
            time.sleep(.5)
            for_click(page_object,MethodResultSetParameter_resultset_dropdown)
            wait_and_close_popup(page_object)
            time.sleep(.5)
            for_click(page_object,MethodResultSetParameter_resultset_option)
            wait_and_close_popup(page_object)
            pagination_outtable_xpath=locators_dictionary['pagination_out_table']

            while True:
                try:
                    page_object.wait_for_selector(pagination_outtable_xpath, timeout= 5000)
                    out_elements_array = page_object.query_selector_all(pagination_outtable_xpath)
                    for i, element in enumerate(out_elements_array):
                        try:
                            text_in_app_array = element.inner_text()
                            extracted_terms = []
                            column_name = 'MethodParamName'  # replace with your actual column name
                            out_Segment_name_value=filtered_out_df .loc[filtered_out_df [column_name] == text_in_app_array, 'SegmentName'].iloc[0]
                            out_Dataitem_name_value=filtered_out_df .loc[filtered_out_df [column_name] == text_in_app_array, 'SegmentParam_Name'].iloc[0]
                            out_Param_name_value=  filtered_out_df .loc[  filtered_out_df [column_name] == text_in_app_array, 'MethodParamName'].iloc[0]
                            if str(out_Param_name_value)==str(text_in_app_array):
                                switchtab_MethodResultSetParameterMap_Segment_dropdown = locators_dictionary['switchtab_MethodResultSetParameterMap_Segment_dropdown'].format(MethodParamName= out_Param_name_value)
                                switchtab_MethodResultSetParameterMap_Segment_value = locators_dictionary['switchtab_MethodResultSetParameterMap_Segment_value'].format(SegmentName=out_Segment_name_value)
                                switchtab_MethodResultSetParameterMap_dataitem_dropdown = locators_dictionary['switchtab_MethodResultSetParameterMap_dataitem_dropdown'].format(MethodParamName=out_Param_name_value)
                                switchtab_MethodResultSetParameterMap_dataitem_value = locators_dictionary['switchtab_MethodResultSetParameterMap_dataitem_value'].format(SegmentParam_Name=out_Dataitem_name_value)
                                Method_ResultSet_Parameter_Map_save = locators_dictionary['Method_ResultSet_Parameter_Map_save']
                                time.sleep(.5)
                                for_click(page_object,switchtab_MethodResultSetParameterMap_Segment_dropdown)
                                wait_and_close_popup(page_object)
                                for_click(page_object,switchtab_MethodResultSetParameterMap_Segment_value)
                                wait_and_close_popup(page_object)
                                for_click(page_object,switchtab_MethodResultSetParameterMap_dataitem_dropdown)
                                wait_and_close_popup(page_object)
                                for_click(page_object,switchtab_MethodResultSetParameterMap_dataitem_value)
                                wait_and_close_popup(page_object)
                                # for_click(page_object,Method_ResultSet_Parameter_Map_save)
                                # wait_and_close_popup(page_object)
                            # Variable_not_resettable.logger.info(f"Parameter : {out_Param_name_value} was mapped")
                 
                                #time.sleep(.5)
                        except Exception as elementerror:
                            Variable_not_resettable.logger.error(f"Error processing element: {elementerror}")
                            continue 
                    try:
                        for_click(page_object, Method_ResultSet_Parameter_Map_save)  # Save the current page
                        Variable_not_resettable.logger.info(f"Overall save for page")
                        wait_and_close_popup(page_object)
                    except:
                        Variable_not_resettable.logger.info(f"Error captured in Save of the Methodresultsetparameter map table")
                        continue
    
                    try:
                        out_pageforwardbutton=locators_dictionary['out_pageforwardbutton']
                        # for_click(page_object,Method_ResultSet_Parameter_Map_save)
                        # Variable_not_resettable.logger.info(f"Overall save for page")
                        # wait_and_close_popup(page_object)
                        # time.sleep(.5)
                        for_click(page_object,out_pageforwardbutton)
                        wait_and_close_popup(page_object)
                        Variable_not_resettable.logger.info(f"forward_arrow clicked")
                        time.sleep(.5)
                    except Exception as forward_request_array_error:
                        Variable_not_resettable.logger.error(f"Reached last page of Resultsetparametermap or error occurred: {forward_request_array_error}")
                        break  # Break the loop if we can't click forward (i.e., last page reached)

                except Exception as main_loop_error:
                    Variable_not_resettable.logger.error(f"Error in the ResultsetParameter Map main loop: {main_loop_error}") # Break the loop if a critical error occurs outside the element processing

def replace_right(original, to_replace, replacement):
    parts = original.rsplit(to_replace, 1)
    return replacement.join(parts)

def for_select_combo_studio(page_object, selector, data):
    if str(data).lower() != "nan" and str(data).lower() != "na" and str(data) != "":
        try:
            page_object.wait_for_selector(selector, timeout= 5000)
            page_object.click(selector, timeout= Common_object.Timeout)
            value_path = replace_right(str(Common_controls.control_Value), "arrow", data)
            selectValue = "//*[@id ='"+value_path+"']"
            page_object.click(selectValue, timeout= Common_object.Timeout)
        except:
            force_click(page_object, selector)
            value_path = replace_right(str(Common_controls.control_Value), "arrow", data)
            #selectValue = "//*[@id ='"+value_path+"']"
            selectValue = "//*[@id ='"+value_path+"']"
            force_click(page_object, selectValue)
    else:
        Variable_not_resettable.logger.info("No data Found")
        raise Exception ("No data given for combo selection")
    

def force_click(page_object, locator):
    Variable_not_resettable.logger.info("JS force click")
    # Use evaluate to click the element found by XPath
    page_object.evaluate(f"""
        (function() {{
            var xpath = "{locator}";
            var element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            if (element) {{
                element.click();
            }} else {{
                console.error("Element not found: " + xpath);
            }}
        }})();
    """)


def select_option_in_combo_box(page_object, selector, value_to_select):
    """
    Selects an option in a <select> combo box using the value attribute.

    Args:
        page_object: The Playwright page object.
        selector: The CSS or XPath selector for the <select> element.
        value_to_select: The value attribute of the <option> to select.

    Raises:
        Exception: If the selection fails.
    """
    try:
        Variable_not_resettable.logger.info(f"Selecting value '{value_to_select}' in combo box with selector: {selector}")
        
        # Use Playwright's select_option to select by value
        page_object.locator(selector).select_option(value_to_select)
        
    except Exception as error:
        Variable_not_resettable.logger.error(f"Failed to select value in combo box: {error}")
        raise Exception(f"Failed to select value: {error}")





