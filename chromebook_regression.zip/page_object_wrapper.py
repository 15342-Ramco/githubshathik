from common_object import Common_data, Common_object, Common_step, Variable_not_resettable, Wrapper_variables, Common_controls
from split_data import *


def reset_default_value():
    

    Wrapper_variables.startsWithId = Wrapper_variables.containsId = Wrapper_variables.elementData = Wrapper_variables.lastIndex = Wrapper_variables.patternMatch = Wrapper_variables.tiles = Wrapper_variables.propType = Wrapper_variables.inputValue = ""
    Wrapper_variables.dataValue1 = Wrapper_variables.dataValue2 = Wrapper_variables.dataValue3 = Wrapper_variables.dataValue4 = Wrapper_variables.dataValue5  = ""
    Wrapper_variables.numberPart, tree, Wrapper_variables.frame = 0, "NO", None



def build_xpath_with_locator_reference(action, element_data):
    # Variable_not_resettable.logger.info("Build xpath using give control ID")
    element_data = str(element_data)
    element_data_direct = element_data
    # if (element_data.split("_").pop()).isdigit():
    #     Wrapper_variables.numberPart = element_data.split("_").pop()
    #     element_data = element_data.replace("_"+str(Wrapper_variables.numberPart), "")
    # Wrapper_variables.elementData = element_data
    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
        Wrapper_variables.elementData = element_data
        # if (Wrapper_variables.elementData.split("_").pop()).isdigit():
        #     Wrapper_variables.numberPart = element_data.split("_").pop()
        #     Wrapper_variables.elementData =Wrapper_variables.elementData.replace("_"+str(Wrapper_variables.numberPart), "")
        #element_data_nebula = element_data_original
        # print("Nebula co-existence case")
        Wrapper_variables.patternMatch = "NO"
        
    elif Variable_not_resettable.APP_TYPE == "Studio":
        Wrapper_variables.elementData = element_data
        Wrapper_variables.patternMatch = "NO"

    elif Variable_not_resettable.APP_TYPE == "Rapids":
        Wrapper_variables.elementData = element_data
        Wrapper_variables.patternMatch = "NO"
    
    elif str(Variable_not_resettable.APP_TYPE).lower() == "epubs":
        Wrapper_variables.elementData = element_data
        Wrapper_variables.patternMatch = "NO"
        
    else:
        if (element_data.split("_").pop()).isdigit():
            Wrapper_variables.numberPart = element_data.split("_").pop()
            element_data = element_data.replace("_"+str(Wrapper_variables.numberPart), "")
        Wrapper_variables.elementData = element_data
        match action:
            case 'Enter Text':
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("ramco") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("tbr") != -1 and  Wrapper_variables.elementData.find("fieldSearch") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("ramcolistedit") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"                    
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                        Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case 'Password Text':
                Common_step.is_password_text_first_time = True
                if Wrapper_variables.elementData.find("textfield") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif  Wrapper_variables.elementData.find("ramcopassword")!=-1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Click Button":
                if "_-" in Wrapper_variables.elementData:
                    if (Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                        Wrapper_variables.containsId = "btnInnerEl"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                        Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("fieldSearch") != -1) and (Wrapper_variables.elementData.find("trigger_search") != -1):
                    Wrapper_variables.containsId = "trigger-search"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_search", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Edit And Enter":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("numberfield") != -1 or Wrapper_variables.elementData.find(
                        "datefield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("_tbr") != -1 or Wrapper_variables.elementData.find("numberfield") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.patternMatch = "YES"
               
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"
            case "Select Combo":
                if (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1 or Wrapper_variables.elementData.find("ramcotagfield") != -1) and (
                        Wrapper_variables.elementData.find("trigger_picker") != -1):
                    if "_-" in Wrapper_variables.elementData:
                        Wrapper_variables.containsId = "trigger-picker"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                        Wrapper_variables.patternMatch = "YES"
                    elif (Wrapper_variables.elementData.split("_").pop()).isdigit():
                        Wrapper_variables.numberPart = Wrapper_variables.elementData.split("_").pop()
                        Wrapper_variables.containsId = "trigger-picker"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker"+"_"+Wrapper_variables.numberPart, "")
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    else:    
                        Wrapper_variables.containsId = "trigger-picker"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("fieldList")) != -1  and (Wrapper_variables.elementData.find("trigger_picker") != -1):
                    Wrapper_variables.containsId = "trigger-picker"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "Click Checkbox":
                if (Wrapper_variables.elementData.find("checkbox") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("check") != -1) and (Wrapper_variables.elementData.find("checkEl") != -1):
                    Wrapper_variables.containsId = "checkEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_checkEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Enter Text Area":
                if Wrapper_variables.elementData.find("textarea") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"
            case "Enter Number":
                if Wrapper_variables.elementData.find("numberfield") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"
            case "Clear Text":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("numberfield") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("datefield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1 or Wrapper_variables.elementData.find("timefield") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and (
                        Wrapper_variables.elementData.find("trigger_picker") != -1):
                    if (Wrapper_variables.elementData.split("_").pop()).isdigit():
                        Wrapper_variables.numberPart = Wrapper_variables.elementData.split("_").pop()
                        Wrapper_variables.containsId = "trigger-picker"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker"+"_"+Wrapper_variables.numberPart, "")
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    else:    
                        Wrapper_variables.containsId = "trigger-picker"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("fieldList")) != -1  and (Wrapper_variables.elementData.find("trigger_picker") != -1):
                    Wrapper_variables.containsId = "trigger-picker"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramcolistedit") != -1 and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"         
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"
            case "Click Link":
                if (Wrapper_variables.elementData.find("link") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramco") != -1 or Wrapper_variables.elementData.find("linkcolumn") != -1) and (
                        Wrapper_variables.elementData.find("textInnerEl") != -1):
                    Wrapper_variables.containsId = "textInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_textInnerEl", "")
                    if len(Wrapper_variables.startsWithId.split("_")) == 2:
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        if (Wrapper_variables.lastIndex != -1):
                            Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]

                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("ramco") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("link") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"

            case "Close Dialog2":
                if Wrapper_variables.elementData.find("tool") != -1:
                    Wrapper_variables.containsId = "toolEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_toolEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"

            case "Close Dialog":
                if Wrapper_variables.elementData.find("tool") != -1:
                    Wrapper_variables.containsId = "toolEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_toolEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"
            
            case "Click Help":
                if (Wrapper_variables.elementData.find("trigger_help") != -1):
                    Wrapper_variables.containsId = "trigger-help"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_help", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("ramcogridcolumn") != -1):
                    Wrapper_variables.containsId = "helpEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_helpEl", "")
                    if len(Wrapper_variables.startsWithId.split("_")) == 2:
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        if (Wrapper_variables.lastIndex != -1):
                            Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"

            case "Enter Date":
                if (Wrapper_variables.elementData.find("datefield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"

            case "Click Toggle":
                if (Wrapper_variables.elementData.find("ramcopanel") != -1) and (Wrapper_variables.elementData.find("header_title_textEl") != -1):
                    Wrapper_variables.containsId = "header-title-textEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_header_title_textEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("ramcopanel") != -1) and (Wrapper_variables.elementData.find("splitter_collapseEl") != -1):
                    Wrapper_variables.containsId = "splitter-collapseEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_splitter_collapseEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"

            case "Click Radio Button":
                if (Wrapper_variables.elementData.find("radio") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("radio") != -1) and (Wrapper_variables.elementData.find("displayEl") != -1):
                    Wrapper_variables.containsId = "displayEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_displayEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "List Edit Enter":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "Click Tab":
                if Wrapper_variables.elementData.find("tab") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"

            case "List Set Enter":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"
            case "Smart Search":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"

            case "Assert Smart Search":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"

            case "Grid Smart Search":
                # inputValues = str(Wrapper_variables.elementData).split(";")
                # Wrapper_variables.elementData = inputValues[0]
                # Wrapper_variables.objectValue = inputValues[1]
                Wrapper_variables.patternMatch = "NO"

            case "Grid Text":
                Wrapper_variables.patternMatch = "NO"

            case "Grid Text Enter":
                Wrapper_variables.patternMatch = "NO"

            case "Display Block":
                Wrapper_variables.patternMatch = "NO"
        
            case "Enter Time":
                if Wrapper_variables.elementData.find("ramcotimefield") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"
            case "Assert Text":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("numberfield") != -1 or Wrapper_variables.elementData.find(
                        "datefield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1 or Wrapper_variables.elementData.find(
                    "combofield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1 or Wrapper_variables.elementData.find("textarea") != -1 or Wrapper_variables.elementData.find("ramcotimefield") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("rowNav") != -1 and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"                    
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    # add later
                    Wrapper_variables.patternMatch = "NO"
            case "Assert Label Text":
                if Wrapper_variables.elementData.find("label") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("combofield") != -1) and Wrapper_variables.elementData.find("labelTextEl") != -1:
                    Wrapper_variables.containsId = "labelTextEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_labelTextEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("label") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramco") != -1 and Wrapper_variables.elementData.find("textInnerEl") != -1:
                    Wrapper_variables.containsId = "textInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_textInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("tab") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramcofileattach") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("radio") != -1 and Wrapper_variables.elementData.find("boxLabelEl") != -1:
                    Wrapper_variables.containsId = "boxLabelEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_boxLabelEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("ramcopanel") != -1) and (Wrapper_variables.elementData.find("header_title_textEl") != -1):
                    Wrapper_variables.containsId = "header-title-textEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_header_title_textEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("_tbr") != -1 and Wrapper_variables.elementData.find("dspRow") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Link Text":
                if Wrapper_variables.elementData.find("link") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Grid Table":
                if Wrapper_variables.elementData.find("_tbr_") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.patternMatch = "YES"
                    splitFieldSearchData(Common_data.data_value,Wrapper_variables.elementData)
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Button Text":
                if Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    # add later
                    Wrapper_variables.patternMatch = "NO"
            
            case 'Assert Object':
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("numberfield") != -1 or Wrapper_variables.elementData.find(
                        "datafield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1 or Wrapper_variables.elementData.find(
                    "ramcotimefield") != -1 or Wrapper_variables.elementData.find("textarea") != -1 or Wrapper_variables.elementData.find(
                    "ramcolistedit") != -1 or Wrapper_variables.elementData.find("label") != -1 or Wrapper_variables.elementData.find(
                    "combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1 or Wrapper_variables.elementData.find(
                    "ramco") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("radio") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1 or Wrapper_variables.elementData.find(
                        "ramcocombo") != -1) and (Wrapper_variables.elementData.find("trigger_picker") != -1):
                    Wrapper_variables.containsId = "trigger-picker"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramcofile") != -1) and (Wrapper_variables.elementData.find("fileInputEl") != -1):
                    Wrapper_variables.containsId = "fileInputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("fileInputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("link") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramco") != -1 or Wrapper_variables.elementData.find("linkcolumn") != -1) and (
                        Wrapper_variables.elementData.find("textInnerEl") != -1):
                    Wrapper_variables.containsId = "textInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_textInnerEl", "")
                    if len(Wrapper_variables.startsWithId.split("_")) == 2:
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        if Wrapper_variables.lastIndex != 1:
                            Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramco") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("trigger_help") != -1:
                    Wrapper_variables.containsId = "trigger-help"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_help", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcogridcolumn") != -1:
                    Wrapper_variables.containsId = "helpEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_helpEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramcopanel") != -1) and (Wrapper_variables.elementData.find("header_title_textEl") != -1):
                    Wrapper_variables.containsId = "header-title-textEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_header_title_textEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("_tab") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcotimefield") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    # print("inside split Assert button")
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("link") != -1:
                    Wrapper_variables.containsId = ""
                    # print("Assert icon")
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    # if len(Wrapper_variables.startsWithId.split("-")) == 3:
                    #     firstPos = Wrapper_variables.startsWithId.rfind("_")
                        # Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        # need to update
                elif (Wrapper_variables.elementData.find("checkbox") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("check") != -1) and (Wrapper_variables.elementData.find("checkEl") != -1):
                    Wrapper_variables.containsId = "checkEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_checkEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    #element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcoimage") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    # Need to update
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Click Theme":
                if Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("Themes") != -1:
                    Wrapper_variables.containsId =""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Click Button Icon":
                if (Wrapper_variables.elementData.find("fieldSearch") != -1) and (Wrapper_variables.elementData.find("trigger_search") != -1):
                    Wrapper_variables.containsId = "trigger-search"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_search", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("_tbr_") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("button") != -1) or (Wrapper_variables.elementData.find("link") != -1):
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    # print("Click Button else condition")
                    if len(Wrapper_variables.startsWithId.split("-"))== 3:
                        # print("Click Button else condition == 3")
                        firstPos = int(Wrapper_variables.startsWithId.find("-"))
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos]+ "_" + Wrapper_variables.startsWithId[firstPos+1 : len(Wrapper_variables.startsWithId)]
                    if len(Wrapper_variables.startsWithId.split("-")) == 4:
                        # print("Click Button else condition == 4")
                        firstPos = int(Wrapper_variables.startsWithId.find("-"))
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos]+ "_" + Wrapper_variables.startsWithId[firstPos+1 : len(Wrapper_variables.startsWithId)]
                        firstPos = int(Wrapper_variables.startsWithId.find("-"))
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos]+ "_" + Wrapper_variables.startsWithId[firstPos+1 : len(Wrapper_variables.startsWithId)]
                    if len(Wrapper_variables.startsWithId.split("-")) == 5:
                        # print("Click Button else condition == 5")
                        firstPos = int(Wrapper_variables.startsWithId.find("-"))
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos]+ "_" + Wrapper_variables.startsWithId[firstPos+1 : len(Wrapper_variables.startsWithId)]
                        # print("Wrapper_variables.startsWithId 1: ", Wrapper_variables.startsWithId)
                        firstPos = int(Wrapper_variables.startsWithId.find("-"))
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos]+ "_" + Wrapper_variables.startsWithId[firstPos+1 : len(Wrapper_variables.startsWithId)]
                        # print("Wrapper_variables.startsWithId 2: ", Wrapper_variables.startsWithId)
                        firstPos = int(Wrapper_variables.startsWithId.find("-"))
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos]+ "_" + Wrapper_variables.startsWithId[firstPos+1 : len(Wrapper_variables.startsWithId)]
                    # print("Wrapper_variables.startsWithId : ", Wrapper_variables.startsWithId)
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("icon") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.patternMatch = "YES"
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                elif Wrapper_variables.elementData.find("tool") != -1 and Wrapper_variables.elementData.find("toolEl") != -1:
                    Wrapper_variables.containsId = "toolEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_toolEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES" 
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Enter Grid Page":
                if ((Wrapper_variables.elementData.find("tbr") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1)):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Assert Combo Selection":
                if ((Wrapper_variables.elementData.find("combofield") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1)):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif ((Wrapper_variables.elementData.find("combofield") != -1) or (Wrapper_variables.elementData.find("ramcocombo") != -1)) and (Wrapper_variables.elementData.find("trigger_picker") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif ((Wrapper_variables.elementData.find("ramcorslistview") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1)):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            
            case "Assert Non-editable":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("numberfield") != -1 or Wrapper_variables.elementData.find(
                        "datafield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1 or Wrapper_variables.elementData.find(
                    "ramcotimefield") != -1 or Wrapper_variables.elementData.find("textarea") != -1 or Wrapper_variables.elementData.find(
                    "ramcolistedit") != -1 or Wrapper_variables.elementData.find("label") != -1 or Wrapper_variables.elementData.find(
                    "combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1 or Wrapper_variables.elementData.find(
                    "ramco") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # print(Wrapper_variables.startsWithId)
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("radio") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1 or Wrapper_variables.elementData.find(
                        "ramcocombo") != -1) and (Wrapper_variables.elementData.find("trigger_picker") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    # print("test")
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # print(Wrapper_variables.startsWithId)
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramcofile") != -1) and (Wrapper_variables.elementData.find("fileInputEl") != -1):
                    Wrapper_variables.containsId = "fileInputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("fileInputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("link") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramco") != -1 or Wrapper_variables.elementData.find("linkcolumn") != -1) and (
                        Wrapper_variables.elementData.find("textInnerEl") != -1):
                    Wrapper_variables.containsId = "textInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_textInnerEl", "")
                    if len(Wrapper_variables.startsWithId.split("_")) == 2:
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        if Wrapper_variables.lastIndex != 1:
                            Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramco") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("trigger_help") != -1:
                    Wrapper_variables.containsId = "trigger-help"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_help", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcogridcolumn") != -1:
                    Wrapper_variables.containsId = "helpEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_helpEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramcopanel") != -1) and (Wrapper_variables.elementData.find("header_title_textEl") != -1):
                    Wrapper_variables.containsId = "header-title-textEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_header_title_textEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("tab") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcotimefield") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("link") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    if len(Wrapper_variables.startsWithId.split("-")) == 3:
                        firstPos = Wrapper_variables.startsWithId.rfind("_")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                        # need to update
                elif (Wrapper_variables.elementData.find("checkbox") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("check") != -1) and (Wrapper_variables.elementData.find("checkEl") != -1):
                    Wrapper_variables.containsId = "checkEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_checkEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcoimage") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    # Need to update
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Visible":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("numberfield") != -1 or Wrapper_variables.elementData.find(
                    "datafield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1 or Wrapper_variables.elementData.find(
                    "ramcotimefield") != -1 or Wrapper_variables.elementData.find("textarea") != -1 or Wrapper_variables.elementData.find(
                    "ramcolistedit") != -1 or Wrapper_variables.elementData.find("label") != -1 or Wrapper_variables.elementData.find(
                    "combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1 or Wrapper_variables.elementData.find(
                    "ramco") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # print(Wrapper_variables.startsWithId)
                elif (Wrapper_variables.elementData.find("radio") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1 or Wrapper_variables.elementData.find(
                        "ramcocombo") != -1) and (Wrapper_variables.elementData.find("trigger_picker") != -1):
                    Wrapper_variables.containsId = "trigger-picker"
                    # print("test")
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # print(Wrapper_variables.startsWithId)
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramcofile") != -1) and (Wrapper_variables.elementData.find("fileInputEl") != -1):
                    Wrapper_variables.containsId = "fileInputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("fileInputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("link") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramco") != -1 or Wrapper_variables.elementData.find("linkcolumn") != -1) and (
                        Wrapper_variables.elementData.find("textInnerEl") != -1):
                    Wrapper_variables.containsId = "textInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_textInnerEl", "")
                    if len(Wrapper_variables.startsWithId.split("_"))== 2:
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        if Wrapper_variables.lastIndex != 1:
                            Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramco") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("trigger_help") != -1:
                    Wrapper_variables.containsId = "trigger-help"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_help", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcogridcolumn") != -1:
                    Wrapper_variables.containsId = "helpEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_helpEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramcopanel") != -1) and (Wrapper_variables.elementData.find("header_title_textEl") != -1):
                    Wrapper_variables.containsId = "header-title-textEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_header_title_textEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("tab") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcotimefield") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("link") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    if len(Wrapper_variables.startsWithId.split("-")) == 3:
                        firstPos = Wrapper_variables.startsWithId.rfind("_")
                        # Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        # need to update
                elif (Wrapper_variables.elementData.find("checkbox") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("check") != -1) and (Wrapper_variables.elementData.find("checkEl") != -1):
                    Wrapper_variables.containsId = "checkEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_checkEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcoimage") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    # Need to update
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Non-Visible":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("numberfield") != -1 or Wrapper_variables.elementData.find(
                        "datafield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1 or Wrapper_variables.elementData.find(
                    "ramcotimefield") != -1 or Wrapper_variables.elementData.find("textarea") != -1 or Wrapper_variables.elementData.find(
                    "ramcolistedit") != -1 or Wrapper_variables.elementData.find("label") != -1 or Wrapper_variables.elementData.find(
                    "combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1 or Wrapper_variables.elementData.find(
                    "ramco") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # print(Wrapper_variables.startsWithId)
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("radio") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1 or Wrapper_variables.elementData.find(
                        "ramcocombo") != -1) and (Wrapper_variables.elementData.find("trigger_picker") != -1):
                    Wrapper_variables.containsId = "trigger-picker"
                    # print("test")
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # print(Wrapper_variables.startsWithId)
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramcofile") != -1) and (Wrapper_variables.elementData.find("fileInputEl") != -1):
                    Wrapper_variables.containsId = "fileInputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("fileInputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("link") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    # element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramco") != -1 or Wrapper_variables.elementData.find("linkcolumn") != -1) and (
                        Wrapper_variables.elementData.find("textInnerEl") != -1):
                    Wrapper_variables.containsId = "textInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_textInnerEl", "")
                    if len(Wrapper_variables.startsWithId.split("_")) == 2:
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        if Wrapper_variables.lastIndex != 1:
                            Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramco") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("trigger_help") != -1:
                    Wrapper_variables.containsId = "trigger-help"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_help", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcogridcolumn") != -1:
                    Wrapper_variables.containsId = "helpEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_helpEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramcopanel") != -1) and (Wrapper_variables.elementData.find("header_title_textEl") != -1):
                    Wrapper_variables.containsId = "header-title-textEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_header_title_textEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("tab") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcotimefield") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != 1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("link") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    if len(Wrapper_variables.startsWithId.split("-")) == 3:
                        firstPos = Wrapper_variables.startsWithId.rfind("_")
                        # Not yet used 
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("checkbox") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("check") != -1) and (Wrapper_variables.elementData.find("checkEl") != -1):
                    Wrapper_variables.containsId = "checkEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_checkEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif Wrapper_variables.elementData.find("ramcoimage") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    # Need to update
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Click Recent Activities":
                if Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("Menu") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
        
            case "Click TrailBar":
                if Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("TrailBar") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Attach Document":
                if Wrapper_variables.elementData.find("filefield") != -1 or Wrapper_variables.elementData.find("_button_fileInputEl") != -1:
                    Wrapper_variables.containsId = "button-fileInputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_button_fileInputEl", "")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId.replace("_", "-")
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("file") != -1 and Wrapper_variables.elementData.find("fileInputEl") != -1:
                    Wrapper_variables.containsId = "fileInputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_fileInputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramcofile") != -1 and Wrapper_variables.elementData.find("browse") != -1:
                    Wrapper_variables.containsId = "trigger-browse"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_browse", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("filefield") != -1 or Wrapper_variables.elementData.find("button_fileInputEl") != -1:
                    Wrapper_variables.containsId = "button-fileInputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_button_fileInputEl", "")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId.replace("_", "-")
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramcoimage") != -1 or Wrapper_variables.elementData.find("_trigger_browse") != -1: 
                    Wrapper_variables.containsId = "trigger-browse" 
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_browse", "") 
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_") 
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:] 
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"
            case "Scroll To Element":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("numberfield") != -1 or Wrapper_variables.elementData.find("datefield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1 or Wrapper_variables.elementData.find("ramcotimefield") != -1 or Wrapper_variables.elementData.find("textarea") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1 or Wrapper_variables.elementData.find("label") != -1 or Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("radio") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and Wrapper_variables.elementData.find("trigger_picker") != -1:
                    Wrapper_variables.containsId = "trigger-picker"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramcofile") != -1 and Wrapper_variables.elementData.find("fileInputEl") != -1:
                    Wrapper_variables.containsId = "fileInputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_fileInputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("link") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramco") != -1 or Wrapper_variables.elementData.find("linkcolumn") != -1 and Wrapper_variables.elementData.find("textInnerEl") != -1:
                    Wrapper_variables.containsId = "textInnerEl"
                    Wrapper_variables.startsWithId =Wrapper_variables.elementData.replace("_textInnerEl", "")
                    if len(Wrapper_variables.startsWithId.split("_")) == 2:
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        if(Wrapper_variables.lastIndex != -1):
                            Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramco") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("trigger_help") != -1:
                    Wrapper_variables.containsId = "trigger-help"
                    Wrapper_variables.startsWithId =Wrapper_variables.elementData.replace("_trigger_help", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramcogridcolumn") != -1:
                    Wrapper_variables.containsId = "helpEl"
                    Wrapper_variables.startsWithId =Wrapper_variables.elementData.replace("_helpEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramcopanel") != -1 and Wrapper_variables.elementData.find("header_title_textEl") != -1:
                    Wrapper_variables.containsId = "header-title-textEl"
                    Wrapper_variables.startsWithId =Wrapper_variables.elementData.replace("_header_title_textEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("tab") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramcotimefield") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId =Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):        
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("link") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    if len(Wrapper_variables.startsWithId.split("-")) == 3:
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                    elif len(Wrapper_variables.startsWithId.split("-")) == 4:
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("checkbox") != -1 and  Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("check") != -1 and Wrapper_variables.elementData.find("checkEl") != -1:
                    Wrapper_variables.containsId = "checkEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_checkEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramcoimage") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId =Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if len(Wrapper_variables.startsWithId.split("-")) == 3:
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("_tbr_") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Import File":
                if Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("link") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId =Wrapper_variables.elementData.replace("_", "-")
                    if len(Wrapper_variables.startsWithId.split("-"))== 3:
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                    elif len(Wrapper_variables.startsWithId.split("-"))== 4:
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                    elif len(Wrapper_variables.startsWithId.split("-"))== 5:
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                        
                elif Wrapper_variables.elementData.find("_tbr_") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Export File":
                if Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("link") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    if len(Wrapper_variables.startsWithId.split("-"))== 3:
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                    elif len(Wrapper_variables.startsWithId.split("-"))== 4:
                        firstPos =Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        firstPos =Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                    elif len(Wrapper_variables.startsWithId.split("-"))== 5:
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("_tbr_") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Click ID With Text":
                Wrapper_variables.patternMatch = "NO"
            
            case "Click Wizard":
                if((Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("Default") != -1)):
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace( "_", "-")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Click Link with Class":
                Wrapper_variables.containsId = ""
                Wrapper_variables.patternMatch = "NO"
                Wrapper_variables.propType = "YES"

            case "Click OK Button":
                if Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):        
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Click Show Help":
                if Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("Help") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            # Page action and play_code is done upto here
            
            case "Click Tile Bottom Left Link":
                if Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace(Wrapper_variables.elementData, "_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind(Wrapper_variables.startsWithId, "_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.tiles = "YES"
                
            case "Assert Tile Body":
                if Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.tiles = "YES"
                    splitDataValue()

            case "Assert Tile Bottom Left Data":
                if Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.tiles = "YES"

            case "Assert Tile Bottom Right Data":
                if Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.tiles = "YES"

            case "Assert Tile Header":
                if Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.tiles = "YES"

            case "Click Hub DisplayBlock Icon":
                Wrapper_variables.containsId = ""
                #//classname = Wrapper_variables.elementData;
                Wrapper_variables.patternMatch = "NO"

            case "Click Hub DisplayBlock Text":
                Wrapper_variables.containsId = ""
                #//classname = Wrapper_variables.elementData;
                Wrapper_variables.patternMatch = "NO"
                # splitFieldSearchData()

            case "Click UserMenu Option":
                if Wrapper_variables.elementData.find("button") != -1 and Wrapper_variables.elementData.find("userMenu") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Select Button Combo":
                if (Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("combo")) != -1 and Wrapper_variables.elementData.find("arrowEl")!= -1:
                    Wrapper_variables.containsId = "arrowEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_arrowEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("combo")) != -1 and  Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "List Edit Select":
                if Wrapper_variables.elementData.find("ramcolistedit") != -1 and Wrapper_variables.elementData.find("trigger_picker") != -1:
                    Wrapper_variables.containsId = "trigger-picker"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "Multi Select Combo":
                if Wrapper_variables.elementData.find("ramcorslistview") != -1 and Wrapper_variables.elementData.find("trigger_picker") != -1:
                    Wrapper_variables.containsId = "trigger-picker"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Assert Tree Grid":
                Wrapper_variables.tree = "YES"
                splitTreeGridDataValue(Common_data.data_value)
            
            case "Grid Tool Bar":
                if Wrapper_variables.elementData.find("tbr") != -1 or Wrapper_variables.elementData.find("tBar") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Grid Search Link":
                if Wrapper_variables.elementData.find("textfield") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("fieldSearch") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "Grid Search Select":
                if Wrapper_variables.elementData.find("fieldSearch") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    splitFieldSearchData(Common_data.data_value,Wrapper_variables.elementData)
                else:
                    Wrapper_variables.patternMatch = "NO"
                    splitFieldSearchData(Common_data.data_value,Wrapper_variables.elementData)
            
            case "Grid Search Single Select":
                if Wrapper_variables.elementData.find("fieldSearch") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    splitFieldSearchData(Common_data.data_value,Wrapper_variables.elementData)
                    if len(Wrapper_variables.startsWithId.split("_"))== 2:
                        Wrapper_variables.containsId = "inputEl"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                        Wrapper_variables.patternMatch = "YES"
                        splitFieldSearchData(Common_data.data_value,Wrapper_variables.elementData)
                else:
                    Wrapper_variables.patternMatch = "NO"
                    splitFieldSearchData(Common_data.data_value,Wrapper_variables.elementData)

            case "Grid Search Zoom Edit":
                if Wrapper_variables.elementData.find("fieldSearch") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    splitFieldSearchData(Common_data.data_value,Wrapper_variables.elementData)
                else:
                    Wrapper_variables.patternMatch = "NO"
                    splitFieldSearchData(Common_data.data_value,Wrapper_variables.elementData)

            case "Click Tile Header":
                if Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if(Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.tiles = "YES"

            case "Display Block Link":
                Wrapper_variables.tiles = "YES"
            
            case "Expand Child Tree":
                if Wrapper_variables.elementData == "" or   Wrapper_variables.elementData == "NA" or str(Wrapper_variables.elementData) == "None":
                    Wrapper_variables.tree = "YES"
                else:
                    idValue = element_data_direct
                    rowIndex = int(idValue.find("row"))
                    length = len(idValue)
                    firstPart = idValue[0: rowIndex+3]
                    lastPart = idValue[rowIndex+3:]
                    lastPart = lastPart.replace("_", "-")
                    Wrapper_variables.startsWithId = firstPart + lastPart
                    Wrapper_variables.tree = "YES"

            case "Click Tree Grid":
                Wrapper_variables.tree = "YES"
                splitTreeGridDataValue(Common_data.data_value)

            case "Click Tree Item":
                if element_data_direct == "" or   element_data_direct == "NA":
                    Wrapper_variables.tree = "YES"
                else:
                    idValue = element_data_direct
                    rowIndex = int(idValue.find("row"))
                    length = len(idValue)
                    firstPart = idValue[0: rowIndex+3]
                    lastPart = idValue[rowIndex+3:]
                    lastPart = lastPart.replace("_", "-")
                    Wrapper_variables.startsWithId = firstPart + lastPart
                    Wrapper_variables.tree = "YES"
            
            case "Expand Tree":
                if Wrapper_variables.elementData == "" or   Wrapper_variables.elementData == "NA":
                    Wrapper_variables.tree = "YES"
                else:
                    idValue = element_data_direct
                    rowIndex = int(idValue.find("row"))
                    length = len(idValue)
                    firstPart = idValue[0: rowIndex+3]
                    lastPart = idValue[rowIndex+3:]
                    lastPart = lastPart.replace("_", "-")
                    Wrapper_variables.startsWithId = firstPart + lastPart
                    Wrapper_variables.tree = "YES"

            case "Save Data":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1 or Wrapper_variables.elementData.find("ramcolabel") != -1 or Wrapper_variables.elementData.find("datefield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1 or Wrapper_variables.elementData.find("numberfield") != -1 or Wrapper_variables.elementData.find("textarea") != -1) and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    # print("First case Save Data")
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("link") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and Wrapper_variables.elementData.find("trigger_picker") != -1:                
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    # print("Else case Save Data")
                    Wrapper_variables.patternMatch = "NO"

            case "Click Data Hyperlink":
                Wrapper_variables.patternMatch = "NO"

            case "Grid Attach Document":
                Wrapper_variables.patternMatch = "NO"
            
            case "Click Ganttchart Checkbox":
                Wrapper_variables.tiles = "YES"

            case "Click Ganttchart Expand":
                Wrapper_variables.tiles = "YES"

            case "Grid Zoom Insert Row":
                Wrapper_variables.patternMatch = "NO"

            case "Grid Search Edit Grid":
                splitFieldSearchObject_ntimes(Common_data.data_value, element_data_direct)
                if (Wrapper_variables.elementData.find("fieldSearch")) != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId.split("_").pop()
                    Wrapper_variables.patternMatch = "YES"
                    # print(Wrapper_variables.startsWithId)
                    # print(Wrapper_variables.containsId)
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Grid Status":
                splitFieldSearchObject(str(Common_data.data_value), element_data_direct)
                Wrapper_variables.patternMatch = "NO"
            
            case "Assert Grid Search Value":
                splitFieldSearchObject_ntimes(Common_data.data_value, element_data_direct)
                if (Wrapper_variables.elementData.find("fieldSearch")) != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId.split("_").pop()
                    Wrapper_variables.patternMatch = "YES"
                    # print(Wrapper_variables.startsWithId)
                    # print(Wrapper_variables.containsId)
                else:
                    Wrapper_variables.patternMatch = "NO"

            
            case "Click Tree Checkbox":
                if Wrapper_variables.elementData == "" or   Wrapper_variables.elementData == "NA" or str(Wrapper_variables.elementData) == "None":
                    Wrapper_variables.tree = "YES"
                else:
                    idValue = element_data_direct
                    rowIndex = int(idValue.find("row"))
                    length = len(idValue)
                    firstPart = idValue[0: rowIndex+3]
                    lastPart = idValue[rowIndex+3:]
                    lastPart = lastPart.replace("_", "-")
                    Wrapper_variables.startsWithId = firstPart + lastPart
                    Wrapper_variables.tree = "YES"
            case "Assert PDF":
                if (Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Checkbox Check":
                if (Wrapper_variables.elementData.find("checkbox") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("check") != -1) and (Wrapper_variables.elementData.find("checkEl") != -1):
                    Wrapper_variables.containsId = "checkEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_checkEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Checkbox Uncheck":
                if (Wrapper_variables.elementData.find("checkbox") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("check") != -1) and (Wrapper_variables.elementData.find("checkEl") != -1):
                    Wrapper_variables.containsId = "checkEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_checkEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Multi Select Search Combo":
                if Wrapper_variables.elementData.find("ramcorslistview") != -1 and Wrapper_variables.elementData.find("trigger_picker") != -1:
                    Wrapper_variables.containsId = "trigger-picker"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Click Template Toolbar":
                if Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("Template") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Combo List":
                if (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and (
                        Wrapper_variables.elementData.find("trigger_picker") != -1):
                    if (Wrapper_variables.elementData.split("_").pop()).isdigit():
                        Wrapper_variables.numberPart = Wrapper_variables.elementData.split("_").pop()
                        Wrapper_variables.containsId = "trigger-picker"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker"+"_"+Wrapper_variables.numberPart, "")
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    else:    
                        Wrapper_variables.containsId = "trigger-picker"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "Assert Sort Table Asc":
                if Wrapper_variables.elementData.find("_tbr_") != -1:
                    Wrapper_variables.containsId = "btnIconEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.split("_tbr_")[0]
                    Wrapper_variables.patternMatch = "YES"
                    splitFieldSearchData(Common_data.data_value,Wrapper_variables.elementData)
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Sort Table Dsc":
                if Wrapper_variables.elementData.find("_tbr_") != -1:
                    Wrapper_variables.containsId = "btnIconEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.split("_tbr_")[0]
                    Wrapper_variables.patternMatch = "YES"
                    splitFieldSearchData(Common_data.data_value,Wrapper_variables.elementData)
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "Grid XML Compare":
                Wrapper_variables.patternMatch = "NO"
            
            case "Assert Checkbox":
                if (Wrapper_variables.elementData.find("checkbox") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("check") != -1) and (Wrapper_variables.elementData.find("checkEl") != -1):
                    Wrapper_variables.containsId = "checkEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_checkEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Checkbox With Data":
                if (Wrapper_variables.elementData.find("checkbox") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("check") != -1) and (Wrapper_variables.elementData.find("checkEl") != -1):
                    Wrapper_variables.containsId = "checkEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_checkEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Grid Search Correlate Link":
                Wrapper_variables.patternMatch = "NO"

            case "PDF Validation":
                if (Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("fieldSearch") != -1) and (Wrapper_variables.elementData.find("trigger_search") != -1):
                    Wrapper_variables.containsId = "trigger-search"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_search", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Enumerate Combo List":
                if (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and (
                        Wrapper_variables.elementData.find("trigger_picker") != -1):
                    if (Wrapper_variables.elementData.split("_").pop()).isdigit():
                        Wrapper_variables.numberPart = Wrapper_variables.elementData.split("_").pop()
                        Wrapper_variables.containsId = "inputEl"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker"+"_"+Wrapper_variables.numberPart, "")
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    else:    
                        Wrapper_variables.containsId = "inputEl"
                        Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            case "Assert UI Grid Asc":
                if Wrapper_variables.elementData.find("ramcogridcolumn") != -1:
                    Wrapper_variables.containsId = "textInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_textInnerEl", "")
                    # Variable_not_resettable.logger.debug(f"Wrapper_variables.startsWithId : {Wrapper_variables.startsWithId}")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert UI Grid Dsc":
                if Wrapper_variables.elementData.find("ramcogridcolumn") != -1:
                    Wrapper_variables.containsId = "textInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_textInnerEl", "")
                    # Variable_not_resettable.logger.debug(f"Wrapper_variables.startsWithId : {Wrapper_variables.startsWithId}")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "Validate Grid Negative Values":
                if Wrapper_variables.elementData.find("_tbr_") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "Assert Grid Search Focus":
                splitFieldSearchObject_ntimes(Common_data.data_value, element_data_direct)
                if (Wrapper_variables.elementData.find("fieldSearch")) != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "_" + Wrapper_variables.startsWithId.split("_").pop()
                    Wrapper_variables.patternMatch = "YES"
                    # print(Wrapper_variables.startsWithId)
                    # print(Wrapper_variables.containsId)
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "Assert Display Block Value":
                Wrapper_variables.patternMatch = "NO"

            case "Assert Grid Display Block":
                Wrapper_variables.patternMatch = "NO"

            case "Save Data In Input Docs":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcolistedit") != -1 or Wrapper_variables.elementData.find("ramcolabel") != -1 or Wrapper_variables.elementData.find("datefield") != -1 or Wrapper_variables.elementData.find("ramcodatetimefield") != -1 or Wrapper_variables.elementData.find("numberfield") != -1 or Wrapper_variables.elementData.find("textarea") != -1) and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    # print("First case Save Data")
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("link") != -1 and Wrapper_variables.elementData.find("btnInnerEl") != -1:
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("combofield") != -1 or Wrapper_variables.elementData.find("ramcocombo") != -1) and Wrapper_variables.elementData.find("trigger_picker") != -1:                
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_picker", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Style":
                if (Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("fieldSearch") != -1) and (Wrapper_variables.elementData.find("trigger_search") != -1):
                    Wrapper_variables.containsId = "trigger-search"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_search", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Excel":
                if (Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO" 
                     
            case "Assert Grid Disable":
                if (Wrapper_variables.elementData.find("details_") != -1) or (Wrapper_variables.elementData.find("ramcogrid") != -1):
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"

            case "Assert Docs":
                if (Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert CSV":
                if (Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("ramcofileattach") != -1 and Wrapper_variables.elementData.find("inputEl") != -1:
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
            
            case "Assert Grid Icon Status":
                Wrapper_variables.patternMatch = "NO"

            case "MultiSort Drag and Drop":
                splitFieldSearchObject(Common_data.data_value, element_data_direct)
                Wrapper_variables.patternMatch = "NO"

            case "Dynamic Grid Uncheck":
                Wrapper_variables.patternMatch = "NO"

            case "Assert Enumerated Grid Smart Search":
                Wrapper_variables.patternMatch = "NO"

            case "Assert Grid Smart Search":
                Wrapper_variables.patternMatch = "NO"

            case "Asserting Available Value In SS":
                Wrapper_variables.patternMatch = "NO"

            case "Report Launch":
                if (Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("fieldSearch") != -1) and (Wrapper_variables.elementData.find("trigger_search") != -1):
                    Wrapper_variables.containsId = "trigger-search"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_search", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Assert Grid UI Values":
                if Wrapper_variables.elementData.find("button") != -1 or Wrapper_variables.elementData.find("link") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_", "-")
                    if len(Wrapper_variables.startsWithId.split("-"))== 3:
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                    elif len(Wrapper_variables.startsWithId.split("-"))== 4:
                        firstPos =Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        firstPos =Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                    elif len(Wrapper_variables.startsWithId.split("-"))== 5:
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        firstPos = Wrapper_variables.startsWithId.find("-")
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:firstPos] + "-" + Wrapper_variables.startsWithId[:firstPos+1], Wrapper_variables.startsWithId[:firstPos-1:]
                        Wrapper_variables.patternMatch = "YES"
                elif Wrapper_variables.elementData.find("_tbr_") != -1:
                    Wrapper_variables.containsId = ""
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Click nth Display Block":
                splitted_control=(Wrapper_variables.elementData).split(";")[1]
                if (((Wrapper_variables.elementData).split(";")[1]).find("button") != -1):
                    Wrapper_variables.containsId = "btnIconEl"
                    Wrapper_variables.startsWithId = splitted_control
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
            
            case "Click nth Grid Column":
                Wrapper_variables.patternMatch = "NO"

            case "Assert Downloaded Excel Column":
                if (Wrapper_variables.elementData.find("button") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if Wrapper_variables.lastIndex != -1:
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("fieldSearch") != -1) and (Wrapper_variables.elementData.find("trigger_search") != -1):
                    Wrapper_variables.containsId = "trigger-search"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_trigger_search", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

            case "Click By Xpath":
                if Common_controls.control_Identifier == "xpath":
                    Wrapper_variables.XpathPattern = "YES"
                else:
                    raise Exception("Identifier missing in Control sheet")

            case "Drag and Drop Grid Column":
                splitFieldSearchObject_for_drag_and_drop(Common_data.data_value, element_data_direct)
                Wrapper_variables.patternMatch = "NO"

            case "Assert Object Inbetween":
                splitFieldSearchObject_for_drag_and_drop(Common_data.data_value, element_data_direct)
                Wrapper_variables.patternMatch = "NO"
            
            case "Document Assertion":
                if (Wrapper_variables.elementData.find("link") != -1) and (Wrapper_variables.elementData.find("btnInnerEl") != -1):
                    Wrapper_variables.containsId = "btnInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_btnInnerEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.startsWithId + "')]//*[contains(@id, '" + Wrapper_variables.containsId + "')]"
                elif (Wrapper_variables.elementData.find("ramco") != -1 or Wrapper_variables.elementData.find("linkcolumn") != -1) and (
                        Wrapper_variables.elementData.find("textInnerEl") != -1):
                    Wrapper_variables.containsId = "textInnerEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_textInnerEl", "")
                    if len(Wrapper_variables.startsWithId.split("_")) == 2:
                        Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                        if (Wrapper_variables.lastIndex != -1):
                            Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]

                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("ramco") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("link") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"
                    element = "//*[starts-with(@id,'" + Wrapper_variables.elementData + "')]"
            
            case "List Set Enter - Saasy":
                if Common_controls.control_Identifier == "xpath":
                    Wrapper_variables.XpathPattern = "YES"
                else:
                    raise Exception("Identifier missing in Control sheet")
                
            case "Wait for Status":
                Wrapper_variables.XpathPattern = "NO"

            case "Hover And Click":
                Wrapper_variables.XpathPattern = "NO"
                
            case "Enter Text:Wait:Esc":
                if (Wrapper_variables.elementData.find("textfield") != -1 or Wrapper_variables.elementData.find("ramco") != -1) and (
                        Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("tbr") != -1 and  Wrapper_variables.elementData.find("fieldSearch") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.patternMatch = "YES"
                elif (Wrapper_variables.elementData.find("ramcolistedit") != -1) and (Wrapper_variables.elementData.find("inputEl") != -1):
                    Wrapper_variables.containsId = "inputEl"                    
                    Wrapper_variables.startsWithId = Wrapper_variables.elementData.replace("_inputEl", "")
                    Wrapper_variables.lastIndex = Wrapper_variables.startsWithId.rfind("_")
                    if (Wrapper_variables.lastIndex != -1):
                        Wrapper_variables.startsWithId = Wrapper_variables.startsWithId[:Wrapper_variables.lastIndex] + "-" + Wrapper_variables.startsWithId[Wrapper_variables.lastIndex + 1:]
                        Wrapper_variables.patternMatch = "YES"
                else:
                    Wrapper_variables.patternMatch = "NO"

def check_element_present(page_object, Xpath):
    try:
        return page_object.selector(Xpath, 10)
    except:
        return None

def get_locator(page_object, action, element_data: str, loop_count):

        elementData = str(element_data)
        build_xpath_with_locator_reference(action, element_data)
        if Wrapper_variables.tiles == "YES":
            if Common_step.ACTION == "Assert Tile Header":
                firstTile_xpath = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]/table/tbody/tr/td//table[1]/tbody/tr/td[1][text()='"+Common_data.data_value+"']"
                firstTile = check_element_present(page_object, firstTile_xpath)
                secondTile_xpath ="//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]/table/tbody/tr/td/div[text()='"+Common_data.data_value+"']"
                secondTile = check_element_present(page_object, secondTile_xpath)
                if secondTile != None:
                    element = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]/table/tbody/tr/td/div[text()='"+Common_data.data_value+"']"
                elif(firstTile != None):
                    element = ("//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]/table/tbody/tr/td//table[1]/tbody/tr/td[1][text()='"+Common_data.data_value+"']")
            elif (Common_step.ACTION == "Assert Tile Body"):
                element = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]//td[@class = 'row_attri'][text()='"+Wrapper_variables.dataValue1+"']/../td[@class='row_value'][text()='"+Wrapper_variables.dataValue2+"']"
            elif(Common_step.ACTION == "Click Tile Header"):
                firstTile_xpath = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]//td[@class ='right_align link']/img"
                firstTile = check_element_present(page_object, firstTile_xpath)
                secondTile_xpath = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]/table/tbody/tr/td/table[1]/tbody/tr/td[2]/img"
                secondTile = check_element_present(page_object, secondTile_xpath)
                if(secondTile != None):
                    element = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]/table/tbody/tr/td/table[1]/tbody/tr/td[2]/img"
                elif(firstTile != None):
                    element = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]//td[@class ='right_align link']/img"
            elif (Common_step.ACTION == "Assert Tile Bottom Left Data"):
                pass
            elif (Common_step.ACTION == "Assert Tile Bottom Right Data"):
                firstTile_xpath = "//div[starts-with(@id,'dsppendingwork_disp-ramcolabel')]//*[contains(@id, 'inputEl')]/table/tbody/tr/td/table[3]/tbody/tr/td[2]/span[text()='"+Common_data.data_value+"']"
                firstTile = check_element_present(page_object, firstTile_xpath)
                secondTile_xpath = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '" +Wrapper_variables.containsId+"')]//td[@class ='add_right'][text()='"+Common_data.data_value+"']"
                secondTile = check_element_present(page_object, secondTile_xpath)
                if(secondTile != None):
                    element = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]//td[@class ='add_right'][text()='"+Common_data.data_value+"']"
                elif(firstTile != None):
                    element = "//div[starts-with(@id,'dsppendingwork_disp-ramcolabel')]//*[contains(@id, 'inputEl')]/table/tbody/tr/td/table[3]/tbody/tr/td[2]/span[text()='"+Common_data.data_value+"']"
            elif(Common_step.ACTION == "Click Tile Bottom Left Link"):
                firstTile_xpath = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '" +Wrapper_variables.containsId+"')]//td[@class ='add_left']/span[text()='"+Common_data.data_value+"']"
                firstTile = check_element_present(page_object, firstTile_xpath)
                secondTile_xpath = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId +"')]/table/tbody/tr/td/table[2]/tbody/tr/td[1]/span[text()='"+Common_data.data_value+"']"
                secondTile = check_element_present(page_object, secondTile_xpath)
                if(secondTile != None):
                    element = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]/table/tbody/tr/td/table[2]/tbody/tr/td[1]/span[text()='"+Common_data.data_value+"']"
                elif(firstTile != None):
                    element = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]//td[@class ='add_left']/span[text()='"+Common_data.data_value+"']"
            elif(Common_step.ACTION == "Click Tile Bottom Right Link"):
                element = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]//td[@class ='add_right']/span[text()='"+Common_data.data_value+"']"
            elif(Common_step.ACTION == "Display Block Link"):
                element = "//div[@id='"+elementData+"']/div/div[4]/div[text()='"+Common_data.data_value+"']"
            elif (Common_step.ACTION == "Click Ganttchart Checkbox"):
                element = ("//*[@id='WMC_Gantt']//*[contains(@class, 'CEClassReadOnly')][text()='"+str(Common_data.data_value)+"']")
            elif (Common_step.ACTION == "Click Ganttchart Expand"):
                element = ("//*[@id='WMC_Gantt']//*[contains(@class, 'CEClassReadOnly')][text()='"+str(Common_data.data_value)+"']//preceding-sibling::td[1]")
        
        elif (Wrapper_variables.tree == "YES"):
            if (Common_step.ACTION == "Assert Tree Grid"):
                    element = "//table[@id='tb']//tr[@class= 'CEDataRow ']["+Wrapper_variables.dataValue1+"]//td["+Wrapper_variables.dataValue2+"]"
            elif(Common_step.ACTION == "Click Tree Grid"):
                    element = "//table[@id='tb']//tr[@class= 'CEDataRow ']["+Wrapper_variables.dataValue1+"]//td["+Wrapper_variables.dataValue2+"]"
            elif(((elementData == "") or (elementData == "nan") or (elementData == "None")) and (Common_step.ACTION == "Expand Child Tree")):
                if str(elementData) == "nan" or str(elementData) == "None":
                    elementData == ""
                element = "//div[@class='TWBodyLeft TWSplitterRight']//td/span[text()='"+str(Common_data.data_value)+"']/../preceding-sibling::td[1]/u[2]"
            elif(((elementData == "") or (elementData == "nan") or (elementData == "None")) and (Common_step.ACTION == "Expand Tree")):
               element = "//div[@class='TWBodyLeft TWSplitterRight']//td/span[text()='"+str(Common_data.data_value)+"']/../preceding-sibling::td[1]"
            elif(((elementData == "") or (elementData == "nan") or (elementData == "None")) and (Common_step.ACTION == "Click Tree Item")):
               element = "//td/span[contains(@onclick, 'treeclick')][text()='"+str(Common_data.data_value)+"']"
            elif Common_step.ACTION == "Expand Child Tree":
                # element = "//*[@id='"+Wrapper_variables.startsWithId+"']/div[3]"
                element = "//*[@id='"+Wrapper_variables.startsWithId+"']/div[contains(@class,'x-tree-expander')]"
            elif Common_step.ACTION == "Click Tree Checkbox":
                # element = "//*[@id='"+Wrapper_variables.startsWithId+"']/div[contains(@class,'x-tree-checkbox')]"
                # element = "//*[@id='"+Wrapper_variables.startsWithId+"']/div[contains(@class,'x-tree-checkbox')]/following-sibling::span[text()='"+str(Common_data.data_value)+"'])[1]"
                element = "(//*[@id='"+Wrapper_variables.startsWithId+"']/span[text()='"+str(Common_data.data_value)+"']/../div[contains(@class,'x-tree-checkbox')])[1]"
            else:
                element = "//*[@id='"+Wrapper_variables.startsWithId+"']/div[2]"
        # elif(Wrapper_variables.tree == "NO"):
        #     pass
        elif (Wrapper_variables.patternMatch == "YES"):
            if(Wrapper_variables.numberPart == 0):
                if (Wrapper_variables.containsId == ""):
                    
                    element = "//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]"
                else:
                    element = "//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]"
            else:
                if (Wrapper_variables.containsId == ""):
                    element  = "(//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')])["+Wrapper_variables.numberPart+"]"
                else:
                    element = "(//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')])["+Wrapper_variables.numberPart+"]"
        elif (Wrapper_variables.patternMatch == "NO"):
                Wrapper_variables.loopNumber = loop_count
                if action == "Click By Xpath":
                    element = Common_controls.control_Value
                 #elif (Variable_not_resettable.APP_TYPE == "Nebula co-existence"):
                elif (Variable_not_resettable.APP_TYPE == "Nebula co-existence") and (action == "Save Data"):
                    if(Wrapper_variables.numberPart == 0):
                        element = "//*[@id='"+Wrapper_variables.elementData+"']"
                    else:
                        element = "(//*[@id='"+Wrapper_variables.elementData+"'])["+Wrapper_variables.numberPart+"]"
                
                elif(Wrapper_variables.loopNumber != None and (action == "Grid Text" or action == "Grid Text Enter" or action == "Save Data" or action == "Click Checkbox Loop")):
                    rowIndex = Wrapper_variables.elementData.find("row")
                    length = len(Wrapper_variables.elementData)
                    gridRowNumber = int(Wrapper_variables.elementData[rowIndex + 3 : length])
                    gridRowNumber = gridRowNumber + int(Wrapper_variables.loopNumber)
                    Wrapper_variables.elementData = str(Wrapper_variables.elementData[0:rowIndex+3]) + str(gridRowNumber)
                    element = "//*[@id='"+Wrapper_variables.elementData+"']"
                elif (Wrapper_variables.propType == "YES"):
                        element = "//div[@class='"+elementData+"' and text()='"+Common_data.data_value+"']"
                else:   
                    if(Common_object.test_config_dictionary['JSThemeType'] == "EXTUI"):
                        element = "//*[@id='"+Wrapper_variables.elementData+"']"
                    else:
                        if(Wrapper_variables.numberPart == 0):
                            element = "//*[@id='"+Wrapper_variables.elementData+"']"
                        else:
                            element = "(//*[@id='"+Wrapper_variables.elementData+"'])["+Wrapper_variables.numberPart+"]"
                
                if Common_controls.control_Identifier == "xpath":
                    element = element_data

        elif (Wrapper_variables.XpathPattern== "YES"):
            element = element_data
        else:
            element = elementData
        return element


    