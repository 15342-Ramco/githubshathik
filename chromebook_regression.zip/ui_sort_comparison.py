import os
import time
from common_object import Common_object, Variable_not_resettable, Wrapper_variables
from excel_utils import assert_sorted_grid_table_xl_for_UI_comparison
from play_code import wait_unitil_please_wait


def Ascending(page_object,data):
    try:
        startswith1 = ((Wrapper_variables.startsWithId).split("_v"))[0]
        column_header_xpath = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'textInnerEl') and text()='{data}']"
        Variable_not_resettable.logger.info(f"column_header_xpath : {column_header_xpath}")
        table_xpath = f"(//*[starts-with(@id,'{startswith1}-ramcogrid')]//*[contains(@id, 'bodyWrap')])[1]"
        page_object.locator(table_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
        trigger_picker_xpath = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'triggerEl')]"
        Variable_not_resettable.logger.info(f"trigger_picker_xpath : {trigger_picker_xpath}")
        page_object.hover(column_header_xpath, timeout= Common_object.Timeout)
        time.sleep(2)
        page_object.wait_for_selector(trigger_picker_xpath, timeout= Common_object.Timeout)        
        page_object.click(trigger_picker_xpath, timeout= Common_object.Timeout)
        menu_path = "//div/a[@name = 'mainMenu_button']"
        page_object.hover(menu_path, timeout= Common_object.Timeout)
        sort_asc_xpath = f"//div[@role='menu' and @aria-hidden='false']//*[text()='Sort Ascending']"
        page_object.wait_for_selector(sort_asc_xpath, timeout= Common_object.Timeout)
        page_object.click(sort_asc_xpath, timeout= Common_object.Timeout)
        wait_unitil_please_wait(page_object, 1000)
        download_drop_down = f"//*[starts-with(@id,'{startswith1}_tbr_btnExport')]//*[contains(@id, 'btnIconEl')]"
        download_xlsx = f"//*[starts-with(@id,'{startswith1}_tbr_btnExpExcel')]//*[contains(@id, 'textEl')][text()='To Excel']"
        download_xlsx_2 = f"//*[starts-with(@id,'{startswith1}_tbr_btnExpExcel')]//*[contains(@id, 'textEl')][text()='To Excel ']"
        
        Variable_not_resettable.logger.debug(f"download drop down: {download_drop_down}")
        Variable_not_resettable.logger.debug(f"download xlsx 1: {download_xlsx}")
        Variable_not_resettable.logger.debug(f"download xlsx 2: {download_xlsx_2}")

        page_object.wait_for_selector(download_drop_down, timeout= Common_object.Timeout)
        page_object.click(download_drop_down, timeout= Common_object.Timeout)
        with page_object.expect_download() as download_info:
            try:
                page_object.click(download_xlsx, timeout=3000)
            except Exception as error:
                page_object.click(download_xlsx_2, timeout=3000)

        download = download_info.value
        Variable_not_resettable.logger.debug(f"download : {download}")
        file_name = download.suggested_filename
        Variable_not_resettable.logger.debug(f"file_name : {file_name}")
        download_folder_path = "./Files/Input_Documents/"
        save_in_path = os.path.join(download_folder_path, file_name)
        Variable_not_resettable.logger.debug(f"save_in_path : {save_in_path}")
        download.save_as(save_in_path)
        download_sheet = file_name.split(".")[0]
        
        Sorted_values_from_excel = assert_sorted_grid_table_xl_for_UI_comparison(file_name, data, "Asc")
        return Sorted_values_from_excel, download_sheet
    except Exception as error:
        Variable_not_resettable.logger.info(str(error))
        raise Exception(str(error))

def Descending(page_object,data):
    try:
        startswith1 = ((Wrapper_variables.startsWithId).split("_v"))[0]
        column_header_xpath = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'textInnerEl') and text()='{data}']"
        page_object.wait_for_selector(column_header_xpath, timeout= Common_object.Timeout)
        table_xpath = f"(//*[starts-with(@id,'{startswith1}-ramcogrid')]//*[contains(@id, 'bodyWrap')])[1]"
        page_object.locator(table_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
        Variable_not_resettable.logger.info(f"column_header_xpath: {column_header_xpath}")
        trigger_picker_xpath = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'triggerEl')]"
        page_object.hover(column_header_xpath, timeout= Common_object.Timeout)
        time.sleep(2)
        page_object.wait_for_selector(trigger_picker_xpath, timeout= Common_object.Timeout)
        
        page_object.click(trigger_picker_xpath, timeout= Common_object.Timeout)
        menu_path = "//div/a[@name = 'mainMenu_button']"
        page_object.hover(menu_path, timeout= Common_object.Timeout)
        sort_dsc_xpath = f"//div[@role='menu' and @aria-hidden='false']//*[text()='Sort Descending']"
        page_object.wait_for_selector(sort_dsc_xpath, timeout= Common_object.Timeout)
        page_object.click(sort_dsc_xpath, timeout= Common_object.Timeout)
        wait_unitil_please_wait(page_object, 1000)
        download_drop_down = f"//*[starts-with(@id,'{startswith1}_tbr_btnExport')]//*[contains(@id, 'btnIconEl')]"
        download_xlsx = f"//*[starts-with(@id,'{startswith1}_tbr_btnExpExcel')]//*[contains(@id, 'textEl')][text()='To Excel']"
        download_xlsx_2 = f"//*[starts-with(@id,'{startswith1}_tbr_btnExpExcel')]//*[contains(@id, 'textEl')][text()='To Excel ']"
        
        Variable_not_resettable.logger.debug(f"download_xlsx: {download_drop_down}")
        Variable_not_resettable.logger.debug(f"download_xlsx: {download_xlsx}")
        Variable_not_resettable.logger.debug(f"download_xlsx: {download_xlsx_2}")

        page_object.wait_for_selector(download_drop_down, timeout= Common_object.Timeout)
        page_object.click(download_drop_down, timeout= Common_object.Timeout)
        with page_object.expect_download() as download_info:
            try:
                page_object.click(download_xlsx, timeout=3000)
            except Exception as error:
                page_object.click(download_xlsx_2, timeout=3000)

        download = download_info.value
        file_name = download.suggested_filename
        Variable_not_resettable.logger.debug(f"file_name : {file_name}")
        download_folder_path = "./Files/Input_Documents/"
        save_in_path = os.path.join(download_folder_path, file_name)
        download.save_as(save_in_path)
        download_sheet = file_name.split(".")[0]
        Variable_not_resettable.logger.debug(f"save_in_path : {save_in_path}")
        Variable_not_resettable.logger.info(download_sheet)        
        Sorted_values_from_excel = assert_sorted_grid_table_xl_for_UI_comparison(file_name, data, "Dsc")
        return Sorted_values_from_excel,download_sheet
        
    except Exception as error:
        Variable_not_resettable.logger.info(str(error))
        raise Exception(str(error))