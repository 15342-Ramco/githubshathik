
import numpy as np


from excel_utils import read_dataFrame_return_dictionary_for_colum_based, read_excel_return_dataFrame




def get_index_of_scenario_list(main_scenario_list, scenario_config_metadata_dictionary):
    for i, d in enumerate(main_scenario_list):
        if scenario_config_metadata_dictionary['AT SCENARIO STEP ID'] != 'nan' and int(scenario_config_metadata_dictionary['AT SCENARIO STEP ID']) in d.values():
            index_ = main_scenario_list.index(d)
            return index_
            break


def get_index_of_step_list(main_step_list, step_config_metadata_dictionary):
    for i, d in enumerate(main_step_list):
        if step_config_metadata_dictionary['AT STEP ID'] != 'nan' and int(step_config_metadata_dictionary['AT STEP ID']) in d.values():
            index_ = main_step_list.index(d)
            return index_
            break

def read_configScenarioMaster_return_scenario_dict(filename,sheetname,scenarios_dictionary):
    df = read_excel_return_dataFrame(filename,sheetname)
    df_list = np.split(df, df[df.isnull().all(1)].index) 
    for df in df_list:
        
        df.dropna(axis=0, how='all', inplace=True)
        if 'SKIP ROWS' in df['Unnamed: 0'].to_list():
            scenario_config_metadata_dictionary = read_dataFrame_return_dictionary_for_colum_based(df[0:5])
        else:
            scenario_config_metadata_dictionary = read_dataFrame_return_dictionary_for_colum_based(df[0:4])
            last_row = len(df)
            scenario_list_data_frame = df[4:last_row]

            scenario_list_data_frame = scenario_list_data_frame.rename(columns=scenario_list_data_frame.iloc[0]).drop(scenario_list_data_frame.index[0])
            scenario_list_data_frame = scenario_list_data_frame[0:]

            scenario_list_data_frame = scenario_list_data_frame.reset_index(inplace=False, drop=True)

            scenario_list_data_frame.columns = scenario_list_data_frame.columns.fillna('A')
            # scenario_list_data_frame.dropna(axis=1, how='all', inplace=True)
            data_frame_dictionary = scenario_list_data_frame.to_dict('records')

            Scenario_start = []
            Scenario_list = []
            Flag = False
            for i in range(len(data_frame_dictionary)):
                if str(data_frame_dictionary[i]['A']) == 'END':
                    Flag = False
                if Flag == True:
                    Scenario_list.append(data_frame_dictionary[i])
                if str(data_frame_dictionary[i]['A']) == 'START':
                    Flag = True
                    Scenario_list.append(data_frame_dictionary[i])
            for scenario_dict in Scenario_list:
                scenario_dict.update({"A" : "START"})
                scenario_dict.update(loop_count_no = None)
                Scenario_start.append(scenario_dict)

        index = get_index_of_scenario_list(scenarios_dictionary,scenario_config_metadata_dictionary)
        if scenario_config_metadata_dictionary['CONFIG_TYPE'] == 'ADD BEFORE':
            for scenario_dict_config in reversed(Scenario_start):
                scenarios_dictionary.insert(index, scenario_dict_config) 
        elif scenario_config_metadata_dictionary['CONFIG_TYPE'] == 'ADD LAST':
            for scenario_dict_config in Scenario_start:
                scenarios_dictionary.append(scenario_dict_config)
        elif scenario_config_metadata_dictionary['CONFIG_TYPE'] == 'SKIP FROM':
            del scenarios_dictionary[index:int(scenario_config_metadata_dictionary['SKIP ROWS'])+index]


def read_config_step_return_step_dict(filename,sheetname,step_dictionary): 
    df = read_excel_return_dataFrame(filename,sheetname)
    df_list = np.split(df, df[df.isnull().all(1)].index)
    for df in df_list:
        df.dropna(axis=0, how='all', inplace=True)
        if 'SKIP ROWS' in df['CONFIG'].to_list():
            step_config_metadata_dictionary = read_dataFrame_return_dictionary_for_colum_based(df[0:5])
        else:
            step_config_metadata_dictionary = read_dataFrame_return_dictionary_for_colum_based(df[0:4])
            last_row = len(df)
            scenario_list_data_frame = df[4:last_row]
            scenario_list_data_frame = scenario_list_data_frame.rename(columns=scenario_list_data_frame.iloc[0]).drop(scenario_list_data_frame.index[0])
            scenario_list_data_frame = scenario_list_data_frame[0:]
            scenario_list_data_frame = scenario_list_data_frame.reset_index(inplace=False, drop=True)
            scenario_list_data_frame.dropna(axis=1, how='all', inplace=True)
            data_frame_dictionary = scenario_list_data_frame.to_dict('records')
            Scenario_start = []
            Flag = False
            for i in range(len(data_frame_dictionary)):
                if str(data_frame_dictionary[i]['STEP_CONFIG']) == 'END STEPS':
                    Flag = False
                if str(data_frame_dictionary[i]['STEP_CONFIG']) == 'nan' or str(data_frame_dictionary[i]['STEP_CONFIG']) != 'END STEPS':
                    Flag = True
                    Scenario_start.append(data_frame_dictionary[i])
        index_ = get_index_of_step_list(step_dictionary,step_config_metadata_dictionary)
        if step_config_metadata_dictionary['CONFIG_TYPE'] == 'ADD BEFORE':
            for scenario_dict_config in reversed(Scenario_start):
                scenario_dict_config.update(Client = True)
                step_dictionary.insert(index_, scenario_dict_config) 
        elif step_config_metadata_dictionary['CONFIG_TYPE'] == 'ADD LAST':
            for scenario_dict_config in Scenario_start:
                scenario_dict_config.update(Client = True)
                step_dictionary.append(scenario_dict_config) 
        elif step_config_metadata_dictionary['CONFIG_TYPE'] == 'SKIP FROM':
            del step_dictionary[index_:int(step_config_metadata_dictionary['SKIP ROWS'])+index_]
    return step_dictionary 