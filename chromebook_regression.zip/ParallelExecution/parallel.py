
import openpyxl
import pandas as pd
from openpyxl.utils.dataframe import dataframe_to_rows
import itertools
from jproperties import Properties
import os
configs = Properties()
from excel_utils import read_excel_return_dictionary_for_colum_based, read_excel_return_dictionary_for_row_based
from utils import split_by_colon, join_path_and_file
from common_object import Variable_not_resettable
from natsort import natsorted

pd.options.mode.chained_assignment = None
base_path = os.getcwd()
scenarios_path = base_path + "/Files/Scenarios"

def check_dependencies():
    list_of_folders=os.listdir(scenarios_path)
    wordlist = ["Set1", "Set2", "Set3"]
    # res = []
    # for i in wordlist:
    #     subres = [string for string in list_of_folders if i in string]
    #     res.append(subres)
    # list_of_dependencies_folders = list(itertools.chain(*res))
    list_of_dependencies_folders = []
    for word in wordlist:
        if word in list_of_folders:
            list_of_dependencies_folders.append(word)
    if len(list_of_dependencies_folders)>0:
        return list_of_dependencies_folders,True
    else:
        return list_of_dependencies_folders,False

def get_scenarios(list_of_dependencies_folders, test_config_dictionary):
    if test_config_dictionary["ParallelExecution"] == "ON-FILTER":
        FilesNameInclude = test_config_dictionary["FilesNameInclude"]
        FilesNameExclude = test_config_dictionary["FilesNameExclude"]

        if FilesNameInclude != "nan" and FilesNameExclude != "nan":
            FilesNameInclude = [file.strip() for file in FilesNameInclude.split(",")]
            FilesNameExclude = [file.strip() for file in FilesNameExclude.split(",")]
            dic = {}
            for i in range (len(list_of_dependencies_folders)):
                files=os.listdir(scenarios_path+"/"+list_of_dependencies_folders[i])
                files=natsorted(files)
                dic[i]=[(list_of_dependencies_folders[i] + "/" + f) for f in files]  
            new_dict = {}    
            for j in range(len(dic)):
                files_list = dic[j] 
                new_files_include_list1 = []
                for file in files_list:
                    for each in FilesNameInclude:
                        if each in file:
                            new_files_include_list1.append(file)
                            break
                new_dict[j]=new_files_include_list1
            dict_with_filter = {}
            for k in range(len(new_dict)):
                files_to_be_removed = []
                files_list_after_include = new_dict[k]
                for file in files_list_after_include:
                    for each in FilesNameExclude:
                        if each in file:
                            files_to_be_removed.append(file)
                            break
                for each_file_to_be_removed in files_to_be_removed:
                    files_list_after_include.remove(each_file_to_be_removed)
                dict_with_filter[k] = files_list_after_include
            return dict_with_filter
        
        elif FilesNameInclude != "nan" and FilesNameExclude == "nan":
            FilesNameInclude = [file.strip() for file in FilesNameInclude.split(",")]
            dic = {}
            for i in range (len(list_of_dependencies_folders)):
                files=os.listdir(scenarios_path+"/"+list_of_dependencies_folders[i])
                files=natsorted(files)
                dic[i]=[(list_of_dependencies_folders[i] + "/" + f) for f in files]  
            new_dict = {}    
            for j in range(len(dic)):
                files_list = dic[j] 
                new_files_include_list1 = []
                for file in files_list:
                    for each in FilesNameInclude:
                        if each in file:
                            new_files_include_list1.append(file)
                            break
                new_dict[j]=new_files_include_list1
            return new_dict

        elif FilesNameInclude == "nan" and FilesNameExclude != "nan":
            FilesNameExclude = [file.strip() for file in FilesNameExclude.split(",")]
            dic = {}
            for i in range (len(list_of_dependencies_folders)):
                files=os.listdir(scenarios_path+"/"+list_of_dependencies_folders[i])
                files=natsorted(files)
                dic[i]=[(list_of_dependencies_folders[i] + "/" + f) for f in files]  
            new_dict = {}    
            for j in range(len(dic)):
                files_list = dic[j] 
                files_to_be_removed = []
                for file in files_list:
                    for each in FilesNameExclude:
                        if each in file:
                            files_to_be_removed.append(file)
                            break
                            # new_files_include_list1.append(file)
                for each_file_to_be_removed in files_to_be_removed:
                    files_list.remove(each_file_to_be_removed)
                new_dict[j]=files_list
            return new_dict

        elif FilesNameInclude == "nan" and FilesNameExclude == "nan":
            dic = {}
            for i in range (len(list_of_dependencies_folders)):
                files=os.listdir(scenarios_path+"/"+list_of_dependencies_folders[i])
                files=natsorted(files)
                dic[i]=[(list_of_dependencies_folders[i] + "/" + f) for f in files]                                                                                                                            
            return dic

    else:
        dic = {}
        for i in range (len(list_of_dependencies_folders)):
            files=os.listdir(scenarios_path+"/"+list_of_dependencies_folders[i])
            files=natsorted(files)
            dic[i]=[(list_of_dependencies_folders[i] + "/" + f) for f in files]
        return dic

def get_scenarios_sub(list_of_dependencies_folders, testConfig_dictionary):
    if testConfig_dictionary["ParallelExecution"] == "ON-FILTER":
        depend = []

        for a in list_of_dependencies_folders:
            depend.append(scenarios_path +"/"+ a)
        dic = {}
        for d in depend:
            dic[os.path.basename(d)] = [f.path for f in os.scandir(d) if f.is_dir()]
        j = []
        for k in list_of_dependencies_folders:
            for path in dic[k]:
                for root, directories, files in os.walk(path, topdown=False):
                    files=natsorted(files)
                    for name in files:
                        strPath = os.path.realpath(os.path.join(root, name))
                        nmFolders = strPath.split(os.path.sep)
                        j.append(nmFolders[-3] + "/" + nmFolders[-2] + "/" + nmFolders[-1])

        scenarios_file_list = j
        file_include = []
        file_exclude = []
        scenarios_file_list_final = []
        # for scenarios_folder in scenarios_folder_list:
        #     files = os.listdir(Common_path.scenarios_path+"/"+scenarios_folder)
        #     files = natsorted(files)
        #     temp_var = [scenarios_file_list.append(scenarios_folder+"/"+f) for f in files]
        if str(testConfig_dictionary["FilesNameInclude"]) != "nan":
            files = [file_include.append(f.strip()) for f in testConfig_dictionary["FilesNameInclude"].split(",") if f!=""]

        if str(testConfig_dictionary["FilesNameExclude"]) != "nan":
            file = [file_exclude.append(f.strip()) for f in testConfig_dictionary["FilesNameExclude"].split(",") if f!=""]
        # print("file_include : ", file_include)
        # print("file_exclude : ",file_exclude)
        if str(testConfig_dictionary["FilesNameExclude"]) != "nan":
            for file in scenarios_file_list_final:
                for f in file_exclude:
                    if f in file:
                        scenarios_file_list.remove(file)
        if str(testConfig_dictionary["FilesNameInclude"]) != "nan":
            for file in scenarios_file_list:
                for f in file_include:
                    if f in file:
                        scenarios_file_list_final.append(file)
        if str(testConfig_dictionary["FilesNameInclude"]) == "nan":
            for f in scenarios_file_list:
                scenarios_file_list_final.append(f)
        files_to_be_removed = []
        if str(testConfig_dictionary["FilesNameExclude"]) != "nan":
            for file in scenarios_file_list_final:
                for f in file_exclude:
                    if f in file:
                        # scenarios_file_list_final.remove(file)
                        files_to_be_removed.append(file)
            for file in files_to_be_removed:
                scenarios_file_list_final.remove(file)
        
        dic1 = {}
        for y in range(len(list_of_dependencies_folders)):
            dic1[y] = [string for string in scenarios_file_list_final if list_of_dependencies_folders[y] in string]
        return dic1
    else:
        depend = []

        for a in list_of_dependencies_folders:
            depend.append(scenarios_path +"/"+ a)
        dic = {}
        for d in depend:
            dic[os.path.basename(d)] = natsorted([f.path for f in os.scandir(d) if f.is_dir()])
        j = []
        for k in list_of_dependencies_folders:
            for path in dic[k]:
                for root, directories, files in os.walk(path, topdown=False):
                    files=natsorted(files)
                    for name in files:
                        strPath = os.path.realpath(os.path.join(root, name))
                        nmFolders = strPath.split(os.path.sep)
                        j.append(nmFolders[-3] + "/" + nmFolders[-2] + "/" + nmFolders[-1])
        dic1 = {}
        for y in range(len(list_of_dependencies_folders)):
            dic1[y] = [string for string in j if list_of_dependencies_folders[y] in string]
        return dic1




def reading_required_files_for_parallel():
    base_path = os.getcwd()
    test_config_path=base_path + "/Files\TestRunner"
    navigation_path=base_path + "/Files/PreConfig"
    # Reading process for properties file and storing in Common Object
    properties = {'navigation_config_file_sheet_name': 'NavigationConfig.xlsx:NavConfig', 'pre_req_config_file_sheet_name': 'PreReqConfig.xlsx:PreReqConfig', 'test_runner_config_file_sheet_name': 'TestRunnerConfig.xlsx:RunnerConfig', 'browser_headless': 'Flase'}
    # Reading process for testConfig file and storing in Common Object
    testConfig_file_name, testConfig_sheet_name = split_by_colon(properties["test_runner_config_file_sheet_name"])
    test_config_dictionary = read_excel_return_dictionary_for_colum_based(join_path_and_file(test_config_path, testConfig_file_name), testConfig_sheet_name)
    #Reading process for Navigation file and storing in Common Object
    navigation_file_name, navigation_sheet_name = split_by_colon(properties["navigation_config_file_sheet_name"])
    navigation_dictionary = read_excel_return_dictionary_for_row_based(join_path_and_file(navigation_path, navigation_file_name), navigation_sheet_name)
    #Reading process Scenario file and storing in Common object
    scenarios_file_list = get_scenarios_file_list_parallel(test_config_dictionary,base_path)
    if len(scenarios_file_list) > 0:
        return scenarios_file_list,test_config_dictionary
    else:
        return scenarios_file_list,test_config_dictionary

def get_scenarios_folder_list_parallel(test_config_dictionary,base_path,scenarios_path):
    testConfig_dictionary = test_config_dictionary
    folder_list = []
    try:
        if testConfig_dictionary["FoldersInclude"] != "nan":
            folders = [folder_list.append(
                f.strip()) for f in testConfig_dictionary["FoldersInclude"].split(",")]
        if testConfig_dictionary["FoldersInclude"] == "nan":
            folders = [folder_list.append(f.strip()) for f in os.listdir(
                scenarios_path)]
        if testConfig_dictionary["FoldersExclude"] != "nan":
            folders = [folder_list.remove(
                f.strip()) for f in testConfig_dictionary["FoldersExclude"].split(",")]
    except Exception as error:
        Variable_not_resettable.logger.error(f"{str(error)}")
        exit()
    return natsorted(folder_list)

def get_scenarios_file_list_parallel(test_config_dictionary,base_path):
    if test_config_dictionary["ParallelExecution"] == "ON-FILTER":
        scenarios_path= base_path + "/Files/Scenarios"
        testConfig_dictionary = test_config_dictionary
        scenarios_folder_list = get_scenarios_folder_list_parallel(test_config_dictionary,base_path,scenarios_path)
        scenarios_file_list = []
        file_include = []
        file_exclude = []
        scenarios_file_list_final = []
        for scenarios_folder in scenarios_folder_list:
            
            files = os.listdir(scenarios_path+"/"+scenarios_folder)
            files=natsorted(files)
            temp_var = [scenarios_file_list.append(scenarios_folder+"/"+f) for f in files]

        if testConfig_dictionary["FilesNameInclude"] != "nan":
            files = [file_include.append(f.strip()) for f in testConfig_dictionary["FilesNameInclude"].split(",") if f!=""]

        if testConfig_dictionary["FilesNameExclude"] != "nan":
            file = [file_exclude.append(f.strip()) for f in testConfig_dictionary["FilesNameExclude"].split(",") if f!=""]
        Variable_not_resettable.logger.info(f"File include : {file_include}")
        Variable_not_resettable.logger.info(f"File_exclude : {file_exclude}")
        if testConfig_dictionary["FilesNameExclude"] != "nan":
            for file in scenarios_file_list_final:
                for f in file_exclude:
                    if f in file:
                        scenarios_file_list.remove(file)
        if testConfig_dictionary["FilesNameInclude"] != "nan":
            for file in scenarios_file_list:
                for f in file_include:
                    if f in file:
                        scenarios_file_list_final.append(file)
        if testConfig_dictionary["FilesNameInclude"] == "nan":
            for f in scenarios_file_list:
                scenarios_file_list_final.append(f)
        files_to_be_removed = []
        if testConfig_dictionary["FilesNameExclude"] != "nan":
            for file in scenarios_file_list_final:
                for f in file_exclude:
                    if f in file:
                        files_to_be_removed.append(file)
            for file in files_to_be_removed:
                scenarios_file_list_final.remove(file)
        # print("scenarios_file_list_final : ",scenarios_file_list_final)
        return scenarios_file_list_final
    else:
        scenarios_path= base_path + "/Files/Scenarios"
        testConfig_dictionary = test_config_dictionary
        scenarios_folder_list = get_scenarios_folder_list_parallel(test_config_dictionary,base_path,scenarios_path)
        scenarios_file_list = []
        file_include = []
        file_exclude = []
        scenarios_file_list_final = []
        for scenarios_folder in scenarios_folder_list:
            
            files = os.listdir(scenarios_path+"/"+scenarios_folder)
            files=natsorted(files)
            temp_var = [scenarios_file_list.append(scenarios_folder+"/"+f) for f in files]

        if testConfig_dictionary["FilesNameInclude"] != "nan":
            files = [file_include.append(f.strip()) for f in testConfig_dictionary["FilesNameInclude"].split(",") if f!=""]

        if testConfig_dictionary["FilesNameExclude"] != "nan":
            file = [file_exclude.append(f.strip()) for f in testConfig_dictionary["FilesNameExclude"].split(",") if f!=""]
        Variable_not_resettable.logger.info(f"File include : {file_include}")
        Variable_not_resettable.logger.info(f"File_exclude : {file_exclude}")
        if testConfig_dictionary["FilesNameExclude"] != "nan":
            for file in scenarios_file_list_final:
                for f in file_exclude:
                    if f in file:
                        scenarios_file_list.remove(file)
        if testConfig_dictionary["FilesNameInclude"] != "nan":
            for file in scenarios_file_list:
                for f in file_include:
                    if f in file:
                        scenarios_file_list_final.append(file)
        if testConfig_dictionary["FilesNameInclude"] == "nan":
            for f in scenarios_file_list:
                scenarios_file_list_final.append(f)
        if testConfig_dictionary["FilesNameExclude"] != "nan":
            for file in scenarios_file_list_final:
                for f in file_exclude:
                    if f in file:
                        scenarios_file_list_final.remove(file)
        # print("scenarios_file_list_final : ",scenarios_file_list_final)
        return scenarios_file_list_final


def file_splitter(agent_data):
    List_split = agent_data
    scenarios_file_list,test_config_dictionary=reading_required_files_for_parallel()
    # print("Scenariolist",scenarios_file_list)
    No_of_scenarios = len(scenarios_file_list)
    Variable_not_resettable.logger.info(f"{str(No_of_scenarios)}")
    dic = {}
    ss = 0
    try:
        if sum(List_split) == 100:
            for i in range(len(List_split)):
                df_range = round(List_split[i] * No_of_scenarios / 100)
                df_range += ss
                if i == len(List_split) - 1:
                    dic[i] = scenarios_file_list[ss:]
                else:
                    dic[i] = scenarios_file_list[ss:df_range]
                    ss = df_range

    except:
        Variable_not_resettable.logger.info("Scenario files not splitted")
    return dic

def read_config_file(file_name):
    base_path = os.getcwd()
    file_name = base_path + "/ParallelExecution/" + file_name
    with open(file_name, "rb") as f:
        configs.load(f)
    data = [list(i) for i in configs.items()]
    dict_data = {}
    agents = []
    for d in data:
        if "Cluster" in d[0]:
            txt = (d[1])[0]
            x = str(txt)
            x = x.split(",")
            agents.append(x[0])
        else:
            dict_data.update({d[0]: list(d[1])[0]})
    agents = [int(a) for a in agents]
    dict_data.update({"Agents": agents})
    return dict_data


def add_row_to_excel_parallel(file_path, sheet_name, data:dict):
    dic = {}
    for k, v in data.items():
        dic[k] = [v]
    df = pd.DataFrame(dic)
    if os.path.isfile(file_path):  # if file already exists append to existing file
        workbook = openpyxl.load_workbook(file_path)  # load workbook if already exists
        sheet = workbook[sheet_name]  # declare the active sheet
        for row in dataframe_to_rows(df, header=False, index=False):
            sheet.append(row)
        workbook.save(file_path)  # save workbook
        workbook.close()  # close workbook
    else:  # create the excel file if doesn't already exist
        with pd.ExcelWriter(path=file_path, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name=sheet_name)

def get_folder_list_parallel_sub(list_of_dependencies_folders):
    # scenarios_folder_list = get_scenarios_folder_list_parallel(test_config_dictionary,base_path,scenarios_path)
    if len(list_of_dependencies_folders)>0:
        depend = []
        for a in list_of_dependencies_folders:
            depend.append(scenarios_path +"/"+ a)
        res = []
        for d in depend:
            # res.append([f.path for f in os.scandir(d) if f.is_dir()])
            res.append(natsorted([f.path for f in os.scandir(d) if f.is_dir()]))
        # sub_path=scenarios_path+"/"+scenarios_folder_list[0]
        # files_sub = os.listdir(sub_path)
        # wordlist = ["Set1", "Set2", "Set3"]
        # list_of_sub_dependencies_folders=[]
        # for word in wordlist:
        #     if word in files_sub:
        #         list_of_sub_dependencies_folders.append(word)
        # res = []
        # for i in wordlist:
        #     subres = [string for string in files_sub if i in string]
        #     res.append(subres)
        list_of_sub_dependencies_folders = list(itertools.chain(*res))
    else:
        list_of_sub_dependencies_folders=[]
    return list_of_sub_dependencies_folders


def get_config():
    base_path = os.getcwd()
    test_config_path = base_path + "/Files/TestRunner"
    navigation_path = base_path + "/Files/PreConfig"
    # Reading process for properties file and storing in Common Object
    properties = {'navigation_config_file_sheet_name': 'NavigationConfig.xlsx:NavConfig',
                  'pre_req_config_file_sheet_name': 'PreReqConfig.xlsx:PreReqConfig',
                  'test_runner_config_file_sheet_name': 'TestRunnerConfig.xlsx:RunnerConfig',
                  'browser_headless': 'False'}
    # Reading process for testConfig file and storing in Common Object
    testConfig_file_name, testConfig_sheet_name = split_by_colon(properties["test_runner_config_file_sheet_name"])
    if Variable_not_resettable.re_run_flag == True:
        test_config_dictionary = read_excel_return_dictionary_for_colum_based(join_path_and_file(test_config_path, testConfig_file_name), testConfig_sheet_name)
        if "GUID" in test_config_dictionary:
            # Append '_RERUN' to the value of 'GUID'
            test_config_dictionary["GUID"] += "_RERUN"
    else:
        test_config_dictionary = read_excel_return_dictionary_for_colum_based(join_path_and_file(test_config_path, testConfig_file_name), testConfig_sheet_name)
    # test_config_dictionary = read_excel_return_dictionary_for_colum_based(join_path_and_file(test_config_path, testConfig_file_name), testConfig_sheet_name)
    return test_config_dictionary