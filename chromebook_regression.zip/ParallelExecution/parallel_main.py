
import multiprocessing
import os
import time
import uuid
from datetime import datetime
import openpyxl
import pandas as pd
from jproperties import Properties
from ParallelExecution.parallel import file_splitter, check_dependencies, get_scenarios, get_scenarios_sub, get_folder_list_parallel_sub
from common_object import Common_object, Common_main_object, Common_path, Common_scenario, Parallel_common_object, Variable_not_resettable
from excel_utils import add_row_to_excel, read_excel_return_dictionary_for_colum_based
from func.scenario_re_run import fail_scenario_collector
from reset_common_object import reset_scenario_variables, reset_scenario_dict, reset_navigation_variables
from scenario import data_provider, scenario_sheet_filter_steps, select_scenario_tags
from steps import scenario_step
from sub_main import reading_required_files
from utils import find_browser_process_id,remove_folder,executionstop, get_cmd_input_params, join_path_and_file, split_by_colon
configs = Properties()
import json



def worker(list_of_file, processID,q,advance_debug_log_folder,PATCH_ID, advance_debug_log_file_name, re_run_flag):
    start_time = time.perf_counter()
    user_dir = 'tmp/playwright'+"_" + str(processID)
    Variable_not_resettable.user_data_dir = os.path.join(os.getcwd(), user_dir)
    remove_folder(Variable_not_resettable.user_data_dir)
    if reading_required_files(re_run_flag):
    #if reading_required_files():
        Common_object.PATCH_ID=PATCH_ID
        Parallel_common_object.process_id = str(processID)
        df = pd.DataFrame(columns=Common_object.advance_debug_log_header)
        df1 = pd.DataFrame(columns=Common_object.test_result_log_header_INFO)
        df2 = pd.DataFrame(columns=Common_object.test_result_log_header_DEBUG)
        Common_main_object.advance_debug_log_folder=advance_debug_log_folder
        Common_main_object.advance_debug_log_file_name = advance_debug_log_file_name
        Common_main_object.advance_debug_log_file_path = Common_main_object.advance_debug_log_folder + "/AdvancedDebugLog_"+Parallel_common_object.process_id +".csv"
        Common_main_object.test_result_log_file_path =Common_main_object.advance_debug_log_folder + "/TestResultLog_"+Parallel_common_object.process_id +".xlsx"
        df.to_csv(Common_main_object.advance_debug_log_file_path, index_label=False)
        with pd.ExcelWriter(Common_main_object.test_result_log_file_path) as writer:
            df1.to_excel(writer, sheet_name="INFO", index=False)
            df2.to_excel(writer, sheet_name="DEBUG", index=False)
        for i in range(len(list_of_file)):
            try:
                Variable_not_resettable.logger.info(f"Process {str(Parallel_common_object.process_id )}: Executing scenario {str(i+1)} out of {str(len(list_of_file))} scenarios")
                Common_main_object.test_result_log_info_dict = {'SCENARIO ID': None, 'SCENARIO NAME': None,
                                                                'RESULT': None, 'ERROR SNAPSHOT': None,
                                                                'EXECUTION_START_TIME': None,
                                                                'EXECUTION_END_TIME': None, "EXECUTION_VIDEO":None}
                Common_main_object.test_result_log_debug_dict = {'SCENARIO ID': None, 'SCENARIO NAME': None,
                                                                    'RESULT': None, 'ERROR SNAPSHOT': None,
                                                                    'STEP ID': None,
                                                                    'XRAY TEST CASE ID': None, 'PAGE OBJECT DATA': None,
                                                                    'ACTION': None, 'DATA VALUE': None,
                                                                    'EXECUTION TIME (sec)': None, 'Error_Raised': None,
                                                                    'Custom_Error': None,
                                                                    'ERROR_MESSAGE': None,
                                                                    'Solution_Suggestion': None}
                start_time = time.perf_counter()
                Common_main_object.scenario_execution_start_time = datetime.now()
                scenarios_file = list_of_file[i]
                # print("[INFO] : SCENARIO FILE : ", list_of_file[i])
                scenario_split= list_of_file[i].split("/")
                Common_object.SCENARIO_FILE_NAME=scenario_split[1]
                
                Common_object.scenarios_meta, Common_object.scenarios_dictionary = scenario_sheet_filter_steps(scenarios_file)
                data_provider_header = str(list((Common_object.scenarios_dictionary[0]).keys())[5])
                data_provider_count = data_provider(data_provider_header)
                #print("[INFO] : Data Provider : ", data_provider_count)
                #print("scenarios_dictionary : ", Common_object.scenarios_dictionary)
                if select_scenario_tags(Common_object.scenarios_meta["SCENARIO_TAGS"]):
                    for num in data_provider_count:
                        if len(data_provider_count) !=1:
                            Common_scenario.data_provider_count_for_scenario = num
                        else:
                            Common_scenario.data_provider_count_for_scenario = ""
                        try:
                            scenario_step(scenarios_file, num)
                            time.sleep(2)
                            end_time = time.perf_counter()
                            scenario_execution_time = str(round(end_time - start_time, 2))
                            Variable_not_resettable.logger.info("Scenario success")
                            Common_main_object.scenario_execution_end_time = datetime.now()
                            Common_main_object.test_result_log_info_dict.update({'SCENARIO ID': Common_object.scenarios_meta["SCENARIO_ID"]+str(Common_scenario.data_provider_count_for_scenario), 'SCENARIO NAME': Common_object.scenarios_meta["SCENARIO NAME"],'EXECUTION_START_TIME': Common_main_object.scenario_execution_start_time, 'EXECUTION_END_TIME': Common_main_object.scenario_execution_end_time})
                            Common_main_object.test_result_log_debug_dict.update({'SCENARIO ID': Common_object.scenarios_meta["SCENARIO_ID"]+str(Common_scenario.data_provider_count_for_scenario), 'SCENARIO NAME': Common_object.scenarios_meta["SCENARIO NAME"],'EXECUTION TIME (sec)': scenario_execution_time})
                            add_row_to_excel(Common_main_object.test_result_log_file_path, "INFO", list(Common_main_object.test_result_log_info_dict.values()))
                            add_row_to_excel(Common_main_object.test_result_log_file_path, "DEBUG", list(Common_main_object.test_result_log_debug_dict.values()))
                            reset_scenario_variables()
                            reset_scenario_dict()
                            reset_navigation_variables()          
                        except Exception as error:
                            if "[Errno 13] Permission denied:" in str(error):
                                Variable_not_resettable.logger.error(f"{str(error)}")
                            else:
                                #print(error)
                                end_time = time.perf_counter()
                                scenario_execution_time = str(round(end_time - start_time, 2))
                                Variable_not_resettable.logger.info("Scenario failed")
                                Common_main_object.scenario_execution_end_time = datetime.now()
                                Common_main_object.test_result_log_info_dict.update({'SCENARIO ID': Common_object.scenarios_meta["SCENARIO_ID"]+str(Common_scenario.data_provider_count_for_scenario),'SCENARIO NAME': Common_object.scenarios_meta["SCENARIO NAME"],'EXECUTION_START_TIME': Common_main_object.scenario_execution_start_time, 'EXECUTION_END_TIME': Common_main_object.scenario_execution_end_time, 'RESULT': 'FAILURE'})
                                Common_main_object.test_result_log_debug_dict.update({'SCENARIO ID': Common_object.scenarios_meta["SCENARIO_ID"]+str(Common_scenario.data_provider_count_for_scenario),'SCENARIO NAME': Common_object.scenarios_meta["SCENARIO NAME"],'EXECUTION TIME (sec)': scenario_execution_time, 'RESULT': 'FAILURE'})       
                                add_row_to_excel(Common_main_object.test_result_log_file_path, "INFO", list(Common_main_object.test_result_log_info_dict.values()))
                                add_row_to_excel(Common_main_object.test_result_log_file_path, "DEBUG", list(Common_main_object.test_result_log_debug_dict.values()))
                                
                                if re_run_flag != True:
                                    fail_scenario_collector(f"Files/Scenarios/{scenarios_file}")
                                
                                reset_scenario_variables()
                                reset_scenario_dict()
                                reset_navigation_variables()
                            Executionstop = executionstop(scenarios_file)
                            if Executionstop:
                                error="[INFO] : Execution stopped due to dependent scenario for before draft bill is failed in list of scenarios ,The failed Scenario is ",scenarios_file
                                # print(error)
                                exit(error)
            except Exception as error:
                Variable_not_resettable.logger.error(f"{str(error)}")   
                                  
    end_time = time.perf_counter()
    Variable_not_resettable.logger.info(f"Process {Parallel_common_object.process_id} closed")
    Variable_not_resettable.logger.info(f"Time consumed by process {Parallel_common_object.process_id} : {str(round(end_time - start_time))} seconds")


def parallel_main(test_config_dictionary,parallel_execution_config_file_data, user_input_params):
    agent_avail = 3
    agent_run = 0
    Variable_not_resettable.logger.info(f"Agent available: {str(agent_avail)}")
    agent_con = 0
    date_now = datetime.now().strftime("%d-%m-%Y %H-%M-%S").replace(":", "_")
    if str(test_config_dictionary["GUID"]).find("REG")!= -1:
        advance_debug_log_file_name = "TestResultLog "+str(date_now)+"_web_regtest_"+test_config_dictionary["GUID"]
    elif str(test_config_dictionary["GUID"]).find("SMK")!=-1:
        advance_debug_log_file_name = "TestResultLog "+str(date_now)+"_web_smktest_"+test_config_dictionary["GUID"]
    elif str(test_config_dictionary["GUID"]).find("SANITY")!=-1:
        advance_debug_log_file_name = "TestResultLog "+str(date_now)+"_web_sanitytest_"+test_config_dictionary["GUID"]
    else:
        advance_debug_log_file_name = "TestResultLog "+str(date_now)+"_web"
        
    advance_debug_log_folder = "Output/"+ advance_debug_log_file_name
    os.mkdir(advance_debug_log_folder)
    Common_object.log_foldername=advance_debug_log_folder
    PATCH_ID=None
    Common_object.properties = {'navigation_config_file_sheet_name': 'NavigationConfig.xlsx:NavConfig', 'pre_req_config_file_sheet_name': 'PreReqConfig.xlsx:PreReqConfig', 'test_runner_config_file_sheet_name': 'TestRunnerConfig.xlsx:RunnerConfig', 'browser_headless': 'False'}
    testConfig_file_name, testConfig_sheet_name = split_by_colon(Common_object.properties["test_runner_config_file_sheet_name"])
    if Variable_not_resettable.re_run_flag == True:
        Common_object.test_config_dictionary = read_excel_return_dictionary_for_colum_based(join_path_and_file(Common_path.test_config_path, testConfig_file_name), testConfig_sheet_name)
        if "GUID" in Common_object.test_config_dictionary:
            # Append '_RERUN' to the value of 'GUID'
            Common_object.test_config_dictionary["GUID"] += "_RERUN"
    else:
        Common_object.test_config_dictionary = read_excel_return_dictionary_for_colum_based(join_path_and_file(Common_path.test_config_path, testConfig_file_name), testConfig_sheet_name)
 
    # Common_object.test_config_dictionary = read_excel_return_dictionary_for_colum_based(join_path_and_file(Common_path.test_config_path, testConfig_file_name), testConfig_sheet_name)
    
    if user_input_params != None:
        get_cmd_input_params(user_input_params)
        if Variable_not_resettable.re_run_flag == True:
            Common_object.PATCH_ID = str(Common_object.PATCH_ID)+"-r" 
    if PATCH_ID == None and str(Common_object.test_config_dictionary["PatchID"]) != "nan" and Common_object.PATCH_ID == None:
        PATCH_ID = Common_object.test_config_dictionary["PatchID"]
    elif PATCH_ID == None and Common_object.PATCH_ID == None:
        PATCH_ID = uuid.uuid4()
    elif Common_object.PATCH_ID != None:
        PATCH_ID = Common_object.PATCH_ID

    manager = multiprocessing.Manager()
    q = manager.Queue()
    pool = multiprocessing.Pool(multiprocessing.cpu_count())
    channel_browser = str(Common_object.test_config_dictionary['Browser']).lower().strip()
    if channel_browser == "chrome-persistent-context":
        Variable_not_resettable.browser_type = "chrome"
    elif channel_browser == "msedge-persistent-context":
        Variable_not_resettable.browser_type = "msedge"
    if agent_avail >= 1:
        list_of_dependencies_folders, dependencies = check_dependencies()
        list_of_sub_dependencies_folders = get_folder_list_parallel_sub(list_of_dependencies_folders)
        if len(list_of_dependencies_folders) > 0 and dependencies == True and len(list_of_sub_dependencies_folders) == 0:
            jobs = []
            split_scenario1 = get_scenarios(list_of_dependencies_folders, test_config_dictionary)
            Variable_not_resettable.logger.info(f"Split scenario1 {split_scenario1}")
            for i in range(len(list_of_dependencies_folders)):
                Variable_not_resettable.logger.info(split_scenario1[i])
                job = pool.apply_async(worker, (split_scenario1[i], int(i), q, advance_debug_log_folder, PATCH_ID, advance_debug_log_file_name, Variable_not_resettable.re_run_flag))
                jobs.append(job)
                time.sleep(10)
                if channel_browser=="chrome-persistent-context" or  channel_browser== "msedge-persistent-context":
                    if i==0:
                        process_1=find_browser_process_id()
                        # Loop until the dictionary is not empty
                        while not process_1:
                            print("The dictionary is empty. Trying to find the browser process ID...")
                            process_1=find_browser_process_id()
                        # Serialize dictionary to JSON and write to a file
                        with open(f'data{i}.json', 'w') as json_file:
                            json.dump(process_1, json_file)
                    elif i==1:
                        process_2=find_browser_process_id()
                        while not process_2:
                            print("The dictionary is empty. Trying to find the browser process ID...")
                            process_2=find_browser_process_id()
                        keys_process_1=set(process_1.keys())
                        keys_process_2 =set(process_2.keys())
                        # Get the different keys
                        different_keys1 = list(keys_process_1.symmetric_difference(keys_process_2))
                        for key,value in process_2.items():
                            if str(key)==str(different_keys1[0]):
                                second={key:value}
                        # Serialize dictionary to JSON and write to a file
                        with open(f'data{i}.json', 'w') as json_file:
                            json.dump(second, json_file)

                    elif i==2:
                        process_3=find_browser_process_id()
                        while not process_3:
                            print("The dictionary is empty. Trying to find the browser process ID...")
                            process_3=find_browser_process_id()
                        keys_process_3 = set(process_3.keys())
                        different_keys2 = list(keys_process_2.symmetric_difference(keys_process_3))
                        for key,value in process_3.items():
                            if key==different_keys2[0]:
                                Third={key:value}
                        # Serialize dictionary to JSON and write to a file
                        with open(f'data{i}.json', 'w') as json_file:
                            json.dump(Third, json_file)
            if split_scenario1 != None:
                for job in jobs:
                    if agent_avail != 0:
                        agent_avail -= 1
                        agent_con += 1
                        agent_run += 1
                        Variable_not_resettable.logger.info(f"Agent {str(agent_run)} Started")
                job.get()
        elif len(list_of_dependencies_folders) == 0 and dependencies == False:
            split_scenario2 = file_splitter(parallel_execution_config_file_data["Agents"])
            # print("split_scenario2", split_scenario2)
            jobs = []
            for i in range(len(parallel_execution_config_file_data['Agents'])):
                Variable_not_resettable.logger.info(split_scenario2[i])
                job = pool.apply_async(worker, (split_scenario2[i], int(i), q, advance_debug_log_folder, PATCH_ID, advance_debug_log_file_name,  Variable_not_resettable.re_run_flag))
                jobs.append(job)
                time.sleep(10)
                if channel_browser=="chrome-persistent-context" or  channel_browser== "msedge-persistent-context":
                    if i==0:
                        process_1=find_browser_process_id()
                        # Loop until the dictionary is not empty
                        while not process_1:
                            print("The dictionary is empty. Trying to find the browser process ID...")
                            process_1=find_browser_process_id()
                        # Serialize dictionary to JSON and write to a file
                        with open(f'data{i}.json', 'w') as json_file:
                            json.dump(process_1, json_file)
                    elif i==1:
                        process_2=find_browser_process_id()
                        while not process_2:
                            print("The dictionary is empty. Trying to find the browser process ID...")
                            process_2=find_browser_process_id()
                        keys_process_1=set(process_1.keys())
                        keys_process_2 =set(process_2.keys())
                        # Get the different keys
                        different_keys1 = list(keys_process_1.symmetric_difference(keys_process_2))
                        for key,value in process_2.items():
                            if str(key)==str(different_keys1[0]):
                                second={key:value}
                        # Serialize dictionary to JSON and write to a file
                        with open(f'data{i}.json', 'w') as json_file:
                            json.dump(second, json_file)

                    elif i==2:
                        process_3=find_browser_process_id()
                        while not process_3:
                            print("The dictionary is empty. Trying to find the browser process ID...")
                            process_3=find_browser_process_id()
                        keys_process_3 = set(process_3.keys())
                        different_keys2 = list(keys_process_2.symmetric_difference(keys_process_3))
                        for key,value in process_3.items():
                            if key==different_keys2[0]:
                                Third={key:value}
                        # Serialize dictionary to JSON and write to a file
                        with open(f'data{i}.json', 'w') as json_file:
                            json.dump(Third, json_file)
            if split_scenario2 != None:
                for job in jobs:
                    if agent_avail != 0:
                        agent_avail -= 1
                        agent_con += 1
                        agent_run += 1
                        Variable_not_resettable.logger.info(f"Agent {str(agent_run) } Started")
                job.get()
        elif len(list_of_dependencies_folders) > 0 and len(list_of_sub_dependencies_folders) > 0:
            split_scenario3 = get_scenarios_sub(list_of_dependencies_folders, test_config_dictionary)
            Variable_not_resettable.logger.info(f"split scenario3: {split_scenario3}")
            jobs = []
            for i in range(len(list_of_dependencies_folders)):
                Variable_not_resettable.logger.info(split_scenario3[i])
                job = pool.apply_async(worker, (split_scenario3[i], int(i), q, advance_debug_log_folder, PATCH_ID, advance_debug_log_file_name, Variable_not_resettable.re_run_flag))
                jobs.append(job)
                time.sleep(10)
                if channel_browser=="chrome-persistent-context" or  channel_browser== "msedge-persistent-context":
                    if i==0:
                        process_1=find_browser_process_id()
                        # Loop until the dictionary is not empty
                        while not process_1:
                            print("The dictionary is empty. Trying to find the browser process ID...")
                            process_1=find_browser_process_id()
                        # Serialize dictionary to JSON and write to a file
                        with open(f'data{i}.json', 'w') as json_file:
                            json.dump(process_1, json_file)
                    elif i==1:
                        process_2=find_browser_process_id()
                        while not process_2:
                            print("The dictionary is empty. Trying to find the browser process ID...")
                            process_2=find_browser_process_id()
                        keys_process_1=set(process_1.keys())
                        keys_process_2 =set(process_2.keys())
                        # Get the different keys
                        different_keys1 = list(keys_process_1.symmetric_difference(keys_process_2))
                        for key,value in process_2.items():
                            if str(key)==str(different_keys1[0]):
                                second={key:value}
                        # Serialize dictionary to JSON and write to a file
                        with open(f'data{i}.json', 'w') as json_file:
                            json.dump(second, json_file)

                    elif i==2:
                        process_3=find_browser_process_id()
                        while not process_3:
                            print("The dictionary is empty. Trying to find the browser process ID...")
                            process_3=find_browser_process_id()
                        keys_process_3 = set(process_3.keys())
                        different_keys2 = list(keys_process_2.symmetric_difference(keys_process_3))
                        for key,value in process_3.items():
                            if key==different_keys2[0]:
                                Third={key:value}
                        # Serialize dictionary to JSON and write to a file
                        with open(f'data{i}.json', 'w') as json_file:
                            json.dump(Third, json_file)
            if split_scenario3 != None:
                for job in jobs:
                    if agent_avail != 0:
                        agent_avail -= 1
                        agent_con += 1
                        agent_run += 1
                        Variable_not_resettable.logger.info(f"Agent { str(agent_run) } Started")
                job.get()
    pool.close()
    pool.join()



def Concatenate_logs():

    folder_path = Common_object.log_foldername
    # Path to the folder containing CSV files

    # Get list of CSV files in the folder
    csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]

    # Sort CSV files by name
    csv_files.sort()

    # Initialize an empty list to store dataframes
    dfs = []

    # Read and concatenate CSV files
    for csv_file in csv_files:
        file_path = os.path.join(folder_path, csv_file)
        df = pd.read_csv(file_path)
        dfs.append(df)
    # Concatenate dataframes
    result = pd.concat(dfs, ignore_index=True)
    # Write the concatenated dataframe to a new CSV file
    # Assign continuous series of numbers to the S_NO column
    result['S_NO'] = range(1, len(result) + 1)
    result.to_csv(folder_path+"/AdvancedDebugLog_concatenated.csv", index=False)
    print("Concatenated CSV file created successfully.")
    
    # Get list of Excel files in the folder
    excel_files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]

    # Sort Excel files by name
    excel_files.sort()

    # Initialize a dictionary to store rows for each sheet
    all_rows_by_sheet = {}

    # Initialize a dictionary to store header rows for each sheet
    header_rows_by_sheet = {}

    # Read each sheet from each Excel file and append its rows to the dictionary
    for excel_file in excel_files:
        file_path = os.path.join(folder_path, excel_file)
        # Open the Excel file
        workbook = openpyxl.load_workbook(file_path)
        # Iterate over each sheet in the Excel file
        for sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            # Initialize lists for rows and headers if sheet doesn't exist in the dictionaries
            if sheet_name not in all_rows_by_sheet:
                all_rows_by_sheet[sheet_name] = []
            if sheet_name not in header_rows_by_sheet:
                header_rows_by_sheet[sheet_name] = None
            # Iterate over each row in the sheet
            for row in sheet.iter_rows(values_only=True):
                # If header row is not set for the sheet, set it and continue to the next row
                if not header_rows_by_sheet[sheet_name]:
                    header_rows_by_sheet[sheet_name] = row
                    continue
                # If the current row is not the header row, append it to the respective list
                if row != header_rows_by_sheet[sheet_name]:
                    # Append the file name to the row
                    row_with_filename = (excel_file,) + row
                    all_rows_by_sheet[sheet_name].append(row_with_filename)

    # Create a new Excel workbook
    output_workbook = openpyxl.Workbook()

    # Write rows to separate sheets in the output Excel file
    for sheet_name, rows in all_rows_by_sheet.items():
        output_sheet = output_workbook.create_sheet(title=sheet_name)
        # Write header row
        output_sheet.append(("File Name",) + header_rows_by_sheet[sheet_name])
        # Write data rows
        for row in rows:
            output_sheet.append(row)

    # Remove the default sheet created by openpyxl
    output_workbook.remove(output_workbook['Sheet'])

    # Save the output Excel file
    output_workbook.save(os.path.join(folder_path, "TestResultLog_concatenated.xlsx"))

    print("Concatenated Excel file with separate sheets and file names added successfully.")

