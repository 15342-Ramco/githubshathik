import os
import openpyxl
import pandas as pd
from csv import writer
from openpyxl import load_workbook
# import win32com.client
import xlwings as xw
import pypandoc
from common_object import Common_main_object, Common_object, Common_path, Common_scenario, Common_step, Variable_not_resettable, Wrapper_variables
from utils import get_alphabet
import psutil
#import win32com.client
import time

def remove_conditional_formatting(file_path):
    # Open the workbook with xlwings
    app = xw.App(visible=False)
    wb = app.books.open(file_path)
    try:
        # Loop through each sheet and clear conditional formatting
        for sheet in wb.sheets:
            sheet.api.Cells.FormatConditions.Delete()
            
        # Save and close the workbook
        wb.save()
        print(f"All conditional formatting removed and file saved as {file_path}")
    finally:
        wb.close()
        app.quit()

def read_excel_return_dataFrame(file_name: str, sheet_name: str) -> pd.DataFrame:
    try:
        data_frame = pd.read_excel(file_name, sheet_name=sheet_name)
        return data_frame
    except Exception as error:
        # print("[ERROR] : ", str(error))
        Variable_not_resettable.logger.error(str(error))
        try:
            remove_conditional_formatting(file_name)
            data_frame = pd.read_excel(file_name, sheet_name=sheet_name,engine='openpyxl')
            return data_frame
        except Exception as error:
            print("[ERROR] : ", str(error))
            raise Exception(str(error))

def read_excel_return_dataFrame_dtypeStr(file_name: str, sheet_name: str) -> pd.DataFrame:
    try:
        data_frame = pd.read_excel(file_name, sheet_name=sheet_name, dtype="str")
        return data_frame
    except Exception as error:
        # print("[ERROR] : ", str(error))
        Variable_not_resettable.logger.error(str(error))
        raise Exception(str(error))

def read_excel_return_dataFrame_for_data_sheet(file_name: str, sheet_name: str) -> pd.DataFrame:
    try:
        data_frame = pd.read_excel(file_name, sheet_name=sheet_name , dtype="str", keep_default_na= False)
        return data_frame
    except Exception as error:
        # print("[ERROR] : ", str(error))
        Variable_not_resettable.logger.error(str(error))
        raise Exception(str(error))

def read_dataFrame_return_dictionary_for_colum_based(data_frame) -> dict:
    dict_temp = {}
    _ = [dict_temp.update({str(data[1]).strip(): str(data[2]).strip()}) for data in data_frame.to_records()]
    return dict_temp

def read_dataFrame_return_dictionary_for_row_based(data_frame: pd.DataFrame):
    return data_frame.to_dict("records")

def read_excel_return_dictionary_for_colum_based(file_name: str, sheet_name: str):
    data_frame = read_excel_return_dataFrame(file_name, sheet_name)
    return read_dataFrame_return_dictionary_for_colum_based(data_frame)

def read_excel_return_dictionary_for_row_based(file_name: str, sheet_name: str):
    data_frame = read_excel_return_dataFrame(file_name, sheet_name)
    return read_dataFrame_return_dictionary_for_row_based(data_frame)

def read_dataFrame_return_dictionary_for_row_based_for_step_sheet(data_frame: pd.DataFrame):
    list_of_dictionary = data_frame.to_dict("records")
    for dict_ in list_of_dictionary:
        if str(dict_["STEP_ID"]) == "nan":
            k = list_of_dictionary.index(dict_)
            del list_of_dictionary[k:]
            break
    return list_of_dictionary

def read_excel_return_dictionary_for_row_based_for_step_sheet(file_name: str, sheet_name: str):
    data_frame = read_excel_return_dataFrame(file_name, sheet_name)
    return read_dataFrame_return_dictionary_for_row_based_for_step_sheet(data_frame)


def advance_debug_log(values_list: list[list]):
    try:
        with open(Common_main_object.advance_debug_log_file_path, "a+", newline='') as csv_file:
            csv_writer = writer(csv_file) 
            csv_writer.writerows(values_list)
            Common_scenario.is_advance_log_done = True
            return True
    except Exception as error:
        # print(str(error))
        Variable_not_resettable.logger.error(str(error))
        return False


def add_row_to_excel(file_path, sheet_name, data: list[str]):
    try:
        wb = load_workbook(file_path)
        sheet = wb[sheet_name]
        sheet.append(data)
        wb.save(filename=file_path)
        return True
    except Exception as error:
        # print(str(error))
        Variable_not_resettable.logger.error(str(error))
        return False
    
def checkdataisempty(row_index,value):
    Variable_not_resettable.logger.info("Entered in to datacheck")
    file_path = Common_path.dataSheet_path + "/"+Common_object.test_config_dictionary['DataTag'] + "/" + Common_step.DATA_FILE + ".xlsx"
    df = pd.read_excel(file_path, sheet_name=Common_step.DATA_SHEET)
    column_index = list(df.columns)
    column_index = [str(column).lower() for column in column_index]

    if Common_step.DATA_REFERENCE2 is None:
        column_index = column_index.index(str(Common_step.DATA_REFERENCE).lower())
    else:
        column_index = column_index.index(str(Common_step.DATA_REFERENCE2).lower())
    column_address = get_alphabet(column_index)
    app1 = xw.App()
    app1.visible = False
    app1.display_alerts = False

    Variable_not_resettable.logger.info("Excel application process id : "+ str(app1.pid))
    Variable_not_resettable.logger.info("Excel version : "+ str(app1.version))
   
    wb_1 = app1.books.open(file_path, update_links=False, ignore_read_only_recommended=True)    
    ws_1 = wb_1.sheets[Common_step.DATA_SHEET]
    extracted_value=ws_1.range(column_address+str(row_index+2)).value
    if extracted_value!=value or extracted_value is None or str(extracted_value).strip()=="" or str(extracted_value).lower()=='nan':
        return True
    else:
        return False


def recalculate_and_save_excel(file_path):
    # Open the workbook using xlwings
    app = xw.App(visible=False)  # Run Excel in the background
    workbook = app.books.open(file_path)
    
    # Recalculate all formulas in the workbook
    workbook.refresh_all()  # Refresh any external data connections
    workbook.app.calculate()  # Force a full recalculation of all formulas
    
    # Save the workbook
    workbook.save()
    
    # Close the workbook and quit Excel
    workbook.close()
    app.quit()
    
    print(f"File saved: {file_path}")

# def recalculate_and_save_excel(file_path):
#     # Start an instance of Excel (Excel will run in the background)
#     excel = win32com.client.Dispatch('Excel.Application')
    
#     # Open the Excel file
#     workbook = excel.Workbooks.Open(file_path)
    
#     # Recalculate all formulas in the workbook
#     workbook.RefreshAll()  # Refresh any external data connections
#     excel.CalculateFullRebuild()  # Force a full recalculation of all formulas
    
#     # Save the workbook
#     workbook.Save()
    
#     # Close the workbook
#     workbook.Close()
    
#     # Quit the Excel application (optional)
#     excel.Quit()


def appendColumnAndSaveData(row1, value):
    # Build the file path using the provided constants
    file_path = Common_path.dataSheet_path + "/" + Common_object.test_config_dictionary['DataTag'] + "/" + Common_step.DATA_FILE + ".xlsx"
    
    # Load the workbook and the specific sheet using openpyxl
    wb = openpyxl.load_workbook(file_path)
    sheet = wb[Common_step.DATA_SHEET]
    
    # Create the column name for the header
    column_name = str(Common_step.DATA_REFERENCE) + "_Save_Data"
    
    # Get the last column number in the sheet
    last_col = sheet.max_column
    
    # Check if the column with the name already exists
    column_exists = False
    for col in range(1, last_col + 1):
        if sheet.cell(row=1, column=col).value == column_name:  # Header row is row 1
            column_exists = True
            column_index = col
            break
    
    # If the column does not exist, add it at the next available column
    if not column_exists:
        column_index = last_col + 1
        sheet.cell(row=1, column=column_index, value=column_name)  # Add the column header in row 1

    # row1 should be greater than 1, as row 1 is the header
    sheet.cell(row=row1+2, column=column_index, value=str(value))  # Insert the value in the right cell
    

    # Save the workbook back to the file
    wb.save(file_path)
    time.sleep(1)
    recalculate_and_save_excel(file_path)



    
# def appendColumnAndSaveData(row1, value):
#     file_path = Common_path.dataSheet_path + "/" + Common_object.test_config_dictionary['DataTag'] + "/" + Common_step.DATA_FILE + ".xlsx"
    
#     # Read the Excel sheet using pandas to get the current columns
#     df = pd.read_excel(file_path, sheet_name=Common_step.DATA_SHEET)
#     column_name=str(Common_step.DATA_REFERENCE)+"_Save_Data"
#     # Check if the column exists, if not, create it
#     if column_name not in df.columns:
#         df[column_name] = None  # Add the column with None values initially
    
#     # Now save the value to the specified row (row1) in the given column
#     # Ensure the row1 is 0-indexed for pandas (row1=1 in Excel should map to row1=0 in pandas)
#     df.at[row1 - 1, column_name] =str(value)
    
#     # Write back to the Excel file using pandas
#     df.to_excel(file_path, sheet_name=Common_step.DATA_SHEET, index=False)

#     # Open the workbook using xlwings to handle any potential Excel-specific features
#     app1 = xw.App()
#     app1.visible = False
#     app1.display_alerts = False
#     Variable_not_resettable.logger.info("Excel application process id: " + str(app1.pid))
#     Variable_not_resettable.logger.info("Excel version: " + str(app1.version))
   
#     wb_1 = app1.books.open(file_path, update_links=False, ignore_read_only_recommended=True)    
#     ws_1 = wb_1.sheets[Common_step.DATA_SHEET]
    
#     # Save any Excel-specific changes (e.g., formulas or formatting)
#     wb_1.save()
#     wb_1.close()
#     app1.quit()
#     app1.kill()

def createColumnAndSaveData(row1, column_name, value):
    file_path = Common_path.dataSheet_path + "/" + Common_object.test_config_dictionary['DataTag'] + "/" + Common_step.DATA_FILE + ".xlsx"
    
    # Read the Excel sheet using pandas to get the current columns
    df = pd.read_excel(file_path, sheet_name=Common_step.DATA_SHEET)
    
    # Check if the column exists, if not, create it
    if column_name not in df.columns:
        df[column_name] = None  # Add the column with None values initially
    
    # Now save the value to the specified row (row1) in the given column
    # Ensure the row1 is 0-indexed for pandas (row1=1 in Excel should map to row1=0 in pandas)
    df.at[row1 - 1, column_name] = value
    
    # Write back to the Excel file using pandas
    df.to_excel(file_path, sheet_name=Common_step.DATA_SHEET, index=False)

    # Open the workbook using xlwings to handle any potential Excel-specific features
    app1 = xw.App()
    app1.visible = False
    app1.display_alerts = False
    Variable_not_resettable.logger.info("Excel application process id: " + str(app1.pid))
    Variable_not_resettable.logger.info("Excel version: " + str(app1.version))
   
    wb_1 = app1.books.open(file_path, update_links=False, ignore_read_only_recommended=True)    
    ws_1 = wb_1.sheets[Common_step.DATA_SHEET]
    
    # Save any Excel-specific changes (e.g., formulas or formatting)
    wb_1.save()
    wb_1.close()
    app1.quit()
    app1.kill()


def saveDataToExcel(row_index, value):
    # delete_gen_py_folder()  #### temp disable ####
    file_path = Common_path.dataSheet_path + "/"+Common_object.test_config_dictionary['DataTag'] + "/" + Common_step.DATA_FILE + ".xlsx"
    # xl = win32com.client.gencache.EnsureDispatch("Excel.Application")
    # # xl = win32com.client.Dispatch("Excel.Application")
    # xl.Visible = False
    # xl.AskToUpdateLinks = False
    # xl.DisplayAlerts = False
    # wb = xl.Workbooks.Open(os.path.abspath(file_path), UpdateLinks=True)
    # ws = wb.Worksheets(Common_step.DATA_SHEET) 
    # find = ws.Rows(1).Find(What=Common_step.DATA_REFERENCE, LookAt=1)
    # add = find.Address
    # col = add.split("$")[1]
    # Cell_address = col + str(row_index+2) 
    # ws.Range(Cell_address).Value = value
    # wb.Save()
    # wb.Close()
    # xl.Quit()
    
    df = pd.read_excel(file_path, sheet_name=Common_step.DATA_SHEET)
    column_index = list(df.columns)
    # print(column_index)
    column_index = [str(column).lower() for column in column_index]
    # print(column_index)
    column_index = column_index.index(str(Common_step.DATA_REFERENCE).lower())
    # print(column_index)
    column_address = get_alphabet(column_index)
    # print(column_address)
    # Variable_not_resetable.excel_application.display_alerts = False
    # Variable_not_resetable.excel_application.visible = False

    app1 = xw.App()
    app1.visible = False
    app1.display_alerts = False
    # print("Excel application process id : ", app1.pid)
    Variable_not_resettable.logger.info("Excel application process id : "+ str(app1.pid))
    # print("Excel version : ", app1.version)
    Variable_not_resettable.logger.info("Excel version : "+ str(app1.version))
   
    wb_1 = app1.books.open(file_path, update_links=False, ignore_read_only_recommended=True)    
    ws_1 = wb_1.sheets[Common_step.DATA_SHEET]
    ws_1.range(column_address+str(row_index+2)).value = value
    wb_1.save()
    wb_1.close()
    app1.quit()
    app1.kill()

# def quit_excel_application():
#     # xl = win32.gencache.EnsureDispatch("Excel.Application")
#     xl = win32com.client.Dispatch("Excel.Application")
#     # xl.Quit()

def quit_excel_application_by_os():
    try:
        # print("INFO: Checking 'excel.exe' application")
        Variable_not_resettable.logger.info("Checking 'excel.exe' application")
        data = os.system('start cmd /c TASKKILL /F /IM excel.exe')
        # print("SUCCESS: The 'excel.exe' application launched successfully.")
        # Variable_not_resettable.logger.info("SUCCESS: The 'excel.exe' application launched successfully.")

        # os.system('wmic process where name="excel.exe" delete')
        # print(data.read())
        # return True
    except Exception as error:
        # print(str(error))
        Variable_not_resettable.logger.error(str(error))
        return False
    
def is_float(value):
    """
    Check if the value can be converted to a float.
    """
    try:
        float(value)
        return True
    except ValueError:
        return False

def normalize_and_compare(value1, value2, decimal_places=4):
    """
    Normalize and compare two values by converting to float and rounding, if possible.
    Otherwise, compare their string representations.
    """
    if is_float(value1) and is_float(value2):
        # Convert both values to float and round them
        float_value1 = round(float(value1), decimal_places)
        float_value2 = round(float(value2), decimal_places)
        return float_value1 == float_value2
    elif is_float(value1) or is_float(value2):
        # Convert both to string with formatted float precision and compare
        float_value1 = f"{float(value1):.{decimal_places}f}" if is_float(value1) else str(value1)
        float_value2 = f"{float(value2):.{decimal_places}f}" if is_float(value2) else str(value2)
        return float_value1 == float_value2
    else:
        # Compare their string representations
        return str(value1) == str(value2)


def grid_validator(input_file_path, input_sheet_name, output_file_path, output_sheet_name):
    output_df = read_excel_return_dataFrame_dtypeStr(output_file_path, output_sheet_name)
    output_dict_list=read_dataFrame_return_dictionary_for_row_based(output_df)
    column_value = Wrapper_variables.inputValue.split(",")
    output_df_selected_columns = output_df[column_value]
    input_list_dict= read_dataFrame_return_dictionary_for_row_based(output_df_selected_columns)
    download_df = read_excel_return_dataFrame(input_file_path, input_sheet_name)
    download_df.columns = download_df.iloc[0]
    download_df = download_df.reindex(download_df.index.drop(0)).reset_index(drop=True)
    download_list_dict = read_dataFrame_return_dictionary_for_row_based(download_df)
    output_list_dict = []
    for download_dict,input_dict,output_dict in zip(download_list_dict,input_list_dict,output_dict_list):
        for input_key in input_dict.keys():
            Variable_not_resettable.logger.debug(f"{download_dict[input_key]}, {input_dict[input_key]}")
            Variable_not_resettable.logger.debug(f"{type(download_dict[input_key])}, {type(input_dict[input_key])}")
            if download_dict[input_key] == input_dict[input_key]:
                output_dict.update({"Status": "Pass"})
            elif normalize_and_compare(download_dict[input_key], input_dict[input_key]):
                output_dict.update({"Status": "Pass"})
            elif str(download_dict[input_key]) == str(input_dict[input_key]):
                output_dict.update({"Status": "Pass"})
            else:
                output_dict.update({"Status": "Fail"})
                break
        output_list_dict.append(output_dict)
    df = pd.DataFrame(output_list_dict)
    with pd.ExcelWriter(output_file_path, mode="a", if_sheet_exists="replace", engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name=output_sheet_name, index=False)



def do_sort_compar_xl(file_path, column_name):
    df = pd.read_excel()


def assert_sorted_grid_table_xl(file_name_xlsm, column_name, sort_by):
    # file_name = "mlfun_grid.xlsm".split(".")[0]
    file_name = f"{file_name_xlsm}".split(".")[0]
    file_name_xlsx = f"{file_name}.xlsx"
    file_name_xlsx_sorted = f"{file_name}_sorted.xlsx"


    file = f"{Common_path.base_path}\Files\Input_Documents\{file_name_xlsm}"
    file_path = f"{Common_path.base_path}\Files\Input_Documents\{file_name_xlsx}"
    file_path_1 = f"{Common_path.base_path}\Files\Input_Documents\{file_name_xlsx_sorted}"
    # column_name = "Description"

    df = pd.read_excel(file, index_col=0)
    new_header  = df.iloc[0]
    df = df[1:]
    df.columns = new_header
    df.to_excel(file_path)
    row_count = len(df)+2
    Variable_not_resettable.logger.info(f"row count : {row_count}")
    df = pd.read_excel(file_path)
    column_index = list(df.columns)
    column_index = [str(column).lower() for column in column_index]
    column_index = column_index.index(str(column_name).lower())
    target_column_address = get_alphabet(column_index)
    last_column = get_alphabet(len(list(df.columns))-1)
    Variable_not_resettable.logger.info(f"Last column address: {last_column}")
    Variable_not_resettable.logger.info(f"Target column address : {target_column_address}")
    is_xl_app_open = False
    is_xl_file_open = False
    is_xl_sheet_open = False
    try:
        xl_app = xw.App()
        is_xl_app_open = True
        xl_app.visible = True
        xl_app.display_alerts = False
        Variable_not_resettable.logger.info("Excel application process id : "+ str(xl_app.pid))
        Variable_not_resettable.logger.info("Excel version : "+ str(xl_app.version))
        wb = xl_app.books.open(file_path, update_links=False, ignore_read_only_recommended=True)   
        is_xl_file_open = True
        ws = wb.sheets[0]
        is_xl_sheet_open = True
        first_col_range = ws.range(f"A2:{last_column}{row_count}")
        data_range = ws.range(f"{target_column_address}2:{target_column_address}{row_count}")
        if sort_by == "Asc":
            ws.range(first_col_range).api.Sort(Key1=data_range.api, Order1=1, Header=2, Orientation=1)
        elif sort_by == "Dsc":
            ws.range(first_col_range).api.Sort(Key1=data_range.api, Order1=2, Header=2, Orientation=1)
        Variable_not_resettable.logger.info(f"Target data range : {data_range}")
        wb.save(file_path_1)
        wb.close()
        xl_app.quit()
        xl_app.kill()
    except Exception as error:
        Variable_not_resettable.logger.info(str(error))
        if is_xl_file_open == True:
            wb.save(file_path_1)
            wb.close()
        if is_xl_app_open == True:
            xl_app.quit()
            xl_app.kill()
        raise Exception(str(error))



    df_orginal = pd.read_excel(file_path)
    df_orginal_column = df_orginal[column_name]
    df_orginal_column_list = df_orginal_column.to_list()
    # print(df_orginal_column_list)

    df_duplicate = pd.read_excel(file_path_1)
    df_duplicate_column = df_duplicate[column_name]
    df_duplicate_column_list = df_duplicate_column.to_list()
    # print(df_duplicate_column_list)

    for orginal_column_value, duplicate_column_value in zip(df_orginal_column_list, df_duplicate_column_list):
        if orginal_column_value == duplicate_column_value:
            pass
        else:
            error_str = f"Assertion Failed"
            raise Exception(error_str)
    Variable_not_resettable.logger.info("Assertion Successfully")

    
    os.remove(file_path)
    os.remove(file_path_1)

def assert_sorted_grid_table_xl_for_UI_comparison(file_name_xlsm, column_name, sort_by):
    file_name = f"{file_name_xlsm}".split(".")[0]
    file_name_xlsx = f"{file_name}.xlsx"
    file_name_xlsx_sorted = f"{file_name}_sorted.xlsx"

    file = f"{Common_path.base_path}\Files\Input_Documents\{file_name_xlsm}"
    file_path = f"{Common_path.base_path}\Files\Input_Documents\{file_name_xlsx}"
    file_path_1 = f"{Common_path.base_path}\Files\Input_Documents\{file_name_xlsx_sorted}"

    df = pd.read_excel(file, index_col=0)
    new_header  = df.iloc[0]
    df = df[1:]
    df.columns = new_header
    df.to_excel(file_path)
    row_count = len(df)+2
    Variable_not_resettable.logger.info(f"row count : {row_count}")
    df = pd.read_excel(file_path)
    column_index = list(df.columns)
    column_index = [str(column).lower() for column in column_index]
    column_index = column_index.index(str(column_name).lower())
    target_column_address = get_alphabet(column_index)
    last_column = get_alphabet(len(list(df.columns))-1)
    Variable_not_resettable.logger.info(f"Last column address: {last_column}")
    Variable_not_resettable.logger.info(f"Target column address : {target_column_address}")
    is_xl_app_open = False
    is_xl_file_open = False
    is_xl_sheet_open = False
    try:
        xl_app = xw.App()
        is_xl_app_open = True
        xl_app.visible = True
        xl_app.display_alerts = False
        Variable_not_resettable.logger.info("Excel application process id : "+ str(xl_app.pid))
        Variable_not_resettable.logger.info("Excel version : "+ str(xl_app.version))
        wb = xl_app.books.open(file_path, update_links=False, ignore_read_only_recommended=True)   
        is_xl_file_open = True
        ws = wb.sheets[0]
        is_xl_sheet_open = True
        first_col_range = ws.range(f"A2:{last_column}{row_count}")
        data_range = ws.range(f"{target_column_address}2:{target_column_address}{row_count}")
        if sort_by == "Asc":
            ws.range(first_col_range).api.Sort(Key1=data_range.api, Order1=1, Header=2, Orientation=1)
        elif sort_by == "Dsc":
            ws.range(first_col_range).api.Sort(Key1=data_range.api, Order1=2, Header=2, Orientation=1)
        Variable_not_resettable.logger.info(f"Target data range : {data_range}")
        wb.save(file_path_1)
        wb.close()
        xl_app.quit()
        xl_app.kill()
    except Exception as error:
        Variable_not_resettable.logger.info(str(error))
        if is_xl_file_open == True:
            wb.save(file_path_1)
            wb.close()
        if is_xl_app_open == True:
            xl_app.quit()
            xl_app.kill()
        raise Exception(str(error))

    df_duplicate = pd.read_excel(file_path_1)
    df_duplicate_column = df_duplicate[column_name]
    df_duplicate_column_list = df_duplicate_column.to_list()
   
    os.remove(file_path_1)
    return df_duplicate_column_list

def saveDataToExcelInInputDocs(row_index, value,file_name, sheet,data_reference):
    file_path = Common_path.base_path + "/Files/Input_Documents/" +file_name    
    df = pd.read_excel(file_path, sheet_name=sheet)
    column_index = list(df.columns)   
    column_index = [str(column).lower() for column in column_index]   
    column_index = column_index.index(str(data_reference).lower())    
    column_address = get_alphabet(column_index)
    app1 = xw.App()
    app1.visible = False    
    app1.display_alerts = False    
    Variable_not_resettable.logger.info("Excel application process id : "+ str(app1.pid))
    Variable_not_resettable.logger.info("Excel version : "+ str(app1.version))   
    wb_1 = app1.books.open(file_path, update_links=False, ignore_read_only_recommended=True)    
    ws_1 = wb_1.sheets[sheet]
    ws_1.range(column_address+str(row_index+2)).value = value    
    wb_1.save()
    wb_1.close()
    app1.quit()
    app1.kill()


def excel_validator(pdf_file_path: str):
    error_str = "Excel is empty"    
    reader_df = pd.read_excel(pdf_file_path).fillna("")
    column_headers = reader_df.columns    
    dict_of_reader_df = reader_df.to_dict("records")
    content_in_excel = []
    for each_dict in dict_of_reader_df:
        for header in column_headers:
            content = each_dict[str(header)]
            if content != "":
               content_in_excel.append(content) 
    # print(content_in_excel)    
    if len(content_in_excel) > 0:
        Variable_not_resettable.logger.info("Excel is not empty")
    else:
        raise Exception(error_str)
    

def convert_doc_to_text(doc_file_path):
    pandoc_directory = "dependency/pandoc-3.1.8/"
    new_path = os.path.join(os.getcwd(), pandoc_directory)
    os.environ["PATH"] = f"{new_path};{os.environ['PATH']}"

    try:
        text = pypandoc.convert_file(doc_file_path, 'plain', format='docx')
        return text
    except Exception as e:
        print(f"Error: {e}")
        return None

def extract_text_with_position(text):
    lines = text.split('\n')
    data_with_position = []
    # current_page = None
    for line_number, line in enumerate(lines, start=1):
        # if re.match(r'^Page \d+$', line.strip()):
        #     current_page = line.strip()
        # else:
            data_with_position.append({
                'Line': line_number,
                'Text': line})

    return data_with_position

def compare_documents(doc1_text, doc2_text):
    data_with_position_doc1 = extract_text_with_position(doc1_text)
    data_with_position_doc2 = extract_text_with_position(doc2_text)
    return data_with_position_doc1, data_with_position_doc2

def write_differences_to_excel(differences, excel_file):
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    # sheet.cell(row=1, column=1, value='Page')
    sheet.cell(row=1, column=1, value='Line')
    sheet.cell(row=1, column=2, value='Text (Doc 1)')
    sheet.cell(row=1, column=3, value='Text (Doc 2)')

    for row, (line_doc1, line_doc2) in enumerate(differences, start=2):
        # sheet.cell(row=row, column=1, value=line_doc1['Page'])
        sheet.cell(row=row, column=1, value=line_doc1['Line'])
        sheet.cell(row=row, column=2, value=line_doc1['Text'])
        sheet.cell(row=row, column=3, value=line_doc2['Text'])
    workbook.save(excel_file)





def kill_excel_processes():
    """Kill any lingering Excel processes to avoid conflicts."""
    for proc in psutil.process_iter(['pid', 'name']):
        if proc.info['name'] == 'EXCEL.EXE':
            proc.kill()





def check_file_validity(file_path):
    """Check if the file is a valid Excel file by trying to read it."""
    try:
        df = pd.read_excel(file_path)
        return True
    except Exception as e:
        Variable_not_resettable.logger.error(f"File {file_path} is not a valid Excel file or is corrupted: {e}")
        return False

def saveDataTo_different_header(row_index, value):
    # delete_gen_py_folder()  #### temp disable ####
    file_path = Common_path.dataSheet_path + "/"+Common_object.test_config_dictionary['DataTag'] + "/" + Common_step.DATA_FILE + ".xlsx"
   
    
    df = pd.read_excel(file_path, sheet_name=Common_step.DATA_SHEET)
    column_index = list(df.columns)
    # print(column_index)
    column_index = [str(column).lower() for column in column_index]
    # print(column_index)
    column_index = column_index.index(str(Common_step.DATA_REFERENCE2).lower())
    # print(column_index)
    column_address = get_alphabet(column_index)
    app1 = xw.App()
    app1.visible = False
    app1.display_alerts = False
    # print("Excel application process id : ", app1.pid)
    Variable_not_resettable.logger.info("Excel application process id : "+ str(app1.pid))
    # print("Excel version : ", app1.version)
    Variable_not_resettable.logger.info("Excel version : "+ str(app1.version))
   
    wb_1 = app1.books.open(file_path, update_links=False,ignore_read_only_recommended=True)   
    ws_1 = wb_1.sheets[Common_step.DATA_SHEET]
    ws_1.range(column_address+str(row_index+2)).value = value
    wb_1.save()
    wb_1.close()
    app1.quit()
    app1.kill()





    