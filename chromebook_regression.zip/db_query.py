
import time

import pyodbc
import pandas as pd
from common_object import Common_db_objects, Common_object, Common_path, Common_step, Variable_not_resettable
from excel_utils import read_dataFrame_return_dictionary_for_row_based
import xlwings as xw

import pymssql
from db_utils import check_db_connection_info

from utils import  get_alphabet

def db_connect_pymssql(driver, server, port, database_name, username, password):
    server_and_port = str(server) +","+str(port)
    Variable_not_resettable.logger.info(f"Connecting Database server : '{server_and_port}'")
    try:
        db_connection_object = pymssql.connect(host = server, user=username, password=password, database=database_name, timeout=Variable_not_resettable.db_connection_time_out_in_sec_for_direct_query, port=port)
        Variable_not_resettable.logger.info(f"Database server '{server_and_port}' connected successfully")
    except Exception as error:
        error_str = f"Database connection Error: {str(error)}"
        Variable_not_resettable.logger.error(error_str)
        raise Exception(error_str)

    return db_connection_object




def db_connect(driver, server, port, database_name, username, password):
    server_and_port = str(server) +","+str(port)
    Variable_not_resettable.logger.info(f"Connecting Database server : '{server_and_port}'")
    connection_string = 'DRIVER={};SERVER={};DATABASE={};UID={};PWD={};'.format(driver, server +","+str(port), database_name, username, password)
    try:
        db_connection_object = pyodbc.connect(connection_string, timeout=Variable_not_resettable.db_connection_time_out_in_sec_for_direct_query)
        Variable_not_resettable.logger.info(f"Database server '{server_and_port}' connected successfully")
    except Exception as error:
        error_str = f"Database connection Error: {str(error)}"
        Variable_not_resettable.logger.error(error_str)
        raise Exception(error_str)

    return db_connection_object

def db_query(db_object, query):
    try:
        Variable_not_resettable.logger.info("Executing the Query : "+ str(query))
        query_result = pd.read_sql(query, db_object)
        Variable_not_resettable.logger.info("Query Executing completed successfully")
    except Exception as error:
        db_object.close()
        error_str = f"Query Executing Failed : {str(error)}"
        Variable_not_resettable.logger.error(error_str)
        # db_object.close()
        Variable_not_resettable.logger.info(f"Database connection closed")
        raise Exception(error_str)
    return query_result


def get_query_input_data(input_data_file_name, input_data_sheet_name, input_data_column_name, final_loop_count):
    input_file_path = Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+input_data_file_name+".xlsx"
    data_frame = pd.read_excel(input_file_path, input_data_sheet_name, dtype="str")
    # print("data_frame :", data_frame)
    input_data = data_frame.to_dict("records")
    if len(input_data) > final_loop_count:
        input_data = input_data[final_loop_count]
    else:
        input_data = input_data[0]
    return input_data[input_data_column_name]

def read_config_sheet_return_list_dict(df:pd.DataFrame, start_row_value_for_each_config: str | None = "DBCONFIG_ID") -> list[dict]:
    df = df.to_dict('records')
    db_connection_list = []
    for d in df:
        if d[(list(df[0].keys()))[0]] == start_row_value_for_each_config:
            db_connection_list.append({})
        if str(d[(list(df[0].keys()))[0]]) != "nan" and str(d[(list(df[0].keys()))[1]]) != "nan":
            db_connection_list[-1].update({d["DBCONNECTION"]: d["Unnamed: 1"]})
    return db_connection_list

def direct_query(db_connection_info, db_query_reference, final_loop_count):
    variable_dict = {}
    for num, query_reference in enumerate(str(db_query_reference["DB_INPUT"]).split(",")):
        input_data_file_name, input_data_sheet_name, input_data_column_name = str(query_reference).split(":")
        query_input_data = get_query_input_data(input_data_file_name, input_data_sheet_name, input_data_column_name, final_loop_count)
        variable_dict.update({"var"+str(num+1) : query_input_data})
    query_string = str(db_query_reference["DB_QUERY"])
    for key, value in variable_dict.items():
        query_string = str(query_string).replace(":"+str(key), "'"+str(value)+"'")
    Common_db_objects.DB_SERVER = db_connection_info["SERVER"]
    Common_db_objects.DB_PORT = db_connection_info["PORT"]
    Common_db_objects.DB_PROVIDER = db_connection_info["PROVIDER"]
    Common_db_objects.DB_NAME = db_connection_info["DBNAME"]
    check_db_connection_info(db_connection_info)
    db_connection_object = db_connect_pymssql(db_connection_info["DRIVER"], db_connection_info["SERVER"], db_connection_info["PORT"], db_connection_info["DBNAME"], db_connection_info["USERNAME"], db_connection_info["PASSWORD"])
    Variable_not_resettable.logger.info("DB connected for direct query")
    Variable_not_resettable.logger.info("query_string : "+ str(query_string))
    try:
        cursor = db_connection_object.cursor(as_dict=True)
        cursor.execute(query_string)
        db_output_data = cursor.fetchall()
    except Exception as error:
        db_connection_object.close()
        Variable_not_resettable.logger.info("DB connection closed")
        Variable_not_resettable.logger.error(str(error))
        raise Exception(str(error))


    # db_output_data = db_query(db_object, query_string)
    # db_object.close()
    db_connection_object.close()
    Variable_not_resettable.logger.info(f"Database connection closed")
    Variable_not_resettable.logger.debug("Database output : "+ str(db_output_data))
    try:
        # db_output_data = db_output_data.to_dict('records')[0]

        db_output_data = db_output_data[0]
    except Exception as error:
        Variable_not_resettable.logger.info(str(error))
        if "list index out of range" in str(error):
            error_str = "No output from database"
            Variable_not_resettable.logger.info(str(error_str))
            db_output_data = ""
            
    db_output_store_files = str(db_query_reference["DB_OUTPUT_STORE"]).split(",")
    db_output_column_name_selectors = str(db_query_reference["DB_OUTPUT"]).split(",")
    db_output_column_name_selectors = [db_output_column.strip() for db_output_column in db_output_column_name_selectors]
    db_output_store_files = [files.replace("\n", "") for files in db_output_store_files]
    db_output_column_name_selectors = [files.replace("\n", "") for files in db_output_column_name_selectors]
    for db_output_store_file,db_output_column_name_selector  in zip(db_output_store_files, db_output_column_name_selectors):
        folder_to_save = None        
        if ">" in db_output_store_file:
            splitting_destination_path = db_output_store_file.split(">")
            folder_to_save = (splitting_destination_path[0]).strip()
            db_output_store_file = splitting_destination_path[1]
        output_data_file_name, output_data_sheet_name, output_data_column_name = str(db_output_store_file).split(":")
        output_data_file_name, output_data_sheet_name, output_data_column_name = output_data_file_name.strip(), output_data_sheet_name.strip(), output_data_column_name.strip()
        if db_output_data != "":
            db_data = db_output_data.get(db_output_column_name_selector)
        else:
            db_data = ""
        if folder_to_save != None:
            if "|" in folder_to_save:
                split_folder_to_save = folder_to_save.split("|")
                file_format = split_folder_to_save[1]
                folder_to_save = split_folder_to_save[0]
                file_path = Common_path.base_path + "\\Files"+"\\"+folder_to_save+"\\"+ output_data_file_name + "."+file_format
                # else:
                #     Variable_not_resettable.logger.info("Please check the file format extension")
            else:
                file_path = Common_path.base_path + "\\Files"+"\\"+folder_to_save+"\\"+ output_data_file_name + ".xlsx"
        else:
            file_path = Common_path.dataSheet_path + "\\"+Common_object.test_config_dictionary['DataTag'] + "\\" + output_data_file_name + ".xlsx"
        df = pd.read_excel(file_path, sheet_name=output_data_sheet_name)
        column_index = list(df.columns)
        column_index = [str(column).lower() for column in column_index]
        column_index = column_index.index(str(output_data_column_name).lower())
        column_address = get_alphabet(column_index)


        app1 = xw.App()
        app1.visible = False
        app1.display_alerts = False
        Variable_not_resettable.logger.debug("Excel application process id : "+ str(app1.pid))
        Variable_not_resettable.logger.debug("Excel version : "+ str(app1.version))

        wb_1 = app1.books.open(file_path, update_links=False, ignore_read_only_recommended=True)  
        ws_1 = wb_1.sheets[output_data_sheet_name]
        Variable_not_resettable.logger.debug(f"db_data : {db_data}")
        ws_1.range(column_address+str(final_loop_count+2)).value = "'"+str(db_data)
        wb_1.save()
        wb_1.close()
        app1.quit()
        app1.kill()

    return db_output_data, db_data

def stored_procedure(db_connection_info, db_query_reference, final_loop_count):
    Variable_not_resettable.logger.debug("db_connection_info : "+ str(db_connection_info))
    username= db_connection_info["USERNAME"]
    password= db_connection_info["PASSWORD"]
    database= db_connection_info["DBNAME"]
    server= db_connection_info["SERVER"]
    port = db_connection_info["PORT"]
    try:
        Variable_not_resettable.logger.info(f"Connecting Database server : '{server}' at port '{port}'")
        # connection = pymssql.connect(server, username, password, database, timeout=60)
        connection = pymssql.connect(host = server, user=username, password=password, database=database, timeout=Variable_not_resettable.db_connection_time_out_in_sec_for_sp, port=port)
        Variable_not_resettable.logger.info(f" Database server connected successfully")
    except Exception as error:
        error_str = f"Unable to connect database server : {str(error)}"
        Variable_not_resettable.logger.error(error_str)
        raise Exception(error_str)

    cursor = connection.cursor(as_dict=True)

    try:
        if db_query_reference["DB_INPUT"] == 'NA' or db_query_reference["DB_INPUT"] == '' or str(db_query_reference["DB_INPUT"]) == "nan":
            Variable_not_resettable.logger.info("Query String : "+ str(db_query_reference["DB_QUERY"]))
            Variable_not_resettable.logger.info(f"Executing Stored Procedure")
            start_time = time.perf_counter()
            cursor.callproc(db_query_reference["DB_QUERY"])
            end_time = time.perf_counter()
            time_consume = end_time - start_time
            Variable_not_resettable.logger.info(f"Stored Procedure completed successfully in : {str(int(time_consume))}sec")
        else:
            inputs_split = db_query_reference['DB_INPUT'].split("|")
            temp_var = []
            for inputs in inputs_split:
                details = inputs.split(",")[-1]
                input_data_file_name, input_data_sheet_name, input_data_column_name = str(details).split(":")
                query_input_data = get_query_input_data(input_data_file_name, input_data_sheet_name, input_data_column_name, final_loop_count)
                temp_var.append(str(query_input_data))
            sp_name = db_query_reference['DB_QUERY']
            sp_params = tuple(temp_var)
            Variable_not_resettable.logger.info(f"SP Name : {sp_name}")
            Variable_not_resettable.logger.info(f"SP Params : {sp_params}")
            Variable_not_resettable.logger.info(f"Executing Stored Procedure")
            start_time = time.perf_counter()
            if len(temp_var) == 0:
                Variable_not_resettable.logger.info(f"SP calling query : {sp_name}")
                cursor.callproc(sp_name)
            elif len(temp_var) > 0:
                Variable_not_resettable.logger.info(f"SP calling query : {sp_name, sp_params}")
                cursor.callproc(sp_name, sp_params)

            end_time = time.perf_counter()
            time_consume = end_time - start_time
            Variable_not_resettable.logger.info(f"Stored Procedure completed successfully in : {str(int(time_consume))}sec")
        cursor.close()
        connection.commit()
        connection.close()
        Variable_not_resettable.logger.info(f"Database connection closed")
    except Exception as error:
        error_str = str(error)
        Variable_not_resettable.logger.info(error_str)
        if "Server connection timed out" in error_str:
            error_str = "Database Server connection timed out :"+ str(Variable_not_resettable.db_connection_time_out_in_sec_for_sp)+" sec"
        Variable_not_resettable.logger.error(error_str)
        cursor.close()
        connection.close()
        Variable_not_resettable.logger.info(f"Database connection closed")
        raise Exception(error_str)
    return None, None

def update_query(db_connection_info, db_query_reference, final_loop_count):
    try:
        db_object = db_connect(db_connection_info["DRIVER"], db_connection_info["SERVER"], db_connection_info["PORT"], db_connection_info["DBNAME"], db_connection_info["USERNAME"], db_connection_info["PASSWORD"])
        cursor = db_object.cursor()
        variable_dict = {}
        query_string = db_query_reference['DB_QUERY']
        for num, query_reference in enumerate(str(db_query_reference["DB_INPUT"]).split(",")):
            input_data_file_name, input_data_sheet_name, input_data_column_name = str(query_reference).split(":")
            query_input_data = get_query_input_data(input_data_file_name, input_data_sheet_name, input_data_column_name, final_loop_count)
            variable_dict.update({"var"+str(num+1) : query_input_data})
        for key, value in variable_dict.items():
            query_string = str(query_string).replace(":"+str(key), "'"+str(value)+"'")
        query_string = query_string.replace("_x000D_", "")
    
        Variable_not_resettable.logger.info("Executing the Query : "+ str(query_string))
        cursor.execute(query_string)
        Variable_not_resettable.logger.info("Query Executing completed successfully")
        db_object.commit()
        Variable_not_resettable.logger.info("Query committed successfully")
    except Exception as error:
        Variable_not_resettable.logger.info(str(error))
        db_object.close()
        Variable_not_resettable.logger.info(f"Database connection closed")
        raise Exception(str(error))

    db_object.close()
    Variable_not_resettable.logger.info(f"Database connection closed")
    return None, None

def insert_query(db_connection_info, db_query_reference, final_loop_count):
    db_object = db_connect(db_connection_info["DRIVER"], db_connection_info["SERVER"], db_connection_info["PORT"], db_connection_info["DBNAME"], db_connection_info["USERNAME"], db_connection_info["PASSWORD"])
    cursor = db_object.cursor()
    variable_dict = {}
    query_string = db_query_reference['DB_QUERY']
    for num, query_reference in enumerate(str(db_query_reference["DB_INPUT"]).split(",")):
        input_data_file_name, input_data_sheet_name, input_data_column_name = str(query_reference).split(":")
        query_input_data = get_query_input_data(input_data_file_name, input_data_sheet_name, input_data_column_name, final_loop_count)
        variable_dict.update({"var"+str(num+1) : query_input_data})
    for key, value in variable_dict.items():
        query_string = str(query_string).replace(":"+str(key), "'"+str(value)+"'")
    query_string = query_string.replace("_x000D_", "")
    try:
        Variable_not_resettable.logger.info("Executing the Query : "+ str(query_string))
        cursor.execute(query_string)
        Variable_not_resettable.logger.info("Query Executing completed successfully")
        db_object.commit()
    except Exception as error:
        Variable_not_resettable.logger.info(str(error))
        db_object.close()
        Variable_not_resettable.logger.info(f"Database connection closed")
        raise Exception(str(error))

    Variable_not_resettable.logger.info("Query committed successfully")
    db_object.close()
    Variable_not_resettable.logger.info(f"Database connection closed")
    return None, None

def db_query_config(final_loop_count):
    DBConfig = Common_object.test_config_dictionary["DBConfig"]

    if DBConfig == None or DBConfig == "" or str(DBConfig).lower() == "nan":
        db_master_path = "Files\\DBQuery\\DBMaster.xlsx"
    else:
        db_master_path = "Files\\DBQuery\\"+DBConfig+".xlsx"
    db_connection_sheet_name = "Connections"
    db_config_sheet_name = "DBQueryConfig"


    db_connection_list = read_config_sheet_return_list_dict(pd.read_excel(db_master_path, db_connection_sheet_name))
    db_config_list = read_dataFrame_return_dictionary_for_row_based(pd.read_excel(db_master_path, db_config_sheet_name))
    Variable_not_resettable.logger.info("db query action : "+ str(Common_step.ACTION))
    query_id = str(Common_step.ACTION).split(":")[1]
    Variable_not_resettable.logger.info("query id : "+ str(query_id))
    try:
        db_config = [db_config for db_config in db_config_list if db_config['QueryID'] == int(query_id)][0]
    except Exception as error:
        if "list index out of range" in str(error):
            err_str = f"Check the Query id: {query_id} in file name: {db_master_path} and sheet name: {db_config_sheet_name}"
            Variable_not_resettable.logger.error("db config :"+ str(db_config))
        raise Exception(str(err_str))
    Variable_not_resettable.logger.info("db config :"+ str(db_config))
    query_reference_file_name, query_reference_sheet_name = str(db_config['QueryReference']).split(":")
    try:
        db_connection_info = [db_connection for db_connection in db_connection_list if str(db_config['DBCONFIG_ID'] )== str(db_connection['DBCONFIG_ID'])][0]
    except Exception as error:
        Variable_not_resettable.logger.error(str(error))
        if "list index out of range" in str(error):
            error_str = f"Check DBMaster and supporting files"
            Variable_not_resettable.logger.warning(error_str)
            raise Exception(error_str)
        else:
            raise Exception(str(error))
    Variable_not_resettable.logger.debug(f"db_connection_info : {db_connection_info}")
    db_master_query_reference = "Files\\DBQuery\\"+query_reference_file_name+".xlsx"
    db_query_reference_sheet_name = query_reference_sheet_name
    db_query_reference_list = read_dataFrame_return_dictionary_for_row_based(pd.read_excel(db_master_query_reference,sheet_name= db_query_reference_sheet_name, dtype="str", keep_default_na=True))
    try:
        db_query_reference = [db_query_reference for db_query_reference in db_query_reference_list if str(db_query_reference['QUERY_ID']) == str(int(query_id))][0]
    except Exception as error:
        Variable_not_resettable.logger.error(str(error))
        if "list index out of range" in str(error):
            error_str = f"Check queryID, DBMaster_QueryReference and supporting files"
            Variable_not_resettable.logger.warning(error_str)
            raise Exception(error_str)
        else:
            raise Exception(str(error))
    Variable_not_resettable.logger.info("db query reference : "+ str(db_query_reference))
    query_type = db_query_reference["QUERY_TYPE"]
    try:
        if query_type == "DIRECT QUERY":
            db_output = direct_query(db_connection_info, db_query_reference,final_loop_count)
        elif query_type == "STORED PROCEDURE":
            db_output = stored_procedure(db_connection_info, db_query_reference, final_loop_count)
        elif query_type == "UPDATE QUERY":
            db_output = update_query(db_connection_info, db_query_reference, final_loop_count)
        elif query_type == "INSERT QUERY":
            db_output = insert_query(db_connection_info, db_query_reference, final_loop_count)
        return db_output
    except Exception as error:
        char_need_to_remove_in_msg_list = ['"', ",", "=", "\n"]
        char_need_to_add_in_msg_list = ["", "-", "-", ". "]
        for char_need_to_remove_in_msg, char_need_to_add_in_msg in zip(char_need_to_remove_in_msg_list,char_need_to_add_in_msg_list):
            error_str = str(error).replace(char_need_to_remove_in_msg, char_need_to_add_in_msg)
        raise Exception(error_str)
