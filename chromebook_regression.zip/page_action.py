
from common_object import Common_controls, Common_data, Common_object, Common_path, Common_scenario, Common_step, Variable_not_resettable
from page_object_wrapper import Wrapper_variables
from play_code import *
from utils import *
from split_data import *
from pdf_extractor.rpa_pdf_extractor_main import asserting_directly_in_xml
import pandas as pd
from pdf_extractor.commonObject import pObject
from excel_utils import *
from xlm_utils import * 
from pdf_extractor.rpa_pdf_extractor_main import *
from ui_sort_comparison import *
from Web_Page_Assertion.mlgrid import *
from files_movement_and_validation import *
import glob
from dataGenerator import *
from change_json_name import *
from control_sheet import *


test_properties = read_properties_file("test.properties")

def create_Child_xpath(props, values):
    created_xpath = "//*[@"+props[0]+"='"+values[0]+"' and @"+props[1]+"='"+values[1]+"']"
    return created_xpath

def page_action(page_object, context, action, loc_xpath, data):
    if ("Assert Error Popup" in Common_step.BASE_ACTION) and ("||" in data):
        split_with_pipe = data.split("||")
        data = split_with_pipe[0]
        Common_object.Error_Popup = split_with_pipe[1]
    
    if ("Assert Success Popup" in Common_step.BASE_ACTION) and ("||" in data):
        split_with_pipe = data.split("||")
        data = split_with_pipe[0]
        Common_object.Error_Popup = split_with_pipe[1]
        
    Variable_not_resettable.logger.info("Xpath : "+ str(loc_xpath))
    Variable_not_resettable.logger.info("Data Value : "+ str(data))

    if test_properties.get("element_highlighter") == "True":
        element_bg_color = get_element_bg_color(page_object, loc_xpath)
        highlight_element(page_object, loc_xpath, get_element_highlighter_color(test_properties))
   

    match action:
        
        case "Enter Text":
            for_click(page_object,loc_xpath)
            for_fill(page_object,loc_xpath,data)
        
        case "Password Text":
            for_click(page_object,loc_xpath)
            if "ramcopassword" in str(loc_xpath):
                page_object.keyboard.type(str(data), delay=200)
            else:
                for_fill(page_object,loc_xpath,data)
        
        case "Click Button":
            # print("Doing page action click button")
            for_click_button(page_object,loc_xpath)
            Variable_not_resettable.logger.info("Click button action completed")
            time.sleep(0.2) # More efficient to close pop ups (Getting benefit for please wait and popup)
            if "Assert Popup" in str(Common_step.BASE_ACTION) or "Skip Error" in str(Common_step.BASE_ACTION):
                time.sleep(1)   
        
        case "Select Combo":

            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                Variable_not_resettable.logger.info("Select Combo for nebula running...")
                for_select_combo_nebula(page_object, loc_xpath, data)
            elif Variable_not_resettable.APP_TYPE == "Studio":
                Variable_not_resettable.logger.info("Select Combo for Studio running...")
                for_select_combo_studio(page_object, loc_xpath, data)
            else:
                for_select_combo(page_object, loc_xpath, data)
        
        case "Multi Select Combo":

            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")   
                page_object.click(loc_xpath)
                if str(data).lower() != "nan" and str(data) != "" and str(data) != None:
                    list_data = str(data).split(";")
                    given_control_value = str(Common_controls.control_Value)
                    for each_data in list_data:
                        required_check_box_path_id = (given_control_value.split("listview"))[0] + "input_async_" + str(each_data) + "_check" 
                        required_check_box_path = "//*[@id='"+required_check_box_path_id+"']"
                        Variable_not_resettable.logger.info(f"required_check_box_path : {required_check_box_path}")
                        page_object.locator(required_check_box_path).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                        page_object.click(required_check_box_path,timeout= Common_object.Timeout)
                        time.sleep(0.2)
                        Variable_not_resettable.logger.info(f"Clicked : {each_data}")

                    page_object.click(loc_xpath)
                else:
                    Variable_not_resettable.logger.info(f"No data given, kindly check the data")

            else:
                multi_input = data.split(";")
                splitdatavalue1 = int(multi_input[0])
                multi_count = 0
                multi_index = 0
                for_click(page_object, loc_xpath)
                while True:
                    if multi_count == splitdatavalue1:
                        break
                    multi_index = multi_index + 1
                    splitdatavalue = multi_input[multi_index]
                    time.sleep(5)
                    combo_value_xpath = "//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, 'listviewpicker-body')]//pre[text()='"+splitdatavalue+"']"
                    # print("Combo Value Xpath : ", combo_value_xpath)
                    getid = page_object.query_selector(combo_value_xpath)
                    # print("getid_selector : ", getid)
                    getid = getid.get_attribute("id")
                    # print("getid : ", getid)
                    inputGetid = getid.split("_")
                    inputid1 = inputGetid[1]
                    inputid2 = inputGetid[2]
                    inputid3 = inputGetid[4]
                    view_picker = "(//*[@aria-hidden='false']//div[contains(@id, '"+inputid1+"_"+inputid2+"')][contains(@id, '"+inputid3+"')])[1]"
                    
                    qry_selector = page_object.query_selector(view_picker)
                    if qry_selector == None:  # Code added on 22/09/2022 because getting error in SRP for no combo value, query selector return None value.
                        for_click(page_object, loc_xpath)
                        raise Exception("No Combo value found")
                    if "checked" in qry_selector.get_attribute("class"):
                        pass
                    else:
                        # print("getid_selector : ", getid)
                        # print("view_picker : ", view_picker)
                        for_click(page_object, view_picker)
                    multi_count = multi_count + 1
                for_click(page_object, loc_xpath) 
        
        case "Click Checkbox":
            for_click_checkbox(page_object,loc_xpath)
        
        case "Edit And Enter":
            for_fill(page_object, loc_xpath, "")
            for_click(page_object,loc_xpath)
            for_fill(page_object, loc_xpath, data)
            time.sleep(1)
            page_object.keyboard.press("Enter")
        
        case "Enter Text Area":
            for_fill(page_object,loc_xpath,data)
        
        case "Enter Number":
            # for_fill(page_object,loc_xpath,"")
            for_fill(page_object,loc_xpath,data)
        
        case "Clear Text":
            if str(Common_controls.control_Identifier)=="xpath":
                for index , each_data in enumerate(data.split(";"), 1):
                    key = f":var{index}"
                    loc_xpath = loc_xpath.replace(key, each_data)
                    Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")

            for_fill(page_object,loc_xpath,"")
        
        case "Click Link":
            for_click_link(page_object,loc_xpath)
        
        case "Close Dialog":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                Variable_not_resettable.logger.info("Close Dialog for nebula running...")
                Variable_not_resettable.logger.info("close dialog xpath : "+ str(loc_xpath))
                element_handler = page_object.query_selector_all(loc_xpath)
                Variable_not_resettable.logger.info("Len of element_handler : "+ str(len(element_handler)))
                Variable_not_resettable.logger.info(str(element_handler))
                is_close_dialog_clicked = False
                try:
                    for element in element_handler:
                        Variable_not_resettable.logger.info("Checking...., Close Dialog is clickable")
                        if element.is_visible():
                            try:
                                Variable_not_resettable.logger.info("Close Dialog is clickable")
                                element.click(timeout=2000)
                                Variable_not_resettable.logger.info("Close Dialog is clicked")
                                is_close_dialog_clicked = True
                                break
                            except:
                                try:
                                    Variable_not_resettable.logger.info("Close Dialog is clickable")
                                    element.click(timeout=2000,  position={"x": 0.0, "y": 0.0})
                                    Variable_not_resettable.logger.info("Close Dialog is clicked")
                                    is_close_dialog_clicked = True
                                    break
                                except Exception as error:
                                    Variable_not_resettable.logger.info("Close Dialog is not clickable")
                    if is_close_dialog_clicked == False:
                        raise Exception("Close dialog Click action failed.")
                except Exception as error:
                    wait_unitil_please_wait(page_object, 100)
                    wait_and_close_popup(page_object)
                    Variable_not_resettable.logger.info("Close Dialog is not clickable, so using keyboard action Escape Key")
                    page_object.keyboard.press("Escape")
                #for_click(page_object,loc_xpath)
            else:
                if check_is_popup(page_object, Common_object.Timeout_pop_up):
                    wait_and_close_popup(page_object)
                    wait_unitil_please_wait(page_object, 100)
                close_dialog_xpath = "//*[@role='dialog' and @aria-hidden='false']//*[@data-qtip='Close dialog'][starts-with(@id,'tool')]//*[contains(@id, 'toolEl')]"
                Variable_not_resettable.logger.info("close dialog xpath : "+ str(close_dialog_xpath))
                element_handler = page_object.query_selector_all(close_dialog_xpath)
                Variable_not_resettable.logger.info("Len of element_handler : "+ str(len(element_handler)))
                Variable_not_resettable.logger.info(str(element_handler))
                is_close_dialog_clicked = False
                try:
                    for element in element_handler:
                        Variable_not_resettable.logger.info("Checking...., Close Dialog is clickable")
                        if element.is_visible():
                            try:
                                Variable_not_resettable.logger.info("Close Dialog is clickable")
                                element.click(timeout=2000)
                                Variable_not_resettable.logger.info("Close Dialog is clicked")
                                is_close_dialog_clicked = True
                                break
                            except:
                                try:
                                    Variable_not_resettable.logger.info("Close Dialog is clickable")
                                    element.click(timeout=2000,  position={"x": 0.0, "y": 0.0})
                                    Variable_not_resettable.logger.info("Close Dialog is clicked")
                                    is_close_dialog_clicked = True
                                    break
                                except Exception as error:
                                    Variable_not_resettable.logger.info("Close Dialog is not clickable")
                    if is_close_dialog_clicked == False:
                        raise Exception("Close dialog Click action failed.")
                except Exception as error:
                    wait_unitil_please_wait(page_object, 100)
                    wait_and_close_popup(page_object)
                    Variable_not_resettable.logger.info("Close Dialog is not clickable, so using keyboard action Escape Key")
                    page_object.keyboard.press("Escape")
        
        case "Close Dialog2":
            wait_unitil_please_wait(page_object, 2000)
            page_object.keyboard.press("Escape")
        
        case "Click Help":
            for_click(page_object,loc_xpath)
        
        case "Enter Date":
            #for_click(page_object,loc_xpath)
            for_fill_date(page_object,loc_xpath,data)    
        
        case "Click Toggle":
            # selector_toggle_following = "//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]/following::div[@name='undefined_tool']"
            # selector_toggle_preceding = "//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, '"+Wrapper_variables.containsId+"')]/preceding ::div[@name='undefined_tool']"
            
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                try:
                    set_focus_to_element(page_object,loc_xpath)
                    for_click(page_object,loc_xpath)
                except Exception as error:
                    Variable_not_resettable.logger.info(str(error))
                    raise Exception(str(error))
            else:
                selector_toggle = "//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]/div[@name='undefined_tool']"
                try:
                    for_click_toggle(page_object,selector_toggle)
                    Variable_not_resettable.logger.info("selector_toggle xpath :"+ str(selector_toggle))
                except Exception as error:
                    Variable_not_resettable.logger.info(str(error))
                    raise Exception(str(error))
        
        case "Click Tab":
            for_click_tab(page_object,loc_xpath)
        
        case "Click Radio Button":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                for_click_radio(page_object,loc_xpath)
            else:
                for_click(page_object,loc_xpath)
        
        case "List Edit Enter":
            wait_unitil_please_wait(page_object,200)
            page_object.click(loc_xpath)
            page_object.fill(loc_xpath, "")
            if str(data).lower() != "nan" and str(data) != "" and str(data) != None and str(data) != str(None)and str(data).lower() != "na":
                # page_object.keyboard.type(str(data), delay=100)
                input_text = str(data)
                lee_count = 0
                for i in range(len(input_text)):
                    lee_count = lee_count+1
                    wait_unitil_please_wait(page_object,100)
                    if lee_count ==1:
                        time.sleep(1)
                    page_object.type(loc_xpath, input_text[i], delay=100)
            else:
                page_object.type(loc_xpath, str(""), delay=500)
            #for_fill(page_object,loc_xpath,data)
            page_object.click(loc_xpath)
            try:
                if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                    pass
                else:
                    search_select = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"') and @aria-hidden='false']//*[contains(@id, 'picker-bodyWrap')]/div[@name='undefined_headercontainer' and @aria-hidden='false']"
                    page_object.wait_for_selector(search_select, timeout= 5000)
            except Exception as error:
                Variable_not_resettable.logger.info("List Edit Enter : " + str(error))
            # time.sleep(0.5)
            wait_unitil_please_wait(page_object,200)
            page_object.keyboard.press("Enter")
        
        case "List Set Enter":
            for_fill(page_object,loc_xpath,"")
            for_list_set_enter(page_object,loc_xpath,data)
            page_object.click(loc_xpath)
            # time.sleep(0.5)
            try:
                if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                        pass
                else:
                    search_select = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"') and @aria-hidden='false']//*[contains(@id, 'picker-bodyWrap')]/div[@name='undefined_headercontainer' and @aria-hidden='false']"
                    page_object.wait_for_selector(search_select, timeout= 5000)
            except Exception as error:
                Variable_not_resettable.logger.info("List Set Enter : " + str(error))
                raise Exception(str(error))
            
            wait_unitil_please_wait(page_object,200)
            page_object.keyboard.press("Enter")
        
        case "Enter Grid Page":
            for_fill(page_object,loc_xpath,"")
            for_click(page_object,loc_xpath)
            for_fill(page_object,loc_xpath,str(data))
            page_object.keyboard.press("Enter")
        
        case "Smart Search":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                input_values = data.split(";")
                Variable_not_resettable.logger.info(f"input_values :{str(input_values)}")
                search_value = input_values[0]
                data_value = input_values[1]
                for_fill(page_object,loc_xpath,"")
                for_click(page_object,loc_xpath)
                search_value_length = len(search_value)
                i = 0
                while (i < search_value_length):
                    page_object.type(loc_xpath, search_value[i], delay=100)
                    search_select_id = (((Common_controls.control_Value).split("_"))[0])+"_picker_listEl"
                    search_select = "//*[@id='"+search_select_id+"']//div[@class='list_row']/span[text()='"+data_value+"']"
                    if assert_locator(page_object, search_select):
                        Variable_not_resettable.logger.info(f"search_select :{str(search_select)}")
                        time.sleep(5)
                        page_object.click(search_select)
                        break
                    time.sleep(0.5)
                    i = i + 1
                    if i == search_value_length:
                        Common_object.Custom_Error = "Smart search result value not found"
            else:
                multi_datavalue = None
                wait_unitil_please_wait(page_object,200)
                input_values = data.split(";")
                search_value = input_values[0]
                data_value = input_values[1]
                if "|" in data_value:
                    data_value_split = data_value.split("|")
                    data_value = data_value_split[0]
                    multi_datavalue = data_value_split[1]
                for_fill(page_object,loc_xpath,"")
                for_click(page_object,loc_xpath)
                search_value_length = len(search_value)
                i = 0
                while (i < search_value_length):
                    if i == 0:
                        time.sleep(1)
                    page_object.type(loc_xpath, search_value[i], delay=100)
                    wait_unitil_please_wait(page_object,500)
                    if multi_datavalue != None:
                        print("Number part present")
                        search_select = "//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, 'picker-bodyWrap')]/div[@name='undefined_headercontainer' and @aria-hidden='false']/..//table//td/div[text()='"+data_value+"']/../following-sibling::td/div[text()='"+multi_datavalue+"']"
                    else:
                        search_select = "(//div[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, 'picker-bodyWrap')]/div[@name='undefined_headercontainer' and @aria-hidden='false']/..//table//td/div[text()='"+data_value+"'])[1]"
                    if assert_locator(page_object, search_select):
                        page_object.click(search_select)
                        break
                    i = i + 1
                    if i == search_value_length:
                        Variable_not_resettable.logger.info(f"search_select_xpath :{str(search_select)}")
                        Common_object.Custom_Error = "Smart search result value not found"
                        raise Exception(str(Common_object.Custom_Error))
                
                Variable_not_resettable.logger.info(f"search_select_xpath :{str(search_select)}")
        
        case "Grid Smart Search1":
            for_fill(page_object,loc_xpath,data)
        
        case "Grid Smart Search":
            inputValues = str(data).split(";")
            search_value = inputValues[0]
            dataValue = inputValues[1]
            page_object.locator(loc_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
            for_click(page_object,loc_xpath)
            # for_fill(page_object,loc_xpath,"")
            page_object.keyboard.press("Control+A")
            page_object.keyboard.press("Backspace")
            search_value_length = len(search_value)
            i = 0
            while (i < search_value_length):
                page_object.keyboard.press(search_value[i])
                wait_unitil_please_wait(page_object,500)
                # if Wrapper_variables.numberPart != 0:
                #     sxpath ="(//*[@id='"+Wrapper_variables.objectValue+"' and text()= '"+dataValue+"'])["+Wrapper_variables.numberPart+"]"
                # else:
                #     sxpath ="//*[@id='"+Wrapper_variables.objectValue+"' and text()= '"+dataValue+"']"
                sxpath = "//div[@class='x-panel x-ltr x-boundlist x-avnsearchwindow x-layer x-panel-default x-grid x-border-box' and @aria-hidden='false']/..//table//td/div[text()='"+dataValue+"']"
                Variable_not_resettable.logger.debug(f"sxpath : {sxpath}")
                if assert_locator(page_object, sxpath):
                    page_object.click(sxpath)
                    break
                i = i + 1
                if i == search_value_length:
                    Common_object.Custom_Error = "Smart search result value not found"
        
        case "Grid Text":
            for_fill_grid_text(page_object,loc_xpath,data)
        
        case "Grid Text Enter":
            for_fill_grid_text_enter(page_object,loc_xpath,data)
        
        case "Display Block":
            for_click(page_object,loc_xpath)
        
        case "Enter Time":
            for_fill_time(page_object,loc_xpath,data)
        
        case "Assert Text":
            for_assert_text_combo(page_object, loc_xpath, data)
            for_success_snapshot(page_object)
        
        case "Assert Label Text":
            if "ramcofileattach" in loc_xpath: # only for this pattern
                page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                get_property_value = page_object.locator(loc_xpath).get_attribute("value")
                Variable_not_resettable.logger.info("Text from application : '" + str(get_property_value)+"'")
                if get_property_value == data:
                    Variable_not_resettable.logger.info("Asserting Text for : '" + str(data)+ "' is Success")
                else:
                    Common_object.Custom_Error = "Asserting Text for : '" + str(data)+ "' is failed because value in application : '"+ str(get_property_value)+"'"
                    Variable_not_resettable.logger.info(str(Common_object.Custom_Error))
                    raise Exception(str( Common_object.Custom_Error))
            else:
                for_assert_text(page_object, loc_xpath, data)
            for_success_snapshot(page_object)
        
        case "Assert Link Text":
            for_assert_text(page_object, loc_xpath, data)
            for_success_snapshot(page_object)
        
        case "Assert Button Text":
            for_assert_text(page_object, loc_xpath, data)
            for_success_snapshot(page_object)
        
        case "Assert Object":
            for_assert_object(page_object, loc_xpath)
            for_success_snapshot(page_object)
        
        case "Assert Not Object":
            for_assert_non_visible(page_object, loc_xpath)
            for_success_snapshot(page_object)
        
        case "Click Theme":
            for_click(page_object,loc_xpath)
        
        case "Click Button Icon":
            Variable_not_resettable.logger.debug("**********************Inside Click Button Icon page Action***************************")
            for_click_link(page_object,loc_xpath)
            Variable_not_resettable.logger.debug("**********************Compldted Click Button Icon page Action***************************")
        
        case "Assert Combo Selection":
            for_click(page_object,loc_xpath)
            for_assert_text_combo(page_object,loc_xpath,data)
            for_success_snapshot(page_object)
        
        case "Assert Non-editable":

            for_assert_non_editable(page_object, loc_xpath)
            for_success_snapshot(page_object)    
        
        case "Assert Non-Visible":

            if Variable_not_resettable.APP_TYPE == "Nebula co-existence" or Variable_not_resettable.APP_TYPE == "Studio":
                if data!=None:
                    for index , each_data in enumerate(data.split(";"), 1):
                            key = f":var{index}"
                            loc_xpath = loc_xpath.replace(key, each_data)

            for_assert_non_visible(page_object, loc_xpath)
            for_success_snapshot(page_object)
        
        case "Assert Visible":

            if Variable_not_resettable.APP_TYPE == "Nebula co-existence" or Variable_not_resettable.APP_TYPE == "Studio":
                if data!=None:
                    for index , each_data in enumerate(data.split(";"), 1):
                            key = f":var{index}"
                            loc_xpath = loc_xpath.replace(key, each_data)

            for_assert_visible(page_object, loc_xpath)
            for_success_snapshot(page_object)
        
        case "Click TrailBar":
            for_click(page_object,loc_xpath)
            trail_list = "//div[contains(@id,'menucheckitem')]//*[contains(@id, 'textEl')][text()='"+data+"']"
            for_click(page_object,trail_list)
        
        case "Click Recent Activities":
            for_click(page_object,loc_xpath)
            menulist = "//div[starts-with(@id,'menuitem')]//*[contains(@id, 'textEl')][text()='"+data+"']"
            for_click(page_object,menulist)
        
        case "Attach Document":
            for_attach(page_object, loc_xpath, data)
        
        case "Scroll To Element":
            scroll_to_element(page_object, loc_xpath)
        
        case "Import File":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence"  or Variable_not_resettable.APP_TYPE == "Studio" :
                Variable_not_resettable.logger.info(f"Import File for Nebula running...")
                for_click(page_object,loc_xpath)
                if str(data) != "nan":
                    control_id_value = ((Common_controls.control_Value).rsplit("_",1))[0]
                    import_file_format_xpath = "//*[starts-with(@id,'"+control_id_value+"')][text()='"+data+"']"
                    print("import_file_format_xpath :",import_file_format_xpath)
                    Variable_not_resettable.logger.info(f"import_file_format_xpath :{str(import_file_format_xpath)}")
                    for_click(page_object,import_file_format_xpath)
                else:
                    Common_object.Custom_Error = "without data value"
            else:
                for_click(page_object,loc_xpath)
                Wrapper_variables.startsWithId = str(Wrapper_variables.startsWithId).split("_")
                startsWithId = Wrapper_variables.startsWithId[0]
                if str(data) != "nan" and str(data) != "":
                    import_data = "//*[starts-with(@id,'"+startsWithId+"')]//*[contains(@id, 'textEl')][text()='"+data+"']"
                    for_click(page_object,import_data)
                else:
                    Common_object.Custom_Error = "without data value"
        
        case "Export File":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence" :
                control_id_value = ((Common_controls.control_Value).rsplit("_",1))[0]
                Variable_not_resettable.logger.info(f"control_id_value : {str(control_id_value)}")

                if (data != "nan") and (data != ""):
                    file_format_xpath = "//*[starts-with(@id,'"+control_id_value+"')][text()='"+data+"']"
                    for_click(page_object,loc_xpath)
                    with page_object.expect_download() as download_info:
                        Variable_not_resettable.logger.info(f"file_format_xpath : {str(file_format_xpath)}")
                        page_object.click(file_format_xpath)
                    download = download_info.value
                    file_name = download.suggested_filename
                    destination_folder_path = "./Downloads/"
                    download.save_as(os.path.join(destination_folder_path, file_name))
                    page_object.set_viewport_size(Common_object.screen_resolution) 

                else:
                    for_click(page_object,loc_xpath)
            elif Variable_not_resettable.APP_TYPE == "Rapids":
                loc_xpath =  Common_controls.control_Value
                if data!=None:
                    for index , each_data in enumerate(data.split(";"), 1):
                        key = f":var{index}"
                        loc_xpath = loc_xpath.replace(key, each_data)
                Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")   
                # for_click_xpath(page_object,loc_xpath)
                for_download(page_object,loc_xpath)

            elif Variable_not_resettable.APP_TYPE == "Studio":
                control_id_value = ((Common_controls.control_Value).rsplit("_",1))[0]
                Variable_not_resettable.logger.info(f"control_id_value : {str(control_id_value)}")
                destination_folder_path = "./Downloads/"

                if (data != "nan") and (data != ""):
                    file_format_xpath = "//*[starts-with(@id,'"+control_id_value+"')][text()='"+data+"']"
                    
                    # Ensure the Downloads folder exists
                    os.makedirs(destination_folder_path, exist_ok=True)

                    with page_object.expect_download() as download_info:
                        page_object.click(loc_xpath)  # Click to initiate the download
                        
                    download = download_info.value
                    file_name = download.suggested_filename

                    # Save the downloaded file to the system Downloads folder
                    download.save_as(os.path.join(destination_folder_path, file_name))
                    page_object.set_viewport_size(Common_object.screen_resolution)
                else:
                    # # Get the default Downloads folder path
                    # downloads_folder = str(Path.home() / "Downloads")

                    # Ensure the Downloads folder exists
                    os.makedirs(destination_folder_path, exist_ok=True)

                    with page_object.expect_download() as download_info:
                        page_object.click(loc_xpath)  # Click to initiate the download
                        
                    download = download_info.value
                    file_name = download.suggested_filename

                    # Save the downloaded file to the system Downloads folder
                    download.save_as(os.path.join(destination_folder_path, file_name))
                    page_object.set_viewport_size(Common_object.screen_resolution)
            else:
                for_click(page_object,loc_xpath)
                if data != "nan" or data != "":
                    Wrapper_variables.startsWithId = str(Wrapper_variables.startsWithId).split("_")
                    startsWithId = Wrapper_variables.startsWithId[0]
                    download_file = "//*[starts-with(@id,'"+startsWithId+"')]//*[contains(@id, 'textEl')][text()='"+data+"']"
                    for_download(page_object,download_file)
                else:
                    Variable_not_resettable.logger.info(f"Export file without data value")
                    pass
            
        case "Click ID With Text":
            props = ["Class", "contentText"]
            values = ["qr display*", data]
            child_xpath = create_Child_xpath(props, values)
            for_click(page_object, child_xpath)
        
        case "Click Wizard":
            for_click(page_object,loc_xpath)
            wizard_value = data.strip() #for creating xpath Need space for text not for id 
            xpath = "//a[starts-with(@id,'"+wizard_value+"')]//*[contains(@id, 'menu')][text()='"+data+"']"
            for_click(page_object,xpath)
        
        case "Click Link with Class":

            for_click(page_object, loc_xpath)    
        
        case "Click OK Button":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                props = ["ObjectIdentifier", "VisibleOnScreen"]
                values = [loc_xpath, "True"]
                page_object.locator(loc_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                for_click_button(page_object,loc_xpath)
            else:
                props = ["ObjectIdentifier", "VisibleOnScreen"]
                values = [loc_xpath, "True"]
                ele = page_object.query_selector_all(loc_xpath)
                for e in ele:
                    if e.is_visible() and str(e.inner_html()).upper() == "OK":
                        e.click()
        
        case "Click Show Help":
            for_click(page_object, loc_xpath)
            show_help_page = get_new_tab(context,1)
            show = "//a[@title='Show Navigation Component']"
            top = "//a[@id='Top']"
            topicHeader = "//div[@id='rh-topic-header']"
            topicHead = "//*[@class='TopicHead']"
            assert_loc_show = assert_locator(show_help_page,show)
            assert_loc_top = assert_locator(show_help_page,top)
            assert_loc_topicHeader = assert_locator(show_help_page,topicHeader)
            assert_loc_topicHead = assert_locator(show_help_page,topicHead)
            if assert_loc_show or assert_loc_top or assert_loc_topicHeader or assert_loc_topicHead:
                # print("OLH Verification Passed")
                Common_object.Custom_Error = "OLH Verification Passed"
            else:
                Common_object.Custom_Error = "OLH Verification Failed"
            show_help_page.close()       
        
        case "Click UserMenu Option":
            for_click(page_object, loc_xpath)
            menuOption = "//div[@role='menu' and @aria-hidden='false']//a[starts-with(@id,'menuitem')]//*[contains(@id, 'textEl')][text()='"+data+"']"
            for_click(page_object, menuOption)
        
        case "Select Button Combo":
            drop_down_btn_clicked = False
            try:
                if Wrapper_variables.patternMatch == "YES":
                    if Wrapper_variables.numberPart == 0:
                        for_click_button_combo(page_object, loc_xpath)
                        drop_down_btn_clicked = True
                        # //div[@role='menu' and @aria-hidden='true']//div/a[starts-with(@id, 'menucheckitem') and contains(@id,'itemEl')]//span[contains(@id,'textEl') and text()='Cancel']
                        menu_option = f"//div[@role='menu' and @aria-hidden='false']//div/a[starts-with(@id, 'menucheckitem') and contains(@id,'itemEl')]//span[contains(@id,'textEl') and text()='{data}']"
                        Variable_not_resettable.logger.info(f"Dropdown xpath : {menu_option}")
                        for_click(page_object, menu_option)
                    else:
                        for_click(page_object, loc_xpath)
                        drop_down_btn_clicked = True
                        menu_option = f"//div[@role='menu' and @aria-hidden='false']//div/a[starts-with(@id, 'menucheckitem') and contains(@id,'itemEl')]//span[contains(@id,'textEl') and text()='{data}']"
                        Variable_not_resettable.logger.info(f"Dropdown xpath : {menu_option}")
                        for_click(page_object, menu_option)
                elif Wrapper_variables.patternMatch == "NO":
                    for_click(page_object, loc_xpath)
                    drop_down_btn_clicked = True
                    menu_option = f"//div[@role='menu' and @aria-hidden='false']//div/a[starts-with(@id, 'menucheckitem') and contains(@id,'itemEl')]//span[contains(@id,'textEl') and text()='{data}']"
                    Variable_not_resettable.logger.info(f"Dropdown xpath : {menu_option}")
                    for_click(page_object, menu_option)
            except Exception as error:
                if  drop_down_btn_clicked == True:
                    for_click_button_combo(page_object, loc_xpath)
                raise Exception(str(error))
        
        case "Click Hub DisplayBlock Icon":
            icon = "//div[@id='"+Wrapper_variables.elementData+"']//div[text()='"+data+"']/following-sibling::div[@class='displayblock float_right avn_add_btn']"
            for_click(page_object, icon)      
        
        case "Click Hub DisplayBlock Text":
            splitFieldSearchData(data,Wrapper_variables.elementData)
            textLink = "//div[@id='"+Wrapper_variables.elementData+"']//div[text()='"+Wrapper_variables.dataValue1+"']/following-sibling::div[text()='"+Wrapper_variables.dataValue2+"']"
            for_click(page_object, textLink)   
        
        case "List Edit Select":
            if Common_object.FIND_TYPE == "FindChildByXPath":
                if Wrapper_variables.patternMatch == "YES":
                    for_click(page_object, loc_xpath)
                    combo_element = "//*[starts-with(@id,'gridview')]//*[contains(@id, 'record')]//div[text()='"+data+"']"
                    for_click(page_object, combo_element)
                elif Wrapper_variables.patternMatch == "NO":
                    for_click(page_object, loc_xpath)
                    props = ["tagName", "contentText"]
                    values = ["table", data]
                    li_option = create_Child_xpath(props, values)
                    for_click(page_object, li_option)
                    
            elif Common_object.FIND_TYPE == "Find":
                for_click(page_object, loc_xpath)
                props = ["tagName", "contentText"]
                values = ["table", data]
                li_option = create_Child_xpath(props, values)
                for_click(page_object, li_option)
        
        case "Click Tile Bottom Left Link":
            for_click(page_object, loc_xpath)
        
        case "Grid Tool Bar":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                Variable_not_resettable.logger.info("Grid Tool Bar for Nebula Running...")
                for_click(page_object, loc_xpath)
                time.sleep(0.5)
                toolValue = Common_data.data_value
                toolbar_id = Common_controls.control_Value
                toolStartWithId = toolbar_id.replace("_tBarGrpBtn", "")
                if((toolValue.find("Save") != -1) and  (toolValue.find("Personalization") != -1)):
                    toolContainsId = "savePers"
                elif((toolValue.find("Remove") != -1) and (toolValue.find("Personalization") != -1)):
                    toolContainsId = "removePers"
                elif((toolValue.find("Column") != -1) and (toolValue.find("Chooser") != -1)):
                    toolContainsId = "columnChooser"
                elif((toolValue.find("Clear") != -1) and (toolValue.find("Sort") != -1)):
                    toolContainsId = "clearMultiSort"
                elif((toolValue.find("Multi") != -1) and (toolValue.find("Sort") != -1)):
                    toolContainsId = "multiSort"
                toolItem_xpath= "//*[starts-with(@id,'"+toolStartWithId+"')]//*[contains(@id, '"+toolContainsId+"')]"
                Variable_not_resettable.logger.info(f"toolItem_xpath : {str(toolItem_xpath)}")
                for_click(page_object, toolItem_xpath)
                time.sleep(2)
            else:
                for_click(page_object, loc_xpath)
                toolValue = Common_data.data_value
                toolStartWithId = Wrapper_variables.startsWithId.replace("_tBarGrpBtn", "")
                if((toolValue.find("Save") != -1) and  (toolValue.find("Personalization") != -1)):
                    toolContainsId = "savePers"
                elif((toolValue.find("Remove") != -1) and (toolValue.find("Personalization") != -1)):
                    toolContainsId = "removePers"
                elif((toolValue.find("Column") != -1) and (toolValue.find("Chooser") != -1)):
                    toolContainsId = "columnChooser"
                elif((toolValue.find("Clear") != -1) and (toolValue.find("Sort") != -1)):
                    toolContainsId = "clearMultiSort"
                elif((toolValue.find("Multi") != -1) and (toolValue.find("Sort") != -1)):
                    toolContainsId = "multiSort"
                toolItem_xpath= "//*[starts-with(@id,'"+toolStartWithId+"')]//*[contains(@id, '"+toolContainsId+"')]"
                Variable_not_resettable.logger.info(f"toolItem_xpath: {toolItem_xpath}")
                for_click(page_object, toolItem_xpath)
        
        case "Grid Search Link":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                Variable_not_resettable.logger.info("Grid Search Link in Nebula running...")
                for_fill(page_object,loc_xpath, data)
                page_object.keyboard.press("Enter")
                # search_option = "//*[@class='grid-link '][text()='"+data+"']"
                # page_object.locator(search_option).scroll_into_view_if_needed(timeout=3000)
                # for_click(page_object,search_option)
                # Variable_not_resettable.logger.info("Link clicked successfully in nebula")
                try:
                    search_option = "//*[contains(@class,'grid-link')][text()='"+data+"']"
                    #//*[contains(@class,'grid-link  ')]//*[text()='Movement Checklist']
                    Variable_not_resettable.logger.info(f"1st grid link path : {search_option}")
                    page_object.locator(search_option).scroll_into_view_if_needed(timeout=3000)
                    for_click(page_object,search_option)
                    Variable_not_resettable.logger.info("Link clicked successfully in nebula")
                except Exception as error:
                    Variable_not_resettable.logger.info(str(error))
                    search_option = "//*[contains(@class,'grid-link')]//*[text()='"+data+"']"
                    Variable_not_resettable.logger.info(f"2nd grid link path : {search_option}")
                    page_object.locator(search_option).scroll_into_view_if_needed(timeout=3000)
                    for_click(page_object,search_option)
                    Variable_not_resettable.logger.info("Link clicked successfully in nebula")
            else:
                for_fill(page_object,loc_xpath, data)
                page_object.keyboard.press("Enter")
                props = ["className", "contentText"]
                values = ["x-grid-cell-inner ", data]
                search_option1 = "//*[@class='x-grid-cell-inner ']/pre[text()='"+values[1]+"']"
                search_option2 = "//*[@class='x-grid-cell-inner x-grid-cell-number-align ']/pre[text()='"+values[1]+"']"
                search_option3 = "//*[@class='x-grid-cell-inner ' ]/div/u[text()='"+values[1]+"']"
                try:
                    for_click(page_object,search_option2)
                    Variable_not_resettable.logger.info("link clicked successfully")
                except:
                    try:
                        for_click(page_object,search_option1)
                        Variable_not_resettable.logger.info("link clicked successfully")
                    except:
                        for_click(page_object,search_option3)
                        Variable_not_resettable.logger.info("link clicked successfully")
        
        case "Grid Search Select":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                Variable_not_resettable.logger.info("Grid Search Select in Nebula running...")
                splitFieldSearchData_nebula(data,Common_controls.control_Value)
                wait_unitil_please_wait(page_object, 200)
                for_fill(page_object, loc_xpath, Wrapper_variables.dataValue2)
                time.sleep(1)
                page_object.keyboard.press("Enter")
                wait_unitil_please_wait(page_object, 100)
                wait_and_close_popup(page_object)
                if (Wrapper_variables.dataValue4 == "" and Wrapper_variables.dataValue5 == ""):
                    # gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']//.."
                    gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='"+Wrapper_variables.dataValue3+"']"
                    print("gridRow1 :",gridRow)
                elif (Wrapper_variables.dataValue4 != "" and Wrapper_variables.dataValue5 == ""):
                    # gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue4+"']"
                    gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::div//*[text()='"+Wrapper_variables.dataValue4+"']"
                    print("gridRow2 :",gridRow)
                else:
                    # gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue4+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue5+"']"
                    gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::div//*[text()='"+Wrapper_variables.dataValue4+"']/../..//following-sibling::div//*[text()='"+Wrapper_variables.dataValue5+"']"
                    print("gridRow3 :",gridRow)
                time.sleep(2)
                grid_elements = page_object.query_selector_all(gridRow)
                #html_content = page_object.locator(selector).get_attribute("value")
                print("Len of grid elements " ,len(grid_elements))
                element_row_count = 0
                for element in grid_elements:
                    print(element)
                    element_row_count = element_row_count+1
                    if element_row_count <= int(Wrapper_variables.dataValue1):
                        print("element_row_count : ", element_row_count)
                        print("Element ID : ", element.get_attribute("id"))
                        element_row_number = str(element.get_attribute("id")).split("row")[1]
                        print(element_row_number)
                        #rowCheckbox = "//div[contains(@id,'"+Wrapper_variables.objectValue+"')]"+"_time_cell_colsel_"+"[contains(@id,'row"+str(element_row_number)+"')]"
                        #rowCheckbox = "//div[contains(@id,'"+Wrapper_variables.objectValue+"')][contains(@id,'row"+str(element_row_number)+"')][@class='x-grid-checkcolumn']"
                        #rowCheckbox = "//*[@id='"+Wrapper_variables.objectValue+" +'_time_cell_colsel_row'+'"+str(element_row_number)+"']"
                        id = Wrapper_variables.objectValue +"_cell_colsel_row" + str(element_row_number)
                        print("id :", id)
                        rowCheckbox = "//*[@id='"+id+"']"
                        print("rowCheckbox :", rowCheckbox)
                        page_object.locator(rowCheckbox).scroll_into_view_if_needed(timeout=3000)
                        for_click(page_object,rowCheckbox)
                        Variable_not_resettable.logger.info("checkbox clicked")
                        # time.sleep(10000)
            else:
                is_dataValue3 = False
                wait_unitil_please_wait(page_object, 200)

                page_object.click(loc_xpath)
                page_object.keyboard.press("Control+A")
                page_object.keyboard.press("Backspace")

                for_fill(page_object, loc_xpath, Wrapper_variables.dataValue2)
                page_object.click(loc_xpath)
                page_object.keyboard.press("Enter")
                time.sleep(2)
                wait_unitil_please_wait(page_object, 100)
                wait_and_close_popup(page_object)
                if (Wrapper_variables.dataValue4 == "" and Wrapper_variables.dataValue5 == ""):
                    gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']"
                    is_dataValue3 = True
                elif (Wrapper_variables.dataValue4 != "" and Wrapper_variables.dataValue5 == ""):
                    gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue4+"']"
                else:
                    gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue4+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue5+"']"
                try:
                    grid_elements = page_object.query_selector_all(gridRow)
                    element_row_count = 0
                    for element in grid_elements:
                        element_row_count = element_row_count+1
                        if element_row_count <= int(Wrapper_variables.dataValue1):
                            element_row_number = str(element.get_attribute("id")).split("row")[1]
                            rowCheckbox = "//div[contains(@id,'"+Wrapper_variables.objectValue+"')][contains(@id,'row"+str(element_row_number)+"')][@class='x-grid-checkcolumn']"
                            for_click(page_object,rowCheckbox)
                except Exception as error:
                    if is_dataValue3:
                        gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']//.."
                        grid_elements = page_object.query_selector_all(gridRow)
                        element_row_count = 0
                        for element in grid_elements:
                            element_row_count = element_row_count+1
                            if element_row_count <= int(Wrapper_variables.dataValue1):
                                element_row_number = str(element.get_attribute("id")).split("row")[1]
                                rowCheckbox = "//div[contains(@id,'"+Wrapper_variables.objectValue+"')][contains(@id,'row"+str(element_row_number)+"')][@class='x-grid-checkcolumn']"
                                for_click(page_object,rowCheckbox)
                    else:
                        raise Exception(str(error))
        
        case "Grid Search Single Select":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                Variable_not_resettable.logger.info("Grid Search Single Select in Nebula running...")
                splitFieldSearchData_nebula(data,Common_controls.control_Value)
                # wait_unitil_please_wait(page_object, 200)
                for_fill(page_object, loc_xpath, data)
                time.sleep(1)
                page_object.keyboard.press("Enter")
                wait_unitil_please_wait(page_object, 100)
                wait_and_close_popup(page_object)
                # if (Wrapper_variables.dataValue4 == "" and Wrapper_variables.dataValue5 == ""):
                    # gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']//.."
                gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='"+data+"']"
                print("gridRow1 :",gridRow)
                # elif (Wrapper_variables.dataValue4 != "" and Wrapper_variables.dataValue5 == ""):
                #     # gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue4+"']"
                #     gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::div//*[text()='"+Wrapper_variables.dataValue4+"']"
                #     print("gridRow2 :",gridRow)
                # else:
                #     # gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue4+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue5+"']"
                #     gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::div//*[text()='"+Wrapper_variables.dataValue4+"']/../..//following-sibling::div//*[text()='"+Wrapper_variables.dataValue5+"']"
                #     print("gridRow3 :",gridRow)
                time.sleep(2)
                grid_elements = page_object.query_selector_all(gridRow)
                #html_content = page_object.locator(selector).get_attribute("value")
                print("Len of grid elements " ,len(grid_elements))
                element_row_count = 0
                for element in grid_elements:
                    print(element)
                    # element_row_count = element_row_count+1
                    # if element_row_count <= int(Wrapper_variables.dataValue1):
                    # print("element_row_count : ", element_row_count)
                    print("Element ID : ", element.get_attribute("id"))
                    element_row_number = str(element.get_attribute("id")).split("row")[1]
                    print(element_row_number)
                    id = Wrapper_variables.objectValue +"_cell_colsel_row" + str(element_row_number)
                    print("id :", id)
                    rowCheckbox = "//*[@id='"+id+"']"
                    print("rowCheckbox :", rowCheckbox)
                    page_object.locator(rowCheckbox).scroll_into_view_if_needed(timeout=3000)
                    for_click(page_object,rowCheckbox)
                    Variable_not_resettable.logger.info("checkbox clicked")
                    break
            else:
                for_fill(page_object,loc_xpath,Wrapper_variables.dataValue1)
                page_object.keyboard.press("Enter")
                wait_unitil_please_wait(page_object, 500)
                wait_and_close_popup(page_object)
                # print("After wait")
                grid_element = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue1+"']//.."
                #grid_element = "//*[contains(@id,'"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//td//*[text()='"+Wrapper_variables.dataValue1+"']"
                grid_elements = page_object.query_selector_all(grid_element)
                # print(grid_elements)
                # print(len(grid_elements))
                if len(grid_elements) == 0:
                    time.sleep(2)
                    grid_elements = page_object.query_selector_all(grid_element)
                    # print(grid_elements)
                for element in grid_elements:
                    # print(element.get_attribute("id"))
                    element_row = str(element.get_attribute("id")).split("row")[1]
                    break
                # print(element_row)
                # rowCheckbox = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table["+str(element_row)+"]//div[@class='x-grid-checkcolumn']"
                rowCheckbox = "(//div[contains(@id,'"+Wrapper_variables.objectValue+"')][contains(@id,'row"+str(element_row)+"')][@class='x-grid-checkcolumn'])[1]"
                #rowCheckbox = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//div[@class='x-grid-checkcolumn' and @id='mlright_grid_sec_cell_colsel_row"+str(element_row)+"']"
                # print(rowCheckbox)
                element_handler = page_object.locator(rowCheckbox)
                element_handler.scroll_into_view_if_needed()
                page_object.click(rowCheckbox, timeout = 1000)
            # except Exception as error:
            #     print(error)
        
        case "Grid Search Zoom Edit":

            # for_fill_Grid_Search_Zoom_Edit(page_object, loc_xpath ,Wrapper_variables.dataValue1)
            # page_object.keyboard.press("Enter")
            # wait_and_close_popup(page_object)
            # # WaitAndDelay.waitAndClosePopUp()
            # for i in range(1, 31):
            #     # print("Grid Row : ", i)
            #     if (Wrapper_variables.dataValue3 == "" and  Wrapper_variables.dataValue4 == ""):
            #         gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table["+str(i)+"]//td//*[text()='"+Wrapper_variables.dataValue2+"']"
            #         rowlink= "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table["+str(i)+"]//div[@class='x-grid-cell-inner x-grid-cell-number-align ']"
            #     elif (Wrapper_variables.dataValue3 != "" and  Wrapper_variables.dataValue4 == ""):
            #         gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table["+str(i)+"]//td//*[text()='"+Wrapper_variables.dataValue2+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue3+"']"
            #         rowlink= "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table["+str(i)+"]//div[@class='x-grid-cell-inner x-grid-cell-number-align ']"
            #     else:
            #         gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')][@aria-hidden='false']//*[@class='x-grid-item-container']//table["+str(i)+"]//td//*[text()='"+Wrapper_variables.dataValue2+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue4+"']"
            #         rowlink= "//div[contains(@id, '"+Wrapper_variables.objectValue+"')][@aria-hidden='false']//*[@class='x-grid-item-container']//table["+str(i)+"]//div[@class='x-grid-cell-inner x-grid-cell-number-align ']"
                
            #     try:
            #         if check_element_handler(page_object, gridRow):   
            #             # print(" rowlink : ", rowlink) 
            #             for_click_Grid_Search_Zoom_Edit(page_object, rowlink)
            #             break
            #     except Exception as error:
            #         pass
            #         # print(error)
            #         # print("Error in Grid Row")
            MAX_RETRIES = 3  # Maximum number of retries
            retry_count = 0
 
            while retry_count < MAX_RETRIES:
                try:
                    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                        splitFieldSearchData_nebula(Common_data.data_value, Wrapper_variables.elementData)
                        wait_unitil_please_wait(page_object, 200)
                        print("Wrapper_variables.dataValue1 :", Wrapper_variables.dataValue1)
                        for_fill(page_object, loc_xpath, Wrapper_variables.dataValue1)
                        page_object.click(loc_xpath)
                        page_object.keyboard.press("Enter")
                        time.sleep(2)
                        wait_unitil_please_wait(page_object, 100)
                        wait_and_close_popup(page_object)
 
                        if Wrapper_variables.dataValue4 == "" and Wrapper_variables.dataValue5 == "":
                            gridRow = f"//div[contains(@id, '{Wrapper_variables.objectValue}')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='{Wrapper_variables.dataValue2}']"
                            print("gridRow1 :", gridRow)
                        elif Wrapper_variables.dataValue4 != "" and Wrapper_variables.dataValue5 == "":
                            gridRow = f"//div[contains(@id, '{Wrapper_variables.objectValue}')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='{Wrapper_variables.dataValue2}']/../../following-sibling::div//*[text()='{Wrapper_variables.dataValue3}']"
                            print("gridRow2 :", gridRow)
                        else:
                            gridRow = (f"//div[contains(@id, '{Wrapper_variables.objectValue}')]//*[@class='InovuaReactDataGrid__cell__content']"
                                    f"//*[text()='{Wrapper_variables.dataValue2}']/../../following-sibling::div//*[text()='{Wrapper_variables.dataValue3}']/../.."
                                    f"//following-sibling::div//*[text()='{Wrapper_variables.dataValue4}']")
                            print("gridRow3 :", gridRow)
 
                        Variable_not_resettable.logger.info("gridRow : " + str(gridRow))
                        grid_elements = page_object.query_selector_all(gridRow)
                        for element in grid_elements:
                            element_row_number_id = str(element.get_attribute("id"))
                            print("element_row_number_id : ", element_row_number_id)
                            element_row_number = str(element_row_number_id).split("row")[1]
                            print("element_row_number : ", element_row_number)
                            break
 
                        Variable_not_resettable.logger.info(f"element_row_number {element_row_number}")
                        row_link = f"//*[@id='{Wrapper_variables.objectValue}_cell_colrn_row{element_row_number}']"
                        Variable_not_resettable.logger.debug("row_link : " + str(row_link))
                        for_click(page_object, row_link)
                    else:
                        wait_unitil_please_wait(page_object, 200)
                        for_fill(page_object, loc_xpath, Wrapper_variables.dataValue1)
                        page_object.click(loc_xpath)
                        page_object.keyboard.press("Enter")
                        time.sleep(2)
                        wait_unitil_please_wait(page_object, 100)
                        wait_and_close_popup(page_object)
 
                        if Wrapper_variables.dataValue3 == "" and Wrapper_variables.dataValue4 == "":
                            gridRow = (f"//div[contains(@id, '{Wrapper_variables.objectValue}')]"
                                    f"//*[@class='x-grid-item-container']//table//td//*[text()={xpath_text_quotes_handler(Wrapper_variables.dataValue2)}]/..")
                        elif Wrapper_variables.dataValue3 != "" and Wrapper_variables.dataValue4 == "":
                            gridRow = (f"//div[contains(@id, '{Wrapper_variables.objectValue}')]"
                                    f"//*[@class='x-grid-item-container']//table//td//*[text()='{Wrapper_variables.dataValue2}']"
                                    f"/../../following-sibling::td//*[text()={xpath_text_quotes_handler(Wrapper_variables.dataValue3)}]")
                        else:
                            gridRow = (f"//div[contains(@id, '{Wrapper_variables.objectValue}')][@aria-hidden='false']"
                                    f"//*[@class='x-grid-item-container']//table//td//*[text()='{Wrapper_variables.dataValue2}']"
                                    f"/../../following-sibling::td//*[text()={xpath_text_quotes_handler(Wrapper_variables.dataValue3)}]"
                                    f"/../../following-sibling::td//*[text()={xpath_text_quotes_handler(Wrapper_variables.dataValue4)}]")
 
                        Variable_not_resettable.logger.debug("gridRow : " + str(gridRow))
                        grid_elements = page_object.query_selector_all(gridRow)[0]
                        element_row_number_id = str(grid_elements.get_attribute("id"))
                        element_row_number = str(grid_elements.get_attribute("id")).split("row")[1]
                        Variable_not_resettable.logger.info(f"element_row_number {element_row_number}")
                        row_link = f"//*[@id='{Wrapper_variables.objectValue}_cell_colrn_row{element_row_number}']"
                        Variable_not_resettable.logger.debug("row_link : " + str(row_link))
                        for_click(page_object, row_link)
 
                    break  # Exit loop if successful
 
                except Exception as e:
                    retry_count += 1
                    Variable_not_resettable.logger.error(f"Attempt {retry_count} failed: {e}")
                    if retry_count >= MAX_RETRIES:
                        raise  # Re-raise the exception if max retries are reached
                    else:
                        Variable_not_resettable.logger.info("Retrying...")
            # if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
            #     splitFieldSearchData_nebula(Common_data.data_value,Wrapper_variables.elementData)
            #     wait_unitil_please_wait(page_object, 200)
            #     print("Wrapper_variables.dataValue1 :", Wrapper_variables.dataValue1)
            #     for_fill(page_object, loc_xpath ,Wrapper_variables.dataValue1)
            #     page_object.click(loc_xpath)
            #     page_object.keyboard.press("Enter")
            #     time.sleep(2)
            #     wait_unitil_please_wait(page_object, 100)
            #     wait_and_close_popup(page_object)
                
            #     if (Wrapper_variables.dataValue4 == "" and Wrapper_variables.dataValue5 == ""):
            #         # gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']//.."
            #         gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='"+Wrapper_variables.dataValue2+"']"
            #         print("gridRow1 :",gridRow)
            #     elif (Wrapper_variables.dataValue4 != "" and Wrapper_variables.dataValue5 == ""):
            #         # gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue4+"']"
            #         gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='"+Wrapper_variables.dataValue2+"']/../../following-sibling::div//*[text()='"+Wrapper_variables.dataValue3+"']"
            #         print("gridRow2 :",gridRow)
            #     else:
            #         # gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue3+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue4+"']/../../following-sibling::td//*[text()='"+Wrapper_variables.dataValue5+"']"
            #         gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='InovuaReactDataGrid__cell__content']//*[text()='"+Wrapper_variables.dataValue2+"']/../../following-sibling::div//*[text()='"+Wrapper_variables.dataValue3+"']/../..//following-sibling::div//*[text()='"+Wrapper_variables.dataValue4+"']"
            #         print("gridRow3 :",gridRow)

            #     Variable_not_resettable.logger.info("gridRow : "+ str(gridRow))
            #     grid_elements = page_object.query_selector_all(gridRow)
            #     for element in grid_elements:
            #         element_row_number_id = str(element.get_attribute("id"))
            #         print("element_row_number_id : ", element_row_number_id)
            #         element_row_number = str(element.get_attribute("id")).split("row")[1]
            #         print("element_row_number : ", element_row_number)
            #         break
            #     Variable_not_resettable.logger.info(f"element_row_number {element_row_number}")
            #     # row_link = "//div[contains(@id,'"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//div[contains(@id,'"+element_row_number+"')][@class='x-grid-cell-inner x-grid-cell-number-align ']"
            #     row_link = f"//*[@id='{Wrapper_variables.objectValue}_cell_colrn_row{element_row_number}']"
            #     Variable_not_resettable.logger.debug("row_link : "+ str(row_link))
            #     for_click(page_object,row_link)
            # else:
            #     wait_unitil_please_wait(page_object, 200)
            #     for_fill(page_object, loc_xpath ,Wrapper_variables.dataValue1)
            #     page_object.click(loc_xpath)
            #     page_object.keyboard.press("Enter")
            #     time.sleep(2)
            #     wait_unitil_please_wait(page_object, 100)
            #     wait_and_close_popup(page_object)
                
            #     if (Wrapper_variables.dataValue3 == "" and  Wrapper_variables.dataValue4 == ""):
            #         gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()="+xpath_text_quotes_handler(Wrapper_variables.dataValue2)+"]/.."
            #     elif (Wrapper_variables.dataValue3 != "" and  Wrapper_variables.dataValue4 == ""):
            #         gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue2+"']/../../following-sibling::td//*[text()="+xpath_text_quotes_handler(Wrapper_variables.dataValue3)+"]"
            #     else:
            #         gridRow = "//div[contains(@id, '"+Wrapper_variables.objectValue+"')][@aria-hidden='false']//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue2+"']/../../following-sibling::td//*[text()="+xpath_text_quotes_handler(Wrapper_variables.dataValue3)+"]/../../following-sibling::td//*[text()="+xpath_text_quotes_handler(Wrapper_variables.dataValue4)+"]"

            #     Variable_not_resettable.logger.debug("gridRow : "+ str(gridRow))
            #     grid_elements = page_object.query_selector_all(gridRow)[0]
            #     element_row_number_id = str(grid_elements.get_attribute("id"))
            #     # print(f"*********************************************************{element_row_number_id}")
            #     element_row_number = str(grid_elements.get_attribute("id")).split("row")[1]
            #     # print(f"*********************************************************{element_row_number}")
            #     Variable_not_resettable.logger.info(f"element_row_number {element_row_number}")
            #     # row_link = "//div[contains(@id,'"+Wrapper_variables.objectValue+"')]//*[@class='x-grid-item-container']//table//div[contains(@id,'"+element_row_number+"')][@class='x-grid-cell-inner x-grid-cell-number-align ']"
            #     row_link = f"//*[@id='{Wrapper_variables.objectValue}_cell_colrn_row{element_row_number}']"
            #     Variable_not_resettable.logger.debug("row_link : "+ str(row_link))
            #     for_click(page_object,row_link)
        
        case "Click Tile Bottom Right Link":
            for_click(page_object,loc_xpath)
        
        case "Click Tile Header":
            for_click(page_object,loc_xpath)  
        
        case "Click Tree Grid":
            for_click(page_object,loc_xpath)    
        
        case "Click Tree Item":
            for_click(page_object,loc_xpath)
        
        case "Assert Tile Body":
            if for_assert_object(page_object, loc_xpath) != None:
                # print("Assertion Passed")
                pass
            else:
                # print("Assertion Failed: Object Not Found")
                raise Exception("Assertion Failed")
            for_success_snapshot(page_object)
        
        case "Assert Tile Bottom Left Data":
            if for_assert_object(page_object, loc_xpath) != None:
                # print("Assertion Passed")
                pass
            else:
                # print("Assertion Failed: Object Not Found")
                raise Exception("Assertion Failed")
            for_success_snapshot(page_object)
        
        case "Assert Tile Header":
            if for_assert_object(page_object, loc_xpath) != None:
                # print("Assertion Passed")
                pass
            else:
                # print("Assertion Failed: Object Not Found")
                raise Exception("Assertion Failed")
            for_success_snapshot(page_object)
        
        case "Display Block Link":
            for_click(page_object, loc_xpath)
        
        case "Expand Child Tree":
            for_click_child_tree(page_object, loc_xpath) 
        
        case "Expand Tree":
            for_click(page_object, loc_xpath)
        
        case "Assert Grid Table":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                for_click(page_object, loc_xpath)
                splitFieldSearchData(data,Common_controls.control_Value)
                splitAssertGridTable(data)
                # Wrapper_variables.startsWithId = str(Wrapper_variables.startsWithId).split("_")
                # startsWithId = Wrapper_variables.startsWithId[0]
                download_xlsx = "//*[starts-with(@id,'"+Wrapper_variables.objectValue+"')]//*[contains(@id, 'btnExpOffice')][text()='To Excel']"
                download_xlsx_2 = "//*[starts-with(@id,'"+Wrapper_variables.objectValue+"')]//*[contains(@id, 'btnExpOffice')][text()='To Excel ']"
                input_file_path,input_sheet_name = for_download_and_assert_grid(page_object, download_xlsx, download_xlsx_2)
                output_folder = "Files/GridValidationOutput/"
                make_directory(output_folder)
                output_file_path =  str(output_folder + Common_object.scenarios_meta["SCENARIO NAME"] + Common_step.DATA_SHEET + str(datetime.now()).replace(":","-") + ".xlsx").replace(" ","_")
                data_file_path = "Files/DataSheets/" + Common_object.test_config_dictionary['DataTag'] + "/" + Common_step.DATA_FILE + ".xlsx"
                output_sheet_name = Common_step.DATA_SHEET
                shutil.copyfile(data_file_path, output_file_path)
                remove_conditional_formatting(input_file_path)
                remove_conditional_formatting(output_file_path)
                grid_validator(input_file_path, input_sheet_name, output_file_path, output_sheet_name)
                for_success_snapshot(page_object)
            elif "Direct Click" in str(Common_step.BASE_ACTION):
                # for_click(page_object, loc_xpath)
                splitAssertGridTable(data)
                # Wrapper_variables.startsWithId = str(Wrapper_variables.startsWithId).split("_")
                # startsWithId = Wrapper_variables.startsWithId[0]
                # download_xlsx = "//*[starts-with(@id,'"+Wrapper_variables.objectValue+"')]//*[contains(@id, 'textEl')][text()='To Excel']"
                # download_xlsx_2 = "//*[starts-with(@id,'"+Wrapper_variables.objectValue+"')]//*[contains(@id, 'textEl')][text()='To Excel ']"
                # print(download_xlsx, download_xlsx_2)
                input_file_path,input_sheet_name = for_download_and_assert_grid_direct_click(page_object, loc_xpath)
                output_folder = "Files/GridValidationOutput/"
                make_directory(output_folder)
                output_file_path =  str(output_folder + Common_object.scenarios_meta["SCENARIO NAME"] + Common_step.DATA_SHEET + str(datetime.now()).replace(":","-") + ".xlsx").replace(" ","_")
                data_file_path = "Files/DataSheets/" + Common_object.test_config_dictionary['DataTag'] + "/" + Common_step.DATA_FILE + ".xlsx"
                output_sheet_name = Common_step.DATA_SHEET
                shutil.copyfile(data_file_path, output_file_path)
                grid_validator(input_file_path, input_sheet_name, output_file_path, output_sheet_name)
                for_success_snapshot(page_object)
            else:
                for_click(page_object, loc_xpath)
                splitAssertGridTable(data)
                # Wrapper_variables.startsWithId = str(Wrapper_variables.startsWithId).split("_")
                # startsWithId = Wrapper_variables.startsWithId[0]
                download_xlsx = "//*[starts-with(@id,'"+Wrapper_variables.objectValue+"')]//*[contains(@id, 'textEl')][text()='To Excel']"
                download_xlsx_2 = "//*[starts-with(@id,'"+Wrapper_variables.objectValue+"')]//*[contains(@id, 'textEl')][text()='To Excel ']"
                # print(download_xlsx, download_xlsx_2)
                input_file_path,input_sheet_name = for_download_and_assert_grid(page_object, download_xlsx, download_xlsx_2)
                output_folder = "Files/GridValidationOutput/"
                make_directory(output_folder)
                output_file_path =  str(output_folder + Common_object.scenarios_meta["SCENARIO NAME"] + Common_step.DATA_SHEET + str(datetime.now()).replace(":","-") + ".xlsx").replace(" ","_")
                data_file_path = "Files/DataSheets/" + Common_object.test_config_dictionary['DataTag'] + "/" + Common_step.DATA_FILE + ".xlsx"
                output_sheet_name = Common_step.DATA_SHEET
                try:
                    shutil.copyfile(data_file_path, output_file_path)
                except Exception as copyerror:
                    Variable_not_resettable.logger.error(copyerror)
                    time.sleep(1)
                    try:
                        shutil.copyfile(data_file_path, output_file_path)
                    except Exception as copyerror:
                        Variable_not_resettable.logger.error(copyerror)
                        time.sleep(1)
                        try:
                            shutil.copyfile(data_file_path, output_file_path)
                        except Exception as copyerror:
                            Variable_not_resettable.logger.error(copyerror)
                            #time.sleep(1)

                remove_conditional_formatting(input_file_path)
                remove_conditional_formatting(output_file_path)
                grid_validator(input_file_path, input_sheet_name, output_file_path, output_sheet_name)
                for_success_snapshot(page_object)

        # case "Save Data":
        #     #page_object.pause()
        #     wait_unitil_please_wait(page_object, 100)
        #     wait_and_close_popup(page_object)
        #     if str(Common_step.Second_Action).lower()=="card count":
        #         try:
        #             container = page_object.wait_for_selector(loc_xpath)
        #             cards = container.query_selector_all('//div[@id and contains(@class, "card")]')
        #             #print(len(cards))
        #             cardcount=len(cards)
        #             Variable_not_resettable.logger.info(f"Number of cards:{cardcount}")
        #             saveDataToExcel(Common_scenario.data_provider_num,cardcount)
        #             Variable_not_resettable.logger.info("Datas are stored into the file")
        #         except Exception as e:
        #             Variable_not_resettable.logger.info(f"An error occurred: {e}")
        #             raise Exception
        #     else:
        #         if ((Wrapper_variables.elementData.find("textfield") != -1) or (Wrapper_variables.elementData.find("numberfield") != -1) or (Wrapper_variables.elementData.find("combofield") != -1)):
        #             saveValue = for_get_input_value(page_object, loc_xpath)
        #             Common_data.data_value = saveValue
        #             saveDataToExcel(Common_scenario.data_provider_num,saveValue)

        #         else:
        #             saveValue = for_get_input_value(page_object, loc_xpath)
        #             Common_data.data_value = saveValue
        #             saveDataToExcel(Common_scenario.data_provider_num,saveValue)
        #         Variable_not_resettable.logger.info("Save Data Value" + str(saveValue))

        # case "Save Data":
        #     #page_object.pause()
        #     wait_unitil_please_wait(page_object, 100)
        #     wait_and_close_popup(page_object)
        #     if str(Common_step.Second_Action).lower()=="card count":
        #         try:
        #             container = page_object.wait_for_selector(loc_xpath)
        #             cards = container.query_selector_all('//div[@id and contains(@class, "card")]')
        #             #print(len(cards))
        #             cardcount=len(cards)
        #             Variable_not_resettable.logger.info(f"Number of cards:{cardcount}")
        #             saveDataToExcel(Common_scenario.data_provider_num,cardcount)
        #             Variable_not_resettable.logger.info("Datas are stored into the file")
        #         except Exception as e:
        #             Variable_not_resettable.logger.info(f"An error occurred: {e}")
        #             raise Exception
        #     else:
        #         if ((Wrapper_variables.elementData.find("textfield") != -1) or (Wrapper_variables.elementData.find("numberfield") != -1) or (Wrapper_variables.elementData.find("combofield") != -1)):
        #             saveValue = for_get_input_value(page_object, loc_xpath)
        #             Common_data.data_value = saveValue
        #             saveDataToExcel(Common_scenario.data_provider_num,saveValue)
        #             dataexist=checkdataisempty(Common_scenario.data_provider_num,saveValue)
        #             if dataexist:
        #                 saveValue = for_get_input_value(page_object, loc_xpath)
        #                 Common_data.data_value = saveValue
        #                 saveDataToExcel(Common_scenario.data_provider_num,saveValue)
        #         else:
        #             saveValue = for_get_input_value(page_object, loc_xpath)
        #             Common_data.data_value = saveValue
        #             saveDataToExcel(Common_scenario.data_provider_num,saveValue)
        #             dataexist=checkdataisempty(Common_scenario.data_provider_num,saveValue)
        #             if dataexist:
        #                 saveValue = for_get_input_value(page_object, loc_xpath)
        #                 Common_data.data_value = saveValue
        #                 saveDataToExcel(Common_scenario.data_provider_num,saveValue)
        #         Variable_not_resettable.logger.info("Save Data Value" + str(saveValue))

        case "Save Data":
            #page_object.pause()
            wait_unitil_please_wait(page_object, 100)
            wait_and_close_popup(page_object)
            if str(Common_step.Second_Action).lower()=="card count":
                try:
                    container = page_object.wait_for_selector(loc_xpath)
                    cards = container.query_selector_all('//div[@id and contains(@class, "card")]')
                    #print(len(cards))
                    cardcount=len(cards)
                    Variable_not_resettable.logger.info(f"Number of cards:{cardcount}")
                    saveDataToExcel(Common_scenario.data_provider_num,cardcount)
                    Variable_not_resettable.logger.info("Datas are stored into the file")
                except Exception as e:
                    Variable_not_resettable.logger.info(f"An error occurred: {e}")
                    raise Exception
            else:
                if ((Wrapper_variables.elementData.find("textfield") != -1) or (Wrapper_variables.elementData.find("numberfield") != -1) or (Wrapper_variables.elementData.find("combofield") != -1)):
                    saveValue = for_get_input_value(page_object, loc_xpath)
                    Common_data.data_value = saveValue
                    saveDataToExcel(Common_scenario.data_provider_num,saveValue)
                else:
                    saveValue = for_get_input_value(page_object, loc_xpath)
                    Common_data.data_value = saveValue
                    saveDataToExcel(Common_scenario.data_provider_num,saveValue)
                Variable_not_resettable.logger.info("Save Data Value" + str(saveValue))
        
        case "Custom Wait Sec":
            try:
                page_object.keyboard.press("Tab")
                if int(data) <= 15:
                    time.sleep(int(data))
                else:
                    # print("[INFO] : Custom Wait Sec maximum wait time is 15 sec")
                    Variable_not_resettable.logger.info("Custom Wait Sec maximum wait time is 15 sec")
                    time.sleep(5)
            except Exception as error:
                raise Exception(str(error)) 
        
        case "Nebula Custom Wait Sec":
            try:
                Variable_not_resettable.logger.info("Custom Wait Sec maximum wait time is 5 sec")
                time.sleep(.25)
            except Exception as error:
                raise Exception(str(error))
        
        case "Click Data Hyperlink":
            crm_grid = "//*[@id='"+Wrapper_variables.elementData+"']/div/div/div[text()='"+Wrapper_variables.dataValue+"']"
            for_click(page_object, crm_grid)
        
        case "Grid Attach Document":
            grid_attach = "//*[@id='"+Wrapper_variables.elementData+"']/div[@data-qtip='Attach']"
            for_grid_attach(page_object, grid_attach, data)
        
        case "Click Ganttchart Checkbox":	
            for_click(page_object, loc_xpath)
        
        case "Click Ganttchart Expand":	
            for_click(page_object, loc_xpath)
        
        case "Grid Zoom Insert Row":
            for_click(page_object, loc_xpath)
            excelInput = str(Wrapper_variables.elementData).split("cell")
            gridobjectValue1 = excelInput[0]
            gridobjectValue2 = gridobjectValue1+"zoom_tbr_addBtn"
            insertrow = "//*[starts-with(@id,'"+gridobjectValue2+"')]"
            for_click(page_object, insertrow)
        
        case "Grid Search Edit Grid":
            # controlValue1;controlValue2
            # tgdded_grid_tbr_fieldSearch_inputEl;tgdded_grid_cell_colv4_row6
            # dataValue1;dataValue2
            # 80G Donations;1000
            for_fill(page_object,loc_xpath,Wrapper_variables.dataValue1)
            page_object.keyboard.press("Enter")
            wait_unitil_please_wait(page_object, 500)
            wait_and_close_popup(page_object)
            grid_element = "//div[contains(@id, '"+Wrapper_variables.objectValue2+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue1+"']"
            Variable_not_resettable.logger.info(f"Grid element xpath: {grid_element}")
            grid_elements = page_object.query_selector_all(grid_element)
            if len(grid_elements) == 0:
                time.sleep(2)
                grid_elements = page_object.query_selector_all(grid_element)
                # print(grid_elements)
            for element in grid_elements:
                # print(element.get_attribute("id"))
                element_row = str(element.get_attribute("id")).split("row")[1]
                break
            custom_id = str(Wrapper_variables.rowinput1)+"row"+str(element_row)
            edit_grid_xpath = "//*[@id='"+custom_id+"']"
            Variable_not_resettable.logger.info(str(f"Edit grid xpath : {edit_grid_xpath}"))
            page_object.wait_for_selector(edit_grid_xpath, timeout= Common_object.Timeout)
            page_object.locator(edit_grid_xpath).scroll_into_view_if_needed()
            page_object.click(edit_grid_xpath, timeout = 1000)
            page_object.keyboard.press("Control+A")
            page_object.keyboard.press("Backspace")
            page_object.keyboard.type(str(Wrapper_variables.dataValue2))
            page_object.keyboard.press("Enter")
        
        case "Assert Grid Search Value":
            # controlValue1;controlValue2
            # tgdded_grid_tbr_fieldSearch_inputEl;tgdded_grid_cell_colv4_row6
            # dataValue1;dataValue2
            # 80G Donations;1000


            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                if Common_controls.control_Identifier.lower() == "id":

                    splitFieldSearchObject_ntimes(Common_data.data_value, Common_controls.control_Value)
                    for_fill(page_object, "//*[@id='"+Wrapper_variables.objectValue+"']" ,Wrapper_variables.dataValue1)
                    page_object.keyboard.press("Enter")
                    wait_unitil_please_wait(page_object, 500)
                    wait_and_close_popup(page_object)
                    #grid_element = "//div[contains(@id, '"+Wrapper_variables.objectValue2+"')]//*[text()='"+Wrapper_variables.dataValue1+"']"
                    grid_element = f"//div[contains(@id, '{Wrapper_variables.objectValue2}')]//*[text()=\"{Wrapper_variables.dataValue1}\"]"
                    Variable_not_resettable.logger.info(f"Grid element xpath: {grid_element}")
                    grid_elements = page_object.query_selector_all(grid_element)

                elif Common_controls.control_Identifier.lower() == "xpath":

                    selector_splitting = str(Common_controls.control_Value).split(";")
                    selector_1 = selector_splitting[0]
                    selector_2 = selector_splitting[1]
                    search_xpath = selector_1
                    grid_xpath = selector_2

                    if "||" in data and data!=None:
                        data_search, data_grid = data.split("||")
                        data_search = data_search.strip()
                        data_grid = data_grid.strip()
                        
                        if data_grid!=None:
                            for index , each_data in enumerate(data_grid .split(";"), 1):
                                key = f":var{index}"
                                grid_element = grid_xpath.replace(key, each_data)
                                Variable_not_resettable.logger.info(f"Grid element xpath: {grid_element}")
                    for_fill(page_object,search_xpath,data_search)
                    page_object.keyboard.press("Enter")
                    wait_unitil_please_wait(page_object, 500)
                    wait_and_close_popup(page_object)
                    grid_elements = page_object.query_selector_all(grid_element)


                if len(grid_elements) == 0:
                    time.sleep(2)
                    grid_elements = page_object.query_selector_all(grid_element)

                Variable_not_resettable.logger.info(f"grid_elements length {len(grid_elements)}")
                for element in grid_elements:
                    Variable_not_resettable.logger.info(f"******************* grid_element {element} *******************")
                    # if "__playwright_target__" in element.evaluate("el => el.getAttributeNames()"):
                    #     Variable_not_resettable.logger.info(f"******************* inside if - 1322 ***************************")

                    #     grid_element = f'//div[contains(@id, "{Wrapper_variables.objectValue2}")]//*[text()="{Wrapper_variables.dataValue1}"]//..'

                    #     Variable_not_resettable.logger.info(f"grid_element xpath: {grid_element}")
                    #     grid_elements = page_object.query_selector_all(grid_element)
                    #     Variable_not_resettable.logger.info(f"grid_element length: {len(grid_elements)}")
                    #     element_tmp = grid_elements[0]
                    #     Variable_not_resettable.logger.info(f"******************* element_tmp - 1329 ***************************")

                    #     element_id = element_tmp.get_attribute("id")
                    #     Variable_not_resettable.logger.info(f"******************* gelement_id - 1332 ***************************")

                    #     if not element_id:
                    #         element_id = element.get_attribute("id")
                    # else:
                    Variable_not_resettable.logger.info(f"******************* inside else - 138 ***************************")
                    Variable_not_resettable.logger.info(f"element_id {element}")
                    element_id = element.get_attribute("id")
                    Variable_not_resettable.logger.info(f"element_id {element_id}")

                    if "row" not in element_id:
                        Variable_not_resettable.logger.error("row not present in grid element")

                    element_row = str(element_id).split("row")[1]
                    element_withoutrow = str(element_id).split("row")[0]
                    Variable_not_resettable.logger.info(f"******************* element_row - 1346 ***************************")
                    break

                if len(grid_elements) == 0:
                    raise Exception(f"grid_elements not found")
                
                if Common_controls.control_Identifier.lower() == "id":
                    custom_id = str(Wrapper_variables.rowinput1)+"row"+str(element_row)
                    assert_grid_cell_xpath = "//*[@id='"+custom_id+"']"
                    Variable_not_resettable.logger.info(str(f"Assert grid cell xpath : {assert_grid_cell_xpath}"))
                    page_object.wait_for_selector(assert_grid_cell_xpath, timeout= Common_object.Timeout)
                    page_object.locator(assert_grid_cell_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                    grid_cell_value = page_object.query_selector(assert_grid_cell_xpath).inner_text()
                    if str(str(Wrapper_variables.dataValue2)) == str(grid_cell_value):
                        success_msg = f"Assertion Grid search Value success"
                        Variable_not_resettable.logger.info(str(success_msg))
                    else:
                        fail_msg = f"Assertion failed for Grid search Value: '{str(Wrapper_variables.dataValue2)}', Because value in application is '{grid_cell_value}'"
                        raise Exception(str(fail_msg))
                    for_success_snapshot(page_object)
                
                elif Common_controls.control_Identifier.lower() == "xpath":
                    custom_id = str(element_withoutrow)+"row"+str(element_row) 
                    assert_grid_cell_xpath = "//*[@id='"+custom_id+"']"
                    Variable_not_resettable.logger.info(str(f"Assert grid cell xpath : {assert_grid_cell_xpath}"))
                    page_object.wait_for_selector(assert_grid_cell_xpath, timeout= Common_object.Timeout)
                    page_object.locator(assert_grid_cell_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                    grid_cell_value = page_object.query_selector(assert_grid_cell_xpath).inner_text()
                    if str(data_grid) == str(grid_cell_value):
                        success_msg = f"Assertion Grid search Value success"
                        Variable_not_resettable.logger.info(str(success_msg))
                    else:
                        fail_msg = f"Assertion failed for Grid search Value: '{str(data_grid)}', Because value in application is '{grid_cell_value}'"
                        raise Exception(str(fail_msg))
                    for_success_snapshot(page_object)


            else:
                for_fill(page_object,loc_xpath,Wrapper_variables.dataValue1)
                page_object.keyboard.press("Enter")
                wait_unitil_please_wait(page_object, 500)
                wait_and_close_popup(page_object)
                #grid_element = "//div[contains(@id, '"+Wrapper_variables.objectValue2+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue1+"']"
                grid_element = f"//div[contains(@id, '{Wrapper_variables.objectValue2}')]//*[@class='x-grid-item-container']//table//td//*[text()=\"{Wrapper_variables.dataValue1}\"]"
                Variable_not_resettable.logger.info(f"Grid element xpath: {grid_element}")
                grid_elements = page_object.query_selector_all(grid_element)
                if len(grid_elements) == 0:
                    time.sleep(2)
                    grid_elements = page_object.query_selector_all(grid_element)
                for element in grid_elements:
                    element_row = str(element.get_attribute("id")).split("row")[1]
                    break
                custom_id = str(Wrapper_variables.rowinput1)+"row"+str(element_row)
                assert_grid_cell_xpath = "//*[@id='"+custom_id+"']"
                Variable_not_resettable.logger.info(str(f"Assert grid cell xpath : {assert_grid_cell_xpath}"))
                page_object.wait_for_selector(assert_grid_cell_xpath, timeout= Common_object.Timeout)
                page_object.locator(assert_grid_cell_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                grid_cell_value = page_object.query_selector(assert_grid_cell_xpath).inner_text()
                if str(str(Wrapper_variables.dataValue2)) == str(grid_cell_value):
                    success_msg = f"Assertion Grid search Value success"
                    Variable_not_resettable.logger.info(str(success_msg))
                else:
                    fail_msg = f"Assertion failed for Grid search Value: '{str(Wrapper_variables.dataValue2)}', Because value in application is '{grid_cell_value}'"
                    raise Exception(str(fail_msg))
                for_success_snapshot(page_object)
        
        case "Assert Grid Status":
            grid_status_xpath = "//*[@id='"+Wrapper_variables.objectValue+"']/div[@id='"+Wrapper_variables.objectValue1+"']"
            try:
                page_object.locator(grid_status_xpath).scroll_into_view_if_needed(timeout=Common_object.Timeout)
                page_object.wait_for_selector(grid_status_xpath, timeout= Common_object.Timeout)
                assertion_msg = "Assert Grid Status: Success"
                Variable_not_resettable.logger.info(str(assertion_msg))
            except Exception as error:
                assertion_msg = "Assert Grid Status: Failed"
                Variable_not_resettable.logger.info(str(assertion_msg))
                raise Exception(str(assertion_msg))
            for_success_snapshot(page_object)
        
        case "Click Tree Checkbox":
            for_click_tree_checkbox_(page_object, loc_xpath)
        
        case "Assert PDF":
            is_page2_opened = False
            is_page2_closed = False
            save_btn_xpath = "//*[@id='save']"
            i_frame_xpath = "//iframe[@id='report_iframe']"
            try:
                page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                with context.expect_page() as new_page:
                    page_object.click(loc_xpath, timeout= Common_object.Timeout)
                    page2 = new_page.value
                Variable_not_resettable.logger.info(str(page2))
                is_page2_opened = True
                page2.wait_for_selector(i_frame_xpath, timeout= 30000)
                frame_element = page2.frame_locator(i_frame_xpath)
                save_btn = frame_element.locator(save_btn_xpath)
                with page2.expect_download(timeout=60000) as download_info:
                    save_btn.click()
                download = download_info.value
                file_name = download.suggested_filename
                Variable_not_resettable.logger.debug(f"file_name: {file_name}")
                destination_file_path = os.path.join(Common_path.input_document, file_name)
                download.save_as(destination_file_path)
                Variable_not_resettable.logger.info(f"file save in {destination_file_path}")
                pdf_validator(destination_file_path)
                time.sleep(2)
                snapshot_file_path = for_success_snapshot(page2)
                Variable_not_resettable.logger.debug(f"Snapshot file path : {snapshot_file_path}")
                time.sleep(1)
                page2.close()
                is_page2_closed = True
            except Exception as error:
                if is_page2_opened == True and is_page2_closed == False:
                    page2.close()
                    Variable_not_resettable.logger.info("page2 closed...")
                raise Exception(str(error))
        
        case "Checkbox Check":
            checkbox_check(page_object,loc_xpath)
        
        case "Checkbox Uncheck":
            checkbox_uncheck(page_object,loc_xpath)
        
        case "Multi Select Search Combo":
            # Sample Data Value: 2; Permit Category; Permit Type
            Variable_not_resettable.logger.debug(f"Multi Select Search Combo timeout : {Common_step.multi_select_search_combo_timeout}")
            trigger_picker_clicked = False
            try:
                input_data = data.split(";")
                no_of_value_select = input_data[0]
                multi_input = input_data[1:][:int(no_of_value_select)]
                page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                page_object.click(loc_xpath, timeout= Common_step.multi_select_search_combo_timeout)
                trigger_picker_clicked = True
                combo_search = "//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, 'listviewpicker-body')]//*[contains(@id, 'inputEl')]"
                page_object.wait_for_selector(combo_search, timeout= Common_step.multi_select_search_combo_timeout)
                for input_value in multi_input:
                    page_object.wait_for_selector(combo_search, timeout= Common_object.Timeout)
                    page_object.fill(combo_search, "")
                    page_object.click(combo_search, timeout= Common_object.Timeout)
                    page_object.fill(combo_search, str(input_value))

                    combo_value_xpath = "//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, 'listviewpicker-body')]//pre[text()='"+input_value+"']"
                    Variable_not_resettable.logger.debug(f"combo value xpath {combo_value_xpath}")
                    page_object.wait_for_selector(combo_value_xpath, timeout= 10000)

                    getid = page_object.query_selector(combo_value_xpath)
                    getid = getid.get_attribute("id")

                    inputGetid = getid.split("_")
                    inputid1 = inputGetid[1]
                    inputid2 = inputGetid[2]
                    inputid3 = inputGetid[4]
                    view_picker = "(//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"')]//*[contains(@id, 'listviewpicker-body')]//div[contains(@id, '"+inputid1+"_"+inputid2+"')][contains(@id, '"+inputid3+"')])[1]"
                    qry_selector = page_object.query_selector(view_picker)
                    page_object.wait_for_selector(view_picker, timeout= Common_object.Timeout)
                    for_click(page_object, view_picker)
                    Common_step.skip_redo = True
                
                page_object.click(loc_xpath, timeout= Common_object.Timeout)
                trigger_picker_clicked == False
            except Exception as error:
                if trigger_picker_clicked == True:
                    page_object.click(loc_xpath, timeout= Common_object.Timeout)
                raise Exception(str(error))
        
        case "Click Template Toolbar":
            for_click(page_object,loc_xpath)
            trail_list = "//div[contains(@id,'menucheckitem')]//*[contains(@id, 'textEl')][text()='"+data+"']"
            for_click(page_object,trail_list)
        
        case "Assert Combo List":
            try:
                time.sleep(0.25)
                drop_down_clicked = False
                data_list = data.split(";")
                try:
                    page_object.scroll_into_view_if_needed()
                    page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                except Exception as error:
                    wait_unitil_please_wait(page_object, 100)
                    wait_and_close_popup(page_object)
                    page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)

                page_object.click(loc_xpath, timeout= Common_object.Timeout)
                drop_down_clicked = True
                combo_list_xpath = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'picker-listEl')]/li"
                combo_list_elements = page_object.query_selector_all(combo_list_xpath)
                combo_value_list = []
                for combo_element in combo_list_elements:
                    combo_li_text = combo_element.inner_text()
                    combo_value_list.append(combo_li_text)
                if drop_down_clicked == True:
                    page_object.click(loc_xpath, timeout= Common_object.Timeout)
                    drop_down_clicked = False
                unmatched_combo_value = []
                for value_from_app, value_from_xl in zip(combo_value_list, data_list):
                    if value_from_app == value_from_xl:
                        Variable_not_resettable.logger.info(f"{value_from_app} : {value_from_xl} Values are Matching")
                    else:
                        unmatched_combo_value.append(f"{value_from_app} : {value_from_xl}")
                        Variable_not_resettable.logger.info(f"{value_from_app}: {value_from_xl} Values are Not Matching")
                if len(unmatched_combo_value) > 0:
                    err_str = f"{unmatched_combo_value} are not matching. Assertion Failed"
                    Variable_not_resettable.logger.info(err_str)
                    Common_step.skip_redo = True
                    raise Exception(err_str)
                else:
                    success_str = f"All input values are matching"
                    Variable_not_resettable.logger.info(success_str)
                Common_step.skip_redo = True
            except Exception as error:
                Variable_not_resettable.logger.info(str(error))
                if drop_down_clicked == True:
                    page_object.click(loc_xpath, timeout= Common_object.Timeout)
                    drop_down_clicked = False
                raise Exception(str(error))
        
        case "Assert Sort Table Asc":
            try:
                column_header_xpath = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'textInnerEl') and text()='{data}']"
                page_object.wait_for_selector(column_header_xpath, timeout= Common_object.Timeout)
                page_object.locator(column_header_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                column_header_id = page_object.query_selector(column_header_xpath).get_attribute("id")
                Variable_not_resettable.logger.info(f"column_header_xpath: {column_header_xpath}")
                if column_header_id.find("ramcogridcolumn") != -1 and column_header_id.find("textInnerEl"):
                        startsWithId = column_header_id[:column_header_id.find("ramcogridcolumn")+15]
                else:
                    pass
                trigger_picker_xpath = f"//*[starts-with(@id,'{startsWithId}')]//*[contains(@id, 'triggerEl')]"
                page_object.hover(column_header_xpath, timeout= Common_object.Timeout)
                time.sleep(2)
                page_object.wait_for_selector(trigger_picker_xpath, timeout= Common_object.Timeout)
                
                page_object.click(trigger_picker_xpath, timeout= Common_object.Timeout)
                menu_path = "//div/a[@name = 'mainMenu_button']"
                page_object.hover(menu_path, timeout= Common_object.Timeout)
                sort_asc_xpath = f"//div[@role='menu' and @aria-hidden='false']//*[text()='Sort Ascending']"
                page_object.wait_for_selector(sort_asc_xpath, timeout= Common_object.Timeout)
                page_object.click(sort_asc_xpath, timeout= Common_object.Timeout)
                wait_unitil_please_wait(page_object, 1000)
                download_drop_down = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}_tbr_btnExport')]//*[contains(@id, 'btnIconEl')]"
                download_xlsx = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}_tbr_btnExpExcel')]//*[contains(@id, 'textEl')][text()='To Excel']"
                download_xlsx_2 = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}_tbr_btnExpExcel')]//*[contains(@id, 'textEl')][text()='To Excel ']"
                
                Variable_not_resettable.logger.debug(f"download drop down: {download_drop_down}")
                Variable_not_resettable.logger.debug(f"download xlsx 1: {download_xlsx}")
                Variable_not_resettable.logger.debug(f"download xlsx 2: {download_xlsx_2}")

                page_object.wait_for_selector(download_drop_down, timeout= Common_object.Timeout)
                page_object.click(download_drop_down, timeout= Common_object.Timeout)

                # input_file_path,input_sheet_name = for_download_and_assert_grid(page_object, download_xlsx, download_xlsx_2)
                with page_object.expect_download() as download_info:
                    try:
                        page_object.click(download_xlsx, timeout=3000)
                    except Exception as error:
                        page_object.click(download_xlsx_2, timeout=3000)

                download = download_info.value
                file_name = download.suggested_filename
                download_folder_path = "./Files/Input_Documents/"
                save_in_path = os.path.join(download_folder_path, file_name)
                download.save_as(save_in_path)
                download_sheet = file_name.split(".")[0]
                # print(save_in_path)
                # print(download_sheet)
                
                assert_sorted_grid_table_xl(file_name, data, "Asc")
            except Exception as error:
                Variable_not_resettable.logger.info(str(error))
                raise Exception(str(error))
        
        case "Assert Sort Table Dsc":
            try:
                column_header_xpath = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'textInnerEl') and text()='{data}']"
                page_object.wait_for_selector(column_header_xpath, timeout= Common_object.Timeout)
                table_xpath = f"(//*[starts-with(@id,'{Wrapper_variables.startsWithId}-ramcogrid')]//*[contains(@id, 'bodyWrap')])[1]"
                page_object.locator(table_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                column_header_id = page_object.query_selector(column_header_xpath).get_attribute("id")
                Variable_not_resettable.logger.info(f"column_header_xpath: {column_header_xpath}")
                if column_header_id.find("ramcogridcolumn") != -1 and column_header_id.find("textInnerEl"):
                    startsWithId = column_header_id[:column_header_id.find("ramcogridcolumn")+15]
                else:
                    pass
                trigger_picker_xpath = f"//*[starts-with(@id,'{startsWithId}')]//*[contains(@id, 'triggerEl')]"
                page_object.hover(column_header_xpath, timeout= Common_object.Timeout)
                time.sleep(2)
                page_object.wait_for_selector(trigger_picker_xpath, timeout= Common_object.Timeout)
                
                page_object.click(trigger_picker_xpath, timeout= Common_object.Timeout)
                menu_path = "//div/a[@name = 'mainMenu_button']"
                page_object.hover(menu_path, timeout= Common_object.Timeout)
                sort_asc_xpath = f"//div[@role='menu' and @aria-hidden='false']//*[text()='Sort Descending']"
                # page_object.locator(sort_asc_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                page_object.wait_for_selector(sort_asc_xpath, timeout= Common_object.Timeout)
                page_object.click(sort_asc_xpath, timeout= Common_object.Timeout)
                wait_unitil_please_wait(page_object, 1000)
                download_drop_down = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}_tbr_btnExport')]//*[contains(@id, 'btnIconEl')]"
                download_xlsx = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}_tbr_btnExpExcel')]//*[contains(@id, 'textEl')][text()='To Excel']"
                download_xlsx_2 = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}_tbr_btnExpExcel')]//*[contains(@id, 'textEl')][text()='To Excel ']"
                
                Variable_not_resettable.logger.debug(f"download_xlsx: {download_drop_down}")
                Variable_not_resettable.logger.debug(f"download_xlsx: {download_xlsx}")
                Variable_not_resettable.logger.debug(f"download_xlsx: {download_xlsx_2}")

                page_object.wait_for_selector(download_drop_down, timeout= Common_object.Timeout)
                page_object.click(download_drop_down, timeout= Common_object.Timeout)

                # input_file_path,input_sheet_name = for_download_and_assert_grid(page_object, download_xlsx, download_xlsx_2)
                with page_object.expect_download() as download_info:
                    try:
                        page_object.click(download_xlsx, timeout=3000)
                    except Exception as error:
                        page_object.click(download_xlsx_2, timeout=3000)

                download = download_info.value
                file_name = download.suggested_filename
                download_folder_path = "./Files/Input_Documents/"
                save_in_path = os.path.join(download_folder_path, file_name)
                download.save_as(save_in_path)
                download_sheet = file_name.split(".")[0]
                print(save_in_path)
                Variable_not_resettable.logger.info(download_sheet)
                
                assert_sorted_grid_table_xl(file_name, data, "Dsc")
            except Exception as error:
                Variable_not_resettable.logger.info(str(error))
                raise Exception(str(error))
        
        case "Grid XML Compare":
            grid_xml_compare(page_object, loc_xpath, data)

        case "Assert Checkbox":
            for_assert_checkbox(page_object, loc_xpath, data)

        case "Checkbox With Data":
            data_temp = data
            data = str(data).upper()
            if data == "YES":
                checkbox_check(page_object,loc_xpath)
            elif data == "NO":
                checkbox_uncheck(page_object,loc_xpath)
            else:
                raise Exception(f"Incorrect Data given '{data_temp}' in data sheet")

        case "Grid Search Correlate Link":  
            
            #finding the required row   
            splitFieldSearchObject(data,Common_controls.control_Value) 
            search_field = f"//*[starts-with(@id,'{str(Wrapper_variables.objectValue).split('_cell')[0]}_tbr_fieldSearch')]//*[contains(@id,'inputEl')]"
            Variable_not_resettable.logger.info(f"search field : {search_field}")
            for_fill(page_object,search_field,data)
            page_object.keyboard.press("Enter")
            wait_unitil_please_wait(page_object, 500)
            wait_and_close_popup(page_object)
           
            Wrapper_variables.objectValue = (Wrapper_variables.objectValue.split("row"))[0]
            gridRow = "//*[starts-with(@id,'"+Wrapper_variables.objectValue+"')]//*[text()='"+data+"']"
            Variable_not_resettable.logger.info(f"gridRow : {gridRow}")
            #getting the id for the required row
            grid_elements = page_object.query_selector_all(gridRow)
            Variable_not_resettable.logger.info(f"grid_elements : {grid_elements}")
            for element in grid_elements:
                gridRow_id_value = element.get_attribute("id")
                break
            Variable_not_resettable.logger.info(f"gridRow_id_value : {gridRow_id_value}")
            #getting the required row to click
            req_row_no = "row"+str((gridRow_id_value.split("row"))[1])
            Variable_not_resettable.logger.info(f"req_row_no : {req_row_no}")
            Wrapper_variables.rowinput1 = Wrapper_variables.rowinput1 + str(req_row_no)
            link_id_value = "//*[@id='"+Wrapper_variables.rowinput1+"']"
            Variable_not_resettable.logger.info(f"link_id_value : {link_id_value}")
            for_click(page_object,link_id_value)

        case "PDF Validation":
            pdf_file = for_download_and_assert_pdf(page_object,loc_xpath,context)
            time.sleep(1)
            pdf_extractor_main_fun()
            pdf_data_extracted_path = Common_path.base_path+"/storage/Extracted Data.xlsx"
            # print("pdf_data_extracted_path : ", pdf_data_extracted_path)
            data_from_extracted_pdf = pd.read_excel(pdf_data_extracted_path, sheet_name="PDF Data",dtype="str")
            data_from_extracted_pdf_dict = data_from_extracted_pdf.to_dict("records")
            # print("******************************************")
            # print("data_from_extracted_pdf_dict :", data_from_extracted_pdf_dict)
            # print("******************************************")
            required_col_headers = str(data).split(",")
            # print("required_col_headers :", required_col_headers)
            data_file_path = "Files/DataSheets/" + Common_object.test_config_dictionary['DataTag'] + "/" + Common_step.DATA_FILE + ".xlsx"
            output_folder = "Files/PDFValidationOutput/"
            make_directory(output_folder)
            output_file_path =  str(output_folder + Common_object.scenarios_meta["SCENARIO NAME"] + Common_step.DATA_SHEET + str(datetime.now()).replace(":","-") + ".xlsx").replace(" ","_")
            shutil.copyfile(data_file_path, output_file_path)
            source_data_sheet = pd.read_excel(output_file_path, sheet_name = Common_step.DATA_SHEET,dtype="str")
            required_source_data_sheet = source_data_sheet[required_col_headers]
            required_source_data_sheet_dict = required_source_data_sheet.to_dict("records")
            # print("******************************************")
            # print("required_source_data_sheet_dict : ", required_source_data_sheet_dict)
            # print("******************************************")
            output_df = pd.read_excel(output_file_path, sheet_name = Common_step.DATA_SHEET)
            output_df_dict = output_df.to_dict("records")
            # output_folder = "Files/PDFValidationOutput/"
            # make_directory(output_folder)
            # output_file_path =  str(output_folder + Common_object.scenarios_meta["SCENARIO NAME"] + Common_step.DATA_SHEET + str(datetime.now()).replace(":","-") + ".xlsx").replace(" ","_")
            output_sheet_name = Common_step.DATA_SHEET
            output_list_dict = []
            # for download_dict,input_dict,output_dict in zip(data_from_extracted_pdf_dict,required_source_data_sheet_dict,output_df_dict):
            #     for input_key in input_dict.keys():
            #         Variable_not_resettable.logger.debug(f"{download_dict[input_key]}, {input_dict[input_key]}")
            #         Variable_not_resettable.logger.debug(f"{type(download_dict[input_key])}, {type(input_dict[input_key])}")
            #         if download_dict[input_key] == input_dict[input_key]:
            #             output_dict.update({"Status": "Pass"})
            #         elif str(download_dict[input_key]) == str(input_dict[input_key]):
            #             output_dict.update({"Status": "Pass"})
            #         else:
            #             output_dict.update({"Status": "Fail"})
            #             break
            employee_code = required_col_headers[0]
            print("employee_code : ", employee_code)
            # for download_dict,input_dict,output_dict in zip(data_from_extracted_pdf_dict,required_source_data_sheet_dict,output_df_dict):
            for input_dict,output_dict in zip(required_source_data_sheet_dict,output_df_dict):
                req_employee_id = input_dict[employee_code]
                for download_dict in data_from_extracted_pdf_dict:
                    if download_dict[employee_code] == req_employee_id:
                        for header in required_col_headers:
                            if download_dict[header] == input_dict[header]:
                                output_dict.update({"Status": "Pass"})
                            elif str(download_dict[header]) == str(input_dict[header]):
                                output_dict.update({"Status": "Pass"})
                            else:    
                                print(" pObject.page_details : ",pObject.page_details)                   
                                if asserting_directly_in_xml(pdf_file,pObject.page_details,req_employee_id,str(input_dict[header])) == "Pass":
                                    output_dict.update({"Status": "Pass"})
                                else:
                                    output_dict.update({"Status": "Fail"})
                                    break
                output_list_dict.append(output_dict)
            df = pd.DataFrame(output_list_dict)
            with pd.ExcelWriter(output_file_path, mode="a", if_sheet_exists="replace", engine="openpyxl") as writer:
                df.to_excel(writer, sheet_name=output_sheet_name, index=False)

        case "Assert Enumerate Combo List":
            if Wrapper_variables.patternMatch == "NO":
                try:
                    drop_down_clicked = False
                    data_list = data.split(";")
                    data_list_req = (data.split(";"))[1:]
                    try:
                        page_object.locator(loc_xpath).scroll_into_view_if_needed()
                        page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                        page_object.locator(loc_xpath).click()
                        page_object.keyboard.press("Control+A")
                        page_object.keyboard.press("Backspace")
                        page_object.keyboard.type(str(data_list[0]))
                        # for_fill(page_object,loc_xpath,data_list[0])
                    except Exception as error:
                        wait_unitil_please_wait(page_object, 100)
                        wait_and_close_popup(page_object)
                        page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)

                    drop_down_clicked = True
                    # combo_closing = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'trigger-picker')]"
                    combo_list_xpath = f"//*[starts-with(@id,'combofield')]//*[contains(@id, 'picker-listEl') and @aria-hidden='false']"
                    combo_list_elements = page_object.query_selector_all(combo_list_xpath)
                    combo_value_list = []
                    for combo_element in combo_list_elements:
                        combo_li_text = combo_element.inner_text()
                        combo_value_list.append(combo_li_text)
                    
                    Variable_not_resettable.logger.info(f"combo_value_list : {combo_value_list}")
                    Variable_not_resettable.logger.info(f"data_list_req : {data_list_req}" )
                    unmatched_combo_value = []               
                    for value_from_app, value_from_xl in zip(combo_value_list, data_list_req):
                        if value_from_app == value_from_xl:
                            Variable_not_resettable.logger.info(f"{value_from_app} : {value_from_xl} Values are Matching")
                        else:
                            unmatched_combo_value.append(f"{value_from_app} : {value_from_xl}")
                            Variable_not_resettable.logger.info(f"{value_from_app}: {value_from_xl} Values are Not Matching")
                    if len(unmatched_combo_value) > 0:
                        err_str = f"{unmatched_combo_value} are not matching. Assertion Failed"
                        Variable_not_resettable.logger.info(err_str)
                        Common_step.skip_redo = True
                        raise Exception(err_str)
                    else:
                        success_str = f"All input values are matching"
                        Variable_not_resettable.logger.info(success_str)
                    Common_step.skip_redo = True
                    # Variable_not_resettable.logger.info(f"combo_closing : {combo_closing}")
                    page_object.keyboard.press("Escape")
                except Exception as error:
                    Variable_not_resettable.logger.info(str(error))
                    if drop_down_clicked == True:
                        page_object.keyboard.press("Escape")
                        drop_down_clicked = False
                    raise Exception(str(error))               
            else:
                try:
                    time.sleep(0.25)
                    drop_down_clicked = False
                    data_list = data.split(";")
                    data_list_req = (data.split(";"))[1:]
                    # print("data_list_req : ", data_list_req)
                    try:
                        page_object.locator(loc_xpath).scroll_into_view_if_needed()
                        page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                        for_fill(page_object,loc_xpath,"")
                        for_fill(page_object,loc_xpath,data_list[0])
                    except Exception as error:
                        wait_unitil_please_wait(page_object, 100)
                        wait_and_close_popup(page_object)
                        page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)

                    # page_object.click(loc_xpath, timeout= Common_object.Timeout)
                    drop_down_clicked = True
                    combo_closing = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'trigger-picker')]"
                    combo_list_xpath = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'picker-listEl')]/li"
                    combo_list_elements = page_object.query_selector_all(combo_list_xpath)
                    combo_value_list = []
                    for combo_element in combo_list_elements:
                        combo_li_text = combo_element.inner_text()
                        combo_value_list.append(combo_li_text)
                    Variable_not_resettable.logger.info(f"combo_value_list : {combo_value_list}")
                    Variable_not_resettable.logger.info(f"data_list_req : {data_list_req}" )
                    unmatched_combo_value = []               
                    for value_from_app, value_from_xl in zip(combo_value_list, data_list_req):
                        if value_from_app == value_from_xl:
                            # print(value_from_app , " || ", value_from_app)
                            Variable_not_resettable.logger.info(f"{value_from_app} : {value_from_xl} Values are Matching")
                        else:
                            # print(value_from_app , " || ", value_from_app,"  not matching")
                            unmatched_combo_value.append(f"{value_from_app} : {value_from_xl}")
                            Variable_not_resettable.logger.info(f"{value_from_app}: {value_from_xl} Values are Not Matching")
                    if len(unmatched_combo_value) > 0:
                        err_str = f"{unmatched_combo_value} are not matching. Assertion Failed"
                        Variable_not_resettable.logger.info(err_str)
                        Common_step.skip_redo = True
                        raise Exception(err_str)
                    else:
                        success_str = f"All input values are matching"
                        Variable_not_resettable.logger.info(success_str)
                    Common_step.skip_redo = True
                    # build_xpath_with_locator_reference(action, Common_controls.control_Value)
                    # combo_closing = f"//*[starts-with(@id,'{Wrapper_variables.startsWithId}')]//*[contains(@id, 'trigger-picker')]"
                    Variable_not_resettable.logger.info(f"combo_closing : {combo_closing}")
                    for_click(page_object,combo_closing)
                except Exception as error:
                    Variable_not_resettable.logger.info(str(error))
                    if drop_down_clicked == True:
                        page_object.click(combo_closing, timeout= Common_object.Timeout)
                        drop_down_clicked = False
                    raise Exception(str(error))

        case "Assert UI Grid Asc":
                Sorted_values_from_excel, downloaded_file_name = Ascending(page_object,data)
                Variable_not_resettable.logger.info(f"downloaded_file_name : {downloaded_file_name}")
                Variable_not_resettable.logger.info(f"Sorted_values_from_excel : {Sorted_values_from_excel}")
                #getting the total no of rows in grid
                splitted_col_header = (Common_controls.control_Value).split("_v")
                path_for_total_rows = "//*[starts-with(@id,'"+splitted_col_header[0]+"')]//*[contains(@id, '_tbr_dspRow')]"
                Variable_not_resettable.logger.info(f"path_for_total_rows : {path_for_total_rows}")
                getting_inner_text = page_object.query_selector(path_for_total_rows)            
                Total_row_count = ((getting_inner_text.inner_text()).split("/"))[1]
                Variable_not_resettable.logger.info(f"Total_row_count : {Total_row_count}")
                list_from_UI = []
                for i in range(1,(int(Total_row_count)+1)):
                    startswith_for_next_button = splitted_col_header[0] + "_tbr_btnNext"
                    next_button = "//*[starts-with(@id,'"+startswith_for_next_button+"')]//*[contains(@id, 'btnIconEl')]"
                    if int(i%10) == 0:
                        for_click(page_object,next_button)
                        wait_unitil_please_wait(page_object, 100)
                    xpath_for_each_row= splitted_col_header[0]+"_cell_colv"+ (splitted_col_header[1])[0] +"_row"+str(i)
                    # print(xpath_for_each_row)
                    xpath_for_each_row = "//*[@id='"+xpath_for_each_row+"']"
                    text_in_UI = page_object.locator(xpath_for_each_row).inner_text()
                    list_from_UI.append(text_in_UI)
                Variable_not_resettable.logger.info(f"list_from_UI : {list_from_UI}")
                failed_list = []
                for data_in_excel, value_from_UI in zip(Sorted_values_from_excel, list_from_UI):
                    if data_in_excel == value_from_UI:
                        failed_list.append("Pass")
                    else:
                        error_str = f"Assertion Failed"
                        failed_list.append("Fail")
                        # print(data_in_excel ," || ", value_from_UI)
                downloaded_file_path = f"{Common_path.base_path}\Files\Input_Documents\{downloaded_file_name}.xlsx"
                Variable_not_resettable.logger.info(f"downloaded_file_path : {downloaded_file_path}")
                sheet = pd.ExcelFile(downloaded_file_path).book.active.title
                dataframe = pd.read_excel(downloaded_file_path,sheet_name=sheet)
                df_status_updated = dataframe.assign(STATUS = None)
                df_status_updated['STATUS'] = failed_list
                writer = pd.ExcelWriter(downloaded_file_path, engine='xlsxwriter')
                df_status_updated.to_excel(writer, sheet_name=sheet, index=False)
                writer.save()
                if "Fail" in failed_list:
                    Variable_not_resettable.logger.info(f"some values are failed in assertion")
                    raise Exception(error_str)
                Variable_not_resettable.logger.info("Assertion Successfully")

        case "Assert UI Grid Dsc":
            Sorted_values_from_excel, downloaded_file_name = Descending(page_object,data)
            Variable_not_resettable.logger.info(f"Sorted_values_from_excel : {Sorted_values_from_excel}")
            #getting the total no of rows in grid
            splitted_col_header = (Common_controls.control_Value).split("_v")
            path_for_total_rows = "//*[starts-with(@id,'"+splitted_col_header[0]+"')]//*[contains(@id, '_tbr_dspRow')]"
            Variable_not_resettable.logger.debug(f"path_for_total_rows : {path_for_total_rows}")
            getting_inner_text = page_object.query_selector(path_for_total_rows)            
            Total_row_count = ((getting_inner_text.inner_text()).split("/"))[1]
            Variable_not_resettable.logger.info(f"Total_row_count : {Total_row_count}")
            list_from_UI = []
            for i in range(1,(int(Total_row_count)+1)):
                startswith_for_next_button = splitted_col_header[0] + "_tbr_btnNext"
                next_button = "//*[starts-with(@id,'"+startswith_for_next_button+"')]//*[contains(@id, 'btnIconEl')]"
                if int(i%10) == 0:
                    for_click(page_object,next_button)
                    wait_unitil_please_wait(page_object, 100)
                xpath_for_each_row= splitted_col_header[0]+"_cell_colv"+ (splitted_col_header[1])[0] +"_row"+str(i)
                Variable_not_resettable.logger.debug(f"xpath_for_each_row : {xpath_for_each_row}")
                xpath_for_each_row = "//*[@id='"+xpath_for_each_row+"']"
                text_in_UI = page_object.locator(xpath_for_each_row).inner_text()
                list_from_UI.append(text_in_UI)
            Variable_not_resettable.logger.info(f"list_from_UI : {list_from_UI}")
            failed_list = []
            for data_in_excel, value_from_UI in zip(Sorted_values_from_excel, list_from_UI):
                if data_in_excel == value_from_UI:
                    failed_list.append("Pass")
                else:
                    error_str = f"Assertion Failed"
                    failed_list.append("Fail")
                    # print(data_in_excel ," || ", value_from_UI)
            downloaded_file_path = f"{Common_path.base_path}\Files\Input_Documents\{downloaded_file_name}.xlsx"
            Variable_not_resettable.logger.debug(f"downloaded_file_path : {downloaded_file_path}")
            sheet = pd.ExcelFile(downloaded_file_path).book.active.title
            dataframe = pd.read_excel(downloaded_file_path,sheet_name=sheet)
            df_status_updated = dataframe.assign(STATUS = None)
            df_status_updated['STATUS'] = failed_list
            writer = pd.ExcelWriter(downloaded_file_path, engine='xlsxwriter')
            df_status_updated.to_excel(writer, sheet_name=sheet, index=False)
            writer.save()
            if "Fail" in failed_list:
                Variable_not_resettable.logger.info("some values are failed in assertion")
                raise Exception(error_str)
            Variable_not_resettable.logger.info("Assertion Successfully")
        
        case "Validate Grid Negative Values":
            input_file_path,input_sheet_name = assert_negative_values(page_object, loc_xpath)
            output_folder = Common_path.base_path+"/Files/GridNegValidationOutput"
            make_directory(output_folder)
            output_file_path =  str(output_folder)+str("/" +input_sheet_name +"_"+ str(datetime.now()).replace(":","-") + ".xlsx").replace(" ","_")
            shutil.copyfile(input_file_path, output_file_path)
            data_frame = pd.read_excel(input_file_path, sheet_name=input_sheet_name)
            data_frame.columns = data_frame.iloc[0]
            data_frame = data_frame.reindex(data_frame.index.drop(0)).reset_index(drop=True)
            data_dict = data_frame.to_dict("records")
            data_columns = data.split(",")
            Dict_for_writing = []
            for each_row in data_dict:
                temp_value_list= []
                for column_value in data_columns:
                    value = "Pass" if each_row[column_value] >=0 else "Fail"
                    temp_value_list.append(value)
                if "Fail" in temp_value_list:
                    each_row.update({"Status": "Fail"})
                else:
                    each_row.update({"Status": "Pass"})
                Dict_for_writing.append(each_row)
                df = pd.DataFrame(Dict_for_writing)
                with pd.ExcelWriter(output_file_path, mode="a", if_sheet_exists="replace", engine="openpyxl") as writer:
                    df.to_excel(writer, sheet_name=input_sheet_name, index=False)
            for_success_snapshot(page_object)

        case "Assert Grid Search Focus":
            wait_unitil_please_wait(page_object, 200)
            for_fill(page_object, loc_xpath, Wrapper_variables.dataValue2)
            Status = []
            for each in range(0,int(Wrapper_variables.dataValue1)):
                page_object.click(loc_xpath)
                page_object.keyboard.press("Enter")
                time.sleep(2)
                wait_unitil_please_wait(page_object, 100)
                wait_and_close_popup(page_object)
                grid_element = "//div[contains(@id, '"+Wrapper_variables.objectValue2+"')]//*[@class='x-grid-item-container']//table//td//*[text()='"+Wrapper_variables.dataValue2+"']"
                Variable_not_resettable.logger.info(f"Grid element xpath: {grid_element}")
                grid_elements = page_object.query_selector_all(grid_element)
                if len(grid_elements) == 0:
                    time.sleep(2)
                    grid_elements = page_object.query_selector_all(grid_element)
                if len(grid_elements) < int(Wrapper_variables.dataValue1):
                    Variable_not_resettable.logger.info("Required no of matches not found")
                    fail_msg = "Required no of matches not found"
                    raise Exception(str(fail_msg))
                for element in grid_elements:
                    element_row = str(element.get_attribute("id")).split("row")[1]
                    custom_id = str(Wrapper_variables.rowinput1)+"row"+str(element_row)
                    assert_grid_cell_xpath = "//*[@id='"+custom_id+"']"
                    Variable_not_resettable.logger.info(str(f"Assert grid cell xpath : {assert_grid_cell_xpath}"))
                    page_object.wait_for_selector(assert_grid_cell_xpath, timeout= Common_object.Timeout)
                    page_object.locator(assert_grid_cell_xpath).scroll_into_view_if_needed()
                    grid_cell_value = page_object.query_selector(assert_grid_cell_xpath).inner_text()
                    Variable_not_resettable.logger.info(f"Wrapper_variables.dataValue2 : {Wrapper_variables.dataValue2}")
                    Variable_not_resettable.logger.info(f"grid_cell_value :  {grid_cell_value}")
                    if str(Wrapper_variables.dataValue2) == str(grid_cell_value):
                        success_msg = f"Assertion Grid search Value success"
                        Variable_not_resettable.logger.info(str(success_msg))
                        Status.append("Pass")
                    else:
                        fail_msg = f"Assertion failed for Grid search Value: '{str(Wrapper_variables.dataValue2)}', Because value in application is '{grid_cell_value}'"
                        Status.append("Fail")
                    if "Fail" in Status:
                        raise Exception(str(fail_msg))
            for_success_snapshot(page_object)
                    
        case "Assert Display Block Value":
            data_in_tile = data.split(";") 
            assertion1 = "//*[@id='"+Common_controls.control_Value+"']/div/div[text()='"+data_in_tile[0]+"']"
            assertion2 = "//*[@id='"+Common_controls.control_Value+"']/div/div/div[text()='"+data_in_tile[1]+"']"
            value1 = page_object.query_selector(assertion1).inner_text()
            value2 = page_object.query_selector(assertion2).inner_text()
            if str(value1) == str(data_in_tile[0]) and str(value2) == str(data_in_tile[1]):
                Variable_not_resettable.logger.info(f"Assertion Passed")
            else:
                Variable_not_resettable.logger.info(f"Assertion Failed")
                fail_msg = f"Assertion failed : '{str(value1)}' || '{str(data_in_tile[0])}' and '{str(value2)}' || '{str(data_in_tile[1])}'"
                raise Exception(str(fail_msg))
            
        case "Assert Grid Display Block":
            #template column; value column
            xpath_for_template_column =  "//*[@id='"+Common_controls.control_Value+"']/div/div/div"
            value_from_template = page_object.query_selector(xpath_for_template_column).inner_text()
            if str(data) == str(value_from_template):
                Variable_not_resettable.logger.info(f"Assertion Passed")
            else:
                Variable_not_resettable.logger.info(f"Assertion Failed")
                fail_msg = f"Assertion failed for Grid Value: '{str(data)}', Because value in application is '{str(value_from_template)}'"
                raise Exception(str(fail_msg))
            
        case "Save Data In Input Docs":
            data_split = data.split(":")
            excel_file_name,sheet_name,data_ref = data_split[0]+".xlsx",data_split[1],data_split[2]
            wait_unitil_please_wait(page_object, 100)
            wait_and_close_popup(page_object)

            if ((Wrapper_variables.elementData.find("textfield") != -1) or (Wrapper_variables.elementData.find("numberfield") != -1) or (Wrapper_variables.elementData.find("combofield") != -1)):
                saveValue = for_get_input_value(page_object, loc_xpath)
                saveDataToExcelInInputDocs(Common_scenario.data_provider_num,saveValue,excel_file_name,sheet_name,data_ref)

            else:
                saveValue = for_get_input_value(page_object, loc_xpath)
                saveDataToExcelInInputDocs(Common_scenario.data_provider_num,saveValue,excel_file_name,sheet_name,data_ref)
            Variable_not_resettable.logger.info("Save Data Value" + str(saveValue))

        case "Assert Style":
            style_from_screen = (page_object.query_selector(loc_xpath)).get_attribute("style")
            Variable_not_resettable.logger.info(f"style_from_screen :{style_from_screen}")
            if str(data) in style_from_screen:
                Variable_not_resettable.logger.info(f"Assertion Passed")
                Variable_not_resettable.logger.info(f"Value_from_screen : {style_from_screen} and value from data sheet : {data}")
            else:
                Variable_not_resettable.logger.info(f"Assertion Failed")
                Variable_not_resettable.logger.info(f"Value_from_screen : {style_from_screen} and value from data sheet : {data}")
                raise Exception(str("Assertion Failed"))
            
        case "Assert Excel":
            is_page2_opened = False
            is_page2_closed = False
            save_btn_xpath = "//*[@id='save']"
            i_frame_xpath = "//iframe[@id='report_iframe']"
            try:
                page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                with context.expect_page() as new_page:
                    page_object.click(loc_xpath, timeout= Common_object.Timeout)
                    page2 = new_page.value
                Variable_not_resettable.logger.info(str(page2))
                is_page2_opened = True
                page2.wait_for_selector(i_frame_xpath, timeout= 30000)
                frame_element = page2.frame_locator(i_frame_xpath)
                save_btn = frame_element.locator(save_btn_xpath)
                with page2.expect_download(timeout=60000) as download_info:
                    save_btn.click()
                download = download_info.value
                file_name = download.suggested_filename
                Variable_not_resettable.logger.debug(f"file_name: {file_name}")
                destination_file_path = os.path.join(Common_path.input_document, file_name)
                download.save_as(destination_file_path)
                Variable_not_resettable.logger.info(f"file save in {destination_file_path}")
                excel_validator(destination_file_path)
                time.sleep(2)
                snapshot_file_path = for_success_snapshot(page2)
                Variable_not_resettable.logger.debug(f"Snapshot file path : {snapshot_file_path}")
                time.sleep(1)
                page2.close()
                is_page2_closed = True
            except Exception as error:
                if is_page2_opened == True and is_page2_closed == False:
                    page2.close()
                    Variable_not_resettable.logger.info("page2 closed...")
                raise Exception(str(error))
            
        case "Custom Wait Minutes":
            try:
                page_object.keyboard.press("Tab")
                if int(data) <= 5:
                    data = int(data) * 60
                    time.sleep(int(data))
                else:
                    # print("[INFO] : Custom Wait Sec maximum wait time is 5 sec")
                    Variable_not_resettable.logger.info("Custom Wait Sec maximum wait time is 5 Minutes")
                    time.sleep(5)
            except Exception as error:
                raise Exception(str(error))

        case "Assert Grid Disable":
            disabled = "//*[starts-with(@id,'"+Wrapper_variables.startsWithId+"') and @aria-disabled='true']"
            grid_status = for_check_obj(page_object, loc_xpath, 1000)
            if grid_status == True:
                Variable_not_resettable.logger.info("Assertion Passed...")
            else:
                Variable_not_resettable.logger.info("Assertion Failed...")
                raise Exception("Assertion Failed...")      
        
        case "Assert Docs":
            is_page2_opened = False
            is_page2_closed = False
            save_btn_xpath = "//*[@id='save']"
            i_frame_xpath = "//iframe[@id='report_iframe']"
            try:
                page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                with context.expect_page() as new_page:
                    page_object.click(loc_xpath, timeout= Common_object.Timeout)
                    page2 = new_page.value
                Variable_not_resettable.logger.info(str(page2))
                is_page2_opened = True
                page2.wait_for_selector(i_frame_xpath, timeout= 30000)
                frame_element = page2.frame_locator(i_frame_xpath)
                save_btn = frame_element.locator(save_btn_xpath)
                with page2.expect_download(timeout=60000) as download_info:
                    save_btn.click()
                download = download_info.value
                file_name = download.suggested_filename
                Variable_not_resettable.logger.debug(f"file_name: {file_name}")
                destination_file_path = os.path.join(Common_path.input_document, file_name)
                download.save_as(destination_file_path)
                Variable_not_resettable.logger.info(f"file save in {destination_file_path}")
                document_validator(destination_file_path)
                time.sleep(2)
                snapshot_file_path = for_success_snapshot(page2)
                Variable_not_resettable.logger.debug(f"Snapshot file path : {snapshot_file_path}")
                time.sleep(1)
                page2.close()
                is_page2_closed = True
            except Exception as error:
                if is_page2_opened == True and is_page2_closed == False:
                    page2.close()
                    Variable_not_resettable.logger.info("page2 closed...")
                raise Exception(str(error))
            
        case "Assert CSV":
            is_page2_opened = False
            is_page2_closed = False
            save_btn_xpath = "//*[@id='save']"
            i_frame_xpath = "//iframe[@id='report_iframe']"
            try:
                page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                with page_object.expect_download(timeout=60000) as download_info:
                    page_object.click(loc_xpath)
                download = download_info.value
                file_name = download.suggested_filename
                Variable_not_resettable.logger.debug(f"file_name: {file_name}")
                destination_file_path = os.path.join(Common_path.input_document, file_name)
                download.save_as(destination_file_path)
                Variable_not_resettable.logger.info(f"file save in {destination_file_path}")
                csv_validator(destination_file_path)
                time.sleep(2)
                snapshot_file_path = for_success_snapshot(page_object)
                Variable_not_resettable.logger.debug(f"Snapshot file path : {snapshot_file_path}")
                time.sleep(1)
                is_page2_closed = True
            except Exception as error:
                Variable_not_resettable.logger.info(str(error))
                raise Exception(str(error))

        case "Assert Grid Icon Status":
            # loc_xpath = "//*[@id='"+Common_controls.control_Value+"']/div"
            loc_xpath = "//*[@id='"+Common_controls.control_Value+"']/div[@class='"+Common_data.data_value+"']"
            Variable_not_resettable.logger.info(f"loc xpath: {loc_xpath}")
            grid_status = for_check_obj(page_object, loc_xpath, 1000)
            if grid_status == True:
                Variable_not_resettable.logger.info("Assertion Passed...")
            else:
                Variable_not_resettable.logger.info("Assertion Failed...")
                raise Exception("Assertion Failed...")
            
        case "Drag And Drop":
            if Variable_not_resettable.APP_TYPE == "Studio":
                selector_splitting = str(Common_controls.control_Value).split(";")
                source_element_xpath = selector_splitting[0]
                target_place_elements_xpath= selector_splitting[1]
                page_object.locator('xpath='+source_element_xpath)
                page_object.wait_for_selector('xpath='+source_element_xpath, timeout= 30000)
                page_object.wait_for_selector('xpath='+target_place_elements_xpath, timeout= 30000)
                page_object.locator('xpath='+source_element_xpath).hover(position={"x":0,"y":0})
                page_object.click('xpath='+source_element_xpath)
                time.sleep(.5)
                element = page_object.query_selector('xpath='+source_element_xpath)
                target_place_xpath_box = element.bounding_box()
                x = target_place_xpath_box['x']
                y = target_place_xpath_box['y']
                width = target_place_xpath_box['width']
                height = target_place_xpath_box['height']
                x_place = int(x)+ (int(width)/2)
                y_place = int(y)+ (int(height)/2)
                time.sleep(0.5)
                page_object.mouse.move(x_place, y_place)
                time.sleep(.5)
                page_object.mouse.down()
                mouse_down_f = True
                Variable_not_resettable.logger.info(f"target_place_elements_xpath: {target_place_elements_xpath}")
                page_object.locator('xpath='+target_place_elements_xpath)
                page_object.wait_for_selector('xpath='+target_place_elements_xpath, timeout= 3000)
                page_object.locator('xpath='+target_place_elements_xpath).hover(position={"x":0,"y":0})
                element = page_object.query_selector('xpath='+target_place_elements_xpath)
                target_place_elements_xpath_box = element.bounding_box()
                x = target_place_elements_xpath_box['x']
                y = target_place_elements_xpath_box['y']
                width = target_place_elements_xpath_box['width']
                height = target_place_elements_xpath_box['height']
                x_place = (int(width)/2) + (int(width)/4)
                y_place = (int(height)/2) + (int(height)/4)
                time.sleep(0.5)
                page_object.locator('xpath='+target_place_elements_xpath).hover(position={"x":x_place,"y":y_place})
                time.sleep(.5)
                page_object.mouse.up()
                mouse_up_f = True
                Variable_not_resettable.logger.info(f"Drag and drop completed")
                time.sleep(0.5)
            else:
                selector_splitting = str(Common_controls.control_Value).split(";")
                selector_drag = selector_splitting[0]
                selector_drop = selector_splitting[1]
                if Common_controls.control_Identifier.lower() == "xpath":
                    drag_xpath = selector_drag
                    drop_xpath = selector_drop
                else:
                    drag_xpath = "//*[@id='"+selector_drag+"']"
                    drop_xpath = "//*[@id='"+selector_drop+"']"

                if "||" in data and data!=None:
                    data_drag, data_drop = data.split("||")
                    data_drag = data_drag.strip()
                    data_drop = data_drop.strip()

                    if data_drag!=None:
                        for index , each_data in enumerate(data_drag.split(";"), 1):
                            key = f":var{index}"
                            drag_xpath = drag_xpath.replace(key, each_data)
                    
                    if data_drop!=None:
                        for index , each_data in enumerate(data_drop.split(";"), 1):
                            key = f":var{index}"
                            drop_xpath = drop_xpath.replace(key, each_data)

                    Variable_not_resettable.logger.info(f"Drag xpath : {drag_xpath}")
                    Variable_not_resettable.logger.info(f"Drop xpath : {drop_xpath}")

                    page_object.wait_for_selector(drag_xpath, timeout= 3000)
                    page_object.wait_for_selector(drop_xpath, timeout= 3000)

                    page_object.locator(drag_xpath).hover(position={"x":0,"y":0})
                    # page_object.click(drag_xpath)
                    time.sleep(.5)
                    drag_element = page_object.query_selector(drag_xpath)
                    drag_target_place_xpath_box = drag_element.bounding_box()
                    drag_x = drag_target_place_xpath_box['x']
                    drag_y = drag_target_place_xpath_box['y']
                    drag_width = drag_target_place_xpath_box['width']
                    drag_height = drag_target_place_xpath_box['height']
                    drag_x_place = int(drag_x)+ (int(drag_width)/2)
                    drag_y_place = int(drag_y)+ (int(drag_height)/2)
                    time.sleep(0.5)
                    page_object.mouse.move(drag_x_place, drag_y_place)
                    time.sleep(.5)
                    page_object.mouse.down()

                    Variable_not_resettable.logger.info(f"Drag started")


                    drop_element = page_object.query_selector(drop_xpath)
                    drop_element.scroll_into_view_if_needed()
                    drop_target_place_xpath_box = drop_element.bounding_box()
                    drop_x = drop_target_place_xpath_box['x']
                    drop_y = drop_target_place_xpath_box['y']
                    drop_width = drop_target_place_xpath_box['width']
                    drop_height = drop_target_place_xpath_box['height']
                    drop_x_place = (int(drop_width)/2)
                    drop_y_place = (int(drop_height)/2)
                    page_object.locator(drop_xpath).hover(position={"x":0,"y":0})
                    time.sleep(0.5)
                    page_object.locator(drop_xpath).hover(position={"x":drop_x_place,"y":drop_y_place})
                    time.sleep(0.5)
                    page_object.mouse.up()

                    Variable_not_resettable.logger.info(f"Drop completed")
            
        case "MultiSort Drag and Drop":
            try:
                mouse_down_f = False
                mouse_up_f = False
                multi_short_count = 0
                previous_each_data = ""
                data = [d.strip() for d in data.split(";")]
                if Common_step.multi_short_done_list  == None:
                    Common_step.multi_short_done_list = {"data":data, "done": []}
                while len(Common_step.multi_short_done_list["data"]) > 0:
                    each_data = Common_step.multi_short_done_list["data"].pop(0)
                    mouse_down_f = False
                    mouse_up_f = False
                    if len(Common_step.multi_short_done_list["done"]) > 0:
                        previous_each_data = Common_step.multi_short_done_list["done"][-1]
                    else:
                        previous_each_data = ""
                    Variable_not_resettable.logger.info(f"Drag and Drop for: {each_data}")
                    multi_short_count += 1
                    objectValue = Wrapper_variables.objectValue
                    objectValue1 = Wrapper_variables.objectValue1
                    objectValue_containsId = objectValue.split("_")[-1]
                    objectValue_startsWithId = objectValue.replace(f"_{objectValue_containsId}", "").replace("_","-")
                    source_element_xpath = f"//div[@aria-hidden='false']//*[starts-with(@id,'{objectValue_startsWithId}')]//*[contains(@id, 'bodyWrap')]//*[starts-with(@id,'{objectValue_startsWithId}') and contains(@id, 'body')]//*[text()='{each_data}']"
                    objectValue1_containsId = objectValue1.split("_")[-1]
                    objectValue1_startsWithId = objectValue1.replace(f"_{objectValue1_containsId}", "").replace("_","-")
                    target_place_elements_xpath = f"//div[@aria-hidden='false']//*[starts-with(@id,'{objectValue1_startsWithId}')]//*[contains(@id, 'bodyWrap')]//*[starts-with(@id,'{objectValue1_startsWithId}') and contains(@id, 'body')]//*[text()='{previous_each_data}']"
                    target_place_xpath = f"//div[@aria-hidden='false']//*[starts-with(@id,'{objectValue1_startsWithId}') and contains(@id, 'bodyWrap')]//*[starts-with(@id,'{objectValue1_startsWithId}') and contains(@id, 'body')]"
                    Variable_not_resettable.logger.info(f"source_element_xpath: {source_element_xpath}")
                    page_object.wait_for_selector(source_element_xpath, timeout= 3000)
                    if multi_short_count == 1:
                        page_object.wait_for_selector(target_place_xpath, timeout= 3000)
                    else:
                        page_object.wait_for_selector(target_place_elements_xpath, timeout= 3000)
                    page_object.locator(source_element_xpath).hover(position={"x":0,"y":0})
                    page_object.click(source_element_xpath)
                    time.sleep(.5)
                    element = page_object.query_selector(source_element_xpath)
                    target_place_xpath_box = element.bounding_box()
                    x = target_place_xpath_box['x']
                    y = target_place_xpath_box['y']
                    width = target_place_xpath_box['width']
                    height = target_place_xpath_box['height']
                    x_place = int(x)+ (int(width)/2)
                    y_place = int(y)+ (int(height)/2)
                    time.sleep(0.5)
                    page_object.mouse.move(x_place, y_place)
                    time.sleep(.5)
                    page_object.mouse.down()
                    mouse_down_f = True
                    if len(Common_step.multi_short_done_list["done"]) == 0:
                        Variable_not_resettable.logger.info(f"target_place_xpath: {target_place_xpath}")
                        page_object.wait_for_selector(target_place_xpath, timeout= 3000)
                        element = page_object.query_selector(target_place_xpath)
                        target_place_xpath_box = element.bounding_box()
                        x = target_place_xpath_box['x']
                        y = target_place_xpath_box['y']
                        width = target_place_xpath_box['width']
                        height = target_place_xpath_box['height']
                        x_place = (int(width)/2)
                        y_place = (int(height)/2)
                        page_object.locator(target_place_xpath).hover(position={"x":0,"y":0})
                        time.sleep(0.5)
                        page_object.locator(target_place_xpath).hover(position={"x":x_place,"y":y_place})
                        time.sleep(0.5)
                        page_object.mouse.up()
                        mouse_up_f = True
                    elif len(Common_step.multi_short_done_list["done"]) > 0:
                        Variable_not_resettable.logger.info(f"target_place_elements_xpath: {target_place_elements_xpath}")
                        page_object.wait_for_selector(target_place_elements_xpath, timeout= 3000)
                        page_object.locator(target_place_elements_xpath).hover(position={"x":0,"y":0})
                        element = page_object.query_selector(target_place_elements_xpath)
                        target_place_elements_xpath_box = element.bounding_box()
                        x = target_place_elements_xpath_box['x']
                        y = target_place_elements_xpath_box['y']
                        width = target_place_elements_xpath_box['width']
                        height = target_place_elements_xpath_box['height']
                        x_place = (int(width)/2) + (int(width)/4)
                        y_place = (int(height)/2) + (int(height)/4)
                        time.sleep(0.5)
                        page_object.locator(target_place_elements_xpath).hover(position={"x":x_place,"y":y_place})
                        time.sleep(.5)
                        page_object.mouse.up()
                        mouse_up_f = True
                    check_place_elements_xpath = f"//div[@aria-hidden='false']//*[starts-with(@id,'{objectValue1_startsWithId}')]//*[contains(@id, 'bodyWrap')]//*[starts-with(@id,'{objectValue1_startsWithId}') and contains(@id, 'body')]//*[text()='{each_data}']"
                    page_object.wait_for_selector(check_place_elements_xpath, timeout= 3000)
                    Common_step.multi_short_done_list["done"].append(each_data)
                time.sleep(.5)
            except Exception as error:
                Common_step.multi_short_done_list["data"].insert(0, each_data)
                Variable_not_resettable.logger.error(str(error))
                items_remaining = Common_step.multi_short_done_list["data"]
                Variable_not_resettable.logger.info( f"Items Remaining: {str(items_remaining)}")
                if mouse_down_f == True and mouse_up_f == False:
                    page_object.mouse.up()
                    mouse_up_f = True

                raise Exception(str(error))

        case "Dynamic Grid Uncheck":
            data_split_list = data.split(";")
            control_value_split_for_total_row_count = ((str(((Common_controls.control_Value).split(";")[0]))).split("_cell"))[0]
            path_for_total_rows = "//*[starts-with(@id,'"+control_value_split_for_total_row_count+"')]//*[contains(@id, '_tbr_dspRow')]"
            Variable_not_resettable.logger.info(f"path_for_total_rows : {path_for_total_rows}")
            getting_inner_text = page_object.query_selector(path_for_total_rows)            
            Total_row_count = ((getting_inner_text.inner_text()).split("/"))[1]
            Variable_not_resettable.logger.info(f"Total_row_count : {Total_row_count}")
            checkbox_control = (str(((Common_controls.control_Value).split(";"))[0]).split("_row"))[0]
            description_control = (str(((Common_controls.control_Value).split(";"))[1]).split("_row"))[0]
            for row in range(1,int(int(Total_row_count)+1)):
                Variable_not_resettable.logger.info(f"{row}")
                for each_data in data_split_list:
                    description_id = description_control + "_row"+str(row)
                    description_xpath = "//*[@id='"+description_id+"']"
                    try:
                        page_object.wait_for_selector(description_xpath, timeout= 3000)
                    except:
                        startswith_for_next_button = control_value_split_for_total_row_count + "_tbr_btnNext"
                        next_button = "//*[starts-with(@id,'"+startswith_for_next_button+"')]//*[contains(@id, 'btnIconEl')]"
                        for_click(page_object,next_button)
                        time.sleep(5)
                    getting_inner_text_of_description = page_object.query_selector(description_xpath)            
                    description_value = getting_inner_text_of_description.inner_text()
                    if description_value == each_data:
                        pass
                    elif str(each_data) == str(description_value):
                        pass
                    else:
                        checkbox_id = str(checkbox_control) + "_row"+str(row)
                        checkbox_xpath = "(//*[@id='"+checkbox_id+"'])[1]"
                        for_click(page_object,checkbox_xpath)

        case "Assert Enumerated Grid Smart Search":
            if Wrapper_variables.patternMatch == "NO":
                # sxpath = "//div[@class='x-panel x-ltr x-boundlist x-avnsearchwindow x-layer x-panel-default x-grid x-border-box' and @aria-hidden='false']/..//table//td/div[text()='"+dataValue+"']"
                try:
                    time.sleep(0.25)
                    input_field_clicked = False
                    wait_unitil_please_wait(page_object,200)
                    input_values = data.split(";")
                    search_value = input_values[0]
                    data_value = input_values[1:]
                    try:
                        # page_object.locator(loc_xpath).scroll_into_view_if_needed()
                        marquee_click = "(//*[starts-with(@id,'newTicker-marquee')])[1]"
                        # page_object.locator(loc_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                        # page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                        # page_object.locator(loc_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                        for_click(page_object,marquee_click)
                        page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                        page_object.locator(loc_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                        for_click(page_object,loc_xpath)
                        # icon = "//div[@id='"+Common_controls.control_Value+"']/following-sibling::div/div[starts-with(@id,'ramcolistedit')]//*[contains(@id, 'trigger-picker')]"
                        # for_click(page_object,icon)
                        page_object.keyboard.press("Control+A")
                        page_object.keyboard.press("Backspace")
                        # for_click(page_object,loc_xpath)
                    except Exception as error:
                        wait_unitil_please_wait(page_object, 100)
                        wait_and_close_popup(page_object)
                        # page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)

                    input_field_clicked = True
                    search_value_length = len(search_value)
                    i = 0
                    while (i < search_value_length):
                        if i == 0:
                            time.sleep(1)
                        # page_object.type(loc_xpath, search_value[i], delay=100)
                        page_object.keyboard.type(str(search_value[i]), delay=100)
                        wait_unitil_please_wait(page_object,500)
                        search_select = "//div[@name='undefined_gridview' and @class='x-grid-view x-grid-with-col-lines x-grid-with-row-lines x-fit-item x-ltr x-grid-view-default x-unselectable x-scroller']"
                        Variable_not_resettable.logger.info(f"search_select :  {search_select}")
                        if assert_locator_for_smart_search(page_object, search_select):
                            for_success_snapshot(page_object)
                            # page_object.click(search_select)
                            value_for_search = page_object.query_selector_all(search_select)
                            smart_search_value_list = []
                            for element in value_for_search:
                                smart_search_value = element.inner_text()
                                smart_search_value = ((smart_search_value.replace("\n\t\n",",")).replace("\n",";")).split(";")
                            for each_data in smart_search_value:   
                                smart_search_value_list.append(each_data)
                            # Variable_not_resettable.logger.info(f"smart_search_value_list: {smart_search_value_list}")
                            if data_value == smart_search_value_list:
                                Variable_not_resettable.logger.info("Assertion Passed...")
                                page_object.keyboard.press("Escape")
                                Variable_not_resettable.logger.info(f"value_from_search : {smart_search_value_list} and value from sheet : {data_value}")
                                break
                            elif str(data_value) == str(smart_search_value_list):
                                Variable_not_resettable.logger.info("Assertion Passed...")
                                page_object.keyboard.press("Escape")
                                Variable_not_resettable.logger.info(f"value_from_search : {smart_search_value_list} and value from sheet : {data_value}")
                                break
                            else:
                                Variable_not_resettable.logger.info("Assertion Failed...")
                                page_object.keyboard.press("Escape")
                                Variable_not_resettable.logger.info(f"value_from_search : {smart_search_value_list} and value from sheet : {data_value}")
                                raise Exception("Assertion Failed...")
                        i = i + 1
                        if i == search_value_length:
                            Common_object.Custom_Error = "Smart search result value not found"
                            raise Exception("Smart search result value not found...")
                except Exception as error:
                    Variable_not_resettable.logger.info(str(error))
                    if input_field_clicked == True:
                        page_object.keyboard.press("Escape")
                        input_field_clicked = False
                    raise Exception(str(error))
                
        case "Assert Grid Smart Search":
            if Wrapper_variables.patternMatch == "NO":
                # sxpath = "//div[@class='x-panel x-ltr x-boundlist x-avnsearchwindow x-layer x-panel-default x-grid x-border-box' and @aria-hidden='false']/..//table//td/div[text()='"+dataValue+"']"
                try:
                    time.sleep(0.25)
                    input_field_clicked = False
                    wait_unitil_please_wait(page_object,200)
                    input_values = data.split(";")
                    # search_value = input_values[0]
                    # data_value = input_values[1:]
                    try:
                        # page_object.locator(loc_xpath).scroll_into_view_if_needed()
                        marquee_click = "(//*[starts-with(@id,'newTicker-marquee')])[1]"
                        for_click(page_object,marquee_click)
                        # page_object.locator(loc_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                        page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
                        page_object.locator(loc_xpath).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                        for_click(page_object,loc_xpath)
                        # for_click(page_object,marquee_click)
                        icon = "//div[@id='"+Common_controls.control_Value+"']/following-sibling::div/div[starts-with(@id,'ramcolistedit')]//*[contains(@id, 'trigger-picker')]"
                        for_click(page_object,icon)
                        # page_object.keyboard.press("Control+A")
                        # page_object.keyboard.press("Backspace")
                        # for_click(page_object,loc_xpath)
                    except Exception as error:
                        Variable_not_resettable.logger.info(str(error))
                        wait_unitil_please_wait(page_object, 100)
                        wait_and_close_popup(page_object)
                        # page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)

                    input_field_clicked = True
                    # search_value_length = len(search_value)
                    # i = 0
                    # while (i < search_value_length):
                    #     if i == 0:
                    #         time.sleep(1)
                    #     # page_object.type(loc_xpath, search_value[i], delay=100)
                    #     # page_object.keyboard.type(str(search_value[i]), delay=100)
                    #     wait_unitil_please_wait(page_object,500)
                    search_select = "//div[@name='undefined_gridview' and @class='x-grid-view x-grid-with-col-lines x-grid-with-row-lines x-fit-item x-ltr x-grid-view-default x-unselectable x-scroller']"
                    Variable_not_resettable.logger.info(f"search_select :  {search_select}")
                    page_object.wait_for_selector(search_select, timeout= Common_object.Timeout)
                    if assert_locator_for_smart_search(page_object, search_select):
                        for_success_snapshot(page_object)
                        # page_object.click(search_select)
                        value_for_search = page_object.query_selector_all(search_select)
                        smart_search_value_list = []
                        for element in value_for_search:
                            smart_search_value = element.inner_text()
                            smart_search_value = ((smart_search_value.replace("\n\t\n",",")).replace("\n",";")).split(";")
                        for each_data in smart_search_value:   
                            smart_search_value_list.append(each_data)
                        Variable_not_resettable.logger.info(f"smart_search_value_list: {smart_search_value_list}")
                        if input_values == smart_search_value_list:
                            Variable_not_resettable.logger.info("Assertion Passed...")
                            page_object.keyboard.press("Escape")
                            Variable_not_resettable.logger.info(f"value_from_search : {smart_search_value_list} and value from sheet : {input_values}")
                        elif str(input_values) == str(smart_search_value_list):
                            Variable_not_resettable.logger.info("Assertion Passed...")
                            page_object.keyboard.press("Escape")
                            Variable_not_resettable.logger.info(f"value_from_search : {smart_search_value_list} and value from sheet : {input_values}")
                        else:
                            Variable_not_resettable.logger.info("Assertion Failed...")
                            page_object.keyboard.press("Escape")
                            Variable_not_resettable.logger.info(f"value_from_search : {smart_search_value_list} and value from sheet : {input_values}")
                            raise Exception("Assertion Failed...")
                    # i = i + 1
                    # if i == search_value_length:
                    #     Common_object.Custom_Error = "Smart search result value not found"
                    #     raise Exception("Smart search result value not found...")
                except Exception as error:
                    Variable_not_resettable.logger.info(str(error))
                    if input_field_clicked == True:
                        page_object.keyboard.press("Escape")
                        input_field_clicked = False
                    raise Exception(str(error))

        case "On Availability":
            popup_element = "//div[@name='undefined_messagebox' and @aria-hidden='false']"
            yes_btn = "//*[starts-with(@id,'yes-button')]//*[contains(@id, 'btnInnerEl')]"
            try:
                page_object.wait_for_selector(popup_element, timeout= Common_object.Timeout_pop_up)
                Variable_not_resettable.logger.info("Pop up found")               
                try:
                    page_object.click(yes_btn)
                except Exception as error:
                    Variable_not_resettable.logger.info(str(error))
            except Exception as error:
                Variable_not_resettable.logger.info("Pop up not found") 

        case "Assert Grid UI Values":
            data = data.split(";")
            header_columns = data[1:]
            for_click(page_object,loc_xpath)
            Wrapper_variables.startsWithId = str(Wrapper_variables.startsWithId).split("_")
            startsWithId = (Wrapper_variables.startsWithId)[0]
            if data != "nan" or data != "":
                download_file = "//*[starts-with(@id,'"+startsWithId+"')]//*[contains(@id, 'textEl')][text()='"+data[0]+"']"
                downloaded_xlsm_file_path,xlsm_file_name = for_download_and_assert_all_grid_values(page_object,download_file)
            else:
                Variable_not_resettable.logger.info(f"Export file without data value")         
            total_rows_in_ui = total_row_count(page_object)
            sheet = pd.ExcelFile(downloaded_xlsm_file_path).book.active.title
            rows_in_excel,entire_excel_dict,excel_file_path = xlsm_to_xlsx_conversion(xlsm_file_name,sheet)
            if int(total_rows_in_ui) == int(rows_in_excel):
                Variable_not_resettable.logger.info(f"Rows matched, Passed")
            else:
                Variable_not_resettable.logger.info(f"Rows not matched, Failed")
                raise Exception(str("Total row count not matching"))
            looping_list_for_headers = []
            for header in header_columns:
                # print(header)
                header_name = "//*[starts-with(@id,'"+startsWithId+"')]//*[contains(@id, 'textInnerEl') and text()='"+header+"']"
                header_id_query = page_object.query_selector(header_name)
                header_id = header_id_query.get_attribute("id")
                split_header_id = (((header_id.split(startsWithId))[1]).split("_"))[1]
                looping_list_for_headers.append(split_header_id)
            
            list_of_entire_rows_from_UI = []
            for row in range(1,int(total_rows_in_ui)+1):
                if int(row % 10) == 0:
                    startswith_for_next_button = startsWithId + "_tbr_btnNext"
                    next_button = "//*[starts-with(@id,'"+startswith_for_next_button+"')]//*[contains(@id, 'btnIconEl')]"
                    for_click(page_object,next_button)
                    wait_unitil_please_wait(page_object, 100)
                cell_value_for_one_row_in_ui = []
                for column_no in looping_list_for_headers:
                    # each_cell = "grddetgrid_cell_colv1_row1"
                    each_cell =  str(startsWithId) +"_cell_col"+str(column_no)+"_row"+str(row)
                    each_cell = "//*[@id='"+each_cell+"']"
                    # print(each_cell)
                    cell_value = page_object.query_selector(each_cell)
                    cell_value = cell_value.inner_text()
                    # print(cell_value)
                    cell_value_for_one_row_in_ui.append(str(cell_value))
                list_of_entire_rows_from_UI.append(cell_value_for_one_row_in_ui)
            
            value_for_entire_row_from_excel = []
            for each_dict in entire_excel_dict:
                value_from_single_row_in_excel = []
                for each_header in header_columns:
                    value = each_dict[each_header]
                    value_from_single_row_in_excel.append(str(value))
                value_for_entire_row_from_excel.append(value_from_single_row_in_excel)

            Status_list = []
            for each_row_in_ui,each_row_in_excel in zip(list_of_entire_rows_from_UI,value_for_entire_row_from_excel):
                if each_row_in_ui == each_row_in_excel:
                    status = "Pass"
                else:
                    status = "Fail"
                    # print(each_row_in_ui)
                    # print(each_row_in_excel)
                    Variable_not_resettable.logger.info(f"Fail")
                Status_list.append(str(status))
            output_folder_path = os.path.join(Common_path.base_path,"UI_Grid_Comparison_Output")
            make_directory(output_folder_path)
            output_file_path = (os.path.join(output_folder_path,"Output_"+str(datetime.now()).replace(":","-") + ".xlsx")).replace(" ","_")
            shutil.copyfile(excel_file_path, output_file_path)
            output_df = pd.read_excel(output_file_path,sheet,dtype="str")
            output_df["Status"] = status
            output_df.to_excel(output_file_path,sheet,index=False)       

        case "Click nth Display Block":
            size = (len(((Common_controls.control_Value).split(";"))[0]))-1
            if int(data) % 2 == 0:
                no_of_clicks_req = int(int(data) / 2) - 1
            else:
                no_of_clicks_req = math.floor((int(data)) / 2)
            req_control_value = ((Common_controls.control_Value).split(";")[0])[0:size] + str(data)
            loc_path_link = "//*[@id='"+req_control_value+"']"
            Variable_not_resettable.logger.info(f"loc_path_link : {loc_path_link}")
            if no_of_clicks_req!=0:
                for each_click in range(no_of_clicks_req):
                    for_click(page_object,loc_xpath)

                # move_btn_up="//*[starts-with(@id,'moveFirst-button')]//*[contains(@id, 'btnIconEl')]"
                page_object.wait_for_selector(loc_path_link, timeout= Common_object.Timeout)
                for_click(page_object,loc_path_link)
                # for_click(page_object,move_btn_up)
            else:
                page_object.wait_for_selector(loc_path_link, timeout= Common_object.Timeout)
                for_click(page_object,loc_path_link)

        case "Click nth Grid Column":
            size = len(Common_controls.control_Value) - 1
            splitted_data = data.split(";")
            req_control_value = (Common_controls.control_Value)[0:size] + str(splitted_data[0])
            req_link_path = "//*[@id='"+req_control_value+"']/../..//*[text()='"+splitted_data[1]+"']"
            page_object.wait_for_selector(req_link_path, timeout= Common_object.Timeout)
            for_click(page_object,req_link_path)

        case "Assert Downloaded Excel Column":
            try:
                data_split = data.split(";") 
                reference_file_name, ref_sheet_name = tuple(split_by_colon_for_excel_assertion(data_split[0]))
                ref_employee_code,ref_employee_name,ref_columns_to_assert = tuple(split_by_colon_for_excel_assertion(data_split[1]))
                dwnld_employee_code,dwnld_employee_name,dwnld_columns_to_assert = tuple(split_by_colon_for_excel_assertion(data_split[2]))

                downloaded_excel_file_name = for_download_and_assert_excel(page_object,loc_xpath,context)
                sheet = pd.ExcelFile(downloaded_excel_file_name).book.active.title
                downloaded_df = pd.read_excel(downloaded_excel_file_name,sheet,dtype="str")
                downloaded_df = downloaded_df.fillna("")
                row_to_consider_as_header = downloaded_df.iloc[5]
                new_downloaded_df = pd.DataFrame(downloaded_df.rename(columns=row_to_consider_as_header).drop(downloaded_df.index[0]))
                new_downloaded_df = new_downloaded_df[5:].reset_index(inplace=False, drop=True)
                downloaded_df_with_req_columns = new_downloaded_df[split_by_colon_for_excel_assertion(data_split[2])]
                final_dict_downloaded = new_downloaded_df.to_dict("records")
                # print(final_dict_downloaded)

                data_excel = os.path.join(Common_path.input_document,str(reference_file_name)+".xlsx")
                data_sheet_df = pd.read_excel(data_excel,sheet_name=ref_sheet_name,dtype="str")
                data_sheet_df = data_sheet_df.fillna("")
                data_df = data_sheet_df[split_by_colon_for_excel_assertion(data_split[1])]
                final_data_dict = data_df.to_dict("records")
                # print(final_data_dict)

                make_directory(Common_path.base_path + "/Files"+"/ExcelComparisonOutput")
                DF_HEADERS_LIST = (downloaded_df.iloc[5]).to_list()
                DF_HEADERS_LIST.append("STATUS")
                # print(DF_HEADERS_LIST)
                DF_HEADERS = pd.DataFrame(columns=DF_HEADERS_LIST)
                Excel_path = Common_path.base_path + "/Files/"+"ExcelComparisonOutput/"+"Output_"+(str(datetime.now().replace(microsecond=0))).replace(":", "_")+".xlsx"
                with pd.ExcelWriter(Excel_path) as writer:
                    DF_HEADERS.to_excel(writer,sheet_name="Output_sheet", index=False)
                fail_count = 0
                for each_downloaded_dict in final_dict_downloaded:
                    download_list = []
                    employee_code = each_downloaded_dict[dwnld_employee_code]
                    for each_refernce_dict in final_data_dict:
                        reference_list = []
                        if each_refernce_dict[ref_employee_code] == employee_code:
                            for download_item in split_by_colon_for_excel_assertion(data_split[2]):
                                value1 = each_downloaded_dict[download_item]
                                download_list.append(value1)
                            for ref_item in split_by_colon_for_excel_assertion(data_split[1]):
                                value2 = each_refernce_dict[ref_item]
                                reference_list.append(value2)
                            if download_list == reference_list:
                                each_downloaded_dict["STATUS"] = "Pass"
                                Variable_not_resettable.logger.info(f"Pass")
                            else:
                                Variable_not_resettable.logger.info(f"download_list : {download_list}")
                                Variable_not_resettable.logger.info(f"reference_list : {reference_list}")
                                each_downloaded_dict["STATUS"] = "Fail"
                                Variable_not_resettable.logger.info(f"Fail")
                            data = list(each_downloaded_dict.values())
                            file_path = Excel_path   
                            add_row_to_excel(file_path, "Output_sheet", data)
                        else:
                            pass
                if fail_count !=0:
                    raise Exception("There is some mismatch between the given columns")
            except Exception as error:
                Variable_not_resettable.logger.info(str(error))
                raise Exception(str(error))
        
        case "Click By Xpath":

            for index , each_data in enumerate(data.split(";"), 1):
                key = f":var{index}"
                loc_xpath = loc_xpath.replace(key, each_data)
            Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")   
            for_click_xpath(page_object,loc_xpath)

        case "Assert Page CSS Styling":
            Variable_not_resettable.logger.info("------------------->>>>>>>>>>Webpage Assertion started<<<<<<<<<<-------------------------")
            page_object.wait_for_load_state('load')
            Assertion_status=WebpageAssertion(page_object)
            Variable_not_resettable.logger.info("------------------->>>>>>>>>>Webpage Assertion completed<<<<<<<<-------------------------")

        case "Drag and Drop Grid Column":
            try:
                mouse_down_f = False
                mouse_up_f = False
                data = [d for d in data.split(";")]
                mouse_down_f = False
                mouse_up_f = False
                objectValue = Wrapper_variables.objectValue
                objectValue1 = Wrapper_variables.objectValue1
                objectValue_containsId = objectValue.split("_")[-1]
                objectValue_startsWithId = objectValue.replace(f"_{objectValue_containsId}", "")
                Wrapper_variables.lastIndex = objectValue_startsWithId.rfind("_")
                objectValue_startsWithId = objectValue_startsWithId[:Wrapper_variables.lastIndex] + "-" + objectValue_startsWithId[Wrapper_variables.lastIndex + 1:]
                source_element_xpath = f"//div[@aria-hidden='false']//*[starts-with(@id,'{objectValue_startsWithId}')]//*[contains(@id, 'bodyWrap')]//*[starts-with(@id,'{objectValue_startsWithId}') and contains(@id, 'body')]//*[text()='{data[0]}']"
                objectValue1_containsId = objectValue.split("_")[-1]
                objectValue1_startsWithId = objectValue.replace(f"_{objectValue_containsId}", "")
                Wrapper_variables.lastIndex = objectValue1_startsWithId.rfind("_")
                objectValue1_startsWithId = objectValue1_startsWithId[:Wrapper_variables.lastIndex] + "-" + objectValue1_startsWithId[Wrapper_variables.lastIndex + 1:]
                target_place_elements_xpath = f"//div[@aria-hidden='false']//*[starts-with(@id,'{objectValue1_startsWithId}')]//*[contains(@id, 'bodyWrap')]//*[starts-with(@id,'{objectValue1_startsWithId}') and contains(@id, 'body')]//*[text()='{data[1]}']"
                target_place_xpath = f"//div[@aria-hidden='false']//*[starts-with(@id,'{objectValue1_startsWithId}') and contains(@id, 'bodyWrap')]//*[starts-with(@id,'{objectValue1_startsWithId}') and contains(@id, 'body')]"
                Variable_not_resettable.logger.info(f"source_element_xpath: {source_element_xpath}")
                page_object.wait_for_selector(source_element_xpath, timeout= 3000)
                page_object.wait_for_selector(target_place_elements_xpath, timeout= 3000)
                page_object.locator(source_element_xpath).hover(position={"x":0,"y":0})
                page_object.click(source_element_xpath)
                time.sleep(.5)
                element = page_object.query_selector(source_element_xpath)
                target_place_xpath_box = element.bounding_box()
                x = target_place_xpath_box['x']
                y = target_place_xpath_box['y']
                width = target_place_xpath_box['width']
                height = target_place_xpath_box['height']
                x_place = int(x)+ (int(width)/2)
                y_place = int(y)+ (int(height)/2)
                time.sleep(0.5)
                page_object.mouse.move(x_place, y_place)
                time.sleep(.5)
                page_object.mouse.down()
                mouse_down_f = True
                Variable_not_resettable.logger.info(f"target_place_elements_xpath: {target_place_elements_xpath}")
                page_object.wait_for_selector(target_place_elements_xpath, timeout= 3000)
                page_object.locator(target_place_elements_xpath).hover(position={"x":0,"y":0})
                element = page_object.query_selector(target_place_elements_xpath)
                target_place_elements_xpath_box = element.bounding_box()
                x = target_place_elements_xpath_box['x']
                y = target_place_elements_xpath_box['y']
                width = target_place_elements_xpath_box['width']
                height = target_place_elements_xpath_box['height']
                x_place = (int(width)/2) + (int(width)/4)
                y_place = (int(height)/2) + (int(height)/4)
                time.sleep(0.5)
                page_object.locator(target_place_elements_xpath).hover(position={"x":x_place,"y":y_place})
                time.sleep(.5)
                page_object.mouse.up()
                mouse_up_f = True
                check_place_elements_xpath = f"//div[@aria-hidden='false']//*[starts-with(@id,'{objectValue1_startsWithId}')]//*[contains(@id, 'bodyWrap')]//*[starts-with(@id,'{objectValue1_startsWithId}') and contains(@id, 'body')]//*[text()='{data[0]}']"
                page_object.wait_for_selector(check_place_elements_xpath, timeout= 3000)
                Variable_not_resettable.logger.info(f"Drag and drop completed")
                time.sleep(0.5)
            except Exception as error:
                Variable_not_resettable.logger.error(str(error))
                if mouse_down_f == True and mouse_up_f == False:
                    page_object.mouse.up()
                    mouse_up_f = True
                raise Exception(str(error))
            
        case "Assert Object Inbetween":
            try:
                data = [d for d in data.split(";")]
                objectValue = Wrapper_variables.objectValue
                objectValue_containsId = objectValue.split("_")[-1]
                objectValue_startsWithId = objectValue.replace(f"_{objectValue_containsId}", "")
                Wrapper_variables.lastIndex = objectValue_startsWithId.rfind("_")
                objectValue_startsWithId = objectValue_startsWithId[:Wrapper_variables.lastIndex] + "-" + objectValue_startsWithId[Wrapper_variables.lastIndex + 1:]
                # objectValue_startsWithId = objectValue.replace(f"_{objectValue_containsId}", "").replace("_","-")
                list_of_bounding_boxes = []
                for each_data in data:
                    source_element_xpath = f"//div[@aria-hidden='false']//*[starts-with(@id,'{objectValue_startsWithId}')]//*[contains(@id, 'bodyWrap')]//*[starts-with(@id,'{objectValue_startsWithId}') and contains(@id, 'body')]//*[text()='{each_data}']"
                    Variable_not_resettable.logger.info(f"source_element_xpath: {source_element_xpath}")
                    page_object.wait_for_selector(source_element_xpath, timeout= 3000)
                    page_object.locator(source_element_xpath).hover(position={"x":0,"y":0})
                    element = page_object.query_selector(source_element_xpath)
                    target_place_xpath_box = element.bounding_box()
                    x = target_place_xpath_box['x']
                    list_of_bounding_boxes.append(x)

                if list_of_bounding_boxes[0] < list_of_bounding_boxes[1] < list_of_bounding_boxes[2]:
                    for_success_snapshot(page_object)
                else:
                    Variable_not_resettable.logger.info(f"Assertion Failed")
                    raise Exception(str("Assertion Failed"))
            except Exception as error:
                Variable_not_resettable.logger.error(str(error))
                raise Exception(str(error))
            
        case "Document Assertion":
            downloaded_doc_file_path ,doc_file_name = for_download_and_assert_all_grid_values(page_object,loc_xpath)
            try:  
                source_doc_path = os.path.join(os.getcwd(),"Files\Input_Documents",data)
                compare_doc_path = downloaded_doc_file_path
                output_folder = "Files/Doc_Assertion_Output/"
                make_directory(output_folder)
                excel_file = os.path.join(os.getcwd(),output_folder,('Differences_'+ str(datetime.now()).replace(":","-") + ".xlsx").replace(" ","_"))
            except Exception as error:
                Variable_not_resettable.logger.info(str(error))
                raise Exception(error)

            text_from_doc1 = convert_doc_to_text(source_doc_path)
            text_from_doc2 = convert_doc_to_text(compare_doc_path)

            if text_from_doc1 is not None and text_from_doc2 is not None:
                differences_doc1, differences_doc2 = compare_documents(text_from_doc1, text_from_doc2)
                differing_lines = []
                for line1, line2 in zip(differences_doc1, differences_doc2):
                    if line1['Text'] != line2['Text']:
                        differing_lines.append((line1, line2))

                if differing_lines:
                    write_differences_to_excel(differing_lines, excel_file)
                    Variable_not_resettable.logger.info(f"Differences written to output excel")
                else:
                    Variable_not_resettable.logger.info("No differences found between the documents")
            else:
                Variable_not_resettable.logger.info("Failed to convert .doc files to text")

        case "List Set Enter - Saasy":
            Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")   
            # for_click_xpath(page_object,loc_xpath)
            # page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            page_object.click(loc_xpath)
            if str(data).lower() != "nan" and str(data) != "" and str(data) != None:
                page_object.fill(loc_xpath, str(data))
            else:
                page_object.fill(loc_xpath, "")
            page_object.keyboard.press("Enter")

        case "Wait for Status":
            time_out = int(data)*60000
            Variable_not_resettable.logger.info(f"wait for status upto : {time_out} milli seconds") 
            Common_step.skip_redo = True
            # Common_step.is_time_out = True
            try:
                page_object.wait_for_selector(loc_xpath, timeout= time_out)
                for_success_snapshot(page_object)
                Variable_not_resettable.logger.info("status found")
                return True
            except:
                raise Exception ("Status not found")
            
        case "Hover And Click":

            selector_splitting = str(Common_controls.control_Value).split(";")
            selector1_hover = selector_splitting[0]
            selector2_click = selector_splitting[1]
            if Common_controls.control_Identifier.lower() == "xpath":
                hover_xpath = selector1_hover
                click_xpath = selector2_click
            else:
                hover_xpath = "//*[@id='"+selector1_hover+"']"
                click_xpath = "//*[@id='"+selector2_click+"']"

            if "||" in data and data!=None:
                data1, data2 = data.split("||")
                data1 = data1.strip()
                data2 = data2.strip()

                if data1!=None:
                    for index , each_data in enumerate(data1.split(";"), 1):
                        key = f":var{index}"
                        hover_xpath = hover_xpath.replace(key, each_data)
                
                if data2!=None:
                    for index , each_data in enumerate(data2.split(";"), 1):
                        key = f":var{index}"
                        click_xpath = click_xpath.replace(key, each_data)

            Variable_not_resettable.logger.info(f"hover_xpath: {hover_xpath}")   
            Variable_not_resettable.logger.info(f"click_xpath : {click_xpath}")   
            
            page_object.wait_for_selector(hover_xpath, timeout= Common_object.Timeout)

            hover_element = page_object.query_selector(hover_xpath)
            hover_element.focus()
            # hover_element.hover()
            try:
                page_object.hover(hover_xpath, timeout= Common_object.Timeout)
            except Exception as error:
                # Variable_not_resettable.logger.warning(str(error))
                pass

            Variable_not_resettable.logger.info(f"hover_xpath completed")
            time.sleep(0.5) 
            page_object.wait_for_selector(click_xpath, timeout= Common_object.Timeout)
            page_object.click(click_xpath)
            Variable_not_resettable.logger.info(f"click_xpath completed") 
        
        case "Autosave Multi Select Combo":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")   
                # page_object.click(loc_xpath)
                if str(data).lower() != "nan" and str(data) != "" and str(data) != None:
                    list_data = str(data).split(";")
                    given_control_value = str(Common_controls.control_Value)
                    for each_data in list_data:
                        page_object.click(loc_xpath)
                        required_chech_box_path_id = (given_control_value.split("listview"))[0] + "input_async_" + str(each_data) + "_check" 
                        required_chech_box_path = "//*[@id='"+required_chech_box_path_id+"']"
                        Variable_not_resettable.logger.info(f"required_chech_box_path : {required_chech_box_path}")
                        page_object.locator(required_chech_box_path).scroll_into_view_if_needed(timeout= Common_object.Timeout)
                        page_object.click(required_chech_box_path,timeout= Common_object.Timeout)
                        time.sleep(0.2) 
                else:
                    Variable_not_resettable.logger.info(f"No data given, kindly check the data")

        case "Multi Select Creatable":
            Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")   
            # for_click_xpath(page_object,loc_xpath)
            # page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
            page_object.click(loc_xpath)
            if str(data).lower() != "nan" and str(data) != "" and str(data) != None:
                list_data = str(data).split(";")
                for each_data in list_data:
                    page_object.fill(loc_xpath, str(each_data))
                    page_object.keyboard.press("Enter")
                Variable_not_resettable.logger.info("Ok clicked...")
            else:
                page_object.fill(loc_xpath, "")
                page_object.keyboard.press("Enter")

        case "Assert Colour":
            #Common_data.data_value2="Not Completed-#F04438;A-#F04426"
            if Common_data.data_value is None and Common_data.data_value1 is not None and Common_data.data_value2 is not None:
                # if Common_data.data_value2 is not None and ";" in Common_data.data_value2:
                #     # firstcolor=Common_data.data_value2.split(";")[0].strip()
                #     # secondcolor=Common_data.data_value2.split(";")[1].strip()
                #     requiredtitle1=Common_data.data_value2.split("-")[0].strip()
                #     # requiredtitle2=secondcolor.split("-")[0].strip()
                #     requiredcolor1=Common_data.data_value2.split("-")[1].strip()
                #     # requiredcolor2=secondcolor.split("-")[1].strip()
                # else:
                requiredtitle1=Common_data.data_value2.split(";")[0].strip()
                requiredcolor1=Common_data.data_value2.split(";")[1].strip()

            if (Common_step.Second_Action).lower()=="findall":
                for iter in range(0,int(Common_data.data_value1)):
                    try:
                        Xpath=loc_xpath.replace("{iter}", str(iter))# Replace the placeholder with the iteration number
                        element = page_object.wait_for_selector(Xpath)
                        # Extract title
                        title = element.get_attribute('title')
                        # Extract color code from SVG child element
                        svg_element = element.query_selector('path')
                        color_code = svg_element.get_attribute('fill')
                        if str(requiredtitle1).lower()==str(title.lower()) and str(requiredcolor1).lower()==str(color_code.lower()):
                            Variable_not_resettable.logger.info(f"Title:{str(title)}")
                            Variable_not_resettable.logger.info(f"Color Code:{str(color_code)}")
                            Variable_not_resettable.logger.info("Status :Pass")
                        else:
                            raise Exception
                        
                    except Exception as e:
                        Variable_not_resettable.logger.info(f"An error occurred:", e)
                        raise Exception
            elif (Common_step.Second_Action).lower()=="findany":
                for iter in range(0,int(Common_data.data_value1)):
                    try:
                        Xpath=loc_xpath.replace("{iter}", str(iter))# Replace the placeholder with the iteration number
                        element = page_object.wait_for_selector(Xpath)
                        # Extract title
                        title = element.get_attribute('title')
                        # Extract color code from SVG child element
                        svg_element = element.query_selector('path')
                        color_code = svg_element.get_attribute('fill')
                        if str(requiredtitle1).lower()==str(title.lower()) and str(requiredcolor1).lower()==str(color_code.lower()):
                                Variable_not_resettable.logger.info(f"Title:{str(title)}")
                                Variable_not_resettable.logger.info(f"Color Code:{str(color_code)}")
                                Variable_not_resettable.logger.info("Status :Pass")
                                break
                        elif iter==int(Common_data.data_value1)-1:
                            Variable_not_resettable.logger.info("Element not found")
                            raise Exception
                        else:
                            pass

                    except Exception as e:
                        Variable_not_resettable.logger.info(f"An error occurred:,{e}")
                        raise Exception
            elif (Common_step.Second_Action).lower()=="findnotin":
                for iter in range(0,int(Common_data.data_value1)):
                    try:
                        Xpath=loc_xpath.replace("{iter}", str(iter))# Replace the placeholder with the iteration number
                        element = page_object.wait_for_selector(Xpath)
                        # Extract title
                        title = element.get_attribute('title')
                        # Extract color code from SVG child element
                        svg_element = element.query_selector('path')
                        color_code = svg_element.get_attribute('fill')
                        if str(requiredtitle1).lower()!=str(title.lower()) and str(requiredcolor1).lower()!=str(color_code.lower()):
                                Variable_not_resettable.logger.info(f"Title: {str(title)}")
                                Variable_not_resettable.logger.info(f"Color Code:{str(color_code)}")
                                Variable_not_resettable.logger.info("Status :Pass")
                        else:
                            raise Exception
                    except Exception as e:
                        Variable_not_resettable.logger.info(f"An error occurred:,{e}")
                        raise Exception

            elif (Common_step.Second_Action).lower()=="assert card rows":
                try:
                    locpath1=Common_controls.control_Value.split(";")[0].strip()
                    locpath2=Common_controls.control_Value.split(";")[1].strip()
                    loc_xpath1="//*[@id='"+locpath1+"']"
                    loc_xpath2="//*[@id='"+locpath2+"']"
                    container = page_object.wait_for_selector(loc_xpath1)
                    cards = container.query_selector_all('//div[@id and contains(@class, "card")]')
                    cardcount=len(cards)
                    # Iterate through each card and click
                    row=0
                    for card in cards:   
                        try:
                            card.click()
                            container1 = page_object.wait_for_selector(loc_xpath2)
                            cards1 = container1.query_selector_all('//div[@id and contains(@class, "card")]')
                            task_counts=0
                            for card1 in cards1:
                                try:
                                    card_id = card1.get_attribute('id')
                                    card_xpath="//*[@id='"+card_id+"']"
                                    element_card = page_object.wait_for_selector(card_xpath)
                                    # Extract title
                                    title = element_card.get_attribute('title')
                                    # Extract color code from SVG child element
                                    svg_element = element_card.query_selector('path')
                                    color_code = svg_element.get_attribute('fill')
                                    if str(requiredcolor1).lower()==str(color_code.lower()):
                                        Variable_not_resettable.logger.info(f"Title: {str(title)}")
                                        Variable_not_resettable.logger.info(f"Color Code:{str(color_code)}")
                                        Variable_not_resettable.logger.info("Status :Pass")
                                        task_counts+=1
                                    else:
                                        raise Exception
                                except Exception as e:
                                    Variable_not_resettable.logger.info(f"An error occurred:{e}")
                                    raise Exception
                            value=readDatafromExcel(row)
                            first_string = value.split('/')[0]
                            if str(task_counts)==str(first_string):
                                Variable_not_resettable.logger.info("Status:Pass")
                            elif str(first_string)!=str(len(cards1)):
                                Variable_not_resettable.logger.info("Negative Case Colors Exists")
                                raise Exception
                            else:
                                raise Exception
                            row+=1
                        except Exception as e:
                            Variable_not_resettable.logger.info(f"An error occurred:{e}")
                            raise Exception
                except Exception as e:
                    Variable_not_resettable.logger.info(f"An error occurred:{e}")
                    raise Exception
                
            elif (Common_step.Second_Action).lower()=="rgb":
                try:    
                    element = page_object.wait_for_selector(loc_xpath)
                    background_color = element.evaluate('(element) => getComputedStyle(element).getPropertyValue("background-color")')
                    Variable_not_resettable.logger.info(f"Background color: {str(background_color)}")
                    if str(background_color)==str(Common_data.data_value):
                        Variable_not_resettable.logger.info("Status:Pass")
                    else:
                        raise Exception
                except Exception as e:
                    Variable_not_resettable.logger.info(f"An error occurred:{e}")
                    raise Exception
            elif (Common_step.Second_Action).lower()=="specific colour":
                locpath1=Common_controls.control_Value.split(";")[0].strip()
                locpath2=Common_controls.control_Value.split(";")[1].strip()
                locpath3=Common_controls.control_Value.split(";")[2].strip()
                loc_xpath1="//*[@id='"+locpath1+"']"
                container = page_object.wait_for_selector(loc_xpath1)
                cards = container.query_selector_all('//div[@id and contains(@class, "card")]')
                row=0
                for card in cards:   
                    try:
                        Xpath2=locpath2.replace("{iter}", str(row))
                        loc_xpath2="//*[@id='"+Xpath2+"']"# Replace the placeholder with the iteration number
                        # Extract title
                        text_box_data = page_object.locator(loc_xpath2).inner_text()
                        
                        if str(text_box_data)==str(Common_data.data_value1):
                            Xpath3=locpath3.replace("{iter}", str(row))
                            loc_xpath3="//*[@id='"+Xpath3+"']"# Replace the placeholder with the iteration number
                            element = page_object.wait_for_selector(loc_xpath3)
                            # Extract title
                            
                            title = element.get_attribute('title')
                            # Extract color code from SVG child element
                            svg_element = element.query_selector('path')
                            color_code = svg_element.get_attribute('fill')
                            if str(requiredtitle1).lower()==str(title.lower()) and str(requiredcolor1).lower()==str(color_code.lower()):
                                Variable_not_resettable.logger.info(f"Title: {str(title)}")
                                Variable_not_resettable.logger.info(f"Color Code:{str(color_code)}")
                                Variable_not_resettable.logger.info("Status :Pass")
                            else:
                                raise Exception
                        row+=1
                        
                    except Exception as e:
                        Variable_not_resettable.logger.info(f"An error occurred:,{e}")
                        raise Exception
                
        case "SaveData Row Wise":
            try:
                for iter in range(0,int(Common_data.data_value1)):
                    Xpath=loc_xpath.replace("{iter}", str(iter))# Replace the placeholder with the iteration number
                    element = page_object.wait_for_selector(Xpath)
                    page_object.locator(Xpath).scroll_into_view_if_needed(timeout=Common_object.Timeout)
                    text_box_data = page_object.locator(Xpath).inner_text()
                    saveDataToExcel_Screen_Loop(Common_scenario.data_provider_num,text_box_data,iter)

            except Exception as e:
                Variable_not_resettable.logger.info(f"An error occurred: {e}")
                
        case "Assert Icon":
            # Locate the element using XPath
            calendar_icon_element = page_object.query_selector(loc_xpath)
            if calendar_icon_element:
                # Check if the element contains an SVG child element
                svg_child_element = calendar_icon_element.query_selector('svg')
                if svg_child_element:
                    # Get the width and height attributes of the SVG element
                    svg_width = svg_child_element.get_attribute('width')
                    svg_height = svg_child_element.get_attribute('height')
                    # Get the viewBox attribute of the SVG element
                    viewBox = svg_child_element.get_attribute('viewBox')
                        
                    # Check if the viewBox attribute matches the expected value for a calendar icon
                    if str(viewBox) == str(Common_data.data_value):
                        Variable_not_resettable.logger.info("Icon Found")
                    else:
                        Variable_not_resettable.logger.info("This Icon does not match the viewBox attribute of a Assert icon.")
                        raise Exception
                else:
                    Variable_not_resettable.logger.info("This element does not contain a valid SVG child element.")
                    raise Exception
            else:
                Variable_not_resettable.logger.info("Element with the provided XPath not found.")
                raise Exception
        
        case "Dynamic Click Using Data":
            for index,each_data in enumerate(data.split(";"), 1):
                key = "{data"+str(index)+"}"
                loc_xpath = loc_xpath.replace(key, each_data)
                print(f"Final xpath: {loc_xpath}")
            Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")
            for_click_xpath(page_object,loc_xpath)

        case "Round Off":
            
            Round_off_data = round(float(Common_data.data_value1))
            saveDataTo_different_header(Common_scenario.data_provider_num,Round_off_data)

        case "Enter Text Rapids":
            # loc_xpath = Common_controls.control_Value
            # for_click(page_object,loc_xpath)
            # for_fill(page_object,loc_xpath,data)

            loc_xpath = Common_controls.control_Value
            split_data = data.split("|")
            data_for_fill = split_data[0]
            if len(split_data)==2:
                data_to_construct_xpath = split_data[1]
                for index , each_data in enumerate(data_to_construct_xpath.split(";"), 1):
                    key = f":var{index}"
                    loc_xpath = loc_xpath.replace(key, each_data)
                Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")   
            for_fill(page_object, loc_xpath, "")
            for_click(page_object,loc_xpath)
            for_fill(page_object,loc_xpath,data_for_fill)
        
        case "Attach Document Rapids":
            loc_xpath = Common_controls.control_Value
            for_attach(page_object, loc_xpath, data)

        case "Assert Text Rapids":
            loc_xpath = Common_controls.control_Value
            # for_assert_text_combo(page_object, loc_xpath, data)
            page_object.wait_for_selector(loc_xpath, timeout= Common_object.Timeout)
            set_focus_to_element(page_object,loc_xpath)
            text_box_data = page_object.locator(loc_xpath).input_value()
            placeholder_data = page_object.locator(loc_xpath).get_attribute("placeholder")
            Variable_not_resettable.logger.debug(f"text_box_data : {text_box_data}")
            if "Round-off" in Common_step.BASE_ACTION:
                new_data = round(float(data))
                new_text_box_data = round(float(text_box_data))
                if new_data == new_text_box_data:
                    # print("[INFO] : Text is Present")
                    Variable_not_resettable.logger.info("Assert Text Round-off Success for: '" + str(data) +f"', Text in application '{text_box_data}' ")
                else:
                    Common_object.Custom_Error = "Assert Text Round-off Failed for: '" + str(data)+f"' , Text in application '{text_box_data}' "
                    raise Exception(Common_object.Custom_Error)
            else:
                if data == text_box_data:
                    # print("[INFO] : Text is Present")
                    Variable_not_resettable.logger.info("Assert Text Success for: '" + str(data) +f"', Text in application '{text_box_data}' ")
                elif data == placeholder_data:
                    Variable_not_resettable.logger.info("Assert Text Success for: '" + str(data) +f"', Text in application '{placeholder_data}' ")
                else:
                    Common_object.Custom_Error = "Assert Text Failed for: '" + str(data)+f"' , Text in application '{text_box_data}' "
                    raise Exception(Common_object.Custom_Error)
            for_success_snapshot(page_object)
        
        case "Save Data Rapids":
            loc_xpath = Common_controls.control_Value
            # placeholder_data = page_object.locator(loc_xpath).get_attribute("placeholder")
            saveValue = for_get_input_value(page_object, loc_xpath)
            Common_data.data_value = saveValue
            saveDataToExcel(Common_scenario.data_provider_num,saveValue)
            dataexist=checkdataisempty(Common_scenario.data_provider_num,saveValue)
            if dataexist:
                saveValue = for_get_input_value(page_object, loc_xpath)
                Common_data.data_value = saveValue
                saveDataToExcel(Common_scenario.data_provider_num,saveValue)
            Variable_not_resettable.logger.info("Save Data Value" + str(saveValue))

        case "Edit json":
            data = (Common_data.data_value).split("|")
            file_path = data[0]  #filename along with extension
            json_file_path = Common_path.input_document +"/"+file_path
            tag_to_be_edited = data[1]  
            tag_value = data[2] 
            data_ref_to_save = data[3]

            if "EXECUTE" in tag_value:
                generated_tag_value = dataGenerator(tag_value)
            else:
                generated_tag_value = tag_value
            modify_json_tag_single_file(json_file_path,tag_to_be_edited,generated_tag_value)
            Variable_not_resettable.logger.info("Successfully modified")

            Common_data.data_value = generated_tag_value
            Variable_not_resettable.logger.info(f"Modified Value  : {generated_tag_value}")
            Common_step.DATA_REFERENCE = data_ref_to_save
            saveDataToExcel(Common_scenario.data_provider_num,generated_tag_value)
            Variable_not_resettable.logger.info("Successfully saved")

        case "Validate Output Files":
            result_list = deliverables_validation()
            Common_step.skip_redo = True
            result_list = [value.lower() for value in result_list]
            if "false" in result_list:
                Variable_not_resettable.logger.info("Failure in validation")
                raise Exception("Validation failed for the downloaded deliverables")
            else:
                Variable_not_resettable.logger.info("Validation successfull")
        
        case "Copy Files":
            source_folder_path = data.split(";")
            files_in_source = glob.glob(source_folder_path[0])
            if not files_in_source:
                raise FileNotFoundError("No files found in the source directory.")
            latest_file = max(files_in_source, key=os.path.getctime)
            Variable_not_resettable.logger.info(f"Latest file: {latest_file}")
            destination_folder = source_folder_path[1]
            if not os.path.exists(destination_folder):
                os.makedirs(destination_folder)
            destination_file = os.path.join(destination_folder, os.path.basename(latest_file))
            Variable_not_resettable.logger.info(f"Destination file: {destination_file}")

            try:
                shutil.move(latest_file, destination_file)
                Variable_not_resettable.logger.info(f"Successfully moved {latest_file} to {destination_file}")

            except PermissionError as e:
                Variable_not_resettable.logger.info(f"PermissionError: {e}")
                Variable_not_resettable.logger.info("Please check if you have the necessary permissions to access the files and directories.")

            except FileNotFoundError as e:
                Variable_not_resettable.logger.info(f"FileNotFoundError: {e}")
                Variable_not_resettable.logger.info("Please check if the source directory and files exist.")

            except Exception as e:
                Variable_not_resettable.logger.info(f"An unexpected error occurred: {e}")

        case "Page Search for An Element":
            if str(Variable_not_resettable.APP_TYPE).lower() == "rapids":
                try:
                    locpath1=Common_controls.control_Value.split(";")[0].strip()
                    locpath2=Common_controls.control_Value.split(";")[1].strip()
                    atleastclickedonetime=False
                    pagenavigate=False
                    try:
                        for_assert_text_page_navigation(page_object,locpath2, data)  
                    except Exception as notinpageerror:
                        pagenavigate=True
                    while pagenavigate:
                        try:
                            for_click_button(page_object,locpath1)
                            atleastclickedonetime=True
                            Variable_not_resettable.logger.info("Click forward button action completed")
                            try:
                                for_assert_text_page_navigation(page_object,locpath2, data)
                                break
                            except Exception as Asserterror:
                                if Asserterror==Common_object.Custom_Error:
                                    Variable_not_resettable.logger.info("Required Word is not there")
                        except TimeoutError:
                            print("Element is no longer clickable or not found")
                            break
                except Exception as Pagesearcherror:
                    if atleastclickedonetime:
                       raise Exception ("Particular element is not available in search of all pages")
                       Variable_not_resettable.logger.info("Particular element is avaialble in search of all pages")
                    else:
                        Variable_not_resettable.logger.info(str(Pagesearcherror))
                        raise Exception(Pagesearcherror)
                    
        case "Json To Json":
            # Define the source and destination paths
            source_path = Common_data.data_value1.split(";")[0]
            destination_path = Common_data.data_value2.split(";")[0]

            # Define the key mapping
            key_mapping = {
                Common_data.data_value1.split(";")[1]:  Common_data.data_value2.split(";")[1]
            }

            # Map the keys from source to destination
            map_keys(source_path, destination_path, key_mapping)

            # # Define the source and destination paths
            # source_path_value = Common_data.data_value1.split(";")[0]
            # destination_path_value = Common_data.data_value2.split(";")[0]
            # source_path="Downloads//"+source_path_value
            # destination_path="Files//Input_Documents//"+destination_path_value
            # source_path = os.path.join(os.getcwd(),source_path)
            # destination_path=os.path.join(os.getcwd(),destination_path)

            # # Define the key mapping
            # key_mapping = {
            #     Common_data.data_value1.split(";")[1]:  Common_data.data_value2.split(";")[1]
            # }

            # # Map the keys from source to destination
            # map_keys(source_path, destination_path, key_mapping)
    
        case "Response Binding":
            controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
            # print(Common_object.controls_dictionary)
            # for each_control_item in Common_object.controls_dictionary:
            key_for_new_dict = "Element"  # Values of this key will become the new keys
            value_for_new_dict = "Value"
            locators_dictionary = {each_row[key_for_new_dict]: each_row[value_for_new_dict] for each_row in Common_object.controls_dictionary}

            file_path_for_response_binding = os.path.join(Common_path.input_document,data)
            df_response_binding = pd.read_excel(file_path_for_response_binding,sheet_name="Specification", header=None)
            header_row = find_header_row(df_response_binding)
            df = pd.read_excel(file_path_for_response_binding, header=header_row)
            filter_column1 = 'segment'
            unique_values1 = df[filter_column1].unique()
            segment_count_param = 0
            #for segment_value in unique_values1:
            filter_column = 'Array Type'
            unique_values = df[filter_column].unique()
            filtered_dfs = {}
            for value in unique_values:
                filtered_dfs[value] = df[df[filter_column] == value]
            string_df = filtered_dfs['H']
            try:
                Array_df=filtered_dfs['ML']
            except Exception as e:
                Array_df = pd.DataFrame(columns=df.columns)
            parent_page_count = 0
            while True:
                parent_page_count += 1
                try:
                    xpath="//*[@class='table ']//*[@class='table-body ']//*[@data-member='schemaName']"
                    page_object.wait_for_selector(xpath, timeout= 5000)
                    elements = page_object.query_selector_all(xpath)
                    selected_columns = ['SLNo','DATA TYPE','DATA FIELDS','Array Type','segment','parameter','Description','Type']
                    for i, element in enumerate(elements):
                        try:
                            text_in_app = element.inner_text()
                            filter_string_df=string_df[string_df['DATA FIELDS'] == text_in_app]
                            filter_array_df=Array_df[Array_df['DATA TYPE']==text_in_app]
                            if len(filter_string_df)!=0:
                                parametertype="string"
                                result_string_df = filter_string_df[selected_columns]
                                result_string_df.reset_index(drop=True, inplace=True)
                                dfresult_string_df = result_string_df.drop(columns=result_string_df.columns[0])
                                result_dict = result_string_df.iloc[0].to_dict()
                                values_dict = {"DATA_FIELDS" : result_dict["DATA FIELDS"],
                                            "segment" : result_dict["segment"],
                                "parameter" : result_dict["parameter"]}                        
                                updated_locators = update_locators(locators_dictionary, values_dict)
                                for each in updated_locators:
                                    for_click(page_object,updated_locators[each])
                                    time.sleep(0.2)
                                    wait_and_close_popup(page_object)
                            elif len(filter_array_df)!=0:
                                parametertype="array"
                                # print(parametertype)
                                result_array_df = filter_array_df[selected_columns]
                                #print(result_array_df)
                                DATA_TYPE=result_array_df.iloc[0]["DATA TYPE"]
                                upward_arrow = "//div[@data-member='schemaName' and text()=':var1']//..//*[@class='map-icon']"
                                backward_arrow = "//div[@class='text-right col']//..//*[@alt='BackArrow']"
                                updarrow=upward_arrow.replace(":var1",DATA_TYPE)
                                for_click(page_object,updarrow)
                                time.sleep(2)
                                while True:
                                    for i in range(len(result_array_df)):
                                        DATA_TYPE=result_array_df.iloc[i]["DATA TYPE"]
                                        DATA_FIELDS =result_array_df.iloc[i]["DATA FIELDS"]
                                        segment = result_array_df.iloc[i]["segment"]
                                        parameter = result_array_df.iloc[i]["parameter"]
                                        
                                        xpath="//*[@class='table ']//*[@class='table-body ']//*[@data-member='schemaName']"
                                        page_object.wait_for_selector(xpath, timeout= 5000)
                                        elements_array = page_object.query_selector_all(xpath)  
                                        for i, element_arr in enumerate(elements_array):
                                            try:
                                                text_in_app_array = element_arr.inner_text()
                                                if str(DATA_FIELDS)==str(text_in_app_array):
                                                    values_dict_array = {"DATA_FIELDS" : DATA_FIELDS,
                                                                    "segment" : segment,"parameter" : parameter}
                                                    updated_locators_array = update_locators(locators_dictionary, values_dict_array)
                                                    for each_arr in updated_locators_array:
                                                        for_click(page_object,updated_locators_array[each_arr])
                                                        wait_and_close_popup(page_object)
                                                
                                            except Exception as Textmismatch:
                                                Variable_not_resettable.logger.info(Textmismatch)
                                        forward_click="//*[@id='responseBinding-content']//*[text()='>']"
                                    
                                    try:
                                        forward_click="//*[@id='responseBinding-content']//*[text()='>']"
                                        for_click(page_object,forward_click)
                                        wait_and_close_popup(page_object)
                                    except Exception as forwarderror:
                                        Variable_not_resettable.logger.info(forwarderror)
                                        requestfirstpage_button ="//*[@id='responseBinding-content']//*[text()='1']"
                                        for_click(page_object,requestfirstpage_button)
                                        backward_arrow="//div[@class='text-right col']//..//*[@alt='BackArrow']"
                                        for_click(page_object,backward_arrow)
                                        cuurentpage_button =f"//*[@id='responseBinding-content']//*[text()='{parent_page_count}']"
                                        for_click(page_object,cuurentpage_button)
                                        break

                                    #raise Exception
                        except Exception as error:
                            Variable_not_resettable.logger.info(error)
                            raise Exception(error)
                    try:
                        forward_click="//*[@id='responseBinding-content']//*[text()='>']"
                        for_click(page_object,forward_click)
                        wait_and_close_popup(page_object)
                    except Exception as forwarderror:
                        Variable_not_resettable.logger.info(forwarderror)
                        raise Exception
                except Exception as while_forwarderror:
                        Variable_not_resettable.logger.info(while_forwarderror)
                        break
                        raise Exception
        
        case "Parameter Binding":

            controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
            locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}
            file_path_for_parameter_binding = os.path.join(Common_path.input_document,data)
            df_param_binding = pd.read_excel(file_path_for_parameter_binding,sheet_name="Specification", header=None)
            header_row = find_header_row(df_param_binding)
            df = pd.read_excel(file_path_for_parameter_binding,sheet_name="Specification", header=header_row)
            filter_column = 'Array Type'
            unique_values = df[filter_column].unique()
            filtered_dfs = {}
            for value in unique_values:
                filtered_dfs[value] = df[df[filter_column] == value]
            string_df = filtered_dfs['H']
            while True:
                try:
                    xpath="//*[@class='table ']//*[@class='table-body ']//*[@data-member='parameterName']"
                    page_object.wait_for_selector(xpath, timeout= 5000)
                    elements = page_object.query_selector_all(xpath)
                    selected_columns = ['SLNo','DATA TYPE','DATA FIELDS','Array Type','segment','parameter','Description','Type']
                    for i, element in enumerate(elements):
                        try:
                            text_in_app = element.inner_text()
                            filter_string_df=string_df[string_df['DATA FIELDS'] == text_in_app]
                            if len(filter_string_df)!=0:
                                result_string_df = filter_string_df[selected_columns]
                                result_string_df.reset_index(drop=True, inplace=True)
                                dfresult_string_df = result_string_df.drop(columns=result_string_df.columns[0])
                                result_dict = result_string_df.iloc[0].to_dict()
                                values_dict = {"DATA_FIELDS" : result_dict["DATA FIELDS"],
                                            "segment" : result_dict["segment"],
                                "parameter" : result_dict["parameter"]}                        
                                updated_locators = update_locators(locators_dictionary, values_dict)
                                for each in updated_locators:
                                    for_click(page_object,updated_locators[each])
                                    time.sleep(.2)
                                    Variable_not_resettable.logger.info(f"Parameter was mapped")
                                    wait_and_close_popup(page_object)
                                    time.sleep(0.2)
                        except Exception as error:
                            Variable_not_resettable.logger.info(error)
                            raise Exception(error)
                    Variable_not_resettable.logger.info(f"Mapping completed")
                    forward_click="//*[@id='parameterBinding-content']//*[text()='>']"
                    try:
                        for_click(page_object,forward_click)
                        Variable_not_resettable.logger.info(f"Doing Pagination")
                        wait_and_close_popup(page_object)
                    except Exception as forwarderror:
                        Variable_not_resettable.logger.info(forwarderror)
                        raise Exception
                except Exception as while_forwarderror:
                        Variable_not_resettable.logger.info(while_forwarderror)
                        break
                        raise Exception
                
        case "Request Binding":
            # file_path_for_request_binding="D:/Openweb_Git/openwebframework/Files/Input_Documents/TCD-Post-With Details section 1.xlsm"
            file_path_for_request_binding= os.path.join(Common_path.input_document,data)
            df_request_binding = pd.read_excel(file_path_for_request_binding,sheet_name="Specification", header=None)
            header_row = find_header_row(df_request_binding)
            df = pd.read_excel(file_path_for_request_binding,sheet_name="Specification", header=header_row)
            filter_column = 'segment'
            unique_values = df[filter_column].unique()
            filtered_dfs = {}
            segment_count_param = 0
            for segment_value in unique_values:
                data_ml = None
                requestfirstpage_button ="//*[@id='requestBinding-content']//*[text()='1']"
                for_click(page_object,requestfirstpage_button)
                filtered_Segments_df = df[df[filter_column] == segment_value]
                Variable_not_resettable.logger.info("segment_value : ", segment_value)
                segment_combodrop_down="//div[@data-task='segmentNameComboChange']"
                segment_select="//li[@data-task='segmentNameComboChange' and text()='"+segment_value+"']"
                savebutton="//button[@class='btn btn-primary btn-sm d-flex align-items-center position-relative']"
                Variable_not_resettable.logger.info("segment_select : ", segment_select)
                for_click(page_object,segment_combodrop_down)
                time.sleep(1.5)
                for_click(page_object,segment_select)
                time.sleep(5)
                for_click(page_object,savebutton)
                data = None
                break_loop = None
                page_count = 1
                start = True
                requestbindingforwardbutton_outer_count = 0
                while True:
                    column_name = 'parameter'  # replace with your actual column name
                    xpath="//*[@class='table ']//*[@class='table-body ']//*[@data-member='dataitemName']"
                    page_object.wait_for_selector(xpath, timeout= 5000)
                    elements_array = page_object.query_selector_all(xpath)
                    for i, element in enumerate(elements_array):
                        text_in_app = element.inner_text()
                        text_in_app_array = element.inner_text()
                        try:
                            Array_type = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'Array Type'].iloc[0]
                        except Exception as e:
                            Array_type = ''
                        if (Array_type.lower() == 'ml') or (Array_type.lower() == 'h'):
                            if (Array_type.lower() != '' and Array_type.lower() == 'ml') or (Array_type.lower() == 'h'):
                                segment_count_param += 1
                                if (segment_count_param == 1 and Array_type.lower() == 'ml') or (Array_type.lower() == 'h'):
                                    try:
                                        try:
                                            DATA_TYPE = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'DATA TYPE'].iloc[0]
                                            DATA_FIELDS = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'DATA FIELDS'].iloc[0]
                                            segment = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'segment'].iloc[0]
                                            parameter = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'parameter'].iloc[0]
                                            Array_type = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'Array Type'].iloc[0]
                                            api_type = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'IN / OUT'].iloc[0]
                                        except Exception as e:
                                            DATA_TYPE = ''
                                            DATA_FIELDS = ''
                                            segment = ''
                                            parameter = ''
                                            Array_type = ''
                                        requestbindingbackwardbutton1=f"//*[@id='requestBinding-content']//*[text()='{page_count}']"
                                        # for_click(page_object,requestbindingbackwardbutton1)
                                        # time.sleep(1)
                                        if str(parameter)==str(text_in_app):
                                            if str(Array_type).lower()=="ml":
                                                data_type = 'ml' 
                                                paradropdown="//*[@class='table-body ']//div[text()='"+ parameter+"']//..//button[@data-bs-toggle='dropdown']"                     
                                                parameter_elect="//*[@class='table-body ']//*[text()='"+ parameter+"']//..//ul//li[text()='"+DATA_TYPE+"']"
                                                time.sleep(1.5)
                                                for_click(page_object,paradropdown)
                                                time.sleep(1.5)
                                                for_click(page_object,parameter_elect)
                                                checkbox="//*[text()='"+parameter+"']//..//input[@type='checkbox']" 
                                                savebutton="//button[@class='btn btn-primary btn-sm d-flex align-items-center position-relative']"
                                                # checkbox_check(page_object,checkbox)
                                                # # for_click(page_object,checkbox)
                                                # for_click(page_object,savebutton)
                                                # Variable_not_resettable.logger.info(f"Parameter was mapped")
                                                # wait_and_close_popup(page_object)
                                                time.sleep(2)
                                                upward_arrow_for_request_array = "//div[@data-member='dataitemName' and text()='"+parameter+"']//..//*[@class='map-icon']"
                                                for_click(page_object,upward_arrow_for_request_array)
                                                time.sleep(5)
                                                # requestbindingforwardbutton="//*[@id='requestBinding-content']//*[text()='1']"
                                                # for_click(page_object,requestbindingforwardbutton)
                                                page_object.wait_for_selector(xpath, timeout= 5000)
                                                requestbindingforwardbutton_inner_count = 0     
                                                array_complete_lst = []
                                                while True:
                                                    elements_array1 = page_object.query_selector_all(xpath)
                                                    for i, element in enumerate(elements_array1):
                                                        try:
                                                            text_in_app_array = element.inner_text()
                                                            extracted_terms = []
                                                            column_name = 'parameter'  # replace with your actual column name
                                                            DATA_TYPE = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'DATA TYPE'].iloc[0]
                                                            DATA_FIELDS1 = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'DATA FIELDS'].iloc[0]
                                                            segment = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'segment'].iloc[0]
                                                            parameter = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'parameter'].iloc[0]
                                                            Array_type = filtered_Segments_df.loc[filtered_Segments_df[column_name] == text_in_app_array, 'Array Type'].iloc[0]
                                                            if str(parameter)==str(text_in_app_array):
                                                                paradropdown="//*[@class='table-body ']//div[text()='"+parameter+"']//..//button[@data-bs-toggle='dropdown']"                     
                                                                parameter_elect_inner="//*[@class='table-body ']//*[text()='"+parameter+"']//..//ul//li[text()='"+DATA_FIELDS1+"']"
                                                                time.sleep(3)
                                                                for_click(page_object,paradropdown)
                                                                time.sleep(2)
                                                                for_click(page_object,parameter_elect_inner)
                                                                checkbox_check(page_object,checkbox)
                                                                # for_click(page_object,checkbox)
                                                                for_click(page_object,savebutton)
                                                                Variable_not_resettable.logger.info(f"Parameter : {parameter} was mapped")
                                                                wait_and_close_popup(page_object)
                                                                time.sleep(1.5)
                                                                array_complete_lst.append(checkbox)
                                                        except Exception as elementerror:
                                                            pass
                                                    requestbindingforwardbutton="//*[@id='requestBinding-content']//*[text()='>']"
                                                    try:
                                                        requestbindingforwardbutton_inner_count += 1
                                                        Variable_not_resettable.logger.info(f"ML page count,{requestbindingforwardbutton_inner_count}")
                                                        for_click(page_object,savebutton)
                                                        Variable_not_resettable.logger.info(f"Overall save for page")
                                                        wait_and_close_popup(page_object)
                                                        time.sleep(2)
                                                        for_click(page_object,requestbindingforwardbutton)
                                                        Variable_not_resettable.logger.info(f"forward_arrow clicked")
                                                        time.sleep(10)
                                                    except Exception as forwrd_request_array_error:
                                                        Variable_not_resettable.logger.info(forwrd_request_array_error)
                                                        backward_arrow="//div[@class='text-right col']//..//*[@alt='BackArrow']"
                                                        requestbindingbackwardbutton="//*[@id='requestBinding-content']//*[text()='<']"
                                                        requestfirstpage_button ="//*[@id='requestBinding-content']//*[text()='1']"
                                                        for_click(page_object,requestfirstpage_button)
                                                        # for i in range(requestbindingforwardbutton_inner_count):
                                                        #     try:
                                                        #         for_click(page_object,requestbindingbackwardbutton)
                                                        #         time.sleep(2)
                                                        #     except Exception as e:
                                                        #         print(e)
                                                        time.sleep(2)
                                                        for_click(page_object,backward_arrow)
                                                        time.sleep(2)
                                                        Variable_not_resettable.logger.info(f"back_arrow clicked")
                                                        for_click(page_object,savebutton)
                                                        wait_and_close_popup(page_object)
                                                        time.sleep(2)
                                                        data_ml = True
                                                        break
                                                    

                                            elif str(Array_type).lower()=="h" and str(api_type).lower()!= 'out':
                                                data_type = 'h'
                                                paradropdown="//*[@class='table-body ']//div[text()='"+ parameter+"']//..//button[@data-bs-toggle='dropdown']"                     
                                                parameter_elect="//*[@class='table-body ']//*[text()='"+ parameter+"']//..//ul//li[text()='"+DATA_FIELDS+"']"
                                                checkbox="//*[text()='"+parameter+"']//..//input[@type='checkbox']"
                                                savebutton="//button[@class='btn btn-primary btn-sm d-flex align-items-center position-relative']"
                                                time.sleep(1.5)
                                                for_click(page_object,paradropdown)
                                                time.sleep(1.5)
                                                for_click(page_object,parameter_elect)
                                                # for_click(page_object,checkbox)
                                                checkbox_check(page_object,checkbox)
                                                time.sleep(1.5)
                                                for_click(page_object,savebutton)
                                                time.sleep(1.5)
                                                wait_and_close_popup(page_object)
                                                Variable_not_resettable.logger.info(f"save button clicked")
                                    except Exception as error:
                                        Variable_not_resettable.logger.info(error)
                                        break_loop = True
                                        break
                    requestbindingforwardbutton="//*[@id='requestBinding-content']//*[text()='>']"
                    if data_ml == True:
                        print('ML loop completed and exiting the loop')
                        break
                    try:
                        if (break_loop != True and Array_type.lower() != 'ml') or (break_loop != True and Array_type.lower() == 'h'):
                            requestbindingforwardbutton_outer_count += 1
                            print('header page count',requestbindingforwardbutton_outer_count)
                            time.sleep(2)
                            for_click(page_object,requestbindingforwardbutton)
                            page_count += 1
                            time.sleep(2)
                            for_click(page_object,savebutton)
                            wait_and_close_popup(page_object)
                            Variable_not_resettable.logger.info(f"save button clicked")
                            data = True
                            time.sleep(10)
                        else:
                            break
                    except Exception as forwrd_request_array_error:
                        Variable_not_resettable.logger.info(forwrd_request_array_error)
                        backward_arrow="//div[@class='text-right col']//..//*[@alt='BackArrow']"
                        requestbindingbackwardbutton="//*[@id='requestBinding-content']//*[text()='<']"
                        requestfirstpage_button ="//*[@id='requestBinding-content']//*[text()='1']"
                        for_click(page_object,requestfirstpage_button)
                        Variable_not_resettable.logger.info(f"back_arrow clicked")
                        for_click(page_object,savebutton)
                        wait_and_close_popup(page_object)
                        time.sleep(2)
                        break   

        case "Enter Text:Wait:Esc":
            try:
                for_click(page_object,loc_xpath)
                for_fill(page_object,loc_xpath,data)
                time.sleep(int(3))
                page_object.keyboard.press("Escape")
            except Exception as error:
                print(str(error))
                raise Exception (str(error))
                    
        case "Enter Data":
            for_click(page_object,loc_xpath)
            for_fill(page_object,loc_xpath,data)

        case "Click Action":
            page_object.focus(loc_xpath, strict= True, timeout=Common_object.Timeout)
            for_click(page_object,loc_xpath)
            Variable_not_resettable.logger.info("Click Action completed")
            time.sleep(0.2) # More efficient to close pop ups (Getting benefit for please wait and popup)
            #wait_and_close_popup(page_object)

            if "Assert Popup" in str(Common_step.BASE_ACTION) or "Skip Error" in str(Common_step.BASE_ACTION):
                time.sleep(1)

        case "Assert Data":

            if "/|" in data:
                data = data.replace("/|", "~+~")

            if "|" in data:
                xpath_data = data.split("|")[0].strip()
                data = data.split("|")[1].strip()
                data = data.replace("~+~", "|")
                for index , each_data in enumerate(xpath_data.split(";"), 1):
                    key = f":var{index}"
                    loc_xpath = loc_xpath.replace(key, each_data)

            else:
                data = data.replace("~+~", "|")
                for index , each_data in enumerate(data.split(";"), 1):
                    key = f":var{index}"
                    loc_xpath = loc_xpath.replace(key, each_data)

            Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")
            for_assert_data(page_object, loc_xpath, data)
            for_success_snapshot(page_object)

        case "Edit Enter Data":
            for_fill(page_object, loc_xpath, "")
            for_click(page_object,loc_xpath)
            for_fill(page_object, loc_xpath, data)
            time.sleep(1)
            page_object.keyboard.press("Enter")

        case "Assert Radio Button":
            for_assert_radio_button(page_object, loc_xpath, data)

        case "Assert Multi Select Combo":
            assert_multi_select_combo(page_object, loc_xpath, data)
                
        case "Assert Combo Options":
            assert_select_combo_options(page_object, loc_xpath, data)
           
        case "Assert Toggle":
            for_assert_checkbox(page_object, loc_xpath, data)
        
        case "Grid Search Click":
            if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
                try:
                    splitFieldSearchObject_ntimes(Common_data.data_value, Common_controls.control_Value)
                    for_fill(page_object, "//*[@id='"+Wrapper_variables.objectValue+"']" ,Wrapper_variables.dataValue1)
                    page_object.keyboard.press("Enter")
                    wait_unitil_please_wait(page_object, 500)
                    wait_and_close_popup(page_object)
                    grid_element = f"//div[contains(@id, '{Wrapper_variables.objectValue2}')]//*[text()=\"{Wrapper_variables.dataValue1}\"]"
 
                    #grid_element = "//div[contains(@id, '"+Wrapper_variables.objectValue2+"')]//*[text()='"+Wrapper_variables.dataValue1+"']"
                    Variable_not_resettable.logger.info(f"Grid element xpath: {grid_element}")
                    grid_elements = page_object.query_selector_all(grid_element)
                    if len(grid_elements) == 0:
                        time.sleep(2)
                        grid_elements = page_object.query_selector_all(grid_element)
                    for element in grid_elements:
                        element_row = str(element.get_attribute("id")).split("row")[1]
                        break
                    if len(grid_elements) == 0:
                        raise Exception(f"grid_elements not found")
                    custom_id = str(Wrapper_variables.rowinput1)+"row"+str(element_row)
                    assert_grid_cell_xpath = "//*[@id='"+custom_id+"']"

                    page_object.wait_for_selector(assert_grid_cell_xpath, timeout= Common_object.Timeout)
                    page_object.click(assert_grid_cell_xpath, timeout= Common_object.Timeout)

                    Variable_not_resettable.logger.info("Grid element Clicked")
                except Exception as error:
                    Variable_not_resettable.logger.error(str(error))
        
        case "Service Creation":
            controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
            locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}
            file_path_for_service_creation = os.path.join(Common_path.input_document,data)
            service_df = pd.read_excel(file_path_for_service_creation,sheet_name="Service", dtype=str)
            service_dict =  service_df.to_dict("records")
            try:
                locators_data_dict = {"ComponentName" : service_df.iloc[0]['ComponentName'],"DBTransactionType" : service_df.iloc[0]['DBTransactionType']}  
                          
                updated_locators = update_locators(locators_dictionary, locators_data_dict)
                values_dict = {"menu_icon" : "None", 
                        "Services" : "None",
                        "menu_close_icon" : "None",
                        "Component_dropdown" : "None",
                        "Component_value" : "None",
                        "add_service_btn" : "None",
                        "Service_Name" : service_df.iloc[0]['ServiceName'],
                        "Description" : service_df.iloc[0]['ServiceName'],
                        "radio_button" : "None",
                        "save_button_component" : "None",
                        "close_icon_addNewService" : "None"} 
                
                for data, locator in zip(values_dict.values(), updated_locators.values()):
                    for_click(page_object,locator)
                    wait_and_close_popup(page_object)
                    if str(data) != "None":
                        for_fill(page_object,locator,data)
                        wait_and_close_popup(page_object)
                    time.sleep(0.2)

                Variable_not_resettable.logger.info(f"Service creation completed")
            except Exception as error:
                    Variable_not_resettable.logger.info(error)
                    raise Exception (str(error))
                
        case "Segment Creation":
            try:
                file_path_for_segment_creation = os.path.join(Common_path.input_document,data)
                service_df = pd.read_excel(file_path_for_segment_creation,sheet_name="Service")
                controlSheet_dictionary(Common_step.CONTROL_FILE,sheet_name="Upto_service")
                locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}
                locators_data_dict = {"ComponentName" : service_df.iloc[0]['ComponentName'],"ServiceName" : service_df.iloc[0]['ServiceName']}  

                updated_locators = update_locators(locators_dictionary, locators_data_dict)
                values_dict = {"menu_icon": "None",
                            "Services" :"None",
                            "menu_close_icon" : "None",
                            "Component_dropdown" : "None",
                            "Component_value" : "None",                      
                            "service_name_loc" : service_df.iloc[0]['ServiceName'],
                            "apply_loc" : "None",                       
                            "Design_service_based_on_service" : "None"}

                for data, locator in zip(values_dict.values(), updated_locators.values()):
                    for_click(page_object,locator)
                    wait_and_close_popup(page_object)
                    if str(data) != "None":
                        for_fill(page_object,locator,data)
                        wait_and_close_popup(page_object)
                    time.sleep(0.2)
                Variable_not_resettable.logger.info(f"Design Service Screen")
                controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
                locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}
                # file_path_for_segment_creation = os.path.join(Common_path.input_document,data)
                # Service_df = pd.read_excel(file_path_for_segment_creation,sheet_name="Service")
                filter_column = 'SegmentName'
                unique_values = service_df[filter_column].unique()
                keys = ['Instance', 'SegmentName'] 
                result_list = []
                for value in unique_values:
                    row = service_df[service_df[filter_column] == value].iloc[0]
                    row_dict = {key: row[key] for key in keys if key in row}
                    result_list.append(row_dict)

                for each_item in result_list:
                    try:             
                        updated_locators = update_locators(locators_dictionary, each_item)
                        data_values = ["None","None", each_item["SegmentName"], each_item["SegmentName"], "None" ,"None", "None","None"]
                        dict_keys = list(updated_locators.keys())
                        for list_item, dict_key in zip(data_values, dict_keys):
                            locator = updated_locators[dict_key]
                            for_click(page_object,locator)
                            wait_and_close_popup(page_object)
                            if str(list_item) != "None":
                                for_fill(page_object,locator,list_item)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)

                        Variable_not_resettable.logger.info(f"Segment creation completed")
                    except Exception as error2:
                            Variable_not_resettable.logger.info(error2)
                            raise Exception
                    
            except Exception as error1:
                Variable_not_resettable.logger.info(error1)
                raise Exception
            
        case "Dataitem Creation":
            file_path_for_segment_creation = os.path.join(Common_path.input_document,data)
            service_df = pd.read_excel(file_path_for_segment_creation,sheet_name="Service", dtype=str)
            data_dict =  service_df.to_dict("records")
            controlSheet_dictionary(Common_step.CONTROL_FILE,sheet_name="Upto_service")
            locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}
            locators_data_dict = {"ComponentName" : service_df.iloc[0]['ComponentName'],"ServiceName" : service_df.iloc[0]['ServiceName']}  
            updated_locators = update_locators(locators_dictionary, locators_data_dict)
            values_dict = {"menu_icon": "None",
                        "Services" :"None",
                        "menu_close_icon" : "None",
                        "Component_dropdown" : "None",
                        "Component_value" : "None",                      
                        "service_name_loc" : service_df.iloc[0]['ServiceName'],
                        "apply_loc" : "None",                       
                        "Design_service_based_on_service" : "None"}

            for data, locator in zip(values_dict.values(), updated_locators.values()):
                for_click(page_object,locator)
                wait_and_close_popup(page_object)
                if str(data) != "None":
                    for_fill(page_object,locator,data)
                    wait_and_close_popup(page_object)
                time.sleep(0.2)
            Variable_not_resettable.logger.info(f"Design Service Screen")
            controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
            locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}
            for each_item in data_dict :
                try:             
                    updated_locators = update_locators(locators_dictionary, each_item)
                    data_values = {"DataItems Tab":"None","Segment Name dropdown":"None","Segment Name Value selection":"None","Add Dataitem" :"None" ,"NameTextadd" : each_item["parameterName"],
                                   "Flow Attribute dropdown" : "None","Flow Attribute value" : "None","Buisness tick" : "None","Search business by text" : each_item["BT"],
                                       "Search business" : "None","Select buisness" : "None","Data Item Save" : "None","Closeicon New Dataitem" : "None"}
                    # dict_keys = list(updated_locators.keys())
                    for data, locator in zip(data_values.values(), updated_locators.values()):
                        # locator = updated_locators[dict_key]
                        for_click(page_object,locator)
                        wait_and_close_popup(page_object)
                        if str(data) != "None":
                            for_fill(page_object,locator,data)
                            wait_and_close_popup(page_object)
                        time.sleep(0.5)

                    Variable_not_resettable.logger.info(f"Dataitem creation completed")
                except Exception as while_forwarderror:
                        Variable_not_resettable.logger.info(while_forwarderror)
                        raise Exception

        case "Create Service Method":
            try:
                Variable_not_resettable.logger.info("Create Service Method- Intiated")
                controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
                locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}
                file_path_for_method_creation = os.path.join(Common_path.input_document,data)
                df= pd.read_excel(file_path_for_method_creation,sheet_name="Method")
                # data_dict =  data_df.to_dict("records")
                menu_loc=locators_dictionary['Sidemenu_loc']
                servicestab_loc=locators_dictionary['Services_Tab_loc']
                menuclose_loc=locators_dictionary['Sidemenu_close_loc']
                servicemethod_hyperlink_loc=locators_dictionary['Servicemethods_hyperlink_loc']
                for_click(page_object,menu_loc)
                wait_and_close_popup(page_object)
                for_click(page_object,servicestab_loc)
                wait_and_close_popup(page_object)
                for_click(page_object,menuclose_loc)
                wait_and_close_popup(page_object)
                for_click(page_object,servicemethod_hyperlink_loc)
                wait_and_close_popup(page_object)
                filter_column1 = 'MethodName'
                unique_methodname = df[filter_column1].unique()
                try:
                    for value in unique_methodname:
                        filtered_method_df = df[df[filter_column1] == value]
                        method_name_data=filtered_method_df['MethodName'].iloc[0]
                        sp_name_data=filtered_method_df['SP_Name'].iloc[0]
                        op_type_data=filtered_method_df['Operation_Type'].iloc[0].lower()
                        method_type_data=filtered_method_df['Method_Type'].iloc[0].lower()
                        create_method_button=locators_dictionary['Create_service_method_loc']
                        method_name_field=locators_dictionary['Method_name_loc']
                        desc_field=locators_dictionary['Method_description_loc']
                        op_type=locators_dictionary['Operation_type_loc'].format(Operation_Type=op_type_data)
                        method_type=locators_dictionary['Method_type_loc'].format(Method_Type=method_type_data)
                        sp_name_loc=locators_dictionary['Sp_name_loc']
                        save_btn=locators_dictionary['Method_save_loc']
                        close_btn=locators_dictionary['Method_close_loc']
                        for_click(page_object,create_method_button)
                        wait_and_close_popup(page_object)
                        time.sleep(0.2)
                        for_fill(page_object,method_name_field,method_name_data)
                        time.sleep(0.2)
                        for_fill(page_object,desc_field,method_name_data)
                        time.sleep(0.2)
                        for_click(page_object,op_type)
                        wait_and_close_popup(page_object)
                        time.sleep(0.2)
                        for_click(page_object,method_type)
                        wait_and_close_popup(page_object)
                        time.sleep(0.2)
                        for_fill(page_object,sp_name_loc,"")
                        time.sleep(0.2)
                        for_fill(page_object,sp_name_loc,sp_name_data)
                        time.sleep(0.2)
                        for_click(page_object,save_btn)
                        wait_and_close_popup(page_object)
                        time.sleep(0.2)
                        for_click(page_object,close_btn)
                        wait_and_close_popup(page_object)
                        time.sleep(0.2)
                        Variable_not_resettable.logger.info(f"Method '{method_name_data}' created")
                    Variable_not_resettable.logger.info("Service Method Creation completed.")
                except Exception as error:
                    Variable_not_resettable.logger.info(error)
                    raise Exception
            except Exception as error:
                    Variable_not_resettable.logger.info(error)
                    raise Exception
            
            
            
        case "Create Service Method Params":
            try:
                Variable_not_resettable.logger.info("Create Service Method Params - Initiated")
                controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
                locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}
                file_path_for_method_creation = os.path.join(Common_path.input_document,data)
                df = pd.read_excel(file_path_for_method_creation,sheet_name="Method")
                menu_loc=locators_dictionary['Sidemenu_loc']
                servicestab_loc=locators_dictionary['Services_Tab_loc']
                menuclose_loc=locators_dictionary['Sidemenu_close_loc']
                servicemethod_hyperlink_loc=locators_dictionary['Servicemethods_hyperlink_loc']
                for_click(page_object,menu_loc)
                wait_and_close_popup(page_object)
                Variable_not_resettable.logger.info("Menu is clicked")
                time.sleep(0.2)
                for_click(page_object,servicestab_loc)
                wait_and_close_popup(page_object)
                Variable_not_resettable.logger.info("Services sideicon is clicked")
                time.sleep(0.2)
                for_click(page_object,menuclose_loc)
                wait_and_close_popup(page_object)
                Variable_not_resettable.logger.info("Menu close is clicked")
                time.sleep(0.2)
                for_click(page_object,servicemethod_hyperlink_loc)
                wait_and_close_popup(page_object)
                Variable_not_resettable.logger.info("Service Method Hyperlink clicked")
                time.sleep(0.2)
                filter_column1 = 'MethodName'
                filter_column2 = "In_Out"
                unique_methodname = df[filter_column1].unique()
                try:
                    for value in unique_methodname:
                        filtered_method_df = df[df[filter_column1] == value]
                        op_type_data=filtered_method_df['Operation_Type'].iloc[0].lower()
                        method_type_data=filtered_method_df['Method_Type'].iloc[0].lower()
                        method_name_search_loc = locators_dictionary['Method_name_search_loc']
                        apply_btn_loc=locators_dictionary['Apply_btn_loc']
                        Optype_setting_loc=locators_dictionary['Optype_setting_loc'].format(Operation_Type=op_type_data)
                        Methodtype_setting_loc=locators_dictionary['Methodtype_setting_loc'].format(Method_Type=method_type_data)
                        Design_dots=locators_dictionary['Method_design_dots'].format(MethodName=value)
                        for_click(page_object,Methodtype_setting_loc)
                        wait_and_close_popup(page_object)
                        Variable_not_resettable.logger.info("Method type filter clicked")
                        time.sleep(0.2)
                        for_click(page_object,Optype_setting_loc)
                        wait_and_close_popup(page_object)
                        Variable_not_resettable.logger.info("Operation type filter clicked")
                        time.sleep(0.2)
                        for_fill(page_object,method_name_search_loc,value)
                        time.sleep(0.2)
                        for_click(page_object,apply_btn_loc)
                        wait_and_close_popup(page_object)
                        Variable_not_resettable.logger.info("Method name is searched")
                        time.sleep(0.2)
                        for_click(page_object,Design_dots)
                        wait_and_close_popup(page_object)
                        Variable_not_resettable.logger.info("Method design dots is clicked")
                        time.sleep(0.2)      
                        in_rows = []
                        out_rows = []
                        for index, row in filtered_method_df.iterrows():
                            if row[filter_column2] == 'IN' or row[filter_column2] == 'IN/OUT':
                                in_rows.append(row)
                            elif row[filter_column2] == 'OUT':
                                out_rows.append(row)
                        In_df = pd.DataFrame(in_rows)
                        Out_df = pd.DataFrame(out_rows)
                        include_contextparam=locators_dictionary['Include_context_parameter']
                        for_click(page_object,include_contextparam)
                        wait_and_close_popup(page_object)
                        Variable_not_resettable.logger.info("Include Context Parameter checkbox clicked")
                        time.sleep(0.2)
                        if not In_df.empty:
                            Variable_not_resettable.logger.info("IN  Method Params Creation started")
                            for index, row in In_df.iterrows():
                                parameter_name_data = row['parameterName']
                                seqno_data = row['ParameterSequence_No']
                                flow_direction_data = row['In_Out']
                                bt_name_data = row['BT']
                                add_parameter=locators_dictionary['Method_addinparam_loc']
                                seqno_loc=locators_dictionary['Method_inparamseqno_loc']
                                param_loc=locators_dictionary['Method_inparamname_loc']
                                flow_loc=locators_dictionary['Method_inparamflow_dropdown_loc']
                                flow_loc1=locators_dictionary['Method_inparamflow_option_loc'].format(In_Out=flow_direction_data)
                                tick_loc=locators_dictionary['Method_inparambt_tick_loc']
                                bt_loc=locators_dictionary['Method_inparambt_loc']
                                search_loc=locators_dictionary['Method_inparambt_search_loc']
                                select_loc=locators_dictionary['Method_inparambt_select_loc'].format(BT=bt_name_data)
                                save_loc=locators_dictionary['Method_inparam_save_loc']
                                wait_and_close_popup(page_object)
                                close_loc=locators_dictionary['Method_inparam_close_loc']
                                #Adding parameter actions
                                for_click(page_object,add_parameter)
                                wait_and_close_popup(page_object)
                                Variable_not_resettable.logger.info("Add parameter button clicked")
                                time.sleep(0.2) 
                                for_fill(page_object,seqno_loc,seqno_data)
                                Variable_not_resettable.logger.info("Seq no is entered")
                                time.sleep(0.2) 
                                for_fill(page_object,param_loc,parameter_name_data)
                                Variable_not_resettable.logger.info("IN Parameter name is entered")
                                time.sleep(0.2) 
                                for_click(page_object,flow_loc)
                                wait_and_close_popup(page_object)
                                for_click(page_object,flow_loc1)
                                wait_and_close_popup(page_object)
                                Variable_not_resettable.logger.info("Flow direction chosen")
                                time.sleep(0.2)
                                for_click(page_object,tick_loc)
                                wait_and_close_popup(page_object)  
                                for_fill(page_object,bt_loc,bt_name_data)
                                for_click(page_object,search_loc)
                                wait_and_close_popup(page_object)
                                Variable_not_resettable.logger.info("BT name searched")
                                time.sleep(0.2)
                                for_click(page_object,select_loc)
                                wait_and_close_popup(page_object)
                                Variable_not_resettable.logger.info(f"BT name '{select_loc}' chosen")
                                time.sleep(0.2)
                                for_click(page_object,save_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                for_click(page_object,close_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                Variable_not_resettable.logger.info(f"Parameter name '{parameter_name_data}' created")
                            Variable_not_resettable.logger.info("IN Service method params creation completed")
                        else:
                            Variable_not_resettable.logger.info("No IN Service Method Parameters")
                            pass
                        if not Out_df.empty:
                            Variable_not_resettable.logger.info("OUT Method Params Creation started")
                            result_tab_loc=locators_dictionary['Method_rstab_loc']
                            for_click(page_object,result_tab_loc)
                            wait_and_close_popup(page_object)
                            filter_column3="ResultSetName"
                            unique_resultsetname = Out_df[filter_column3].unique()
                            for value in unique_resultsetname:
                                filtered_resultset_outdf = Out_df[Out_df[filter_column3] == value]
                                rsseqno_data=filtered_resultset_outdf["ResultSetSequence_No"].iloc[0]
                                rsname_data=filtered_resultset_outdf["ResultSetName"].iloc[0]
                                rsinstance_data=filtered_resultset_outdf["Instance"].iloc[0]
                                rsadd_loc=locators_dictionary['Method_rsadd_loc']
                                rsseqno_loc=locators_dictionary['Method_rsseqno_loc']
                                rsname_loc=locators_dictionary['Method_rsname_loc']
                                instance_loc=locators_dictionary['Method_rsinstance_dropdown_loc']
                                instance_loc1=locators_dictionary['Method_rsinstance_option_loc'].format(Instance=rsinstance_data)
                                rssave_loc=locators_dictionary['Method_rs_save_loc']
                                rsclose_loc=locators_dictionary['Method_rs_close_loc']
                                for_click(page_object,rsadd_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                Variable_not_resettable.logger.info("Add resultset is clicked")
                                for_fill(page_object,rsseqno_loc,rsseqno_data)
                                time.sleep(0.2)
                                Variable_not_resettable.logger.info("seqno is clicked")
                                for_fill(page_object,rsname_loc,rsname_data)
                                time.sleep(0.2)
                                Variable_not_resettable.logger.info("resultsetname is clicked")
                                for_click(page_object,instance_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                for_click(page_object,instance_loc1)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                Variable_not_resettable.logger.info("Instance is chosen")
                                for_click(page_object,rssave_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                for_click(page_object,rsclose_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                Variable_not_resettable.logger.info(f"Resultset '{rsname_data}' created")

                            Variable_not_resettable.logger.info("Resultset creation completed")
                            rsparamtab_loc=locators_dictionary['Method_rsparamtab_loc']
                            for_click(page_object,rsparamtab_loc)
                            wait_and_close_popup(page_object)
                            for value in unique_resultsetname:
                                filtered_resultset_outdf = Out_df[Out_df[filter_column3] == value]
                                _loc1=locators_dictionary['Method_rsparam_rs_dropdown_loc']
                                _loc2=locators_dictionary['Method_rsparam_rs_option_loc'].format(ResultSetName=value)
                                for_click(page_object,_loc1)
                                wait_and_close_popup(page_object)
                                for_click(page_object,_loc2)
                                wait_and_close_popup(page_object)
                                for index, row in filtered_resultset_outdf.iterrows():
                                    paramname_data1=row['parameterName']
                                    bt_data1=row['BT']
                                    _loc3=locators_dictionary['Method_rsparamadd_loc']
                                    _loc4=locators_dictionary['Method_rsparamname_loc']
                                    _loc5=locators_dictionary['Method_rsparambt_tick_loc']
                                    _loc6=locators_dictionary['Method_rsparambt_loc']
                                    _loc7=locators_dictionary['Method_rsparambt_search_loc']
                                    _loc8=locators_dictionary['Method_rsparambt_select_loc'].format(BT=bt_data1)
                                    _loc9=locators_dictionary['Method_rsparam_save_loc']
                                    _loc10=locators_dictionary['Method_rsparam_close_loc']
                                    for_click(page_object,_loc3)
                                    wait_and_close_popup(page_object)
                                    time.sleep(0.2)
                                    Variable_not_resettable.logger.info("Add Resultsetparam button clicked")
                                    for_fill(page_object,_loc4,paramname_data1)
                                    Variable_not_resettable.logger.info("Out param name entered")
                                    time.sleep(0.2)
                                    for_click(page_object,_loc5)
                                    wait_and_close_popup(page_object)
                                    time.sleep(0.2)
                                    for_fill(page_object,_loc6,bt_data1)
                                    time.sleep(0.2)
                                    for_click(page_object,_loc7)
                                    wait_and_close_popup(page_object)
                                    time.sleep(0.2)
                                    Variable_not_resettable.logger.info("BT is searched")
                                    for_click(page_object,_loc8)
                                    wait_and_close_popup(page_object)
                                    time.sleep(0.2)
                                    Variable_not_resettable.logger.info(f"BT '{bt_data1}' is chosen")
                                    for_click(page_object,_loc9)
                                    wait_and_close_popup(page_object)
                                    time.sleep(0.2)
                                    for_click(page_object,_loc10)
                                    wait_and_close_popup(page_object)
                                    time.sleep(0.2)
                                    Variable_not_resettable.logger.info(f"OUT param '{paramname_data1}' is created")
                            Variable_not_resettable.logger.info("OUT Method params creation completed")
                        else:
                            Variable_not_resettable.logger.info("No OUT Service Method Parameters")
                            pass
                        sidemenu_loc=locators_dictionary['Sidemenu_loc']
                        services_loc=locators_dictionary['Services_Tab_loc']
                        side_close_loc=locators_dictionary['Sidemenu_close_loc']
                        method_link_loc=locators_dictionary['Servicemethods_hyperlink_loc']
                        for_click(page_object, sidemenu_loc)
                        wait_and_close_popup(page_object)
                        time.sleep(0.2)
                        for_click(page_object,services_loc)
                        wait_and_close_popup(page_object)
                        time.sleep(0.2)
                        for_click(page_object,side_close_loc)
                        wait_and_close_popup(page_object)
                        time.sleep(0.2)
                        for_click(page_object,method_link_loc)
                        wait_and_close_popup(page_object)
                        time.sleep(0.2)
                        Variable_not_resettable.logger.info("Methods hyperlink clicked")       

                
                except Exception as e:
                    Variable_not_resettable.logger.info(e)
                    raise e
            except Exception as e:
                    Variable_not_resettable.logger.info(e)
                    raise e

                
        case "Create Process Section":
            try:
                Variable_not_resettable.logger.info("Create Process Section - Initiated")
                controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
                locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}
                file_path_for_processsection_creation = os.path.join(Common_path.input_document,data)
                df= pd.read_excel(file_path_for_processsection_creation,sheet_name="ProcessSectionName")
                filter_column1 = 'ProcessSectionName'
                filter_column2='ServiceName'
                unique_sectionname = df[filter_column1].unique()
                unique_servicename = df[filter_column1].unique()
                comp_name_data=df['ComponentName'].iloc[0]
                service_name_data=df['ServiceName'].iloc[0]
                comp_drpdown_loc=locators_dictionary['Service_component_dropdown_loc']
                comp_option_loc=locators_dictionary['Service_component_option_loc'].format(ComponentName=comp_name_data)
                service_name_loc=locators_dictionary['Service_namesearch_loc']
                apply_loc=locators_dictionary['Service_apply_loc']
                design_loc=locators_dictionary['Service_design_dots'].format(ServiceName=service_name_data)
                menu_loc=locators_dictionary['Sidemenu_loc']
                servicestab_loc=locators_dictionary['Services_Tab_loc']
                menuclose_loc=locators_dictionary['Sidemenu_close_loc']
                for_click(page_object,menu_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Menu is clicked")
                for_click(page_object,servicestab_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Services sideicon is clicked")
                for_click(page_object,menuclose_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Services sideicon is clicked")
                for_click(page_object,comp_drpdown_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                for_click(page_object,comp_option_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Component dropdown is chosen")
                for_fill(page_object,service_name_loc,service_name_data)
                time.sleep(0.2)
                for_click(page_object,apply_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Service is searched")
                for_click(page_object,design_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Design Service dots are clicked")
                try:
                    for value in unique_sectionname:
                        filtered_processsection_df = df[df[filter_column1] == value]
                        sqno_data=filtered_processsection_df['ProcessSectionSeqNo'].iloc[0]
                        sectionname_data=filtered_processsection_df['ProcessSectionName'].iloc[0]
                        add_section_loc=locators_dictionary['ProcessSection_add_loc']
                        seqno_loc=locators_dictionary['ProcessSection_seqno_loc']
                        sectionname_loc=locators_dictionary['ProcessSection_name_loc']
                        sectiondesc_loc=locators_dictionary['ProcessSection_desc_loc']
                        save_loc=locators_dictionary['ProcessSection_save_loc']
                        close_loc=locators_dictionary['ProcessSection_close_loc']
                        for_click(page_object,add_section_loc)
                        wait_and_close_popup(page_object)
                        for_fill(page_object,seqno_loc,sqno_data)
                        for_fill(page_object,sectionname_loc,sectionname_data)
                        for_fill(page_object,sectiondesc_loc,sectionname_data)
                        for_click(page_object,save_loc)
                        wait_and_close_popup(page_object)
                        for_click(page_object,close_loc)
                        wait_and_close_popup(page_object)
                    Variable_not_resettable.logger.info(f"Process section :{value} is created")
                except Exception as error:
                    Variable_not_resettable.logger.info(error)
                    raise error
            except Exception as error:
                    Variable_not_resettable.logger.info(error)
                    raise error
        

        case "Create Statements":
            try:
                Variable_not_resettable.logger.info("Create Statements - Initiated")
                controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
                locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}
                file_path_for_processsection_creation = os.path.join(Common_path.input_document,data)
                df= pd.read_excel(file_path_for_processsection_creation,sheet_name="ProcessSectionName")
                filter_column1 = 'ProcessSectionName'
                unique_sectionname = df[filter_column1].unique()
                menu_loc=locators_dictionary['Sidemenu_loc']
                servicestab_loc=locators_dictionary['Services_Tab_loc']
                menuclose_loc=locators_dictionary['Sidemenu_close_loc']
                comp_name_data=df['ComponentName'].iloc[0]
                service_name_data=df['ServiceName'].iloc[0]
                comp_drpdown_loc=locators_dictionary['Service_component_dropdown_loc']
                comp_option_loc=locators_dictionary['Service_component_option_loc'].format(ComponentName=comp_name_data)
                service_name_loc=locators_dictionary['Service_namesearch_loc']
                apply_loc=locators_dictionary['Service_apply_loc']
                design_loc=locators_dictionary['Service_design_dots'].format(ServiceName=service_name_data)
                for_click(page_object,menu_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Menu is clicked")
                for_click(page_object,servicestab_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Services sideicon is clicked")
                for_click(page_object,menuclose_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Menu close is clicked")
                for_click(page_object,comp_drpdown_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                for_click(page_object,comp_option_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Component dropdown is chosen")
                for_fill(page_object,service_name_loc,service_name_data)
                time.sleep(0.2)
                for_click(page_object,apply_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Service is searched")
                for_click(page_object,design_loc)
                wait_and_close_popup(page_object)
                time.sleep(0.2)
                Variable_not_resettable.logger.info("Design Service dots are clicked")
                try:
                    for value in unique_sectionname:
                        Variable_not_resettable.logger.info(f"Process section :{value}")
                        filtered_processsection_df = df[df[filter_column1] == value]
                        sectionname_data=filtered_processsection_df['ProcessSectionName'].iloc[0]
                        add_icon_loc=locators_dictionary['Processsection_addstmnt_loc'].format(ProcessSectionName=sectionname_data)
                        for_click(page_object,add_icon_loc)
                        wait_and_close_popup(page_object)
                        time.sleep(0.2)
                        Variable_not_resettable.logger.info(f"Process section :{sectionname_data} is clicked")
                        filter_column2 = 'ProcessSectionName'
                        for index, row in filtered_processsection_df.iterrows():
                            seqno_data = row['StatementSeqNo']
                            stmnt_id_data=row['StatementID']
                            parentstmnt_id_data=row['ParentStatementID']
                            stmnt_type_data=row['StatementType']
                            methodname_data=row['MethodName']
                            loopsegment_data=row['LoopSegment']
                            add_stmnt_loc=locators_dictionary['Statement_add_loc']
                            seqno_loc=locators_dictionary['Statement_seqno_loc']
                            stmntid_loc=locators_dictionary['Statement_id_loc']
                            stmnttype_drpdown_loc=locators_dictionary['Statement_type_dropdown_loc']
                            stmnttype_option_loc=locators_dictionary['Statement_type_option_loc'].format(StatementType=stmnt_type_data)
                            method_drpdown_loc=locators_dictionary['Statement_method_dropdown_loc']
                            method_option_loc=locators_dictionary['Statement_method_option_loc'].format(MethodName=methodname_data)
                            segment_drpdown_loc=locators_dictionary['Statement_segment_dropdown_loc']
                            segment_option_loc=locators_dictionary['Statement_segment_option_loc'].format(LoopSegment=loopsegment_data)
                            parentstmnt_drpdown_loc=locators_dictionary['Statement_parentid_dropdown_loc']
                            parentstmnt_option_loc=locators_dictionary['Statement_parentid_option_loc'].format(ParentStatementID=parentstmnt_id_data)
                            save_loc=locators_dictionary['Statement_save_loc']
                            close_loc=locators_dictionary['Statement_close_loc']
                            back_loc=locators_dictionary['Statement_back_loc']
                            for_click(page_object,add_stmnt_loc)
                            wait_and_close_popup(page_object)
                            time.sleep(0.2)
                            Variable_not_resettable.logger.info("Add statement icon is clicked")
                            for_fill(page_object,seqno_loc,seqno_data)
                            time.sleep(0.2)
                            Variable_not_resettable.logger.info("Seq No is enetered")
                            for_fill(page_object,stmntid_loc,stmnt_id_data)
                            time.sleep(0.2)
                            Variable_not_resettable.logger.info(f"Statement id '{stmnt_id_data}'  is entered")
                            if row['StatementType']=="Execute Method":
                                Variable_not_resettable.logger.info(f"Statementtype : {row['StatementType']}")
                                for_click(page_object,stmnttype_drpdown_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                for_click(page_object,stmnttype_option_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                Variable_not_resettable.logger.info("Statementtype dropdown is chosen")                             
                                if row['ParentStatementID']=="" or pd.isna(row['ParentStatementID']):
                                    pass
                                else:
                                    for_click(page_object,parentstmnt_drpdown_loc)
                                    wait_and_close_popup(page_object)
                                    time.sleep(0.2)
                                    for_click(page_object,parentstmnt_option_loc)
                                    wait_and_close_popup(page_object)
                                    time.sleep(0.2)
                                    Variable_not_resettable.logger.info(f"Parent statement dropdown is chosen : '{parentstmnt_option_loc}' ")
                                for_click(page_object,method_drpdown_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                for_click(page_object,method_option_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                Variable_not_resettable.logger.info("Method dropdown is chosen")
                            elif row['StatementType']=="ForEach":
                                Variable_not_resettable.logger.info(f"Statementtype : {row['StatementType']}")
                                for_click(page_object,stmnttype_drpdown_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                for_click(page_object,stmnttype_option_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                Variable_not_resettable.logger.info("Statementtype dropdown is chosen")
                                for_click(page_object,segment_drpdown_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                for_click(page_object,segment_option_loc)
                                wait_and_close_popup(page_object)
                                time.sleep(0.2)
                                Variable_not_resettable.logger.info("Segment dropdown is chosen")   
                            else:
                                Variable_not_resettable.logger.info("Statement type did not match")
                                pass
                            for_click(page_object,save_loc)
                            wait_and_close_popup(page_object)
                            time.sleep(0.2)
                            Variable_not_resettable.logger.info("Save clicked")
                            for_click(page_object,close_loc)
                            wait_and_close_popup(page_object)
                            time.sleep(0.2)
                            #Adding below because of parent statement bug
                            for_click(page_object,menu_loc)
                            wait_and_close_popup(page_object)
                            time.sleep(0.2)
                            Variable_not_resettable.logger.info("Menu is clicked")
                            for_click(page_object,servicestab_loc)
                            wait_and_close_popup(page_object)
                            time.sleep(0.2)
                            Variable_not_resettable.logger.info("Services sideicon is clicked")
                            for_click(page_object,menuclose_loc)
                            wait_and_close_popup(page_object)
                            time.sleep(0.2)
                            Variable_not_resettable.logger.info("Menu close is clicked")
                            for_click(page_object,comp_drpdown_loc)
                            wait_and_close_popup(page_object)
                            time.sleep(0.2)
                            for_click(page_object,comp_option_loc)
                            wait_and_close_popup(page_object)
                            Variable_not_resettable.logger.info("Component dropdown is chosen")
                            time.sleep(0.2)
                            for_fill(page_object,service_name_loc,service_name_data)
                            time.sleep(0.2)
                            for_click(page_object,apply_loc)
                            wait_and_close_popup(page_object)
                            time.sleep(0.2)
                            Variable_not_resettable.logger.info("Service is searched")
                            time.sleep(0.2)
                            for_click(page_object,design_loc)
                            wait_and_close_popup(page_object)
                            time.sleep(0.2)
                            Variable_not_resettable.logger.info("Design Service dots are clicked")
                            for_click(page_object,add_icon_loc)
                            wait_and_close_popup(page_object)
                            time.sleep(0.2)
                        Variable_not_resettable.logger.info(f"Statement id '{stmnt_id_data}' is created successfully")

                except Exception as e:
                    Variable_not_resettable.logger.info(e)
                    raise e
            except Exception as e:
                Variable_not_resettable.logger.info(e)
                raise e


        case "Service Method Mapping":
            # controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
            controlSheet_dictionary(Common_step.CONTROL_FILE, Common_step.CONTROL_SHEET)
            locators_dictionary = {each_row["Element"]: each_row["Value"] for each_row in Common_object.controls_dictionary}   
            file_path_for_processsection_creation = os.path.join(Common_path.input_document,data)
            data_df_ProcessSectionName = pd.read_excel(file_path_for_processsection_creation,sheet_name="ProcessSectionName", dtype=str)
            data_dict_ProcessSectionName =  data_df_ProcessSectionName.to_dict("records")
            comp_name_data= data_df_ProcessSectionName ['ComponentName'].iloc[0]
            service_name_data= data_df_ProcessSectionName ['ServiceName'].iloc[0]
            menu_loc=locators_dictionary['Sidemenu_loc']
            servicestab_loc=locators_dictionary['Services_Tab_loc']
            menuclose_loc=locators_dictionary['Sidemenu_close_loc']
            for_click(page_object,menu_loc)
            wait_and_close_popup(page_object)
            for_click(page_object,servicestab_loc)
            wait_and_close_popup(page_object)
            for_click(page_object,menuclose_loc)
            wait_and_close_popup(page_object)
            comp_drpdown_loc=locators_dictionary['Service_component_dropdown_loc']
            comp_option_loc=locators_dictionary['Service_component_option_loc'].format(ComponentName=comp_name_data)
            service_name_loc=locators_dictionary['Service_namesearch_loc']
            apply_loc=locators_dictionary['Service_apply_loc']
            design_loc=locators_dictionary['Service_design_dots'].format(ServiceName=service_name_data)
            for_click(page_object,comp_drpdown_loc)
            wait_and_close_popup(page_object)
            for_click(page_object,comp_option_loc)
            wait_and_close_popup(page_object)
            for_fill(page_object,service_name_loc,service_name_data)
            for_click(page_object,apply_loc)
            wait_and_close_popup(page_object)
            for_click(page_object,design_loc)
            wait_and_close_popup(page_object)
            filter_column = 'ProcessSectionName'
            unique_values = data_df_ProcessSectionName[filter_column].unique()
            for section in unique_values:
                #clicking based on section name          
                Design_statement = locators_dictionary['Processsection_addstmnt_loc'].format(ProcessSectionName=section)
                for_click(page_object,Design_statement)
                time.sleep(1)
                wait_and_close_popup(page_object)
                index=0
                while index < len(data_dict_ProcessSectionName):
                    each_item = data_dict_ProcessSectionName[index]
                # for index,each_item in enumerate(data_dict_ProcessSectionName):
                    try:
                        #clicking each statement based on execute or foreach
                        if "Execute" in each_item["StatementType"] : #Execute Method('compUpdHdrMth_at')
                            statement = "Execute Method('"+ each_item["MethodName"]+"')"
                            Process_Section_Statement_Action = locators_dictionary['Process_Section_Statement_Action'].format(statement)
                            method_name_df = pd.read_excel(file_path_for_processsection_creation,sheet_name="ServiceMethodMap", dtype=str)
                            filtered_methodname_df = method_name_df[method_name_df["MethodName"] == each_item["MethodName"]]  
                            for_click(page_object,Process_Section_Statement_Action)
                            increment_by=1
                            wait_and_close_popup(page_object)
                            time.sleep(1)  
                          
                                                                                         
                        
                        elif "ForEach" in each_item["StatementType"]: #ForEach (row in compUpdateDtlReq_at)
                                                       
                            match_value = "ForEach"
                            match_column = 'StatementType'
                            retrieve_column = 'MethodName'  # Column to retrieve the value from in the next row

                            # Find the index of the row where the value matches
                            matched_index = data_df_ProcessSectionName[data_df_ProcessSectionName[match_column] == match_value].index

                            # Check if the next row exists and retrieve the value from another column
                            if not matched_index.empty and matched_index[0] + 1 < len(data_df_ProcessSectionName):
                                next_row_value = data_df_ProcessSectionName.loc[matched_index[0] + 1, retrieve_column]
                                Variable_not_resettable.logger.info(f"Value from the next row in '{retrieve_column}': {next_row_value}")
                            else:
                                Variable_not_resettable.logger.info("Match not found or no next row exists.")
                        
                            foreach_statement_link = "ForEach (row in "+ each_item["LoopSegment"]+")"
                            statement = "Execute Method('"+next_row_value+"')"
                            foreach_statement_link_locator = locators_dictionary['foreach_statement_link_locator'].format(foreach_statement_link)
                            Process_Section_Statement_Action =locators_dictionary['Process_Section_Statement_Action'].format(statement)
                            method_name_df = pd.read_excel(file_path_for_processsection_creation,sheet_name="ServiceMethodMap", dtype=str)
                            filtered_methodname_df = method_name_df[method_name_df["MethodName"] == next_row_value] 
                            increment_by=2
                            for_click(page_object,foreach_statement_link_locator)
                            wait_and_close_popup(page_object)
                            time.sleep(1)
                            for_click(page_object,Process_Section_Statement_Action)
                            time.sleep(1)
                            wait_and_close_popup(page_object)
                        Mapping_process_section_statements(page_object,locators_dictionary,filtered_methodname_df)
                        Variable_not_resettable.logger.info("Mapping completed for a statement")
                        # backarrow2 = "//*[@class='ms-auto cursor-pointer col-md-1 col-lg-1 col-xl-1']//*[@alt='BackArrow']"
                        backarrow1 =locators_dictionary['MethodMap_backarrow']
                        # for_click(page_object,backarrow2)
                        for_click(page_object,backarrow1)
                        wait_and_close_popup(page_object)

                    except Exception as while_forwarderror:
                        Variable_not_resettable.logger.info(while_forwarderror)
                        raise Exception
                    finally:
                         # Always increment the index after handling the row, even if an exception occurs
                        index += increment_by

        case "Double Click":
            for index , each_data in enumerate(data.split(";"), 1):
                key = f":var{index}"
                loc_xpath = loc_xpath.replace(key, each_data)
            Variable_not_resettable.logger.info(f"Final xpath: {loc_xpath}")  
            Doubleclick(page_object,loc_xpath)
            Variable_not_resettable.logger.info("Double Click button action completed")
            time.sleep(0.2)

        
        case "Select Combo Option":
            if Common_controls.control_Identifier=="xpath":
                if "|" in data:
                    data_value_split = data_value.split("|")
                    data_value = data_value_split[0]
                    data= data_value_split[1]
                    for index , each_data in enumerate(data_value.split(";"), 1):
                        key = f":var{index}"
                        loc_xpath = loc_xpath.replace(key, each_data)


            select_option_in_combo_box(page_object, loc_xpath,data) 
            Variable_not_resettable.logger.info("Force Click action completed")
                



    if test_properties.get("element_highlighter") == "True":
        replace_highlight_element(page_object, loc_xpath, element_bg_color)
