import os
from common_object import Common_config, Common_object, Common_path, Common_step, Variable_not_resettable
from excel_utils import read_excel_return_dataFrame, read_dataFrame_return_dictionary_for_row_based
import pandas as pd



def controlSheet_dictionary(file_name: str, sheet_name: str):
    sheet_name = str(sheet_name).strip()
    # Variable_not_resettable.logger.info("Control sheet_name :"+ str(sheet_name))
    excel_file = pd.ExcelFile(Common_path.control_sheet_path+"/"+file_name+".xlsx")
    excel_sheets = excel_file.sheet_names
    # Variable_not_resettable.logger.info("Control excel_sheets list :"+ str(excel_sheets))
    sheet_name_new = [name for name in excel_sheets if name.lower() == sheet_name.lower()]

    if len(sheet_name_new) == 0:
        error_str = "Control file sheet name '"+ str(sheet_name)+"' not present in refereed excel workbook '"+Common_step.CONTROL_FILE+".xlsx'"
        Variable_not_resettable.logger.error(error_str)
        raise Exception(error_str)

    Variable_not_resettable.logger.debug("Control sheet_name_new :"+ str(sheet_name_new))
    data_frame= read_excel_return_dataFrame(Common_path.control_sheet_path+"/"+file_name+".xlsx", sheet_name_new[0])
    dictionary_data = read_dataFrame_return_dictionary_for_row_based(data_frame)
    Common_object.controls_dictionary = dictionary_data

def controlSheet_dictionary_config(file_name: str, sheet_name: str):
    sheet_name = str(sheet_name).strip()
    base_path = os.getcwd()
    config_control_sheet_path : str = base_path + "/Files/ControlSheets/"+Common_config.client_name
    excel_file = pd.ExcelFile(config_control_sheet_path +"/"+ file_name+".xlsx")
    excel_sheets = excel_file.sheet_names
    sheet_name_new = [name for name in excel_sheets if name.lower() == sheet_name.lower()]

    if len(sheet_name_new) == 0:
        error_str = "Control file sheet name '"+ str(sheet_name)+"' not present in refereed excel workbook '"+Common_step.CONTROL_FILE+".xlsx'"
        Variable_not_resettable.logger.error(error_str)
        raise Exception(error_str)

    data_frame= read_excel_return_dataFrame(config_control_sheet_path +"/"+ file_name+".xlsx", sheet_name_new[0])
    dictionary_data = read_dataFrame_return_dictionary_for_row_based(data_frame)
    Common_object.controls_dictionary = dictionary_data


def controlSheet_element_value(element:str) -> dict:
    for f in reversed(Common_object.controls_dictionary):
        # if str(f["Element"]).lower() == str(element).lower():
        if str(f["Element"]) == str(element):
            return f