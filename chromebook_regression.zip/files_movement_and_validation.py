from datetime import datetime
import os
import shutil
import pandas as pd
from common_object import Variable_not_resettable,Common_step
import subprocess
import smbprotocol
from smbprotocol.connection import Dialects


def connect_to_network_path(network_path, username, password):
    """
    Connects to the specified network path using the provided credentials.

    Args:
        network_path (str): The network path to connect to (e.g., r'/server/share').
        username (str): The username for authentication.
        password (str): The password for authentication.
    """
    # Initialize smbprotocol
    smbprotocol.ClientConfig(username=username, password=password)

    # Connect to the network share
    try:
        # Format the network path for SMB connection
        share_path = network_path.replace("/", "/")  # Ensure the path is correctly formatted for smbprotocol
        smbprotocol.set_connection("localhost", Dialects.SMB_3_0)
        
        # Connect to the network share
        connection = smbprotocol.SMBConnection(
            server=network_path.split("/")[2],  # Get the server from network_path
            share=network_path.split("/")[3],   # Get the share from network_path
            username=username,
            password=password
        )

        # Attempt to authenticate
        connection.login()
        print("Connected successfully")
    except Exception as e:
        print(f"Failed to connect: {e}")

# # Example usage:
# network_path = r"/server\share"
# username = "your_username"
# password = "your_password"
# connect_to_network_path(network_path, username, password)


# # Connect to the network share
# def connect_to_network_path(network_path, username, password):
#     Variable_not_resettable.logger.info(network_path)
#     """
#     Connects to the specified network path using the provided credentials.

#     Args:
#         network_path (str): The network path to connect to.
#         username (str): The username for authentication.
#         password (str): The password for authentication.
#     """
#     netresource = win32wnet.NETRESOURCE()
#     netresource.lpRemoteName = network_path
#     netresource.dwType = win32netcon.RESOURCETYPE_DISK

#     win32wnet.WNetAddConnection2(netresource, password, username, 0)
    
def list_files_and_sizes(directory):
    """
    Lists files and their sizes in the specified directory.

    Args:
        directory (str): The directory to list files from.

    Returns:
        list: A list of dictionaries, where each dictionary contains the filename and its size in KB.
    """
    file_list = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            file_size = os.path.getsize(file_path) / 1024
            file_list.append({"filename": os.path.relpath(file_path, directory), "size": file_size})
    return file_list

def copy_directory(src, dst):
    """
    Copies a directory from source to destination with a progress bar.

    Args:
        src (str): The source directory path.
        dst (str): The destination directory path.
    """
    if os.path.exists(dst):
        shutil.rmtree(dst)  # Remove the destination directory if it exists
    os.makedirs(dst)
    Variable_not_resettable.logger.info("copying Files...")
    
    total_files = sum([len(files) for r, d, files in os.walk(src)])
    # progress_bar = tqdm(total=total_files, desc="Copying files", unit="file")

    for root, dirs, files in os.walk(src):
        relative_path = os.path.relpath(root, src)
        destination_dir = os.path.join(dst, relative_path)
        if not os.path.exists(destination_dir):
            os.makedirs(destination_dir)
        
        for file in files:
            src_file = os.path.join(root, file)
            dst_file = os.path.join(destination_dir, file)

            # Move the cursor up to the progress bar line and clear it
            # stdout.write("\033[F\033[K")
            # Variable_not_resettable.logger.info the current copying file
            # stdout.write(f"Copying: {file}\n")
            # stdout.flush()

            shutil.copy2(src_file, dst_file)
            # progress_bar.update(1)

    # progress_bar.close()
    # stdout.write("\n")

def compare_directories(src_list, dst_list):
    """
    Compares files and sizes between source and destination lists.

    Args:
        src_list (list): List of files and sizes from the source directory.
        dst_list (list): List of files and sizes from the destination directory.

    Returns:
        bool: True if the directories match, False otherwise.
    """
    if len(src_list) != len(dst_list):
        Variable_not_resettable.logger.info("The number of files does not match.")
        return False

    src_dict = {item['filename']: item['size'] for item in src_list}
    dst_dict = {item['filename']: item['size'] for item in dst_list}

    for filename, size in src_dict.items():
        if filename not in dst_dict:
            Variable_not_resettable.logger.info(f"File {filename} is missing in the destination.")
            return False
        if abs(size - dst_dict[filename]) > 1e-2:  # Allowing a small tolerance for size difference
            Variable_not_resettable.logger.info(f"File size mismatch for {filename}: {size} KB (source) vs {dst_dict[filename]} KB (destination)")
            return False

    return True

# Define the network path and credentials

def check_files(path):
    results = []
    if os.path.exists(path):
        file_size = os.path.getsize(path)
        verify_msg = file_size > 0
        results.append({
            'path': path,
            'file_size': file_size,
            'verify_msg': verify_msg
        })
    else:
        results.append({
            'path': path,
            'file_size': None,
            'verify_msg': False
        })
    return results[0]




def read_dataFrame_return_dictionary_for_colum_based(data_frame) -> dict:
    dict_temp = {}
    _ = [dict_temp.update({str(data[1]).strip(): str(data[2]).strip()}) for data in data_frame.to_records()]
    return dict_temp

def close_the_connection():
    
    # Create the command with the /y flag to automatically confirm the deletion
    command = 'net use * /delete /y'

    # Run the command
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    try:
        # Wait for the command to complete with a timeout
        stdout, stderr = process.communicate(timeout=30)  # Adjust timeout as needed
        if process.returncode == 0:
            print('Successfully deleted the network connection: *')
            print(stdout)
        else:
            print(f'Failed to delete the network connection: *')
            print(stderr)
    except subprocess.TimeoutExpired:
        # If the process times out, terminate it
        print("Command timed out, terminating the process.")
        process.terminate()
        stdout, stderr = process.communicate()
        print(f'Output after termination:\n{stdout}')
        print(f'Error after termination:\n{stderr}')
    finally:
        # Ensure the process is terminated
        process.kill()
        print("Process killed.")


def move_files(df_dic,spec_test_path,df_info):   
    Variable_not_resettable.logger.info(spec_test_path) 

    path_confs = {
        "base_path1": df_dic['share_point_path'],
        "base_path2":df_info['base_directory'].iloc[0] ,

    }
    username = df_dic['username']
    password = df_dic['password']


    path_confs["base_path3"]=path_confs["base_path2"]+"-release"
    network_path1 = path_confs['base_path1'] + path_confs['base_path2']
    network_path2 = path_confs['base_path1'] + path_confs['base_path3']
    local_path1 = spec_test_path + path_confs['base_path2']
    local_path2 = spec_test_path + path_confs['base_path3']

    connect_to_network_path(network_path1, username, password)


    src_files1 = list_files_and_sizes(network_path1)
    copy_directory(network_path1, local_path1)
    dst_files1 = list_files_and_sizes(local_path1)

    copy_directory(network_path2, local_path2)
    dst_files2 = list_files_and_sizes(local_path2)
    src_files2 = list_files_and_sizes(network_path2)


    if dst_files1 == src_files1:
        Variable_not_resettable.logger.info(f"Copied: {network_path1} to {local_path1} and files are verified")
    else:
        Variable_not_resettable.logger.info(f"Copied: {network_path1} to {local_path1} and files are mismatch")

    if dst_files2 == src_files2:
        Variable_not_resettable.logger.info(f"Copied: {network_path2} to {local_path2} and files are verified")
    else:
        Variable_not_resettable.logger.info(f"Copied: {network_path2} to {local_path2} and files are mismatch")


def compare_files(df_info,output_path,spec_test_path):

    concat_paths=[]
    
    for index,value in enumerate(df_info['path'].tolist()):
        check_path=spec_test_path+value+"/"+df_info['filename'][index]
        result=check_files(check_path)['verify_msg']
        if result:
            result="true"
        else:
            result='false'
        concat_paths.append(result)

    df_info['result']=concat_paths

    df_info.to_excel(output_path,index=False)
    return df_info['result']

def deliverables_validation():

    input_path = os.path.join(os.getcwd(),'Deliverables_info.xlsx') 
    date_now = datetime.now().strftime("%d-%m-%Y %H-%M-%S").replace(":", "_")
    spec_test_path = os.path.join(os.getcwd(),"Output","Rapids_"+date_now)
    output_path = os.path.join(spec_test_path,"Deliverables_Validation_output.xlsx")

    df2=pd.read_excel(input_path,sheet_name='credentials')

    # spec_test_path="D:/Utillities/json_file_rename/folder1" #reference

    df_dic=read_dataFrame_return_dictionary_for_colum_based(df2)
   
    #Move and Compare files
    # concat_paths.append('result')
    df_info = pd.read_excel(input_path,sheet_name=str(Common_step.DATA_SHEET))
    
    move_files(df_dic,spec_test_path,df_info)
    #close_the_connection()
    validation_result = compare_files(df_info,output_path,spec_test_path)
    # Variable_not_resettable.logger.info(validation_result)
    return list(validation_result)

# deliverables_validation()
