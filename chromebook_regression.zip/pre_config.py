from common_object import Common_object, Common_path, Common_preConfig, Common_step
from excel_utils import read_excel_return_dataFrame, read_dataFrame_return_dictionary_for_colum_based
from utils import  split_by_colon
from control_sheet import controlSheet_element_value, controlSheet_dictionary
from data_sheet import dataSheet_dictionary
from page_action import page_action
from page_object_wrapper import get_locator
from play_code import *
from navigation import get_data_value


def pre_config_sheet_filter_steps(pre_config_file_name:str, pre_config_id: str):
    # Common_step.Pre_config_filename=pre_config_file_name
    # Common_step.Pre_config_sheet_name="PreReqConfig"
    pre_config_data_frame = read_excel_return_dataFrame(pre_config_file_name,"PreReqConfig")
    pre_config_metadata_dictionary = read_dataFrame_return_dictionary_for_colum_based(pre_config_data_frame[0:2])
    last_row = len(pre_config_data_frame)
    pre_config_list_data_frame =  pre_config_data_frame[2:last_row]
    pre_config_list_data_frame = pre_config_list_data_frame.rename(columns=pre_config_list_data_frame.iloc[0]).drop(pre_config_list_data_frame.index[0])
    pre_config_list_data_frame = pre_config_list_data_frame[0:]
    pre_config_list_data_frame = pre_config_list_data_frame.reset_index(inplace=False, drop=True)
    data_frame_dictionary = pre_config_list_data_frame.to_dict('records')
    pre_config_start = []
    Flag = True
    if pre_config_metadata_dictionary["PREREQ_CONFIG_ID"] == pre_config_id:
        for i in range(len(data_frame_dictionary)):
            if str(data_frame_dictionary[i]['STEP_ID']) == 'END_PREREQ_CONFIG':
                Flag = False
            if Flag == True:
                pre_config_start.append(data_frame_dictionary[i])

    return (pre_config_metadata_dictionary, pre_config_start)



def pre_config_variables(page,context, STEP_CONFIG_LIST, loop_count, ):
    Common_object.pre_config_dictionary = pre_config_sheet_filter_steps(Common_path.pre_config_path, STEP_CONFIG_LIST[0])
    if len(Common_object.pre_config_dictionary[1]) != 0 and Common_step.SKIP_PRE_CONFIG == False:
        # log_step_list = []
        for pre_config_step in Common_object.pre_config_dictionary[1]:
            Common_preConfig.PRECONF_PAGE_NAME = pre_config_step['PAGE_NAME']
            Common_preConfig.PRECONF_ELEMENT_REFERENCE = pre_config_step['ELEMENT_REFERENCE']
            Common_preConfig.PRECONF_ACTION = pre_config_step['ACTION']
            Common_preConfig.PRECONF_DATA_NAME = pre_config_step['DATA_NAME']
            Common_preConfig.PRECONF_DATA_REFERENCE = pre_config_step['DATA_REFERENCE']
            if str(Common_preConfig.PRECONF_PAGE_NAME) != "nan":
                Common_preConfig.PRECONF_CONTROL_FILE, Common_preConfig.PRECONF_CONTROL_SHEET = tuple(split_by_colon(Common_preConfig.PRECONF_PAGE_NAME))
                # store the control sheet data in common object as dictionary
                controlSheet_dictionary(Common_preConfig.PRECONF_CONTROL_FILE, Common_preConfig.PRECONF_CONTROL_SHEET)
                controlSheet_data = controlSheet_element_value(Common_preConfig.PRECONF_ELEMENT_REFERENCE)
                Common_preConfig.pre_config_control_elementId = controlSheet_data['Value']
                # print(Common_preConfig.pre_config_control_elementId)

            if str(Common_preConfig.PRECONF_DATA_NAME) != "nan":
                Common_preConfig.PRECONF_DATA_FILE, Common_preConfig.PRECONF_DATA_SHEET = tuple(split_by_colon(Common_preConfig.PRECONF_DATA_NAME))
                # store the data sheet data in common object as dictionary
                dataSheet_dictionary(Common_preConfig.PRECONF_DATA_FILE, Common_preConfig.PRECONF_DATA_SHEET)
                Common_preConfig.dataSheet_reference_value = get_data_value(Common_object.dataSheet_dictionary, Common_preConfig.PRECONF_DATA_REFERENCE)
                page_action(page,context, Common_preConfig.PRECONF_ACTION, get_locator(page,Common_preConfig.PRECONF_ACTION, Common_preConfig.pre_config_control_elementId, loop_count), Common_preConfig.dataSheet_reference_value)
                if Variable_not_resettable.APP_TYPE == "Studio":
                    popuphandler_for_studio(page)           
            else:
                page_action(page,context, Common_preConfig.PRECONF_ACTION, get_locator(page,Common_preConfig.PRECONF_ACTION, Common_preConfig.pre_config_control_elementId, loop_count), "nan")
                if Variable_not_resettable.APP_TYPE == "Studio":
                    popuphandler_for_studio(page) 
            # log_step_list.append(log_list('PASS'))
        Common_step.SKIP_PRE_CONFIG = True
        # advance_debug_log(log_step_list)
        