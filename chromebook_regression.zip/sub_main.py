import time
from common_object import Common_main_object, Common_object, Common_path, Common_scenario, Common_step, Variable_not_resettable
from excel_utils import add_row_to_excel, advance_debug_log, read_excel_return_dictionary_for_colum_based, read_excel_return_dictionary_for_row_based
from func.scenario_re_run import fail_scenario_collector, fail_scenarios_folder_cleanup, fail_scenarios_folder_rename
from reset_common_object import reset_navigation_variables, reset_scenario_dict, reset_scenario_variables
from utils import create_folder_not_exist, executionstop, log_list, split_by_colon, join_path_and_file, test_runner_config_validator
from scenario import data_provider, get_scenarios_file_list, scenario_sheet_filter_steps, select_scenario_tags,get_scenarios_file_list_single_execution
from steps import scenario_step
from datetime import datetime
import os
import pandas as pd
import uuid



def reading_required_files(is_rerun_true):
#def reading_required_files():
    # Reading process for properties file and storing in Common Object
    Common_object.properties = {'navigation_config_file_sheet_name': 'NavigationConfig.xlsx:NavConfig', 'pre_req_config_file_sheet_name': 'PreReqConfig.xlsx:PreReqConfig', 'test_runner_config_file_sheet_name': 'TestRunnerConfig.xlsx:RunnerConfig', 'browser_headless': 'False'}
    # Reading process for testConfig file and storing in Common Object
    testConfig_file_name, testConfig_sheet_name = split_by_colon(Common_object.properties["test_runner_config_file_sheet_name"])
    # print("[INFO] : Reading TestConfig Files")
    Variable_not_resettable.logger.info("Reading TestConfig Files")
    if is_rerun_true == True:
        Common_object.test_config_dictionary = read_excel_return_dictionary_for_colum_based(join_path_and_file(Common_path.test_config_path, testConfig_file_name), testConfig_sheet_name)
        if "GUID" in Common_object.test_config_dictionary:
            # Append '_RERUN' to the value of 'GUID'
            Common_object.test_config_dictionary["GUID"] += "_RERUN"
    else:
        Common_object.test_config_dictionary = read_excel_return_dictionary_for_colum_based(join_path_and_file(Common_path.test_config_path, testConfig_file_name), testConfig_sheet_name)
 
    # Common_object.test_config_dictionary = read_excel_return_dictionary_for_colum_based(join_path_and_file(Common_path.test_config_path, testConfig_file_name), testConfig_sheet_name)
    if Common_object.Macros_filter_enabled:
        Common_object.test_config_dictionary["FilesNameInclude"] = Common_object.scenario_list_filter
        Variable_not_resettable.logger.info(Common_object.test_config_dictionary)
    try:
        Common_object.test_config_dictionary["VIDEOS"]
        Variable_not_resettable.APP_TYPE = Common_object.test_config_dictionary["AppType"]
    except Exception as error:
        error_str = str(error)
        if "'AppType'" == str(error) or "'VIDEOS'" in str(error):
            error_str = f"{str(error)} Field is missing or incorrect in TestRunnerConfig.xlsx"
        raise Exception(str(error_str))
    
    Common_object.test_config_dictionary['TagsInclude'] = str(Common_object.test_config_dictionary['TagsInclude']).split(",")
    Common_object.test_config_dictionary['TagsInclude'] = [tag.strip() for tag in  Common_object.test_config_dictionary['TagsInclude']]
    Common_object.test_config_dictionary['TagsExclude'] = str(Common_object.test_config_dictionary['TagsExclude']).split(",")
    Common_object.test_config_dictionary['TagsExclude'] = [tag.strip() for tag in  Common_object.test_config_dictionary['TagsExclude']]
    #Reading process for Navigation file and storing in Common Object
    # print("[INFO] : Reading Navigation Files")
    Variable_not_resettable.logger.info("Reading Navigation Files")
    navigation_file_name, navigation_sheet_name = split_by_colon(Common_object.properties["navigation_config_file_sheet_name"])
    Common_object.navigation_dictionary = read_excel_return_dictionary_for_row_based(join_path_and_file(Common_path.navigation_path, navigation_file_name), navigation_sheet_name)
    #Reading process Scenario file and storing in Common object
    # print("[INFO] : Reading Scenario Files")
    Variable_not_resettable.logger.info("Reading Scenario Files")
    Common_object.scenarios_file_list = get_scenarios_file_list()
    # print(Common_object.scenarios_file_list)
    Variable_not_resettable.logger.debug("Scenario Files included in this execution:  "+ str(Common_object.scenarios_file_list))
    create_folder_not_exist("Output")
    if len(Common_object.scenarios_file_list) > 0:
        return True
    else:
        return False


        
def start_test(is_Prerequisites):
    
    if Common_object.PATCH_ID == None and str(Common_object.test_config_dictionary["PatchID"]) != "nan":
        Common_object.PATCH_ID = Common_object.test_config_dictionary["PatchID"]
    elif Common_object.PATCH_ID == None:
        Common_object.PATCH_ID = uuid.uuid4()
    date_now = datetime.now().strftime("%d-%m-%Y %H-%M-%S").replace(":", "_")
    if str(Common_object.test_config_dictionary["GUID"]).find("REG")!= -1:
        Common_main_object.advance_debug_log_file_name = "TestResultLog "+str(date_now)+"_web_regtest_"+Common_object.test_config_dictionary["GUID"]
    elif str(Common_object.test_config_dictionary["GUID"]).find("SMK")!=-1:
        Common_main_object.advance_debug_log_file_name = "TestResultLog "+str(date_now)+"_web_smktest_"+Common_object.test_config_dictionary["GUID"]
    elif str(Common_object.test_config_dictionary["GUID"]).find("SANITY")!=-1:
        Common_main_object.advance_debug_log_file_name = "TestResultLog "+str(date_now)+"_web_sanitytest_"+Common_object.test_config_dictionary["GUID"]
    else:
        Common_main_object.advance_debug_log_file_name = "TestResultLog "+str(date_now)+"_web"

    Common_main_object.advance_debug_log_folder = "Output/"+  Common_main_object.advance_debug_log_file_name
    if Common_object.test_config_dictionary["WebPageAssertionMode"].lower()!="scrap":
        os.mkdir(Common_main_object.advance_debug_log_folder)
        df = pd.DataFrame(columns=Common_object.advance_debug_log_header)
        df1 = pd.DataFrame(columns=Common_object.test_result_log_header_INFO)
        df2 = pd.DataFrame(columns=Common_object.test_result_log_header_DEBUG)
        Common_main_object.advance_debug_log_file_path = Common_main_object.advance_debug_log_folder+"/AdvancedDebugLog.csv"
        Common_main_object.test_result_log_file_path = Common_main_object.advance_debug_log_folder+"/TestResultLog.xlsx"
        df.to_csv(Common_main_object.advance_debug_log_file_path, index_label=False)
        with pd.ExcelWriter(Common_main_object.test_result_log_file_path) as writer:
            df1.to_excel(writer,sheet_name="INFO", index=False)
            df2.to_excel(writer,sheet_name="DEBUG", index=False)
            
    
    if is_Prerequisites:
        Common_object.scenarios_file_list = get_scenarios_file_list_single_execution()
    for scenarios_file in Common_object.scenarios_file_list:
        try:
            Common_main_object.test_result_log_info_dict = {'SCENARIO ID': None, 'SCENARIO NAME': None, 'RESULT': None, 'ERROR SNAPSHOT': None,'EXECUTION_START_TIME': None, 'EXECUTION_END_TIME': None, "EXECUTION_VIDEO":None}
            Common_main_object.test_result_log_debug_dict = {'SCENARIO ID': None, 'SCENARIO NAME': None, 'RESULT': None, 'ERROR SNAPSHOT': None, 'STEP ID': None,
            'XRAY TEST CASE ID': None, 'PAGE OBJECT DATA': None, 'ACTION': None, 'DATA VALUE': None,'EXECUTION TIME (sec)': None, 'Error_Raised': None, 'Custom_Error': None,
            'ERROR_MESSAGE': None, 'Solution_Suggestion': None}
            start_time = time.perf_counter()
            Common_main_object.scenario_execution_start_time = datetime.now()
            
            # print("[INFO] : Running scenario file : ", scenarios_file)
            Variable_not_resettable.logger.info("Running scenario file : "+ scenarios_file)
            scenario_split= scenarios_file.split("/")
            Common_object.SCENARIO_FILE_NAME=scenario_split[1]


            Common_object.scenarios_meta, Common_object.scenarios_dictionary = scenario_sheet_filter_steps(scenarios_file)
            data_provider_header = str(list((Common_object.scenarios_dictionary[0]).keys())[5])
            data_provider_count = data_provider(data_provider_header)

            # print("[INFO] : Data Provider : ", data_provider_count)
            #print("scenarios_dictionary : ", Common_object.scenarios_dictionary)
            if select_scenario_tags(Common_object.scenarios_meta["SCENARIO_TAGS"]):
                for num in data_provider_count:
                    if data_provider_header.find("{") >= 0:
                        Common_scenario.data_provider_count_for_scenario = "_"+str(num)
                    else:
                        Common_scenario.data_provider_count_for_scenario = ""
                    try:
                        scenario_step(scenarios_file, num)
                        time.sleep(2)
                        end_time = time.perf_counter()
                        scenario_execution_time = str(round(end_time - start_time, 2))
                        Common_main_object.scenario_execution_end_time = datetime.now()
                        Common_main_object.test_result_log_info_dict.update({'SCENARIO ID': Common_object.scenarios_meta["SCENARIO_ID"]+str(Common_scenario.data_provider_count_for_scenario), 'SCENARIO NAME': Common_object.scenarios_meta["SCENARIO NAME"],'EXECUTION_START_TIME': Common_main_object.scenario_execution_start_time, 'EXECUTION_END_TIME': Common_main_object.scenario_execution_end_time})
                        Common_main_object.test_result_log_debug_dict.update({'SCENARIO ID': Common_object.scenarios_meta["SCENARIO_ID"]+str(Common_scenario.data_provider_count_for_scenario), 'SCENARIO NAME': Common_object.scenarios_meta["SCENARIO NAME"],'EXECUTION TIME (sec)': scenario_execution_time})
                        if Common_object.test_config_dictionary["WebPageAssertionMode"].lower()!="scrap":
                            add_row_to_excel(Common_main_object.test_result_log_file_path, "INFO", list(Common_main_object.test_result_log_info_dict.values()))
                            add_row_to_excel(Common_main_object.test_result_log_file_path, "DEBUG", list(Common_main_object.test_result_log_debug_dict.values()))
                        # print("[INFO] : Scenario success")
                        Variable_not_resettable.logger.info("Scenario success")
                        reset_scenario_variables()
                        reset_navigation_variables()          
                    except Exception as error:
                        Variable_not_resettable.logger.error(str(error))
                        if "[Errno 13] Permission denied:" in str(error):
                            # print("[ERROR] : ", error)
                            Variable_not_resettable.logger.error(str(error))
                        else:
                            #print(error)
                            end_time = time.perf_counter()
                            scenario_execution_time = str(round(end_time - start_time, 2))
                            Common_main_object.scenario_execution_end_time = datetime.now()
                            if Common_main_object.test_result_log_debug_dict.get("ERROR_MESSAGE") == None:
                                Common_main_object.test_result_log_debug_dict.update({'ERROR_MESSAGE': str(error)})       
                            Common_main_object.test_result_log_info_dict.update({'SCENARIO ID': Common_object.scenarios_meta["SCENARIO_ID"]+str(Common_scenario.data_provider_count_for_scenario),'SCENARIO NAME': Common_object.scenarios_meta["SCENARIO NAME"],'EXECUTION_START_TIME': Common_main_object.scenario_execution_start_time, 'EXECUTION_END_TIME': Common_main_object.scenario_execution_end_time, 'RESULT': 'FAILURE'})
                            Common_main_object.test_result_log_debug_dict.update({'SCENARIO ID': Common_object.scenarios_meta["SCENARIO_ID"]+str(Common_scenario.data_provider_count_for_scenario),'SCENARIO NAME': Common_object.scenarios_meta["SCENARIO NAME"],'EXECUTION TIME (sec)': scenario_execution_time, 'RESULT': 'FAILURE'})       
                            if Common_object.test_config_dictionary["WebPageAssertionMode"].lower()!="scrap":
                                add_row_to_excel(Common_main_object.test_result_log_file_path, "INFO", list(Common_main_object.test_result_log_info_dict.values()))
                                add_row_to_excel(Common_main_object.test_result_log_file_path, "DEBUG", list(Common_main_object.test_result_log_debug_dict.values()))
                            # print("[INFO] : Scenario failed")
                            if Common_scenario.is_advance_log_done == False:
                                Common_step.step_count =  Common_step.step_count + 1
                                error_temp_log_list = []
                                error_temp_log_list.append(log_list('FAIL'))
                                advance_debug_log(error_temp_log_list)
                                
                            Variable_not_resettable.logger.error("Scenario failed")

                            if Variable_not_resettable.re_run_flag != True:
                                if str(Common_object.test_config_dictionary.get("FailRerun")).upper() == "ON":
                                    fail_scenario_collector(f"Files/Scenarios/{scenarios_file}")

                            reset_scenario_variables()
                            reset_navigation_variables()
                        Executionstop = executionstop(scenarios_file)
                        if Executionstop:
                            error="[INFO] : Execution stopped due to dependent scenario for before draft bill is failed in list of scenarios ,The failed Scenario is ",scenarios_file
                            # print(error)
                            exit(error)
                reset_scenario_dict()
        except Exception as error:
            # print("[ERROR] : ", str(error))  
            Variable_not_resettable.logger.error(str(error))   
        






