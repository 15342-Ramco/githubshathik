from common_object import Common_navigation, Common_object, Common_nav_path, Common_step, Variable_not_resettable


def navigation_elements(NavConfigId:str):
    if NavConfigId != "nan":
        if Variable_not_resettable.APP_TYPE == "Openworks":
            print("")
            check_nav_config = [i for i, x in enumerate(Common_object.navigation_dictionary) if NavConfigId == x['NavigationConfigID']]
            if len(check_nav_config) == 0:
                error_str = f"Please check the Navigation id : {NavConfigId}, was missing in NavigationConfig.xlsx"
                Variable_not_resettable.logger.info(error_str)
                raise Exception(error_str)
                
            elif len(check_nav_config) > 1:
                warning_str = f"Please check the Navigation id : {NavConfigId}, Have some duplication in NavigationConfig.xlsx"
                Variable_not_resettable.logger.warning(warning_str)

            index_NavConfig = Common_object.navigation_dictionary.index(next(filter(lambda n: n.get('NavigationConfigID') == NavConfigId, Common_object.navigation_dictionary)))
            Common_navigation.Process = Common_object.navigation_dictionary[index_NavConfig]["Process Name"]
            Common_navigation.Component = Common_object.navigation_dictionary[index_NavConfig]["Component Name"]
            Common_navigation.Activity = Common_object.navigation_dictionary[index_NavConfig]["Activity Name"]
            Common_nav_path.menu_path = "//*[starts-with(@id,'mainNbMenu-button')]//*[contains(@id, 'btnWrap')]"

            Common_nav_path.Process_path = "//*[contains(@class,'collapsed')]//*[contains(@id,'ext-element') and @style='margin-left: 0px;']//*[text()='"+Common_navigation.Process+"']"
            Common_nav_path.Component_path ="//li[contains(@class,'expanded')]//*[contains(@id,'ext-element') and @style='margin-left: 0px;']//*[text()='"+Common_navigation.Process+"']//..//..//..//*[contains(@class,'collapsed')]//*[contains(@id,'ext-element') and @style='margin-left: 5px;']//*[text()='"+Common_navigation.Component+"']"
            # Common_navigation.Previous_Process_and_component=[str(Common_navigation.Process),str(Common_navigation.Component)]
            Common_nav_path.Activity_path="//li[contains(@class,'expanded')]//*[contains(@id,'ext-element') and @style='margin-left: 0px;']//*[text()='"+Common_navigation.Process+"']//..//..//..//..//*[contains(@class,'expanded')]//*[contains(@id,'ext-element') and @style='margin-left: 5px;']//*[text()='"+Common_navigation.Component+"']//..//..//..//../*[contains(@class,'leaf')]//*[contains(@id,'ext-element') and @style='margin-left: 10px;']//*[text()='"+Common_navigation.Activity+"']"
        elif Variable_not_resettable.APP_TYPE == "Nebula co-existence":
            print("Navigating nebula server")
            index_NavConfig = Common_object.navigation_dictionary.index(next(filter(lambda n: n.get('NavigationConfigID') == NavConfigId, Common_object.navigation_dictionary)))
            Common_navigation.Process = Common_object.navigation_dictionary[index_NavConfig]["Process Name"]
            Common_navigation.Component = Common_object.navigation_dictionary[index_NavConfig]["Component Name"]
            Common_navigation.Activity = Common_object.navigation_dictionary[index_NavConfig]["Activity Name"]
            
             
            if (Common_navigation.Component[-1]).isdigit():
                if (Common_navigation.Component[-2]) == "_":
                    index_component = str(Common_navigation.Component[-1])
                    Common_nav_path.Component_path ="(//*[starts-with(@id,'SideNavMenu1')]//*[text()='"+Common_navigation.Component+"'])["+index_component+"]"
            else:
                Common_nav_path.Component_path = "//*[starts-with(@id,'SideNavMenu1')]//*[text()='"+Common_navigation.Component+"']"
            
            if str(Common_navigation.Activity)== "nan":
                Variable_not_resettable.logger.info(f"No Activity found")
            else:
                if (Common_navigation.Activity[-1]).isdigit():
                    if (Common_navigation.Activity[-2]) == "_":
                        index_activity = str(Common_navigation.Activity[-1])
                        Common_navigation.Activity = Common_navigation.Activity[:(len(Common_navigation.Activity)-2)]
                        Common_nav_path.Activity_path = "(//*[starts-with(@id,'SideNavMenu2')]//*[text()='"+Common_navigation.Activity+"'])["+index_activity+"]"
                else:
                    Common_nav_path.Activity_path = "//*[starts-with(@id,'SideNavMenu2')]//*[text()='"+Common_navigation.Activity+"']"
            
            
            # if (Common_navigation.Process[-1]).isdigit():
            #     if (Common_navigation.Process[-2]) == "_":
            #         index_process = str(Common_navigation.Process[-1])
            #         Common_navigation.Process = Common_navigation.Process[:(len(Common_navigation.Process)-2)]
            #         Common_nav_path.Process_path ="(//li[@class='bx--side-nav__item level_1']/button[@aria-expanded='false']/span[text()='"+Common_navigation.Process+"'])["+index_process+"]"
            # else:
            #     Common_nav_path.Process_path ="//li[@class='bx--side-nav__item level_1']/button[@aria-expanded='false']/span[text()='"+Common_navigation.Process+"']"
            
            # if (Common_navigation.previous_Component == Common_navigation.Component) and (Common_navigation.previous_Activity == Common_navigation.Activity):
            #             Variable_not_resettable.logger.info(f"The current navigation is same as the previous Navigation")
            #             Variable_not_resettable.logger.info(f"Doing Navigation ******************************************")
            #             Common_nav_path.Component_path = "//*[@class='sidenav-menu-item selected-item sidenav-component-menu-item']/div[text()='"+Common_navigation.Component+"']"
            #             if str(Common_navigation.Activity)== "nan":
            #                 Variable_not_resettable.logger.info(f"No Activity found")
            #             else:
            #                 Common_nav_path.Activity_path = "//*[@class='sidenav-menu-item selected-item sidenav-activity-menu-item']/div[text()='"+Common_navigation.Activity+"']"
            # elif (Common_navigation.previous_Component == Common_navigation.Component):
            #     Variable_not_resettable.logger.info(f"The current navigation for component is same as the previous Navigation")
            #     Variable_not_resettable.logger.info(f"Doing Navigation ******************************************")
            #     Common_nav_path.Component_path = "//*[@class='sidenav-menu-item selected-item sidenav-component-menu-item']/div[text()='"+Common_navigation.Component+"']"
            #     if str(Common_navigation.Activity)== "nan":
            #         Variable_not_resettable.logger.info(f"No Activity found")
            #     else:
            #         Common_nav_path.Activity_path = "//*[@class='sidenav-menu-item sidenav-activity-menu-item']/div[text()='"+Common_navigation.Activity+"']"
            # else:
            #     if (Common_navigation.Component[-1]).isdigit():
            #         if (Common_navigation.Component[-2]) == "_":
            #             index_component = str(Common_navigation.Component[-1])
            #             # Common_navigation.Component = Common_navigation.Component[:(len(Common_navigation.Component)-2)]
            #             Common_nav_path.Component_path ="(//li[@class='bx--side-nav__item level_1']/button[@aria-expanded='true']/../ul/li[@class='bx--side-nav__item level_2']/button/span[text()='"+Common_navigation.Component+"'])["+index_component+"]"

            #     else:
            #         # Common_nav_path.Component_path ="//li[@class='bx--side-nav__item level_1']/button[@aria-expanded='true']/../ul/li[@class='bx--side-nav__item level_2']/button/span[text()='"+Common_navigation.Component+"']"
            #         Common_nav_path.Component_path = "//*[@class='sidenav-menu-item sidenav-component-menu-item']/div[text()='"+Common_navigation.Component+"']"
                
            #     if str(Common_navigation.Activity)== "nan":
            #         Variable_not_resettable.logger.info(f"No Activity found")
            #     else:
            #         if (Common_navigation.Activity[-1]).isdigit():
            #             if (Common_navigation.Activity[-2]) == "_":
            #                 index_activity = str(Common_navigation.Activity[-1])
            #                 Common_navigation.Activity = Common_navigation.Activity[:(len(Common_navigation.Activity)-2)]
            #                 # Common_nav_path.Activity_path = "(//li[@class='bx--side-nav__item level_2']/button[@aria-expanded='true']/../ul/li[@class='bx--side-nav__menu-item menulink']/a/span/div[text()='"+Common_navigation.Activity+"'])["+index_activity+"]"
            #                 Common_nav_path.Activity_path = "(//*[@class='sidenav-menu-item sidenav-activity-menu-item']/div[text()='"+Common_navigation.Activity+"'])["+index_activity+"]"
            #         else:
            #             # Common_nav_path.Activity_path = "//li[@class='bx--side-nav__item level_2']/button[@aria-expanded='true']/../ul/li[@class='bx--side-nav__menu-item menulink']/a/span/div[text()='"+Common_navigation.Activity+"']"
            #             Common_nav_path.Activity_path = "//*[@class='sidenav-menu-item sidenav-activity-menu-item']/div[text()='"+Common_navigation.Activity+"']"




            # Common_nav_path.menu_path = "//*[@aria-label='Open menu']"
            # Common_nav_path.menu_path = "//*[@class='icon-wrap icon-s icon-left']"
            # Common_navigation.previous_process = Common_navigation.Process 
            # Common_navigation.previous_Component = Common_navigation.Component
            # Common_navigation.previous_Activity = Common_navigation.Activity
            
            # Common_nav_path.menu_path ="//*[@id='MenuBar_Icon_toggleSideNav']"
            # print("Process : ", Common_nav_path.Process_path)
            # print("Component : ",  Common_nav_path.Component_path)
            # print("Activity : ",Common_nav_path.Activity_path)
            
            Common_nav_path.menu_path = "//*[@id='MenuBar_Icon_toggleSideNav']"
            if Common_step.SKIP_NAVIGATION == False:
                print("Process : ", Common_nav_path.Process_path)
                print("Component : ",  Common_nav_path.Component_path)
                if str(Common_navigation.Activity) == "nan":
                    pass
                else:
                    print("Activity : ",Common_nav_path.Activity_path  )

        elif str(Variable_not_resettable.APP_TYPE).lower() == "epubs":
            check_nav_config = [i for i, x in enumerate(Common_object.navigation_dictionary) if NavConfigId == x['NavigationConfigID']]
            if len(check_nav_config) == 0:
                error_str = f"Please check the Navigation id : {NavConfigId}, was missing in NavigationConfig.xlsx"
                Variable_not_resettable.logger.info(error_str)
                raise Exception(error_str)
                
            elif len(check_nav_config) > 1:
                warning_str = f"Please check the Navigation id : {NavConfigId}, Have some duplication in NavigationConfig.xlsx"
                Variable_not_resettable.logger.warning(warning_str)

            index_NavConfig = Common_object.navigation_dictionary.index(next(filter(lambda n: n.get('NavigationConfigID') == NavConfigId, Common_object.navigation_dictionary)))
            Common_navigation.Process = Common_object.navigation_dictionary[index_NavConfig]["Process Name"]
            Common_navigation.Component = Common_object.navigation_dictionary[index_NavConfig]["Component Name"]
            Common_navigation.Activity = Common_object.navigation_dictionary[index_NavConfig]["Activity Name"]
            Common_nav_path.menu_path = "//*[@id='hamburgerMenuBtn']"

            Common_nav_path.Process_path =  "//*[@class='panel-title expand']//a[text()='" + Common_navigation.Process + "']"
            
            Common_nav_path.Component_path = "//*[@id='mySidenav']/div/h4/a[text()='" + Common_navigation.Process + "']/following::div[1][@class='panel-collapse collapse show']/a[text()='" +  Common_navigation.Component + "']"
            Common_nav_path.Activity_path = None
          


        else:
            check_nav_config = [i for i, x in enumerate(Common_object.navigation_dictionary) if NavConfigId == x['NavigationConfigID']]
            if len(check_nav_config) == 0:
                error_str = f"Please check the Navigation id : {NavConfigId}, was missing in NavigationConfig.xlsx"
                Variable_not_resettable.logger.info(error_str)
                raise Exception(error_str)
                
            elif len(check_nav_config) > 1:
                warning_str = f"Please check the Navigation id : {NavConfigId}, Have some duplication in NavigationConfig.xlsx"
                Variable_not_resettable.logger.warning(warning_str)

            index_NavConfig = Common_object.navigation_dictionary.index(next(filter(lambda n: n.get('NavigationConfigID') == NavConfigId, Common_object.navigation_dictionary)))
            Common_navigation.Process = Common_object.navigation_dictionary[index_NavConfig]["Process Name"]
            Common_navigation.Component = Common_object.navigation_dictionary[index_NavConfig]["Component Name"]
            Common_navigation.Activity = Common_object.navigation_dictionary[index_NavConfig]["Activity Name"]
            Common_nav_path.menu_path = "//div/a[@name = 'mainMenu_button']"

            # Common_navigation.process_breadcrumb_xpath = "//*[starts-with(@id,'btnComponent-button')]//*[starts-with(@id,'btnComponent-button') and contains(@id, 'btnInnerEl')]"
            # Common_navigation.component_breadcrumb_xpath = "//*[starts-with(@id,'btnActivity-button')]//*[starts-with(@id,'btnActivity-button') and contains(@id, 'btnInnerEl')]"
            # Common_navigation.activity_breadcrumb_xpath = "//*[starts-with(@id,'txtIlboTitle-button')]//*[starts-with(@id,'txtIlboTitle-button') and contains(@id, 'btnInnerEl')]"

            if Variable_not_resettable.test_properties.get("navigation_option") == "Default_Navigation" or Variable_not_resettable.test_properties.get("navigation_option") == None:
                Common_nav_path.Process_path = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr x-menu-bpc']//span[text()='"+Common_navigation.Process+"']"
                Common_nav_path.Component_path = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr x-menu-component']//span[text()='"+Common_navigation.Component+"']"
                Common_nav_path.Activity_path = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr x-menu-activity']//span[text()='"+Common_navigation.Activity+"']"
            elif Variable_not_resettable.test_properties.get("navigation_option") == "Navigation_1":
                Common_nav_path.Process_path = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr']//span[text()='"+Common_navigation.Process+"']"
                Common_nav_path.Component_path = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr']//span[text()='"+Common_navigation.Component+"']"
                Common_nav_path.Activity_path = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr']//span[text()='"+Common_navigation.Activity+"']"
            else:
                Common_nav_path.Process_path = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr x-menu-bpc']//span[text()='"+Common_navigation.Process+"']"
                Common_nav_path.Component_path = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr x-menu-component']//span[text()='"+Common_navigation.Component+"']"
                Common_nav_path.Activity_path = "//div[@role='menu' and @aria-hidden='false']//div[@class='x-menu-item x-menu-item-default x-box-item x-ltr x-menu-activity']//span[text()='"+Common_navigation.Activity+"']"






def get_data_value(list_dictionary:list, data_ref:str):
    for dict_ in list_dictionary:
        try:
            data_value = dict_[data_ref]
            break
        except Exception as e:
                pass   
    return data_value

def get_value_from_element_ref(element_reference:str):
    index_of_element_ref =  Common_object.controls_dictionary.index(next(filter(lambda n: n.get('Element') == element_reference, Common_object.controls_dictionary)))
    value = Common_object.controls_dictionary[index_of_element_ref]["Value"]
    return value

