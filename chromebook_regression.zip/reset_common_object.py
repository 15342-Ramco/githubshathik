from typing import List
from common_object import Common_controls, Common_data, Common_db_objects, Common_navigation, Common_object, Common_preConfig, Common_scenario, Common_scenario_loops, Common_scenario_loops_list, Common_step, Event_capture_var, Wrapper_variables

def reset_scenario_variables():
    Common_scenario.STEPS_FILE_REFERENCE: str = None
    Common_scenario.STEPS_ID_REFERENCE: str = None
    Common_scenario.DATA_PROVIDER:str = None
    Common_scenario.STEP_FILE: str = None
    Common_scenario.STEP_SHEET: str = None
    Common_scenario.STEP_ID_START : int = None
    Common_scenario.STEP_ID_END : int = None
    Common_scenario.INPUT_TYPE : str = None
    Common_scenario.FLOW_CONFIG_LIST : list = None
    Common_scenario.RTRACK_ID: str = None
    Common_scenario.error_snapshot_file_name = None
    Common_scenario.success_snapshot_file_name: str = None
    Common_scenario.data_provider_count_for_scenario: int = None
    Common_scenario.is_advance_log_done: bool = False
    Common_navigation.previous_process = None
    Common_navigation.previous_Component = None
    Common_navigation.previous_Activity = None
    Common_navigation.Previous_Process_and_component = None
    Common_scenario.xray_test_case_id = None
    
def reset_step_variables():
    Common_step.ACTION: str = None
    Common_step.PAGE_NAME: str = None
    Common_step.DATA_NAME: str = None
    Common_step.STEP_CONFIG: str = None
    Common_step.ELEMENT_REFERENCE: str = None
    Common_step.DATA_REFERENCE: str = None
    Common_step.CONTROL_FILE: str = None
    Common_step.CONTROL_SHEET = None
    Common_step.DATA_FILE: str = None 
    Common_step.DATA_SHEET: str = None
    Common_step.PRE_NAV_CONFIG: list= None
    Common_step.STEP_DESC :str = None
    Common_step.step_id : int = None
    Common_step.step_count :int = 0
    Common_step.step_execution_time : str = None
    Common_step.error_popup_message: str = None
    Common_object.Custom_Error : str = None
    Common_object.Custom_Error_1: str = None
    Common_step.BASE_ACTION: str = None
    #Common_object.Timeout = 3000
    Common_scenario.data_provider_num = 0
    Common_step.SKIP_NAVIGATION = False
    Common_step.SKIP_PRE_CONFIG = False
    Common_object.ImageToString: str = None
    # Common_object.EXECUTION_VIDEO_PATH: str = None
    Common_step.ERROR_SNAPSHOT_FILENAME : str = None
    Common_object.Error_Raised: str = None
    Common_step.is_time_out = False
    Common_step.is_click_done = False
    Common_step.is_pre_config = False
    Common_step.is_nav_config = False
    Common_step.is_switch_context = False
    Common_step.skip_redo = False
    Common_step.multi_select_search_combo_timeout = 10000
    Common_step.multi_short_done_list = None
    Common_step.action_completed_assert_error_popup = None
    Common_step.is_assert_error_popup_completed = False
    Common_object.Error_Popup = None
    Common_step.popup_loop_count = 0
    Common_step.API_ID = None
    Common_step.api_unauthorized_loop_count = 0
    Common_step.Assert_downloaded_excel_column = False
    Common_step.DATA_REFERENCE: str = None
    Common_step.DATA_REFERENCE1: str = None
    Common_step.Second_Action:str=None
    

def reset_common_controls():
    Common_controls.control_Element :str = None
    Common_controls.control_Type : str = None
    Common_controls.control_Identifier : str = None
    Common_controls.control_Value : str = None



def reset_preconfig_variables():
    Common_preConfig.PRECONF_PAGE_NAME: str = None
    Common_preConfig.PRECONF_ELEMENT_REFERENCE: str = None
    Common_preConfig.PRECONF_ACTION: str = None
    Common_preConfig.PRECONF_DATA_NAME: str = None
    Common_preConfig.PRECONF_DATA_REFERENCE: str = None
    Common_preConfig.PRECONF_ACTION: str = None
    Common_preConfig.PRECONF_CONTROL_FILE: str = None
    Common_preConfig.PRECONF_CONTROL_SHEET: str = None
    Common_preConfig.PRECONF_DATA_FILE: str = None
    Common_preConfig.PRECONF_DATA_SHEET: str = None
    Common_preConfig.pre_config_control_elementId: str = None
    Common_preConfig.dataSheet_reference_value: str = None

def reset_data_variables():
    Common_data.data_value : str = None
    Common_data.data_value1 : str = None
    Common_data.data_value2 : str = None

def reset_navigation_variables():
    Common_navigation.Process: str = None
    Common_navigation.Component: str = None
    Common_navigation.Activity: str = None


def reset_Wrapper_variables():
    Wrapper_variables.elementData : str = None
    Wrapper_variables.startsWithId : str = None
    Wrapper_variables.containsId : str = None
    Wrapper_variables.lastIndex: str = None
    Wrapper_variables.patternMatch: str = None
    Wrapper_variables.tiles: str = None
    Wrapper_variables.propType: str = None
    Wrapper_variables.inputValue: str = None
    Wrapper_variables.dataValue1: str = None
    Wrapper_variables.dataValue2: str = None
    Wrapper_variables.dataValue3: str = None
    Wrapper_variables.dataValue4: str = None
    Wrapper_variables.dataValue5: str = None
    Wrapper_variables.objectValue: str = None
    Wrapper_variables.objectValue1: str = None
    Wrapper_variables.objectValue2: str = None
    Wrapper_variables.rowinput1 : str = None
    Wrapper_variables.numberPart: int = 0
    Wrapper_variables.tree: str = "NO"
    Wrapper_variables.frame: str = None
    Wrapper_variables.downloadDefaultPath : str = None
    Wrapper_variables.loopNumber : str = None
    Wrapper_variables.XpathPattern: str = None

def reset_scenario_dict():
    Common_object.scenarios_meta: dict = None
    Common_object.scenarios_dictionary : list[dict]= None
    Common_object.data_provider_list: list = None
    

def reset_step_dict():
    Common_object.steps_dictionary : dict= None

def reset_controls_dict():
    Common_object.controls_dictionary : dict= None

def reset_datasheet_dict():
    Common_object.dataSheet_dictionary : dict = None

def reset_scenario_loops():
    Common_scenario_loops.start_loop_flag = False
    Common_scenario_loops.end_loop_flag = False
    Common_scenario_loops.loop_count: int = None
    Common_scenario_loops.loop_name : str = None


def reset_Common_scenario_loops_list():
    Common_scenario_loops_list.scenarios_in_loop: list = []
    Common_scenario_loops_list.loop_name_dict : dict = {}

def reset_Common_db_objects():
    Common_db_objects.DB_SERVER :str = None
    Common_db_objects.DB_PORT :str = None
    Common_db_objects.DB_PROVIDER :str = None
    Common_db_objects.DB_NAME :str = None


def reset_event_capture_var():
    Event_capture_var.RVWRTQS_COMPONENT_PARENT_1 : str = None
    Event_capture_var.RVWRTQS_ACTIVITY_PARENT_1 : str = None
    Event_capture_var.RVWRTQS_ILBO_PARENT_1 : str = None
    Event_capture_var.RVWRTQS_EVENTNAME_PARENT_1 : str = None
    Event_capture_var.RVWRTQS_COMPONENT_CHILD_1 : str = None
    Event_capture_var.RVWRTQS_ACTIVITY_CHILD_1 : str = None
    Event_capture_var.RVWRTQS_ILBO_CHILD_1 : str = None
    Event_capture_var.RVWRTQS_EVENTNAME_CHILD_1 : str = None

    # Event_capture_var.ECR_VERSION: str = None
    Event_capture_var.Event_turn_count = 0

def reset_variables(): # reset variables after each steps
    reset_step_variables()
    reset_preconfig_variables() 
    reset_data_variables() 
    reset_Wrapper_variables()
    reset_datasheet_dict()
    reset_controls_dict()
    #reset_navigation_variables()
    reset_Common_db_objects()
    reset_common_controls()
    reset_event_capture_var()
    

