from cmath import nan
import os, re, sys
import time
from datetime import datetime
import psutil
import subprocess
import pandas as pd
from common_object import Common_action_list, Common_controls, Common_data, Common_db_objects, Common_main_object, Common_navigation, Common_object, Common_path, Common_scenario, Common_step, Event_capture_var, Parallel_common_object, Variable_not_resettable, draftbill_common_object
from jproperties import Properties
import shutil
import xlwings as xw
from docx import Document
from PyPDF2 import PdfReader
# from pywinauto import Application
# import keyboard
import time
import json
from urllib.parse import urlparse, parse_qs

properties = Properties()

def read_properties_file(filename: str):
    try:
        dict_temp = {}
        with open(filename, 'rb') as read_properties:
            properties.load(read_properties)
        data = dict(properties.items())
        
        for d in data.items():
            dict_temp.update({d[0]: d[1].data})
    except Exception as error:
        pass
    return dict_temp

def split_by_colon(file_sheet_name):
    splitted_list = str(file_sheet_name).split(":")
    splitted_list = [element.strip() for element in splitted_list]
    return splitted_list

def split_by_dash(file_sheet_name):
    splitted_list = str(file_sheet_name).split("-")
    splitted_list = [element.strip() for element in splitted_list]
    return splitted_list
    
def create_folder_not_exist(folder_name: str):
    try:
        if os.path.isdir(folder_name):
            pass
        else:
            os.makedirs(folder_name)
            # print(f"[INFO] : Folder '{folder_name}' created successfully")
    except OSError as error:
        # print(f"[ERROR] : {error}")
        Variable_not_resettable.logger.info(f"[ERROR] : {error}")

def join_path_and_file(path:str, filename:str):
    return os.path.join(path, filename)


def get_current_date_time():
    return datetime.datetime.now()

def get_current_time_Zone():
    return time.tzname[0]

def get_cpu_usage():
    return psutil.cpu_percent()
    
def get_memory_usage():
    return psutil.virtual_memory().percent

def execution_time_calc(fun):
    def inner_function(*filename):
        start_time = time.perf_counter()
        arg = filename
        z = fun(*arg)
        end_time = time.perf_counter()
        # print("Time consumed : " + str(round(end_time - start_time, 2)) + " seconds")
        return z
    return inner_function


def log_list(status):
    if status=="PASS":
        EXECUTION_VIDEO_PATH=None
        Common_object.Custom_Error=None
        Common_step.error_popup_message==None
    elif status=="FAIL":
        if Common_controls.control_Value != None:
            Common_object.Error_Raised=Common_controls.control_Value+' has error'
        EXECUTION_VIDEO_PATH=Common_object.VIDEO_PATH
        if Common_step.error_popup_message==None:
            Common_step.error_popup_message=Common_object.Custom_Error
        #print(str('Error occurred while executing - Filename:'+Common_scenario.STEP_FILE+'; SheetName:'+ Common_scenario.STEP_SHEET+'; STEP_ID:'+Common_step.step_id+'; PAGE_NAME:'+Common_step.PAGE_NAME+'; ELEMENT_REFERENCE:'+Common_step.ELEMENT_REFERENCE+'; ELEMENT_VALUE:'+ Common_controls.control_Value+'; ACTION:'+Common_step.ACTION+'; DATA_NAME:'+Common_step.DATA_NAME+'; DATA_RYEFERENCE:'+Common_step.DATA_REFERENCE+'; DATA_VALUE:'+Common_data.data_value))
        Common_object.Custom_Error_1="Error occurred while executing - Filename:{}; SheetName:{}; STEP_ID:{}; PAGE_NAME:{}; ELEMENT_REFERENCE:{}; ELEMENT_VALUE:{}; ACTION:{}; DATA_NAME:{}; DATA_REFERENCE:{}; DATA_VALUE:{}".format(Common_scenario.STEP_FILE,Common_scenario.STEP_SHEET,str(Common_step.step_id),Common_step.PAGE_NAME,Common_step.ELEMENT_REFERENCE,Common_controls.control_Value,Common_step.ACTION,Common_step.DATA_NAME,Common_step.DATA_REFERENCE,Common_data.data_value).replace("nan", "").replace('None', '')
    
    Common_step.error_popup_message = str(Common_step.error_popup_message) # error data may have different type, so formatted to string here
    
    char_need_to_remove_in_msg_list = ['"', ",", "=", "\n"]
    char_need_to_add_in_msg_list = ["", " ", "", ". "]
    for char_need_to_remove_in_msg, char_need_to_add_in_msg in zip(char_need_to_remove_in_msg_list,char_need_to_add_in_msg_list):
        if Common_object.Error_Raised  != None:
            Common_object.Error_Raised = Common_object.Error_Raised.replace(char_need_to_remove_in_msg, char_need_to_add_in_msg)
        if Common_object.Custom_Error_1 != None:
            Common_object.Custom_Error_1 = Common_object.Custom_Error_1.replace(char_need_to_remove_in_msg, char_need_to_add_in_msg)   
        if Common_step.error_popup_message != None:
            Common_step.error_popup_message = Common_step.error_popup_message.replace(char_need_to_remove_in_msg, char_need_to_add_in_msg)
        if  Common_scenario.RTRACK_ID != None:
             Common_scenario.RTRACK_ID =  Common_scenario.RTRACK_ID.replace(char_need_to_remove_in_msg, char_need_to_add_in_msg)
       
    
    # # Error Message customization 
    # if Common_step.error_popup_message != None:
    #     input_error_popup_message = Common_step.error_popup_message
    #     new_error_popup_message = ""

    #     time_out_patter = "Timeout .* exceeded"
    #     time_out_patter_result = re.findall(time_out_patter, input_error_popup_message)
    #     if time_out_patter_result:
    #         new_error_popup_message = new_error_popup_message +str(time_out_patter_result[0])
    #         Common_step.error_popup_message = new_error_popup_message +"; waiting for selector with control id : "+str(Common_controls.control_Value)+";"
    #         new_error_popup_message = Common_step.error_popup_message
    #     # waiting_for_selector_patter = 'waiting for selector ".*"'
    #     # waiting_for_selector_patter_result = re.findall(waiting_for_selector_patter, input_error_popup_message)
    #     # if waiting_for_selector_patter_result:
    #     #     new_error_popup_message = new_error_popup_message +"waiting for selector with control id : "+str(Common_controls.control_Value)+";"
    #     #     Common_step.error_popup_message = new_error_popup_message

    #     more_element_patter = "selector resolved to .* elements"
    #     more_element_patter_result = re.findall(more_element_patter, input_error_popup_message)
    #     number = "More then one"
    #     if more_element_patter_result:
    #         number = re.findall(r"\d+", more_element_patter_result[0])[0]
    #     if more_element_patter_result:
    #         new_error_popup_message = new_error_popup_message +f" {number} element found for the selector with control id : "+str(Common_controls.control_Value)+";"
    #         Common_step.error_popup_message = new_error_popup_message.strip()
    # print(Common_object.Error_Raised )
    RVWRTQS_DISPATCH = ""
    if Event_capture_var.RVWRTQS_COMPONENT_PARENT_1 == None and Event_capture_var.RVWRTQS_ACTIVITY_PARENT_1 == None and Event_capture_var.RVWRTQS_ILBO_PARENT_1 == None and Event_capture_var.RVWRTQS_EVENTNAME_PARENT_1 == None and Event_capture_var.RVWRTQS_REQID_PARENT_1 == None:
        if Event_capture_var.RVWRTQS_COMPONENT_CHILD_1 == None and Event_capture_var.RVWRTQS_ACTIVITY_CHILD_1 == None and Event_capture_var.RVWRTQS_ILBO_CHILD_1 == None and Event_capture_var.RVWRTQS_EVENTNAME_CHILD_1 == None and Event_capture_var.RVWRTQS_REQID_CHILD_1 != None:
            RVWRTQS_DISPATCH = ""
        elif Event_capture_var.RVWRTQS_COMPONENT_CHILD_1 != None and Event_capture_var.RVWRTQS_ACTIVITY_CHILD_1 != None and Event_capture_var.RVWRTQS_ILBO_CHILD_1 != None and Event_capture_var.RVWRTQS_EVENTNAME_CHILD_1 != None and Event_capture_var.RVWRTQS_REQID_CHILD_1 != None:
            RVWRTQS_DISPATCH = f";{Event_capture_var.RVWRTQS_COMPONENT_CHILD_1}||{Event_capture_var.RVWRTQS_ACTIVITY_CHILD_1}||{ Event_capture_var.RVWRTQS_ILBO_CHILD_1}||{Event_capture_var.RVWRTQS_EVENTNAME_CHILD_1}||{Event_capture_var.RVWRTQS_REQID_CHILD_1}"
    elif Event_capture_var.RVWRTQS_COMPONENT_PARENT_1 != None and Event_capture_var.RVWRTQS_ACTIVITY_PARENT_1 != None and Event_capture_var.RVWRTQS_ILBO_PARENT_1 != None and Event_capture_var.RVWRTQS_EVENTNAME_PARENT_1 != None and Event_capture_var.RVWRTQS_REQID_PARENT_1 != None:
        if Event_capture_var.RVWRTQS_COMPONENT_CHILD_1 == None and Event_capture_var.RVWRTQS_ACTIVITY_CHILD_1 == None and Event_capture_var.RVWRTQS_ILBO_CHILD_1 == None and Event_capture_var.RVWRTQS_EVENTNAME_CHILD_1 == None and Event_capture_var.RVWRTQS_REQID_CHILD_1 == None:
            RVWRTQS_DISPATCH = f"{Event_capture_var.RVWRTQS_COMPONENT_PARENT_1}||{Event_capture_var.RVWRTQS_ACTIVITY_PARENT_1}||{Event_capture_var.RVWRTQS_ILBO_PARENT_1}||{Event_capture_var.RVWRTQS_EVENTNAME_PARENT_1}||{Event_capture_var.RVWRTQS_REQID_PARENT_1};"
        elif Event_capture_var.RVWRTQS_COMPONENT_CHILD_1 != None and Event_capture_var.RVWRTQS_ACTIVITY_CHILD_1 != None and Event_capture_var.RVWRTQS_ILBO_CHILD_1 != None and Event_capture_var.RVWRTQS_EVENTNAME_CHILD_1 != None and Event_capture_var.RVWRTQS_REQID_CHILD_1 != None:
            RVWRTQS_DISPATCH = f"{Event_capture_var.RVWRTQS_COMPONENT_PARENT_1}||{Event_capture_var.RVWRTQS_ACTIVITY_PARENT_1}||{Event_capture_var.RVWRTQS_ILBO_PARENT_1}||{Event_capture_var.RVWRTQS_EVENTNAME_PARENT_1}||{Event_capture_var.RVWRTQS_REQID_PARENT_1};{Event_capture_var.RVWRTQS_COMPONENT_CHILD_1}||{Event_capture_var.RVWRTQS_ACTIVITY_CHILD_1}||{ Event_capture_var.RVWRTQS_ILBO_CHILD_1}||{Event_capture_var.RVWRTQS_EVENTNAME_CHILD_1}||{Event_capture_var.RVWRTQS_REQID_CHILD_1}"
    else:
        RVWRTQS_DISPATCH = ""

    Variable_not_resettable.logger.info(f"RVWRTQS_DISPATCH : {RVWRTQS_DISPATCH}")
    if "Prerequisites" in Common_object.test_config_dictionary and Common_object.test_config_dictionary["Prerequisites"] and Common_object.test_config_dictionary["Prerequisites"] != 'OFF' and 'nan' not in str(Common_object.test_config_dictionary["Prerequisites"]).lower():
 
 
        values_list1 = [
            Common_step.step_count,
            Common_object.test_config_dictionary["TestConfigID"],
            Common_object.test_config_dictionary["ApplicationURL"],
            2.6,
            Common_object.test_config_dictionary["CustomerCode"],
            Common_object.test_config_dictionary["ProductLine"],
            Common_object.test_config_dictionary["CUVersion"],
            Common_object.test_config_dictionary["RTVersion"],
            Common_object.test_config_dictionary["ProductEnvironment"],
            Common_object.test_config_dictionary["GUID"],
            '', #'Enterprise Asset Management'
            Common_object.test_config_dictionary["Browser"],
            Common_object.test_config_dictionary['Prerequisites'],
            '',
            '',
            ''
            ,
            #Common_object.test_config_dictionary['TagsInclude'],
            '',
            # Common_object.test_config_dictionary['TagsExclude'],
            '',
            Common_object.test_config_dictionary['DataTag'],  
            Common_main_object.advance_debug_log_file_name,
            str(Common_object.screen_resolution["width"])+"x"+str(Common_object.screen_resolution["height"]),
            Common_object.test_config_dictionary["ClientName"],
            '',  # 'BUILD_NUMBER'
            Common_object.SCENARIO_FILE_NAME, # 'SCENARIO_FILE_NAME',
            Common_object.scenarios_meta['SCENARIO_ID']+str(Common_scenario.data_provider_count_for_scenario),
            Common_object.scenarios_meta["SCENARIO_TAGS"],
            Common_scenario.STEPS_FILE_REFERENCE,
            Common_scenario.STEPS_ID_REFERENCE,
            str( Common_step.DATA_NAME),  
            str(Common_step.DATA_REFERENCE),
            Common_scenario.STEP_FILE,
            Common_scenario.STEP_SHEET,
            Common_step.step_id,
            Common_step.STEP_TYPE,
            Common_step.XRAY_TEST_CASE_ID,
            Common_step.STEP_DESC,
            Common_step.PAGE_NAME,
            Common_step.ELEMENT_REFERENCE,
            Common_step.BASE_ACTION,
            Common_step.CONTROL_FILE,
            Common_step.CONTROL_SHEET,
            str(Common_controls.control_Type),
            str(Common_controls.control_Identifier),      
            Common_controls.control_Value,
            Common_step.DATA_FILE,
            Common_step.DATA_SHEET,
            Common_data.data_value,  
            Common_navigation.Process,
            Common_navigation.Component,
            Common_navigation.Activity,
            Common_object.FIND_TYPE,
            Common_step.Pre_config_filename,
            Common_step.Pre_config_sheet_name,
            Common_db_objects.DB_SERVER,
            Common_db_objects.DB_PORT,
            Common_db_objects.DB_PROVIDER,
            Common_db_objects.DB_NAME,
            status,
            datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            time.tzname[0],
            Common_step.step_execution_time,
            Common_object.EXECUTION_VERSION_NUMBER,      
            psutil.cpu_percent(),
            psutil.virtual_memory().percent,
            Common_object.Error_Raised,
            Common_object.Custom_Error_1,    
            Common_step.error_popup_message,
            Common_scenario.RTRACK_ID,
            Common_object.PATCH_ID,
            Common_step.ERROR_SNAPSHOT_FILENAME,
            Common_object.ImageToString,
            Variable_not_resettable.FRAME_WORK_VERSION,
            EXECUTION_VIDEO_PATH,
            int(Parallel_common_object.process_id)+1,
            Common_object.test_config_dictionary["ProductCode"],
            Common_step.Response_log_file_name,
            RVWRTQS_DISPATCH,
            Event_capture_var.ECR_VERSION]
    else:
       
        values_list1 = [
            Common_step.step_count,
            Common_object.test_config_dictionary["TestConfigID"],
            Common_object.test_config_dictionary["ApplicationURL"],
            2.6,
            Common_object.test_config_dictionary["CustomerCode"],
            Common_object.test_config_dictionary["ProductLine"],
            Common_object.test_config_dictionary["CUVersion"],
            Common_object.test_config_dictionary["RTVersion"],
            Common_object.test_config_dictionary["ProductEnvironment"],
            Common_object.test_config_dictionary["GUID"],
            '', #'Enterprise Asset Management'
            Common_object.test_config_dictionary["Browser"],
            Common_object.test_config_dictionary['FoldersInclude'],
            Common_object.test_config_dictionary['FoldersExclude'],
            Common_object.test_config_dictionary['FilesNameInclude'],
            Common_object.test_config_dictionary['FilesNameExclude'],
            #Common_object.test_config_dictionary['TagsInclude'],
            ', '.join(Common_object.test_config_dictionary['TagsInclude']),
            # Common_object.test_config_dictionary['TagsExclude'],
            ', '.join( Common_object.test_config_dictionary['TagsExclude']),
            Common_object.test_config_dictionary['DataTag'],  
            Common_main_object.advance_debug_log_file_name,
            str(Common_object.screen_resolution["width"])+"x"+str(Common_object.screen_resolution["height"]),
            Common_object.test_config_dictionary["ClientName"],
            '',  # 'BUILD_NUMBER'
            Common_object.SCENARIO_FILE_NAME, # 'SCENARIO_FILE_NAME',
            Common_object.scenarios_meta['SCENARIO_ID']+str(Common_scenario.data_provider_count_for_scenario),
            Common_object.scenarios_meta["SCENARIO_TAGS"],
            Common_scenario.STEPS_FILE_REFERENCE,
            Common_scenario.STEPS_ID_REFERENCE,
            str( Common_step.DATA_NAME),  
            str(Common_step.DATA_REFERENCE),
            Common_scenario.STEP_FILE,
            Common_scenario.STEP_SHEET,
            Common_step.step_id,
            Common_step.STEP_TYPE,
            Common_step.XRAY_TEST_CASE_ID,
            Common_step.STEP_DESC,
            Common_step.PAGE_NAME,
            Common_step.ELEMENT_REFERENCE,
            Common_step.BASE_ACTION,
            Common_step.CONTROL_FILE,
            Common_step.CONTROL_SHEET,
            str(Common_controls.control_Type),
            str(Common_controls.control_Identifier),      
            Common_controls.control_Value,
            Common_step.DATA_FILE,
            Common_step.DATA_SHEET,
            Common_data.data_value,  
            Common_navigation.Process,
            Common_navigation.Component,
            Common_navigation.Activity,
            Common_object.FIND_TYPE,
            Common_step.Pre_config_filename,
            Common_step.Pre_config_sheet_name,
            Common_db_objects.DB_SERVER,
            Common_db_objects.DB_PORT,
            Common_db_objects.DB_PROVIDER,
            Common_db_objects.DB_NAME,
            status,
            datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            time.tzname[0],
            Common_step.step_execution_time,
            Common_object.EXECUTION_VERSION_NUMBER,      
            psutil.cpu_percent(),
            psutil.virtual_memory().percent,
            Common_object.Error_Raised,
            Common_object.Custom_Error_1,    
            Common_step.error_popup_message,
            Common_scenario.RTRACK_ID,
            Common_object.PATCH_ID,
            Common_step.ERROR_SNAPSHOT_FILENAME,
            Common_object.ImageToString,
            Variable_not_resettable.FRAME_WORK_VERSION,
            EXECUTION_VIDEO_PATH,
            int(Parallel_common_object.process_id)+1,
            Common_object.test_config_dictionary["ProductCode"],
            Common_step.Response_log_file_name,
            RVWRTQS_DISPATCH,
            Event_capture_var.ECR_VERSION]


    # values_list1 = [
    #     Common_step.step_count,
    #     Common_object.test_config_dictionary["TestConfigID"],
    #     Common_object.test_config_dictionary["ApplicationURL"],
    #     2.6,
    #     Common_object.test_config_dictionary["CustomerCode"],
    #     Common_object.test_config_dictionary["ProductLine"],
    #     Common_object.test_config_dictionary["CUVersion"],
    #     Common_object.test_config_dictionary["RTVersion"],
    #     Common_object.test_config_dictionary["ProductEnvironment"],
    #     Common_object.test_config_dictionary["GUID"],
    #     '', #'Enterprise Asset Management'
    #     Common_object.test_config_dictionary["Browser"], 
    #     Common_object.test_config_dictionary['FoldersInclude'],
    #     Common_object.test_config_dictionary['FoldersExclude'], 
    #     Common_object.test_config_dictionary['FilesNameInclude'],
    #     Common_object.test_config_dictionary['FilesNameExclude'], 
    #     #Common_object.test_config_dictionary['TagsInclude'], 
    #     ', '.join(Common_object.test_config_dictionary['TagsInclude']),
    #     # Common_object.test_config_dictionary['TagsExclude'], 
    #     ', '.join( Common_object.test_config_dictionary['TagsExclude']),
    #     Common_object.test_config_dictionary['DataTag'],  
    #     Common_main_object.advance_debug_log_file_name,
    #     str(Common_object.screen_resolution["width"])+"x"+str(Common_object.screen_resolution["height"]),
    #     Common_object.test_config_dictionary["ClientName"], 
    #     '',  # 'BUILD_NUMBER'
    #     Common_object.SCENARIO_FILE_NAME, # 'SCENARIO_FILE_NAME',
    #     Common_object.scenarios_meta['SCENARIO_ID']+str(Common_scenario.data_provider_count_for_scenario), 
    #     Common_object.scenarios_meta["SCENARIO_TAGS"],
    #     Common_scenario.STEPS_FILE_REFERENCE, 
    #     Common_scenario.STEPS_ID_REFERENCE, 
    #     str( Common_step.DATA_NAME),  
    #     str(Common_step.DATA_REFERENCE), 
    #     Common_scenario.STEP_FILE, 
    #     Common_scenario.STEP_SHEET, 
    #     Common_step.step_id,
    #     Common_step.STEP_TYPE, 
    #     Common_step.XRAY_TEST_CASE_ID,
    #     Common_step.STEP_DESC, 
    #     Common_step.PAGE_NAME,
    #     Common_step.ELEMENT_REFERENCE,
    #     Common_step.BASE_ACTION, 
    #     Common_step.CONTROL_FILE, 
    #     Common_step.CONTROL_SHEET, 
    #     str(Common_controls.control_Type), 
    #     str(Common_controls.control_Identifier),      
    #     Common_controls.control_Value, 
    #     Common_step.DATA_FILE, 
    #     Common_step.DATA_SHEET, 
    #     Common_data.data_value,   
    #     Common_navigation.Process, 
    #     Common_navigation.Component, 
    #     Common_navigation.Activity, 
    #     Common_object.FIND_TYPE,
    #     Common_step.Pre_config_filename, 
    #     Common_step.Pre_config_sheet_name, 
    #     Common_db_objects.DB_SERVER,
    #     Common_db_objects.DB_PORT,
    #     Common_db_objects.DB_PROVIDER,
    #     Common_db_objects.DB_NAME,
    #     status, 
    #     datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
    #     time.tzname[0], 
    #     Common_step.step_execution_time, 
    #     Common_object.EXECUTION_VERSION_NUMBER,       
    #     psutil.cpu_percent(), 
    #     psutil.virtual_memory().percent, 
    #     Common_object.Error_Raised, 
    #     Common_object.Custom_Error_1,    
    #     Common_step.error_popup_message, 
    #     Common_scenario.RTRACK_ID,
    #     Common_object.PATCH_ID,
    #     Common_step.ERROR_SNAPSHOT_FILENAME,
    #     Common_object.ImageToString,
    #     Variable_not_resettable.FRAME_WORK_VERSION,
    #     EXECUTION_VIDEO_PATH,
    #     int(Parallel_common_object.process_id)+1,
    #     Common_object.test_config_dictionary["ProductCode"],
    #     Common_step.Response_log_file_name,
    #     RVWRTQS_DISPATCH,
    #     Event_capture_var.ECR_VERSION]
        
    values_list=[]
    for i in range(len(values_list1)):
        values_list1[i] = str(values_list1[i]).replace("\n", " ").replace("\t", " ")
        if values_list1[i] != None:
            values_list1[i] = str(values_list1[i])
        if values_list1[i]=='nan' or values_list1[i]=='NaN' or values_list1[i]== str(None) or values_list1[i]== "NA" or values_list1[i]== None:
            values_list1[i]=""
            values_list.append(values_list1[i])
        else:
            values_list.append(values_list1[i])
    return values_list


def draftbill(scenarios_folder_list):
    wordlist = ["Dependent1", "Dependent2", "Dependent3"]
    # res = []
    # for i in wordlist:
    #     subres = [string for string in scenarios_folder_list if i in string]
    #     res.append(subres)
    # list_of_dependencies_folders = list(itertools.chain(*res))
    list_of_draftbill_folders = []
    for word in wordlist:
        if word in scenarios_folder_list:
            list_of_draftbill_folders.append(word)
    # print(list_of_draftbill_folders)
    if len(list_of_draftbill_folders)==3:
        draftbill_common_object.draftflag=True
    else:
        draftbill_common_object.draftflag=False


def executionstop(scenarios_file):
    # and draftbill_common_object.draftflag == True:
    if "Dependent1" in scenarios_file and draftbill_common_object.draftflag == True:
        return True
    else:
        return False

def get_date_format(date_input: str):
    date_format_list = ["%d %b %Y", "%d %B %Y","%d %b %y", "%d %B %y", "%d-%m-%Y", "%d/%m/%Y", "%d-%m-%y", "%d/%m/%y", 
    "%Y %d %b", "%Y %d %B","%y %d %b", "%y %d %B","%Y/%m/%d", "%Y-%m-%d", "%y/%m/%d", "%y-%m-%d", 
    "%d %b %Y %H:%M:%S", "%d %B %Y %H:%M:%S","%d %b %y %H:%M:%S", "%d %B %y %H:%M:%S","%d-%m-%Y %H:%M:%S", "%d/%m/%Y %H:%M:%S", "%d-%m-%y %H:%M:%S", "%d/%m/%y %H:%M:%S",
    "%Y %d %b %H:%M:%S", "%Y %d %B %H:%M:%S","%y %d %b %H:%M:%S", "%y %d %B %H:%M:%S","%Y/%m/%d %H:%M:%S", "%Y-%m-%d %H:%M:%S", "%y/%m/%d %H:%M:%S", "%y-%m-%d %H:%M:%S", 
    "%d %b %Y %H:%M:%S%z", "%d %B %Y %H:%M:%S%z","%d %b %y %H:%M:%S%z", "%d %B %y %H:%M:%S%z","%d-%m-%Y %H:%M:%S%z", "%d/%m/%Y %H:%M:%S%z", "%d-%m-%y %H:%M:%S%z", "%d/%m/%y %H:%M:%S%z",
    "%Y %d %b %H:%M:%S%z", "%Y %d %B %H:%M:%S%z","%y %d %b %H:%M:%S%z", "%y %d %B %H:%M:%S%z","%Y/%m/%d %H:%M:%S%z", "%Y-%m-%d %H:%M:%S%z", "%y/%m/%d %H:%M:%S%z", "%y-%m-%d %H:%M:%S%z",
    "%d %b %Y %H:%M:%S%Z", "%d %B %Y %H:%M:%S%Z","%d %b %y %H:%M:%S%Z", "%d %B %y %H:%M:%S%Z","%d-%m-%Y %H:%M:%S%Z", "%d/%m/%Y %H:%M:%S%Z", "%d-%m-%y %H:%M:%S%Z", "%d/%m/%y %H:%M:%S%Z",
    "%Y %d %b %H:%M:%S%Z", "%Y %d %B %H:%M:%S%Z","%y %d %b %H:%M:%S%Z", "%y %d %B %H:%M:%S%Z","%Y/%m/%d %H:%M:%S%Z", "%Y-%m-%d %H:%M:%S%Z", "%y/%m/%d %H:%M:%S%Z", "%y-%m-%d %H:%M:%S%Z",
    "%d-%b-%Y", "%d-%B-%Y","%d-%b-%y", "%d-%B-%y", "%Y-%m-%d %H:%M:%S.%f", "%Y/%m/%d %H:%M:%S.%f", "%Y %m %d %H:%M:%S.%f", "%d-%m-%y %I:%M:%S %p", "%d/%m/%y %I:%M:%S %p", 
    "%d-%m-%Y %I:%M:%S %p", "%d/%m/%Y %I:%M:%S %p", "%I:%M:%S %p", "%H:%M:%S", "%H:%M", "%d+%m+%Y", "%m/%Y"]
    for date_format in date_format_list:
        try:
            temp_var = datetime.strptime(date_input, date_format)
            print("Input Date formate : ", date_format)
            return date_format
        except:
            pass

def get_date_format_from_application(element_str_input):
    date_format = element_str_input
    if Variable_not_resettable.APP_TYPE == "Nebula co-existence":
        date_format = element_str_input
        li_1 = ["DD", "D","MMM", "MM","YYYY","hh","mm","ss","tt",]
        li_2 = ["%d", "%d","%b", "%m", "%Y", "%I", "%M", "%S", "%p"]
        for each_li_1, each_li_2 in zip(li_1,li_2):
            date_format = date_format.replace(each_li_1, each_li_2)
        Variable_not_resettable.logger.info("Date formate required in application : "+ str(date_format))
        return date_format
    else:
        date_format = date_format.split("format")[1].strip()
        li_1 = ["DD","MM","YYYY","hh","mm","ss","tt"]
        li_2 = ["%d", "%m", "%Y", "%I", "%M", "%S", "%p"]
        for each_li_1, each_li_2 in zip(li_1,li_2):
            date_format = date_format.replace(each_li_1, each_li_2)
        Variable_not_resettable.logger.info("Date formate required in application : "+ str(date_format))
        return date_format

def get_date_with_right_formate(file_name, sheet_name, column_name_input, cell_row):
    column_name = column_name_input.lower()
    try:
        excel_path =  Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx"
        app1 = xw.App()
        app1.visible = False
        app1.display_alerts = False
        Variable_not_resettable.logger.info("Excel application process id : "+ str(app1.pid))
        Variable_not_resettable.logger.info("Excel version : "+ str(app1.version))
        wb_1 = app1.books.open(excel_path, update_links=False, ignore_read_only_recommended=True)
        ws_1 = wb_1.sheets[sheet_name]
        wb_1.save()
        wb_1.close()
        app1.quit()
        app1.kill()

        df = pd.read_excel(excel_path, sheet_name= sheet_name, dtype="str")
        date = df.to_dict("records")
        date = Common_object.dataSheet_dictionary
        Variable_not_resettable.logger.info("Date in from data sheet: "+ str(date[cell_row][column_name]))
        return date[cell_row][column_name]
    except Exception as error:
        Variable_not_resettable.logger.info(str(error))
        app1.quit()
        app1.kill()
        raise Exception("Unable to read the date from Excel, Reason "+ str(error))

        
        

def get_final_date(element_str_input, date):
    return_value = None
    try:
        input_format = get_date_format(date)
        output_format = get_date_format_from_application(element_str_input)
        return_value =  datetime.strptime(date, input_format).strftime(output_format)
        return return_value
    except Exception as error:
        Variable_not_resettable.logger.debug(str(error))
        return return_value



# def get_date_with_right_formate(file_name, sheet_name, column_name_input, cell_row):
#     column_name = column_name_input.lower()
#     print(file_name, sheet_name, column_name, cell_row)
#     excel = win32com.client.Dispatch("Excel.Application")
#     # print(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx")
#     excel.DisplayAlerts = False
#     excel.Visible = False
#     excel.AskToUpdateLinks = False
#     # excel.DisplayAlerts = False
#     wb = excel.Workbooks.Open(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx", UpdateLinks=False)
#     ws = wb.Worksheets(sheet_name) 
#     find_column_name = ws.Rows("1").Find(What=column_name, LookAt = 1)
#     address_obj = find_column_name.Address
#     address = address_obj.replace("$", "")
#     column_ref = ws.Range(address).Column
#     data_value = ws.Cells(cell_row+2,column_ref).Value
#     data_Formula = ws.Cells(cell_row+2,column_ref).Formula
#     wb.Close()
#     excel.Quit()
#     # print("Value : ",data_value)
#     # print("Formula : ",data_Formula)
#     if "=TODAY()" in data_Formula:
#         # print(1)
#         data_value = datetime.strftime(data_value,"%d-%m-%Y")
#         return data_value
#     elif "=NOW()" in data_Formula:
#         # print(2)
#         data_value = datetime.strftime(data_value,"%d-%m-%Y %H:%M:%S")
#         return data_value
#     elif "=TEXT" in data_Formula:
#         # print(3)
#         return data_value
#     else:
#         return data_value


# def get_date_with_right_formate(file_name, sheet_name, column_name, cell_row):
#     print(file_name, sheet_name, column_name, cell_row)
#     excel = win32com.client.gencache.EnsureDispatch('Excel.Application')
#     print(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx")
#     wb = excel.Workbooks.Open(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx", UpdateLinks=False)
#     ws = wb.Worksheets(sheet_name) 
#     find_column_name = ws.Rows("1").Find(What=column_name, LookAt = 1)
#     address_obj = find_column_name.Address
#     address = address_obj.replace("$", "")
#     column_ref = ws.Range(address).Column
#     excel.Visible = True

#     data_value = ws.Cells(cell_row+2,column_ref).Value
#     data_Formula = ws.Cells(cell_row+2,column_ref).Formula
#     print("Value : ",data_value)
#     print("Formula : ",data_Formula)
#     if "=TODAY()" in data_Formula:
#         print(1)
#         data_value = datetime.strftime(data_value,"%d-%m-%Y")
#         wb.Close()
#         return data_value
#     elif "=NOW()" in data_Formula:
#         print(2)
#         data_value = datetime.strftime(data_value,"%d-%m-%Y %H:%M:%S")
#         wb.Close()
#         return data_value
#     elif "=TEXT" in data_Formula:
#         print(3)
#         wb.Close()
#         return data_value
#     else:
#         temp_data = data_value
#         # 29/09/2022
#         data_value = data_value.split(" ")
#         if len(data_value) == 1:
#             wb.Close()
#             try:
#                 date_formate = get_date_format(temp_data)
#                 return datetime.strptime(temp_data, date_formate).strftime("%d/%m/%Y")
#             except:
#                 try:
#                     date_formate = get_date_format(temp_data)
#                     return datetime.strptime(temp_data, date_formate).strftime("%d/%m/%Y")
#                 except:
#                     return temp_data
#         elif len(data_value) == 2:
#             if "1" in data_value[1] or "2" in data_value[1] or "3" in data_value[1] or "4" in data_value[1] or "5" in data_value[1] or "6" in data_value[1] or "7" in data_value[1] or "8" in data_value[1] or "9" in data_value[1]: 
#                 wb.Close()
#                 return temp_data
#             else:
#                 wb.Close()
#                 return data_value[0]
#         else:
#             wb.Close()
#             return data_value

def get_date_format_from_system():
    command = "date"
    proc = subprocess.Popen(command, shell=True, stdout =subprocess.PIPE)
    # print(proc.pid)
    Variable_not_resettable.logger.info(str(proc.pid))
    out, err  = proc.communicate()[0]
    date = out.decode("utf-8")
    start_index = out.find("(")
    end_index = out.find(")")
    system_date_format = out[start_index+1: end_index]
    symbol = date[2]
    date_format = '%d' +symbol+'%m'+symbol+'%Y'
    subprocess.Popen.kill(proc)
    return date_format



# def get_date_with_right_formate(file_name, sheet_name, column_name, cell_row):
#     try:
#         excel = win32com.client.gencache.EnsureDispatch("Excel.Application")
#         excel.DisplayAlerts = False
#         excel.Visible = False
#         wb = excel.Workbooks.Open(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx", UpdateLinks=False)
#         wb.AskToUpdateLinks = False
#         wb.DisplayAlerts = False
#         ws = wb.Worksheets(sheet_name)
#         excel.DisplayAlerts = False
#         wb.Save()
#         wb.Close()
#         excel.Quit()
#         file_path = Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx"
#         df = pd.read_excel(filepath=file_path, sheet_name=sheet_name)
#         df_data = df.to_dict()
#         df_date = df_data[cell_row][column_name]
#         income_date_formate = get_date_format(df_date)
#         return df_date, income_date_formate
#     except Exception as error:
#         print(str(error))
#         raise Exception(str(error))



# def get_date_with_right_formate_temp(file_name, sheet_name, column_name, cell_row):
#     excel = win32com.client.gencache.EnsureDispatch("Excel.Application")
#     excel.DisplayAlerts = False
#     excel.Visible = False
#     wb = excel.Workbooks.Open(Common_path.dataSheet_path+"\\"+Common_object.test_config_dictionary["DataTag"]+"\\"+file_name+".xlsx", UpdateLinks=False)
#     wb.AskToUpdateLinks = False
#     wb.DisplayAlerts = False
#     ws = wb.Worksheets(sheet_name)
#     excel.DisplayAlerts = False
#     find = ws.Rows("1").Find(What=column_name, LookAt = 1)
#     address_obj = find.Address
#     address = address_obj.replace("$", "")
#     column_num = ws.Range(address).Column
#     column_index = address_obj.split("$")[1]
#     print("Normal : ",ws.Cells(cell_row+2,column_num).Value)
#     data_value = ws.Cells(cell_row+2,column_num).Value
#     Formula = ws.Cells(cell_row+2,column_num).Formula
#     # Formula = ws.Range(column_index + '3').Formula
#     print("Formula:",ws.Cells(cell_row+2,column_num).Formula)
#     date_format = Common_main_object.system_date_format
#     return_value = None
#     try:
#         if "=NOW" in str(Formula):
#             print("Now Formula")
#             data = ws.Cells(cell_row+2,column_num).Value
#             need_date_format = date_format + " " + "%H:%M:%S"
#             data = str(ws.Cells(cell_row+2,column_num).Value.strftime(need_date_format))
#             wb.Close()
#             return_value =  data
#         elif "=TODAY" in str(Formula):
#             print("Today Formula")
#             data = ws.Cells(cell_row+2,column_num).Value
#             data = str(ws.Cells(cell_row+2,column_num).Value.strftime(date_format))
#             wb.Close()
#             return_value =  data
#         elif "=TEXT" in str(Formula):
#             print("Text Formula")
#             data = ws.Cells(cell_row+2,column_num).Value
#             wb.Close()
#             return_value =  data
#         else:
#             if data_value == "" or data_value == None or str(data_value) == "nan":
#                 wb.Close()
#                 return_value = ""
#             elif data_value != "" or data_value != None or str(data_value) != "nan":
#                 ws.Columns(column_index + ':' + column_index).TextToColumns(Destination=ws.Range(column_index + "1"), DataType=1, TextQualifier=1, FieldInfo=(column_num, 2))
#                 data_value = ws.Cells(cell_row+2,column_num).Value   
#                 temp_data = data_value
#                 data_value = data_value.split(" ")
#                 if len(data_value) == 1:
#                     wb.Close()
#                     input_date_format = get_date_format(temp_data)
#                     return_value =  datetime.strptime(temp_data, input_date_format).strftime(date_format)

#                 elif len(data_value) == 2:
#                     if "1" in data_value[1] or "2" in data_value[1] or "3" in data_value[1] or "4" in data_value[1] or "5" in data_value[1] or "6" in data_value[1] or "7" in data_value[1] or "8" in data_value[1] or "9" in data_value[1]: 
#                         wb.Close()
#                         input_date_format = get_date_format(temp_data)
#                         return_value =  datetime.strptime(temp_data, input_date_format).strftime(date_format+" %H:%M:%S")
#                     else:
#                         wb.Close()
#                         input_date_format = get_date_format(temp_data)
#                         return_value =  datetime.strptime(temp_data, input_date_format).strftime(date_format)
#                 else:
#                     wb.Close()
#                     input_date_format = get_date_format(temp_data)
#                     return_value =  datetime.strptime(temp_data, input_date_format).strftime(date_format)
#     except Exception as error:
#         wb.Close()
#         print(error)
#         raise Exception(str(error))
#     print("Return value from get date function : ", return_value)
#     wb.Close()
#     return return_value
    

def delete_gen_py_folder():
    user_path = os.path.expanduser("~")
    temp_path = "\\AppData\\Local\\Temp"
    gen_py_path = user_path+temp_path
    data = os.listdir(gen_py_path)
    # print(data)
    for d in data:
        try:
            if "tmp" in str(d)[0:3] or "gen_py" in str(d):
                # print(d)
                Variable_not_resettable.logger(str(d))
                # shutil.rmtree(user_path+temp_path+"\\"+d+"\\gen_py")
                shutil.rmtree(user_path+temp_path+"\\"+d)
        except Exception as error:
            # print(error)
            Variable_not_resettable.logger.info(str(error))
            pass
    time.sleep(1)




def test_runner_config_validator(data: list[dict]):
    error_count = 0
    fields_in_excel = [d["TEST_CONFIG_KEY"] for d in data]
    required_fields = ['TestConfigID', 'TestConfigName', 'ApplicationURL', 'Browser', 'FoldersInclude', 'FoldersExclude', 'FilesNameInclude', 'FilesNameExclude', 'TagsInclude', 'TagsExclude', 'DataTag', 'JSThemeType', 'ClientName', 'Rtrack', 'CustomerCode', 'ProductLine', 'CUVersion', 'RTVersion', 'ProductEnvironment', 'GUID', 'DBConfig', 'ParallelExecution', 'VIDEOS']
    for required_field in required_fields:
        if required_field in fields_in_excel:
            pass
        else:
            error_count = error_count +1
            # print("["+required_field + "] field is missing in TestRunnerConfig.xlsx")
            Variable_not_resettable.logger.info("["+str(required_field) + "] field is missing in TestRunnerConfig.xlsx")
    for field_in_excel in fields_in_excel:
        if field_in_excel in required_fields:
            pass
        else:
            error_count = error_count +1
            # print("The given field ["+ field_in_excel + "] is incorrect in TestRunnerConfig.xlsx")
            Variable_not_resettable.logger.info("The given field ["+ str(field_in_excel) + "] is incorrect in TestRunnerConfig.xlsx")
    if error_count != 0:
        raise Exception("Check the TestRunnerConfig.xlsx file")

# def remove_folder(folder_path):
#     try:    
#         if os.path.exists(folder_path):   
#             shutil.rmtree(folder_path)
#             print(f"Folder '{folder_path}' removed successfully.")
#         else:
#             print(f"Folder '{folder_path}' does not exist.")
#     except Exception as removeerror:
#         time.sleep(0.1)
#         try:    
#             if os.path.exists(folder_path):
#                 shutil.rmtree(folder_path)
#                 print(f"Folder '{folder_path}' removed successfully.")
#             else:
#                 print(f"Folder '{folder_path}' does not exist.")
#         except Exception as removeerror:
#             time.sleep(0.1)
#             try:    
#                 if os.path.exists(folder_path):
#                     shutil.rmtree(folder_path)
#                     print(f"Folder '{folder_path}' removed successfully.")
#                 else:
#                     print(f"Folder '{folder_path}' does not exist.")
#             except Exception as removeerror:
#                 print(removeerror)

def remove_folder(folder_path):
    try:    
        if os.path.exists(folder_path):   
            shutil.rmtree(folder_path)
            print(f"Folder '{folder_path}' removed successfully.")
        else:
            print(f"Folder '{folder_path}' does not exist.")
    except Exception as removeerror:
        time.sleep(1)
        try:    
            if os.path.exists(folder_path):
                shutil.rmtree(folder_path)
                print(f"Folder '{folder_path}' removed successfully.")
            else:
                print(f"Folder '{folder_path}' does not exist.")
        except Exception as removeerror:
            time.sleep(1)
            try:    
                if os.path.exists(folder_path):
                    shutil.rmtree(folder_path)
                    print(f"Folder '{folder_path}' removed successfully.")
                else:
                    print(f"Folder '{folder_path}' does not exist.")
            except Exception as removeerror:
                raise Exception (removeerror)

# def return_excel_object():
#     app1 = xw.App()
#     app1.visible = False
#     app1.display_alerts = False
#     app_id = app1.pid
#     # print("Excel application process id : ", app_id)
#     Variable_not_resettable.logger.info("Excel application process id : "+ str(app_id))
#     time.sleep(2)
#     try:
#         app = Application().connect(process=app_id)
#         app.top_window().set_focus()
#         keyboard.press('alt')
#         keyboard.press('f4')
#         keyboard.release('f4')
#         keyboard.release('alt')
#     except Exception as error:
#         # print(str(error))
#         Variable_not_resettable.logger.info(str(error))
#     # app1.visible = False
#     return app1


def get_alphabet(input_number):
    number = input_number+1
    column_char = ""
    while number > 0:
        number, remainder = divmod(number-1, 26)
        column_char = chr(65 + remainder) + column_char
    return column_char

# print(get_alphabet(0))


def make_directory(directory_path):
    try:
        os.makedirs(directory_path)
        return True
    except Exception as error:
        return False


def check_action_available(input_action):
    # Variable_not_resettable.logger.info("Checking action ..............................")
    if input_action in Common_action_list.all_action:
        return True
    else:
        exe_str = f"Incorrect action '{input_action}' given in step sheet"
        # Variable_not_resettable.logger.info(exe_str)
        raise Exception(exe_str)


def xpath_text_quotes_handler(dataValue: str):
    if dataValue.find("'") != -1:
        dataValue = '"'+dataValue+'"'
    elif dataValue.find('"') != -1:
        dataValue = "'"+dataValue+"'"
    else:
        dataValue = '"'+dataValue+'"'
    return dataValue



def error_popup_message_customization():
    if Common_step.error_popup_message != None:
        input_error_popup_message = Common_step.error_popup_message
        new_error_popup_message = ""

        time_out_patter = "Timeout .* exceeded"
        time_out_patter_result = re.findall(time_out_patter, input_error_popup_message)
        if time_out_patter_result:
            new_error_popup_message = new_error_popup_message +str(time_out_patter_result[0])
            Common_step.error_popup_message = new_error_popup_message +"; waiting for selector with control id : "+str(Common_controls.control_Value)+";"
            new_error_popup_message = Common_step.error_popup_message

            # ******************** New requirement added *********************
            # Common_step.error_popup_message = str(Common_controls.control_Value) + ": Element was not found "  
            # new_error_popup_message = Common_step.error_popup_message
            #  ***************************************************************

            
        # waiting_for_selector_patter = 'waiting for selector ".*"'
        # waiting_for_selector_patter_result = re.findall(waiting_for_selector_patter, input_error_popup_message)
        # if waiting_for_selector_patter_result:
        #     new_error_popup_message = new_error_popup_message +"waiting for selector with control id : "+str(Common_controls.control_Value)+";"
        #     Common_step.error_popup_message = new_error_popup_message

        more_element_patter = "resolved to .* elements"
        more_element_patter_result = re.findall(more_element_patter, input_error_popup_message)
        number = "More then one"
        if more_element_patter_result:
            number = re.findall(r"\d+", more_element_patter_result[0])[0]
        if more_element_patter_result:
            new_error_popup_message = new_error_popup_message +f" {number} element found for the selector with control id : "+str(Common_controls.control_Value)+";"
            Common_step.error_popup_message = new_error_popup_message.strip()


def pdf_validator(pdf_file_path: str):
    error_str = "PDF is empty"
    reader = PdfReader(pdf_file_path)
    number_of_pages = len(reader.pages)
    if number_of_pages > 0:
        page = reader.pages[0]
        text = page.extract_text()
        if len(text) > 0:
            Variable_not_resettable.logger.info("PDF is not empty")
        else:
            raise Exception(error_str)
    else:
        raise Exception(error_str)
            

def get_cmd_input_params(arg_list):
    for arg in arg_list:
        if "/testType" in arg:
            if "=" in arg:
                testType_value = ((arg.split("="))[1]).strip()     
                Variable_not_resettable.logger.info(f"testType_value : {testType_value}")           
        elif "/patchGUID" in arg:
            if "=" in arg:
                patchGUID_value = ((arg.split("="))[1]).strip()
                Common_object.PATCH_ID = patchGUID_value
                Variable_not_resettable.logger.info(f"patchGUID_value : {patchGUID_value}")  
        elif ("[" in arg) and ("]" in arg):
            print("arg : ", arg)
            Common_object.scenario_list_filter = str(arg).replace("[","").replace("]","")
            # Common_object.scenario_list_filter = str(Common_object.scenario_list_filter).split(",")
            Common_object.Macros_filter_enabled =  True
        else:
            Variable_not_resettable.logger.error(f"Incorrect input parameter") 
    return True

def writing_html_log(html_content):
    output_folder = os.path.join(os.getcwd(),"temp\\html_output")
    make_directory(output_folder)
    file_path = os.path.join(output_folder,str(Common_object.scenarios_meta["SCENARIO_ID"])+"_"+(str(datetime.now().replace(microsecond=0))).replace(":", "_")+".html")
    
    try:
        with open(file_path,"w",encoding="utf-8") as file:
            file.write(html_content)
            file.close()
    except:
        pass




def document_validator(doc_file_path: str):
    try:
        # Load the Word document
        doc = Document(doc_file_path)
        
        # Check if the document is empty (no paragraphs or text)
        if not doc.paragraphs or all(paragraph.text.strip() == '' for paragraph in doc.paragraphs):
            print('The document is empty')
            raise Exception("The document is empty")
        else:
            print('The document has content')
            
    except Exception as error:
        print(f"Error: {str(error)}")


def csv_validator(csv_file_path: str):
    error_str = "CSV is empty"    
    reader_df = pd.read_csv(csv_file_path).fillna("")
    column_headers = reader_df.columns    
    dict_of_reader_df = reader_df.to_dict("records")
    content_in_CSV = []
    for each_dict in dict_of_reader_df:
        for header in column_headers:
            content = each_dict[str(header)]
            if content != "":
               content_in_CSV.append(content) 
        if len(content_in_CSV) > 0:
            break
    # print(content_in_CSV)    
    if len(content_in_CSV) > 0:
        Variable_not_resettable.logger.info("CSV is not empty")
    else:
        Variable_not_resettable.logger.info("CSV is empty")
        raise Exception(error_str)


def handle_response(response):
        parsed_url = urlparse(response.url)
        query_params = parse_qs(parsed_url.query)
        try:
            if "/dispatcher.aspx" in str(parsed_url):
                RVWRTQS_COMPONENT = query_params.get('RVWRTQS_COMPONENT')[0]
                RVWRTQS_ACTIVITY = query_params.get('RVWRTQS_ACTIVITY')[0]
                RVWRTQS_ILBO = query_params.get('RVWRTQS_ILBO')[0]
                RVWRTQS_EVENTNAME = query_params.get('RVWRTQS_EVENTNAME')[0]
                RVWRTQS_REQID = query_params.get('RVWRTQS_REQID')[0]

                Variable_not_resettable.logger.info(f"RVWRTQS_COMPONENT: {RVWRTQS_COMPONENT}")
                Variable_not_resettable.logger.info(f"RVWRTQS_ACTIVITY: {RVWRTQS_ACTIVITY}")
                Variable_not_resettable.logger.info(f"RVWRTQS_ILBO: {RVWRTQS_ILBO}")
                Variable_not_resettable.logger.info(f"RVWRTQS_EVENTNAME: {RVWRTQS_EVENTNAME}")
                Variable_not_resettable.logger.info(f"RVWRTQS_REQID: {RVWRTQS_REQID}")

                if Event_capture_var.Event_turn_count == 0:
                    Event_capture_var.RVWRTQS_COMPONENT_PARENT_1 = RVWRTQS_COMPONENT
                    Event_capture_var.RVWRTQS_ACTIVITY_PARENT_1 = RVWRTQS_ACTIVITY
                    Event_capture_var.RVWRTQS_ILBO_PARENT_1 = RVWRTQS_ILBO
                    Event_capture_var.RVWRTQS_EVENTNAME_PARENT_1 = RVWRTQS_EVENTNAME
                    Event_capture_var.RVWRTQS_REQID_PARENT_1 = RVWRTQS_REQID
                    Event_capture_var.Event_turn_count = Event_capture_var.Event_turn_count + 1
                else:
                    Event_capture_var.RVWRTQS_COMPONENT_CHILD_1 = RVWRTQS_COMPONENT
                    Event_capture_var.RVWRTQS_ACTIVITY_CHILD_1 = RVWRTQS_ACTIVITY
                    Event_capture_var.RVWRTQS_ILBO_CHILD_1 = RVWRTQS_ILBO
                    Event_capture_var.RVWRTQS_EVENTNAME_CHILD_1 = RVWRTQS_EVENTNAME
                    Event_capture_var.RVWRTQS_REQID_CHILD_1 = RVWRTQS_REQID


            elif "/GetPageDetails.ashx" in str(response.url) or "/GetPageDetails.aspx" in str(response.url):

                resp=json.loads(response.text())
                if 'version' in resp.keys():
                    PAGE_VERSION=resp.get("version")
                    Event_capture_var.ECR_VERSION = PAGE_VERSION
                    Variable_not_resettable.logger.info(f"PAGE_VERSION: {PAGE_VERSION}")
            
        except Exception as error:
             Variable_not_resettable.logger.error(str(error))


def split_by_colon_for_excel_assertion(file_sheet_name):
    splitted_list = str(file_sheet_name).split(":")
    splitted_list = [element for element in splitted_list]
    return splitted_list

def find_browser_process_id():
    try:
        exe_name = sys.argv[0]
        chrome_with_python_parent = {}
        for process in psutil.process_iter(['pid', 'name']):
            process_id = process.pid
            process_name = process.name()
            process_status = process.status()
            is_python_parent = False
            is_node_parent = False
            is_exe_parent = False
            if process_name == f"{Variable_not_resettable.browser_type}.exe":
                parent_processes = process.parents()
                parent_python_process_id = None
                parent_node_process_id = None
                parent_exe_process_id = None
                for parent_process in parent_processes:
                    if (parent_process.name() == "cmd.exe"):
                        is_python_parent = True
                        parent_python_process_id = parent_process.pid
                    elif (parent_process.name() == "node.exe"):
                        is_node_parent = True
                        parent_node_process_id = parent_process.pid
                    elif (parent_process.name() == exe_name):
                        is_exe_parent = True
                        parent_exe_process_id = parent_process.pid
            if is_python_parent and is_node_parent and is_exe_parent:
                # if chrome_with_python_parent.get(parent_python_process_id) == None :
                #     chrome_with_python_parent.update({parent_python_process_id:[process_id]})
                # else:
                    # chrome_with_python_parent.get(parent_python_process_id).append(process_id)
                if chrome_with_python_parent.get(parent_node_process_id)==None:
                    chrome_with_python_parent.update({parent_node_process_id:[process_id]})
                else:
                    chrome_with_python_parent.get(parent_node_process_id).append(process_id)
        return chrome_with_python_parent
    except Exception as browserpiderror:
        print("findprocess: "+str(browserpiderror))
        return {}

def Kill_running_browsers():
    if Common_object.test_config_dictionary["ParallelExecution"] == "ON":
        try:
            if not Common_object.firstkill:
                # Deserialize JSON from a file back to a dictionary
                with open(f'data{str(Parallel_common_object.process_id)}.json', 'r') as json_file:
                    chrome_with_python_parent= json.load(json_file)
                    key1=list(chrome_with_python_parent.keys())
                    Common_object.Keyfor_pid= key1[0]
                if len(chrome_with_python_parent)!=0:
                    for parent_pid, child_pids in chrome_with_python_parent.items():
                        parent_process = psutil.Process(int(parent_pid))
                        children = parent_process.children(recursive=True)
                        for child in children:
                            try:
                                if child.pid in child_pids:
                                    print("Terminating Child instances "+str(child.pid))
                                    child.terminate()
                                Common_object.firstkill=True
                            except Exception as terminateerror:
                                print("termination error "+str(terminateerror))
            else:
                time.sleep(3)
                browser_with_python_parent=find_browser_process_id()
                if Common_object.Keyfor_pid in browser_with_python_parent:
                    print("Key "+str(Common_object.Keyfor_pid)+" exists in the dictionary")
                else:
                    browser_with_python_parent=find_browser_process_id()
                    if Common_object.Keyfor_pid in browser_with_python_parent:
                        print("Key "+str(Common_object.Keyfor_pid)+" exists in the dictionary")
                    else:
                        browser_with_python_parent=find_browser_process_id()

                for key,value in browser_with_python_parent.items():
                    if str(key)==str(Common_object.Keyfor_pid):
                        chrome_with_python_parent={key:value}
                if len(chrome_with_python_parent)!=0:
                    for parent_pid, child_pids in chrome_with_python_parent.items():
                        parent_process = psutil.Process(int(parent_pid))
                        children = parent_process.children(recursive=True)
                        for child in children:
                            try:
                                if child.pid in child_pids:
                                    print("Terminating Child instances "+str(child.pid))
                                    child.terminate()
                                Common_object.firstkill=True
                            except Exception as terminateerror:
                                print("termination error "+str(terminateerror))

        except Exception as browserkillerror:
            print("browserkillerror,"+str(browserkillerror)) 
    else:
        try:
            exe_name = sys.argv[0]
            chrome_with_python_parent = {}
            for process in psutil.process_iter(['pid', 'name']):
                process_id = process.pid
                process_name = process.name()
                process_status = process.status()
                is_python_parent = False
                is_node_parent = False
                is_exe_parent = False
                if process_name == f"{Variable_not_resettable.browser_type}.exe":
                    parent_processes = process.parents()
                    parent_python_process_id = None
                    parent_node_process_id = None
                    parent_exe_process_id = None
                    for parent_process in parent_processes:
                        if (parent_process.name() == "cmd.exe"):
                            is_python_parent = True
                            parent_python_process_id = parent_process.pid
                        elif (parent_process.name() == "node.exe"):
                            is_node_parent = True
                            parent_node_process_id = parent_process.pid
                        elif (parent_process.name() == exe_name):
                            is_exe_parent = True
                            parent_exe_process_id = parent_process.pid
                if is_python_parent and is_node_parent and is_exe_parent:
                    # if chrome_with_python_parent.get(parent_python_process_id) == None :
                    #     chrome_with_python_parent.update({parent_python_process_id:[process_id]})
                    # else:
                        # chrome_with_python_parent.get(parent_python_process_id).append(process_id)
                    if chrome_with_python_parent.get(parent_node_process_id)==None:
                        chrome_with_python_parent.update({parent_node_process_id:[process_id]})
                    else:
                        chrome_with_python_parent.get(parent_node_process_id).append(process_id)
            if len(chrome_with_python_parent)!=0:
                for parent_pid, child_pids in chrome_with_python_parent.items():
                    parent_process = psutil.Process(parent_pid)
                    children = parent_process.children(recursive=True)
                    for child in children:
                        try:
                            if child.pid in child_pids:
                                print("Terminating Child instances "+str(child.pid))
                                child.terminate()
                        except Exception as terminateerror:
                            print(terminateerror)
                    # parent_process.terminate()
                    print("Parent Process terminated")
        except Exception as browserkillerror:
            print(browserkillerror)

def readDatafromExcel(row_index):
    try:
        value=""
        # delete_gen_py_folder()  #### temp disable ####
        file_path = Common_path.dataSheet_path + "\\"+Common_object.test_config_dictionary['DataTag'] + "\\" + Common_step.DATA_FILE + ".xlsx"
        df = pd.read_excel(file_path, sheet_name=Common_step.DATA_SHEET)
        column_index = list(df.columns)
        # print(column_index)
        column_index = [str(column).lower() for column in column_index]
        # print(column_index)
        if Common_step.DATA_REFERENCE1 is None:
            column_index = column_index.index(str(Common_step.DATA_REFERENCE).lower())
        else:
            column_index = column_index.index(str(Common_step.DATA_REFERENCE1).lower())
        # print(column_index)
        column_address = get_alphabet(column_index)
        # print(column_address)
        # Variable_not_resetable.excel_application.display_alerts = False
        # Variable_not_resetable.excel_application.visible = False
 
        app1 = xw.App()
        app1.visible = False
        app1.display_alerts = False
        # print("Excel application process id : ", app1.pid)
        Variable_not_resettable.logger.info("Excel application process id : "+ str(app1.pid))
        # print("Excel version : ", app1.version)
        Variable_not_resettable.logger.info("Excel version : "+ str(app1.version))
   
        wb_1 = app1.books.open(file_path, update_links=False, ignore_read_only_recommended=True)    
        ws_1 = wb_1.sheets[Common_step.DATA_SHEET]
        value=ws_1.range(column_address+str(int(row_index+2))).value
        wb_1.save()
        wb_1.close()
        app1.quit()
        app1.kill()
        return value
   
    except Exception as readerror:
        Variable_not_resettable.logger.error(str(readerror))
        return value

def saveDataToExcel_Screen_Loop(row_index,value,iter):
    try:
        file_path = Common_path.dataSheet_path + "\\"+Common_object.test_config_dictionary['DataTag'] + "\\" + Common_step.DATA_FILE + ".xlsx"
        df = pd.read_excel(file_path, sheet_name=Common_step.DATA_SHEET)
        column_index = list(df.columns)
        column_index = [str(column).lower() for column in column_index]
        if Common_step.DATA_REFERENCE2 is None:
            column_index = column_index.index(str(Common_step.DATA_REFERENCE).lower())
        else:
            column_index = column_index.index(str(Common_step.DATA_REFERENCE2).lower())
        column_address = get_alphabet(column_index)
 
        app1 = xw.App()
        app1.visible = False
        app1.display_alerts = False
        Variable_not_resettable.logger.info("Excel application process id : "+ str(app1.pid))
        Variable_not_resettable.logger.info("Excel version : "+ str(app1.version))
        wb_1 = app1.books.open(file_path, update_links=False, ignore_read_only_recommended=True)    
        ws_1 = wb_1.sheets[Common_step.DATA_SHEET]
        ws_1.range(column_address+str(row_index+int(iter+2))).value = value
        wb_1.save()
        wb_1.close()
        app1.quit()
        app1.kill()
    except Exception as Error_onread:
        Variable_not_resettable.logger.info(Error_onread)