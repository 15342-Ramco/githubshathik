from common_object import Common_controls, Common_data, Common_navigation, Common_object, Common_scenario, Common_step, Variable_not_resettable
from dataGenerator import dataGenerator
from excel_utils import read_excel_return_dictionary_for_row_based
import requests
import json
import base64

def description_builder(params_value, new_rTask_params, summary_str):
    description_text = params_value
    empty_text = ""
    if "summary" in description_text:
        if str(new_rTask_params.get("summary")[0].get("Value")).lower() == "nan" or str(new_rTask_params.get("summary")[0].get("Value")).lower() == "none":
            summary_str = str(Common_object.scenarios_meta["SCENARIO_ID"])+" - "+ str(Common_step.error_popup_message)[0:230]
        else:
             summary_str = str(Common_object.scenarios_meta["SCENARIO_ID"])+" - "+str(new_rTask_params.get("summary")[0].get("Value"))+" - "+ str(Common_step.error_popup_message)[0:230]
        empty_text = empty_text +"Summary: "+ str(summary_str)+"-"
    if "stepID" in description_text:
        empty_text = empty_text +" Step ID: "+  str(Common_step.step_id)+" - "
    if "stepType" in description_text:
        empty_text = empty_text +" Step Type: "+  str(Common_step.STEP_TYPE)+" - "
    if "stepAction" in description_text:
        empty_text = empty_text +" Step Action: "+  str(Common_step.BASE_ACTION)+" - "
    if "pageName" in description_text:
        empty_text = empty_text +" Page Name: "+  str(Common_step.PAGE_NAME)+" - "
    if "dataName" in description_text:
        empty_text = empty_text +" Data Name: "+  str(Common_step.DATA_NAME)+" - "
    if "elementReference" in description_text:
        empty_text = empty_text +" Element Reference: "+  str(Common_step.ELEMENT_REFERENCE)+" - "
    if "dataReference" in description_text:
        empty_text = empty_text +" Data Reference: "+  str(Common_step.DATA_REFERENCE)+" - "
    if "customErrorMsg" in description_text:
        Custom_Error_1="Error occurred while executing - Filename:{}; SheetName:{}; STEP_ID:{}; PAGE_NAME:{}; ELEMENT_REFERENCE:{}; ELEMENT_VALUE:{}; ACTION:{}; DATA_NAME:{}; DATA_REFERENCE:{}; DATA_VALUE:{}".format(Common_scenario.STEP_FILE,Common_scenario.STEP_SHEET,int(Common_step.step_id),Common_step.PAGE_NAME,Common_step.ELEMENT_REFERENCE,Common_controls.control_Value,Common_step.ACTION,Common_step.DATA_NAME,Common_step.DATA_REFERENCE,Common_data.data_value).replace("nan", "").replace('None', '')
        empty_text = empty_text + str(Custom_Error_1)+" - "
    return empty_text.strip()

def generate_basic_auth_token(username: str, password: str) -> str:
    credentials = f"{username}:{password}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    basic_auth_token = f"Basic {encoded_credentials}"
    
    return basic_auth_token

                        
def rtask_raise_ticket():
    try:
        rTask_credential = read_excel_return_dictionary_for_row_based("Files\TestRunner\RtaskConfig.xlsx", "credential")
        new_rTask_credential = {}
        _ = {new_rTask_credential.update({credential['Name']:credential['Value']}) for credential in rTask_credential}

        rTask_params = read_excel_return_dictionary_for_row_based("Files\TestRunner\RtaskConfig.xlsx", "params")
        new_rTask_params = {}
        _ = {new_rTask_params.update({params['Id']:[{ "type":params['type'], "Value":params['Value']}]}) for params in  rTask_params}
        required_fields = {}
        _ = {required_fields.update({params['Name']:params['Value']}) for params in rTask_params}

        for key, value in new_rTask_credential.items():
            if value == None or str(value) == "nan" or str(value) == "nan":
                raise Exception(f"{key} field in rTrackConfig should not be empty")


        url = new_rTask_credential.get('url')
        username = new_rTask_credential.get('username')
        password = new_rTask_credential.get('password')
        check_list = [url, username, password]
        for check in check_list:
            if check == None:
                raise Exception(f"Please check the {check} field in rTrackConfig, it may missing or incorrect")
        issue_fields={}
        for params_key, params_value in new_rTask_params.items():
            # print(params_key, params_value)
            if params_value[0].get("type") == "textbox":
                if params_key.lower() == "summary":
                    if str(params_value[0].get("Value")).lower() == "nan" or str(params_value[0].get("Value")).lower() == "none" or str(params_value[0].get("Value")).lower() == "":
                        summary_str = str(Common_object.scenarios_meta["SCENARIO_ID"])+" - "+ str(Common_step.error_popup_message)[0:230]
                        issue_fields.update({params_key : summary_str})
                    else:
                        summary_str = str(Common_object.scenarios_meta["SCENARIO_ID"])+" - "+str(params_value[0].get("Value"))+" - "+ str(Common_step.error_popup_message)[0:230]
                        issue_fields.update({params_key : summary_str})
                elif params_key.lower() == "description":
                    issue_fields.update({params_key : description_builder(params_value[0].get("Value"), new_rTask_params, summary_str)})
                elif params_value[0].get("Value") == "xrayTestCaseID":
                    issue_fields.update({params_key : str(Common_step.XRAY_TEST_CASE_ID)})
                elif params_value[0].get("Value") == "ScenarioID":
                    issue_fields.update({params_key : str(Common_object.scenarios_meta["SCENARIO_ID"])})
                elif "EXECUTE:" in params_value[0].get("Value"):
                    rtrack_data_gen = dataGenerator((params_value[0]).get("Value"))
                    Variable_not_resettable.logger.debug("rtrack_data_gen : ",rtrack_data_gen)
                    issue_fields.update({params_key : str(rtrack_data_gen)})
                elif params_value[0].get("Value") == "URL":
                    issue_fields.update({params_key : str(Common_object.test_config_dictionary["ApplicationURL"])})
                else:
                    issue_fields.update({params_key : params_value[0].get("Value")})
            elif params_value[0].get("type") == "dropdown":
                issue_fields.update({params_key : {"value":params_value[0].get("Value")}})
            elif params_value[0].get("type") == "dropdowndynamic":
                if str(params_value[0].get("Value")) == "Process":
                    issue_fields.update({params_key : Common_navigation.Process})
                elif str(params_value[0].get("Value")) == "Component":
                    issue_fields.update({params_key : Common_navigation.Component})
                elif str(params_value[0].get("Value")) == "Activity":
                    issue_fields.update({params_key : Common_navigation.Activity})
                else:
                    issue_fields.update({params_key : params_value[0].get("Value")})
        
        # Convert keys in dict2 to lowercase
        dict2_lower = {key.lower(): value for key, value in issue_fields.items()}

        # Update values in dict1 using case-insensitive keys
        for key, value in required_fields.items():
            lower_key = key.lower()
            if lower_key in dict2_lower:
                required_fields[key] = dict2_lower[lower_key]
        payload = json.dumps(required_fields)
        
        headers = {
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        "authorization": generate_basic_auth_token(username, password),
        'Connection': 'keep-alive',
        'Content-Type': 'application/json',
        'Origin': 'http://qltywarcnv01.ramco.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0',
        'timezone': 'Asia/Calcutta'
        }

        response = requests.request("POST", url, headers=headers, data=payload)
        key=response.json().get("Key")

        return key

    except Exception as error:
        Variable_not_resettable.logger.error(error)
        Variable_not_resettable.logger.warning("rTask ticket not created!!!")
        return f"No Ticket ID - {str(error)}"