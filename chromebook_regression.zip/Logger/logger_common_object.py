


class Logger_object:
    # format available on https://docs.python.org/3/library/logging.html#logrecord-attributes

    console_log_format = '%(asctime)s | %(levelname)s | %(message)s'
    console_log_format_our_use = '%(asctime)s | %(levelname)s | %(module)s-%(lineno)d: %(message)s'
    log_file_log_formate = '%(process)d | %(asctime)s | %(levelname)s | %(module)s-%(lineno)d: %(funcName)s: %(message)s'