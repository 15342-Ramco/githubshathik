import logging
from Logger.logger_common_object import Logger_object
from utils import read_properties_file

def set_logger(file_path: str):
    try:
        inspector = read_properties_file("test.properties")
        if inspector["write_logger"] == "True":

            logger = logging.getLogger()
            logger.setLevel(logging.NOTSET)

            # our first handler is a console handler
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            console_handler.setFormatter(logging.Formatter(Logger_object.console_log_format))
            logger.addHandler(console_handler)

            # the second handler is a file handler
            file_handler = logging.FileHandler(file_path)
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(logging.Formatter(Logger_object.log_file_log_formate))
            logger.addHandler(file_handler)
            return logger
        else:
            logger = logging.getLogger()
            logger.setLevel(logging.NOTSET)

            # our first handler is a console handler
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            console_handler.setFormatter(logging.Formatter(Logger_object.console_log_format))
            logger.addHandler(console_handler)

            return logger
    except:
            logger = logging.getLogger()
            logger.setLevel(logging.NOTSET)

            # our first handler is a console handler
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            console_handler.setFormatter(logging.Formatter(Logger_object.console_log_format))
            logger.addHandler(console_handler)

            return logger
    
