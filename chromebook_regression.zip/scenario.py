
import os
from common_object import Common_config, Common_object, Common_path, Common_scenario_loops, Variable_not_resettable
from excel_utils import read_excel_return_dataFrame, read_dataFrame_return_dictionary_for_colum_based, read_excel_return_dictionary_for_row_based
from utils import draftbill
from natsort import natsorted


def get_scenarios_file_list_single_execution():
    testConfig_dictionary = Common_object.test_config_dictionary
    scenarios_folder_list = get_scenarios_folder_list_single_execution()
    draftbill(scenarios_folder_list)
    scenarios_file_list = []
    file_include = []
    file_exclude = []
    scenarios_file_list_final = []
    for scenarios_folder in scenarios_folder_list:
        files = os.listdir(Common_path.scenarios_path+"\\"+scenarios_folder)
        files = natsorted(files)
        temp_var = [scenarios_file_list.append(scenarios_folder+"\\"+f) for f in files]
    # if str(testConfig_dictionary["Prerequisites"]) != "nan":
    #     files = [file_include.append(f.strip()) for f in testConfig_dictionary["Prerequisites"].split(",") if f!=""]
 
    if str(testConfig_dictionary["Prerequisites"]) != "nan":
        for file in scenarios_file_list:
            scenarios_file_list_final.append(file)
   
 
    return scenarios_file_list_final


def get_scenarios_folder_list_single_execution():
    testConfig_dictionary = Common_object.test_config_dictionary
    folder_list = []
    try:
        if testConfig_dictionary["Prerequisites"] != "nan":
            folders = [folder_list.append(f.strip()) for f in testConfig_dictionary["Prerequisites"].split(",")]
       
    except Exception as error:
        # print(error)
        exit()
    # folder_list = [each_folder for each_folder in folder_list if "fail_" not in each_folder and "original_" not in each_folder]
    folder_list = natsorted([each_folder for each_folder in folder_list if "fail_" not in each_folder and "original_" not in each_folder])
    return folder_list


def get_scenarios_folder_list():
    testConfig_dictionary = Common_object.test_config_dictionary
    folder_list = []
    try:
        if testConfig_dictionary["FoldersInclude"] != "nan":
            folders = [folder_list.append(f.strip()) for f in testConfig_dictionary["FoldersInclude"].split(",")]
        if testConfig_dictionary["FoldersInclude"] == "nan":
            folders = [folder_list.append(f.strip()) for f in os.listdir(Common_path.scenarios_path)]
        if testConfig_dictionary["FoldersExclude"] != "nan":
            folders = [folder_list.remove(f.strip()) for f in testConfig_dictionary["FoldersExclude"].split(",")]
    except Exception as error:
        # print(error)
        exit()
    # folder_list = [each_folder for each_folder in folder_list if "fail_" not in each_folder and "original_" not in each_folder]
    folder_list = natsorted([each_folder for each_folder in folder_list if "fail_" not in each_folder and "original_" not in each_folder])
    return folder_list


def get_scenarios_file_list():
    testConfig_dictionary = Common_object.test_config_dictionary
    scenarios_folder_list = get_scenarios_folder_list()
    draftbill(scenarios_folder_list)
    scenarios_file_list = []
    file_include = []
    file_exclude = []
    scenarios_file_list_final = []
    for scenarios_folder in scenarios_folder_list:
        files = os.listdir(Common_path.scenarios_path+"\\"+scenarios_folder)
        files = natsorted(files)
        temp_var = [scenarios_file_list.append(scenarios_folder+"\\"+f) for f in files]
    if str(testConfig_dictionary["FilesNameInclude"]) != "nan":
        files = [file_include.append(f.strip()) for f in testConfig_dictionary["FilesNameInclude"].split(",") if f!=""]

    if str(testConfig_dictionary["FilesNameExclude"]) != "nan":
        file = [file_exclude.append(f.strip()) for f in testConfig_dictionary["FilesNameExclude"].split(",") if f!=""]
    # print("file_include : ", file_include)
    # print("file_exclude : ",file_exclude)
    if str(testConfig_dictionary["FilesNameExclude"]) != "nan":
        for file in scenarios_file_list_final:
             for f in file_exclude:
                if f in file:
                    scenarios_file_list.remove(file)
    if str(testConfig_dictionary["FilesNameInclude"]) != "nan":
        for file in scenarios_file_list:
            for f in file_include:
                if f in file:
                    scenarios_file_list_final.append(file)
    if str(testConfig_dictionary["FilesNameInclude"]) == "nan":
        for f in scenarios_file_list:
            scenarios_file_list_final.append(f)
    if str(testConfig_dictionary["FilesNameExclude"]) != "nan":
        scenarios_file_list_final = [file for file in scenarios_file_list_final if not any(f in file for f in file_exclude)]
        # for file in scenarios_file_list_final:
        #      for f in file_exclude:
        #         if f in file:
        #             scenarios_file_list_final.remove(file)
    if str(testConfig_dictionary['ClientName'])!= "nan":
        Common_config.client_name = testConfig_dictionary['ClientName']
        base_path = os.getcwd()
        configPath = base_path + "\\Files\\Config\\"+Common_config.client_name+"\\"
        scenarioMasterConfigPath = ".\\Files\\Config\\"+Common_config.client_name+"\\Scenario\\ConfigScenarioMaster.xlsx"
        configScenarioMasterSheetName = "ConfigScenarioMaster"
        Common_config.config_scenario_dict = read_excel_return_dictionary_for_row_based(scenarioMasterConfigPath,configScenarioMasterSheetName)
        page_master_config_path = ".\\Files\\Config\\"+Common_config.client_name+"\\Page\\ConfigPageMaster.xlsx"
        config_page_master_sheet_name = "ConfigPageMaster"
        Common_config.config_step_dict = read_excel_return_dictionary_for_row_based(page_master_config_path,config_page_master_sheet_name)
    # print("scenarios_file_list_final : ",scenarios_file_list_final)


    return scenarios_file_list_final


def scenario_sheet_filter_steps(scenario_file_name: str):
    scenario_data_frame = read_excel_return_dataFrame(
        Common_path.scenarios_path+"\\"+scenario_file_name, "Scenario")
    scenario_metadata_dictionary = read_dataFrame_return_dictionary_for_colum_based(
        scenario_data_frame[0:3])
    last_row = len(scenario_data_frame)
    scenario_list_data_frame = scenario_data_frame[3:last_row]
    scenario_list_data_frame = scenario_list_data_frame.rename(
        columns=scenario_list_data_frame.iloc[0]).drop(scenario_list_data_frame.index[0])
    scenario_list_data_frame = scenario_list_data_frame[0:]
    scenario_list_data_frame = scenario_list_data_frame.reset_index(
        inplace=False, drop=True)
    scenario_list_data_frame.columns = scenario_list_data_frame.columns.fillna(
        'A')
    data_frame_dictionary = scenario_list_data_frame.to_dict('records')
    Scenario_start = []
    Flag = False
    for i in range(len(data_frame_dictionary)):
        if str(data_frame_dictionary[i]['A']) == 'END_SCENARIO':
            Flag = False
            break
        if Flag == True:
            Scenario_start.append(data_frame_dictionary[i])
        if str(data_frame_dictionary[i]['A']) == 'START_SCENARIO':
            Flag = True
            Scenario_start.append(data_frame_dictionary[i])
    return (scenario_metadata_dictionary, Scenario_start)


def select_scenario_tags(scenario_tag: str):
    # print("scenario_tag : ", scenario_tag)
    Variable_not_resettable.logger.info("scenario_tag : "+ str(scenario_tag))
    flag = False
    scenario_tag = scenario_tag.split(",")
    scenario_tag = [tag.strip() for tag in  scenario_tag]
    # print("Common_object.test_config_dictionary['TagsInclude'][0] : ",Common_object.test_config_dictionary['TagsInclude'][0])
    Variable_not_resettable.logger.debug("Common_object.test_config_dictionary['TagsInclude'][0] : "+str(Common_object.test_config_dictionary['TagsInclude'][0]))
    if str(Common_object.test_config_dictionary['TagsInclude'][0]) == "nan":
        flag = True
    if str( Common_object.test_config_dictionary['TagsExclude'][0]) == "nan":
        flag = True
    if str(Common_object.test_config_dictionary['TagsInclude'][0]) != "nan":
        if  any(item in Common_object.test_config_dictionary['TagsInclude'] for item in scenario_tag):
            flag = True
        else:
            flag = False
    if str(Common_object.test_config_dictionary['TagsExclude'][0]) != "nan":
        if  any(item in Common_object.test_config_dictionary['TagsExclude'] for item in scenario_tag):
            flag = False
        else:
            flag = True
    return flag


def data_provider(text: str) -> list:
    if "{" in text:
        text = text.split("{")
        text = text[1].replace("}", "")
        text = text.split(",")
        text = [num.strip() for num in text]
        text = [int(num) if num.isdigit() else None for num in text]
        if None not in text and len(text) == 1:
            text = [num+1 for num in range(text[0])]
        if None in text or len(text) > 1:
            text = [num for num in text if str(num).isdigit()]
    else:
        text = [1]
    return text

def scenario_loops(loop_start_end_value : str):
    text = loop_start_end_value
    if "START LOOP"  in text and "END LOOP" in text:
        Common_scenario_loops.start_loop_flag = True
        Common_scenario_loops.end_loop_flag = True
    elif "START LOOP" in text:
        Common_scenario_loops.start_loop_flag = True
    elif "END LOOP" in text:
        Common_scenario_loops.end_loop_flag = True

    



