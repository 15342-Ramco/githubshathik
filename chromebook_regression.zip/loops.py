from cmath import nan
from common_object import  Common_scenario_loops_list




def start_loop(name, count, start_scenario_id, end_scenario_id):
    temp_dict = {name : {"loop count": int(count), "start scenario id":int(start_scenario_id), "end scenario id": end_scenario_id}}
    Common_scenario_loops_list.loop_name_dict.update(temp_dict)

def end_loop(name, end_scenario_id):
            Common_scenario_loops_list.loop_name_dict[name]["end scenario id"]= int(end_scenario_id)


def loop_wrapper(scenarios_dictionary):
    temp_list = []
    start_loop_flag = False
    loop_count_bulk = 0
    loop_count_bulk_list = []
    loop_count_bulk_fixed = 0
    for scenario in scenarios_dictionary:
        if len(list(scenario.keys()))  > 5:
            text = str(scenario[list(scenario.keys())[5]])
            # print("text from scenario :", text)
        else:
            text = nan
            # print("text from scenario :", text)
        if str(text) == "nan" and start_loop_flag == False:
            scenario.update(loop_count_no = None)
            temp_list.append(scenario)
        if "START LOOP" in text and "END LOOP" in text:
            if "START LOOP" in text:
                start_loop_flag = True
                first_dict_symbol = text.find("{")
                sec_dict_symbol = text.find("}")
                loop_count = int(text[first_dict_symbol+1:sec_dict_symbol])
                for loop in range(int(loop_count)):
                    scenario_temp = {}
                    scenario_temp.update(scenario)
                    scenario_temp.update(loop_count_no = loop) 
                    
                    temp_list.append(scenario_temp)
            if "END LOOP" in text:
                start_loop_flag = False

        if "START LOOP" in text and "END LOOP" not in text and start_loop_flag == False and text != "nan":
            start_loop_flag = True
            loop_count_bulk_list = []
            first_dict_symbol = text.find("{")
            sec_dict_symbol = text.find("}")
            loop_count_bulk = int(text[first_dict_symbol+1:sec_dict_symbol])
            loop_count_bulk_fixed = int(loop_count_bulk)
            scenario_temp = {}
            scenario_temp.update(scenario)
            loop_count_bulk_list.append(scenario_temp)

        if start_loop_flag == True and text == "nan":
            start_loop_flag = True
            scenario_temp = {}
            scenario_temp.update(scenario)
            loop_count_bulk_list.append(scenario_temp)
        
        if text != "nan" and "START LOOP" not in text and "END LOOP" in text:
            start_loop_flag = False
            if loop_count_bulk_fixed != 0:
                loop_count_bulk = loop_count_bulk -1
                scenario_temp = {}
                scenario_temp.update(scenario)
                loop_count_bulk_list.append(scenario_temp)
            
            for count in  range(int(loop_count_bulk_fixed)):
                for scenario_bulk in loop_count_bulk_list:
                    scenario_temp = {}
                    scenario_temp.update(loop_count_no = count)
                    scenario_temp.update(scenario_bulk)
                    temp_list.append(scenario_temp)
                
    Common_scenario_loops_list.loop_name_dict = temp_list
    return Common_scenario_loops_list.loop_name_dict


# def loop_wrapper(scenarios_dictionary):
#     for scenario_step in scenarios_dictionary:
#         text = str(scenario_step[list(scenario_step.keys())[5]])
#         start_loop_name = end_loop_name =  None
#         loop_count = 0
#         start_scenario_id = end_scenario_id = None
#         if str(scenario_step[list(scenario_step.keys())[5]]) != "nan":
#             if ("START LOOP" in text) and ("END LOOP" in text): 
#                 if "START LOOP" in text:
#                     start_loop_name = re.sub(r"[\(\)]", "", (re.findall(r"\([A-Z]\)", text))[0])
#                     loop_count = re.sub(r"[\{\}]", "", (re.findall(r"\{\d\}", text))[0])
#                     start_scenario_id = scenario_step["SCENARIO_STEP_ID"]
#                     start_loop(start_loop_name, loop_count, start_scenario_id, end_scenario_id)
#                 if "END LOOP" in text:
#                     end_loop_name = re.sub(r"[\[\]]", "", (re.findall(r"\[[A-Z]\]", text))[0])
#                     end_scenario_id = scenario_step["SCENARIO_STEP_ID"]
#                     end_loop(end_loop_name, end_scenario_id)
#             if ("START LOOP" in text) and ("END LOOP" not in text):
#                 start_loop_name = re.sub(r"[\(\)]", "", (re.findall(r"\([A-Z]\)", text))[0])
#                 loop_count = re.sub(r"[\{\}]", "", (re.findall(r"\{\d\}", text))[0])
#                 start_scenario_id = scenario_step["SCENARIO_STEP_ID"]
#                 start_loop(start_loop_name, loop_count, start_scenario_id, end_scenario_id)
#             if ("START LOOP" not in text) and ("END LOOP" in text):
#                 end_loop_name = re.sub(r"[\[\]]", "", (re.findall(r"\[[A-Z]\]", text))[0])
#                 end_scenario_id = scenario_step["SCENARIO_STEP_ID"]
#                 end_loop(end_loop_name, end_scenario_id)

#     for loop_name in Common_scenario_loops_list.loop_name_dict:
#         loop_details = Common_scenario_loops_list.loop_name_dict[loop_name]
#         for num in range(loop_details["start scenario id"], loop_details["end scenario id"]+1):
#             Common_scenario_loops_list.scenarios_in_loop.append(num)

#     return Common_scenario_loops_list.loop_name_dict

# loop_dict = loop_wrapper(Common_object.scenarios_dictionary)

# for scenario_step in Common_object.scenarios_dictionary: 
#     text = str(scenario_step[list(scenario_step.keys())[5]])
#     if text != "nan": 
#         if ("START LOOP" in text) and ("END LOOP" in text):
#             start_loop_name = re.sub(r"[\(\)]", "", (re.findall(r"\([A-Z]\)", text))[0])
#             loop_details = loop_dict[start_loop_name]
#             for loop in range(loop_details["loop count"]):
#                 for num in range(loop_details["start scenario id"], loop_details["end scenario id"]+1):
#                     for scenario_step in Common_object.scenarios_dictionary:
#                         if scenario_step["SCENARIO_STEP_ID"] == num:
#                             print(scenario_step)
#         else:
#             if "START LOOP" in text:
#                 start_loop_name = re.sub(r"[\(\)]", "", (re.findall(r"\([A-Z]\)", text))[0])
#                 loop_details = loop_dict[start_loop_name]
#                 for loop in range(loop_details["loop count"]):
#                     for num in range(loop_details["start scenario id"], loop_details["end scenario id"]+1):
#                        for scenario_step in Common_object.scenarios_dictionary:
#                         if scenario_step["SCENARIO_STEP_ID"] == num:
#                             print(scenario_step)
#     else:
#         if scenario_step["SCENARIO_STEP_ID"] not in Common_scenario_loops.scenarios_in_loop:
#             print(scenario_step)


