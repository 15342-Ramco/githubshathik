from common_object import Common_step
from page_object_wrapper import Wrapper_variables


def splitFieldSearchData(data,elementData):
    excelInput = data.split(";")
    Wrapper_variables.dataValue1 = excelInput[0]
    Wrapper_variables.dataValue2 = excelInput[1] if len(excelInput) >= 2 else ""
    Wrapper_variables.dataValue3 = excelInput[2] if len(excelInput) >= 3 else ""
    Wrapper_variables.dataValue4 = excelInput[3] if len(excelInput) >= 4 else ""
    Wrapper_variables.dataValue5 = excelInput[4] if len(excelInput) >= 5 else ""
    if elementData.find("_tbr_") != -1 and (Common_step.ACTION == "Grid Search Zoom Edit" or Common_step.ACTION == "Assert Grid Table" or Common_step.ACTION == "Grid Search Select" or Common_step.ACTION == "Grid Search Single Select"):
        objectValue = elementData.split("_tbr")
    else:
        objectValue = elementData.split("_")
    Wrapper_variables.objectValue = objectValue[0]

def splitFieldSearchData_nebula(data,elementData):
    excelInput = data.split(";")
    Wrapper_variables.dataValue1 = excelInput[0]
    Wrapper_variables.dataValue2 = excelInput[1] if len(excelInput) >= 2 else ""
    Wrapper_variables.dataValue3 = excelInput[2] if len(excelInput) >= 3 else ""
    Wrapper_variables.dataValue4 = excelInput[3] if len(excelInput) >= 4 else ""
    Wrapper_variables.dataValue5 = excelInput[4] if len(excelInput) >= 5 else ""
    # if elementData.find("_tbr_") != -1 and (Common_step.ACTION == "Grid Search Zoom Edit" or Common_step.ACTION == "Assert Grid Table" or Common_step.ACTION == "Grid Search Select"):
    #     objectValue = elementData.split("_tbr")
    # else:
    if elementData[0] == "_":
        objectValue = elementData.split("_")
        Wrapper_variables.objectValue = "_"+objectValue[1]
    elif "_tbr" in elementData:
        objectValue = elementData.split("_tbr")
        Wrapper_variables.objectValue = objectValue[0]
    else:
        objectValue = elementData.split("_")
        Wrapper_variables.objectValue = objectValue[0]
        
def splitTreeGridDataValue(data):
    excelInput = data.split(";")
    Wrapper_variables.dataValue1 = excelInput[0]
    Wrapper_variables.dataValue2 = excelInput[1]
    Wrapper_variables.dataValue3 = excelInput[2] if len(excelInput)> 2 else excelInput[2] == ""


def splitAssertGridTable(data):
    excelInput = data.split(";")
    Wrapper_variables.downloadDefaultPath = excelInput[0]
    Wrapper_variables.inputValue = excelInput[1]

def splitDataValue(data):
    ListSeparator = "};{"
    Wrapper_variables.dataValue1 = data.split(ListSeparator)[0]
    Wrapper_variables.dataValue2 = data.split(ListSeparator)[1]
    dataValue1Length = int(len(Wrapper_variables.dataValue1))
    dataValue2Length = int(len(Wrapper_variables.dataValue2))
    Wrapper_variables.dataValue1 = Wrapper_variables.dataValue1[1: dataValue1Length-1]
    Wrapper_variables.dataValue2 = Wrapper_variables.dataValue2[0: dataValue2Length-1]

def splitFieldSearchObject(data,elementData):
    excelInput = elementData.split(";")
    Wrapper_variables.objectValue = excelInput[0]
    Wrapper_variables.objectValue1 = excelInput[1]
    Wrapper_variables.elementData =  Wrapper_variables.objectValue
    objectInput = elementData.split("_tbr")
    Wrapper_variables.objectValue2 = objectInput[0]
    rowinput =  Wrapper_variables.objectValue1.split("row")
    Wrapper_variables.rowinput1 = rowinput[0]
    
    excelInputData = data.split(";")
    if len(excelInputData) == 1:
        Wrapper_variables.dataValue1 = excelInputData[0]
    if len(excelInputData) == 2:
        Wrapper_variables.dataValue2 = excelInputData[1]

def splitFieldSearchObject_ntimes(data,elementData):
    excelInput = elementData.split(";")
    Wrapper_variables.objectValue = excelInput[0]
    Wrapper_variables.objectValue1 = excelInput[1]
    Wrapper_variables.elementData =  Wrapper_variables.objectValue    
    objectInput = elementData.split("_tbr")
    Wrapper_variables.objectValue2 = objectInput[0]
    rowinput =  Wrapper_variables.objectValue1.split("row")
    Wrapper_variables.rowinput1 = rowinput[0]
    
    excelInputData = data.split(";")
    if len(excelInputData) == 1:
        Wrapper_variables.dataValue1 = excelInputData[0]
    if len(excelInputData) == 2:
        Wrapper_variables.dataValue1 = excelInputData[0]
        Wrapper_variables.dataValue2 = excelInputData[1]

def splitFieldSearchObject_for_drag_and_drop(data,elementData):

    excelInput = elementData.split(";")
    Wrapper_variables.objectValue = elementData#excelInput[0]
    Wrapper_variables.objectValue1 = elementData#excelInput[1]
    Wrapper_variables.elementData =  Wrapper_variables.objectValue
    objectInput = elementData.split("_tbr")
    Wrapper_variables.objectValue2 = objectInput[0]
    rowinput =  Wrapper_variables.objectValue1.split("row")
    Wrapper_variables.rowinput1 = rowinput[0]
    excelInputData = data.split(";")
    if len(excelInputData) == 1:
        Wrapper_variables.dataValue1 = excelInputData[0]
    if len(excelInputData) == 2:
        Wrapper_variables.dataValue2 = excelInputData[1]