import pandas as pd
import pyodbc
import os
from common_object import Common_object, Common_path
from projectObject import projectVariable

# Take the values from commonObject
configPath = "./Files/DBQuery/"
configDBMasterFileNameExt = "DBMaster.xlsx"
connectionSheetName = "Connections"
ConfigSheetName = "DBQueryConfig"
dataPath = "./Files/DataSheets/common/"


def loadDBConnections():
    projectVariable.query_id = projectVariable.action.split(":")[1]
    dbqueryConfig = pd.read_excel(os.path.abspath(configPath + configDBMasterFileNameExt), sheet_name=ConfigSheetName)
    config_ref1 = dbqueryConfig[dbqueryConfig['QueryID'] == projectVariable.query_id]['DBCONFIG_ID']
    dbconfigID = config_ref1[config_ref1.index[0]]
    connections = pd.read_excel(os.path.abspath(configPath + configDBMasterFileNameExt), sheet_name=connectionSheetName)
    connections.dropna(axis=0, inplace=True)
    connection_ref = pd.DataFrame(columns=['DBCONNECTION', 'DBCONFIG_ID', 'SERVER', 'PORT', 'DBNAME', 'USERNAME', 'PASSWORD', 'PROVIDER', 'DRIVER'])
    for x, y in enumerate(range(1, int(connections.shape[0] / 8) + 1)):
        df = connections.iloc[8 * x:8 * y, :]
        df = df.set_index('DBCONNECTION').T.reset_index(drop=True)
        connection_ref = pd.concat([connection_ref, df])
    projectVariable.server = connection_ref[connection_ref['DBCONFIG_ID'] == dbconfigID]['SERVER'][0]
    projectVariable.port = connection_ref[connection_ref['DBCONFIG_ID'] == dbconfigID]['PORT'][0]
    projectVariable.dbname = connection_ref[connection_ref['DBCONFIG_ID'] == dbconfigID]['DBNAME'][0]
    projectVariable.username = connection_ref[connection_ref['DBCONFIG_ID'] == dbconfigID]['USERNAME'][0]
    projectVariable.password = connection_ref[connection_ref['DBCONFIG_ID'] == dbconfigID]['PASSWORD'][0]
    projectVariable.provider = connection_ref[connection_ref['DBCONFIG_ID'] == dbconfigID]['PROVIDER'][0]
    projectVariable.driver = connection_ref[connection_ref['DBCONFIG_ID'] == dbconfigID]['DRIVER'][0]


def dbQueryConfig():
    projectVariable.query_id = projectVariable.action.split(":")[1]
    dbqueryConfig = pd.read_excel(os.path.abspath(configPath + configDBMasterFileNameExt), sheet_name=ConfigSheetName)
    config_ref = dbqueryConfig[dbqueryConfig['QueryID'] == projectVariable.query_id]['QueryReference']
    queryReference = config_ref[config_ref.index[0]]
    QueryReference_filename = queryReference.split(":")[0]
    QueryReference_sheetname = queryReference.split(":")[1]
    queryDf = pd.read_excel(os.path.abspath(configPath + QueryReference_filename), sheet_name=QueryReference_sheetname)
    queryFrame = queryDf[queryDf['QUERY_ID'] == projectVariable.query_id]
    projectVariable.queryFrame = queryFrame
    queryType = queryFrame['QUERY_TYPE'][queryFrame.index[0]]
    projectVariable.query = queryFrame['DB_QUERY'][queryFrame.index[0]]
    projectVariable.db_input = queryFrame['DB_INPUT'][queryFrame.index[0]]
    projectVariable.db_output = queryFrame['DB_OUTPUT'][queryFrame.index[0]]
    projectVariable.db_output_store = queryFrame['DB_OUTPUT_STORE'][queryFrame.index[0]]
    if queryType == "DIRECT QUERY":
        directQuery()
    elif queryType == "STORED PROCEDURE":
        storedProcedure()
    elif queryType == "UPDATE QUERY":
        updateQuery()


def saveDataToExcel(filename, sheetname, column, row_index, value):
    file_path = Common_path.dataSheet_path + "/"+Common_object.test_config_dictionary['DataTag'] + "/" + filename + ".xlsx"
    df = pd.read_excel(str(file_path), sheet_name= sheetname)
    df.loc[row_index, column] = value
    with pd.ExcelWriter(str(file_path), mode="a", if_sheet_exists="replace", engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name=sheetname, index=False)


def directQuery():
    row_index = ""   # Need to map the row index
    loadDBConnections()
    connection_string = 'DRIVER={};SERVER={};DATABASE={};UID={};PWD={};'.format(projectVariable.driver, projectVariable.server + "," + projectVariable.port, projectVariable.dbname, projectVariable.username, projectVariable.password)
    mydb = pyodbc.connect(connection_string)
    inputs = projectVariable.db_input.split(",")
    variables = {}
    for x, file in enumerate(inputs):
        filename = file.split(":")[0]
        sheet = file.split(":")[1]
        column = file.split(":")[2]
        df = pd.read_excel(dataPath + filename + ".xlsx", sheet_name=sheet)
        value = df[column][0]   # get exact row number from input file
        variables[":var{}".format(x + 1)] = value
    query = projectVariable.query
    for key, value in variables.items():
        query = query.replace(key, value)
    result = pd.read_sql(query, mydb)
    values = projectVariable.db_output.split(",")
    outputs = projectVariable.db_output_store.split(",")
    for file, db_column in zip(outputs, values):
        filename = file.split(":")[0]
        sheet = file.split(":")[1]
        column = file.split(":")[2]
        value = result[db_column][0]
        saveDataToExcel(filename, sheet, column, row_index, value) # get exact row number from o/p file


def storedProcedure():
    loadDBConnections()
    connection_string = 'DRIVER={};SERVER={};DATABASE={};UID={};PWD={};'.format(projectVariable.driver, projectVariable.server + "," + projectVariable.port, projectVariable.dbname, projectVariable.username, projectVariable.password)
    mydb = pyodbc.connect(connection_string)
    cursor = mydb.cursor()
    if projectVariable.db_input == 'NA' or projectVariable.db_input == '':
        cursor.execute(projectVariable.query)
    else:
        inputs = projectVariable.db_input.split("|")
        parameters = ""
        for file in inputs:
            details = file.split(",")[-1]
            filename = details.split(":")[0]
            sheet = details.split(":")[1]
            column = details.split(":")[2]
            df = pd.read_excel(dataPath + filename + ".xlsx", sheet_name=sheet)
            value = df[column][0]   # get exact row number from input file
            parameters = parameters + value + ", "
        query = projectVariable.query + " " + parameters[:-2]
        cursor.execute(query)


def updateQuery():
    loadDBConnections()
    connection_string = 'DRIVER={};SERVER={};DATABASE={};UID={};PWD={};'.format(projectVariable.driver, projectVariable.server + "," + projectVariable.port, projectVariable.dbname, projectVariable.username, projectVariable.password)
    mydb = pyodbc.connect(connection_string)
    cursor = mydb.cursor()
    inputs = projectVariable.db_input.split(",")
    variables = {}
    for x, file in enumerate(inputs):
        filename = file.split(":")[0]
        sheet = file.split(":")[1]
        column = file.split(":")[2]
        df = pd.read_excel(dataPath + filename + ".xlsx", sheet_name=sheet)
        value = df[column]   # get exact row number from input file
        variables[":var{}".format(x + 1)] = value
    query = projectVariable.query
    for key, value in variables.items():
        query = query.replace(key, value)
    cursor.execute(query)
    mydb.commit()
