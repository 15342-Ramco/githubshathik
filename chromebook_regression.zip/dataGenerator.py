import re
import random
import numpy as np
import math
from datetime import date, timedelta, datetime
from dateutil.relativedelta import relativedelta
import calendar
from excel_utils import appendColumnAndSaveData
from common_object import Common_scenario
from common_object import Variable_not_resettable



def Num(exc):
    nos = re.search(r'\d+', exc).group()
    random_number = str(np.random.randint(10 ** (int(nos)-1), (10 ** (int(nos)))-1, dtype="int64"))
    return random_number
def Alpha(exc):
    chars = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
             't', 'u', 'v', 'w', 'x', 'y', 'z']
    limit = re.search(r'\d+', exc).group()
    randomlist = random.sample(range(0, 26), int(limit))
    result = "".join([chars[i] for i in randomlist])
    if 'ALPHA_L' in exc:
        result = result.lower()
    elif 'ALPHA_U' in exc:
        result = result.upper()
    return result
def AlphaNum(exc):
    chars = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
             't', 'u', 'v', 'w', 'x', 'y', 'z']
    limit = re.search(r'\d+', exc).group()
    lchars = math.floor(int(limit) / 2)
    lnums = int(limit) - lchars
    randomlist1 = random.sample(range(0, 26), lchars)
    randomlist2 = random.sample(range(0, 10), lnums)
    result1 = "".join([chars[i] for i in randomlist1])
    result2 = "".join([str(i) for i in randomlist2])
    result_ = result1 + result2
    result = ''.join(random.sample(result_, len(result_)))
    if 'ALPHANUM_L' in exc:
        result = result.lower()
    elif 'ALPHANUM_U' in exc:
        result = result.upper()
    return result
def custom_value(exc):
    result = re.search(r'[(].*[)]', exc).group().replace('(', '').replace(')', '')
    return result

class randomClass:
    def __init__(self, execute):
        self.execute = execute
        arguments = re.findall(r'{(.*?)}', self.execute)[0].split(',')
        self.arguments = arguments
        self.chars = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
                      't', 'u', 'v', 'w', 'x', 'y', 'z']
    def randomNum(self):
        nos = re.search(r'\d+', self.arguments[0]).group()
        random_number = str(np.random.randint(10 ** (int(nos)-1), (10 ** (int(nos)))-1, dtype="int64"))
        return random_number
    def randomAlpha(self):
        limit = re.search(r'\d+', self.arguments[0]).group()
        randomlist = random.sample(range(0, 26), int(limit))
        result = "".join([self.chars[i] for i in randomlist])
        if 'ALPHA_L' in self.arguments[0]:
            result = result.lower()
        elif 'ALPHA_U' in self.arguments[0]:
            result = result.upper()
        return result
    def randomAlphaNum(self):
        limit = re.search(r'\d+', self.arguments[0]).group()
        lchars = math.floor(int(limit) / 2)
        lnums = int(limit) - lchars
        randomlist1 = random.sample(range(0, 26), lchars)
        randomlist2 = random.sample(range(0, 10), lnums)
        result1 = "".join([self.chars[i] for i in randomlist1])
        result2 = "".join([str(i) for i in randomlist2])
        result_ = result1 + result2
        result = ''.join(random.sample(result_, len(result_)))
        if 'ALPHANUM_L' in self.arguments[0]:
            result = result.lower()
        elif 'ALPHANUM_U' in self.arguments[0]:
            result = result.upper()
        return result
    def executeRandom(self):
        args = self.arguments
        result = ""
        for arg in args:
            if 'ALPHA_' in arg:
                arg_result = Alpha(arg)
                result = result + arg_result
            elif 'ALPHANUM_' in arg:
                arg_result = AlphaNum(arg)
                result = result + arg_result
            elif 'NUM' in arg:
                arg_result = Num(arg)
                result = result + arg_result
            elif 'CUST' in arg:
                arg_result = custom_value(arg)
                result = result + arg_result
        return result

class dateClass:
    def __init__(self, execute):
        self.execute = execute
        today = date.today()
        self.today = today
        arguments = re.findall(r'{(.*?)}', self.execute)[0].split(',')
        self.arguments = arguments
    def executeholiday_excludeDate_and_save_data(self):
        # Define date format
        dateFormat = None
        if self.arguments[0] == "TODAY_D/M/Y":
            dateFormat = "%d/%m/%Y"
        elif self.arguments[0] == "TODAY_D-M-Y":
            dateFormat = "%d-%m-%Y"
        elif self.arguments[0] == "TODAY_D/Mon/Y":
            dateFormat = "%d/%b/%Y"
        elif self.arguments[0] == "TODAY_M/D/Y":
            dateFormat = "%m/%d/%Y"
        elif self.arguments[0] == "TODAY_M-D-Y":
            dateFormat = "%m-%d-%Y"
        elif self.arguments[0] == "TODAY_Y/M/D":
            dateFormat = "%Y/%m/%d"
        elif self.arguments[0] == "TODAY_Y-M-D":
            dateFormat = "%Y-%m-%d"
        elif self.arguments[0] == "TODAY_D.M.Y":
            dateFormat = "%d.%m.%Y"
        
        # Tamil Nadu Holidays (simplified list for the example, you can add actual holiday dates)
        tamil_nadu_holidays = [
            "01/01", "14/01", "26/01", "01/05", "15/08", "02/10", "25/12"  # Example fixed holidays
        ]
        
        # Calculate the initial date
        if len(self.arguments) == 2:
            update = str(self.arguments[1]).strip().replace(" ", "")
            output_date = (self.today + timedelta(days=int(update))).strftime(dateFormat)
        else:
            output_date = self.today.strftime(dateFormat)

        # Function to check if the date is a weekend or holiday
        def is_excluded_date(date):
            # Check for Saturday (5) or Sunday (6)
            if date.weekday() in [5, 6]:  # 5 is Saturday, 6 is Sunday
                return True
            # Check for Tamil Nadu holidays
            holiday_str = date.strftime("%d/%m")
            if holiday_str in tamil_nadu_holidays:
                return True
            return False

        # If the generated date is a weekend or a holiday, move to the next working day
        result_date = datetime.strptime(output_date, dateFormat)
        while is_excluded_date(result_date):
            result_date += timedelta(days=1)  # Move to the next day if it's excluded
        appendColumnAndSaveData(Common_scenario.data_provider_num,result_date.strftime(dateFormat))
        # Return the result as a string formatted date
        return result_date.strftime(dateFormat)
    

    def executeholiday_excludeDate(self):
        # Define date format
        dateFormat = None
        if self.arguments[0] == "TODAY_D/M/Y":
            dateFormat = "%d/%m/%Y"
        elif self.arguments[0] == "TODAY_D-M-Y":
            dateFormat = "%d-%m-%Y"
        elif self.arguments[0] == "TODAY_D/Mon/Y":
            dateFormat = "%d/%b/%Y"
        elif self.arguments[0] == "TODAY_M/D/Y":
            dateFormat = "%m/%d/%Y"
        elif self.arguments[0] == "TODAY_M-D-Y":
            dateFormat = "%m-%d-%Y"
        elif self.arguments[0] == "TODAY_Y/M/D":
            dateFormat = "%Y/%m/%d"
        elif self.arguments[0] == "TODAY_Y-M-D":
            dateFormat = "%Y-%m-%d"
        elif self.arguments[0] == "TODAY_D.M.Y":
            dateFormat = "%d.%m.%Y"
        
        # Tamil Nadu Holidays (simplified list for the example, you can add actual holiday dates)
        tamil_nadu_holidays = [
            "01/01", "14/01", "26/01", "01/05", "15/08", "02/10", "25/12"  # Example fixed holidays
        ]
        
        # Calculate the initial date
        if len(self.arguments) == 2:
            update = str(self.arguments[1]).strip().replace(" ", "")
            output_date = (self.today + timedelta(days=int(update))).strftime(dateFormat)
        else:
            output_date = self.today.strftime(dateFormat)

        # Function to check if the date is a weekend or holiday
        def is_excluded_date(date):
            # Check for Saturday (5) or Sunday (6)
            if date.weekday() in [5, 6]:  # 5 is Saturday, 6 is Sunday
                return True
            # Check for Tamil Nadu holidays
            holiday_str = date.strftime("%d/%m")
            if holiday_str in tamil_nadu_holidays:
                return True
            return False

        # If the generated date is a weekend or a holiday, move to the next working day
        result_date = datetime.strptime(output_date, dateFormat)
        while is_excluded_date(result_date):
            result_date += timedelta(days=1)  # Move to the next day if it's excluded

        # Return the result as a string formatted date
        return result_date.strftime(dateFormat)
    

    def executesatsun_includeDate(self):
         # Define date format
        dateFormat = None
        if self.arguments[0] == "TODAY_D/M/Y":
            dateFormat = "%d/%m/%Y"
        elif self.arguments[0] == "TODAY_D-M-Y":
            dateFormat = "%d-%m-%Y"
        elif self.arguments[0] == "TODAY_D/Mon/Y":
            dateFormat = "%d/%b/%Y"
        elif self.arguments[0] == "TODAY_M/D/Y":
            dateFormat = "%m/%d/%Y"
        elif self.arguments[0] == "TODAY_M-D-Y":
            dateFormat = "%m-%d-%Y"
        elif self.arguments[0] == "TODAY_Y/M/D":
            dateFormat = "%Y/%m/%d"
        elif self.arguments[0] == "TODAY_Y-M-D":
            dateFormat = "%Y-%m-%d"
        elif self.arguments[0] == "TODAY_D.M.Y":
            dateFormat = "%d.%m.%Y"
        
         # Calculate the initial date
        if len(self.arguments) == 2:
            update = str(self.arguments[1]).strip().replace(" ", "")
            output_date = (self.today + timedelta(days=int(update))).strftime(dateFormat)
        else:
            output_date = self.today.strftime(dateFormat)
        # Regular expression to match "SATURDAYSUNDAY+" or "SATURDAYSUNDAY-"
        match = re.findall(r'SATURDAYSUNDAY[+-]',  self.execute)

        # Output the matched result
        if match:
            if "+" in match[0]:
                sign="+"
            elif "-" in match[0]:
                sign="-"  # Should output 'SATURDAYSUNDAY+' or 'SATURDAYSUNDAY-'
        else:
            print("No match found")

                
        # Helper function to find next Saturday or Sunday
        def find_next_saturday_sunday(start_date, forward=True):
            current_date = start_date
            days_to_move = 1 if forward else -1
            while current_date.weekday() not in [5, 6]:  # 5 is Saturday, 6 is Sunday
                current_date += timedelta(days=days_to_move)
            return current_date
         # If the generated date is a weekend or a holiday, move to the next working day
        result_date = datetime.strptime(output_date, dateFormat)
        # Calculate the target date
        if sign == "+":
            result_date = find_next_saturday_sunday(result_date, forward=True)
        elif sign == "-":
            result_date = find_next_saturday_sunday(result_date, forward=False)

        # Return the formatted date string
        return result_date.strftime(dateFormat)


    def executeDate(self):
        # print(self.arguments)
        dateFormat = None
        if self.arguments[0] == "TODAY_D/M/Y":
            dateFormat = "%d/%m/%Y"
        elif self.arguments[0] == "TODAY_D-M-Y":
            dateFormat = "%d-%m-%Y"
        elif self.arguments[0] == "TODAY_D/Mon/Y":
            dateFormat = "%d/%b/%Y"
        elif self.arguments[0] == "TODAY_M/D/Y":
            dateFormat = "%m/%d/%Y"
        elif self.arguments[0] == "TODAY_M-D-Y":
            dateFormat = "%m-%d-%Y"
        elif self.arguments[0] == "TODAY_Y/M/D":
            dateFormat = "%Y/%m/%d"
        elif self.arguments[0] == "TODAY_Y-M-D":
            dateFormat = "%Y-%m-%d"
        elif self.arguments[0] == "TODAY_D.M.Y":
            dateFormat = "%d.%m.%Y"

        if len(self.arguments) == 2:
            update = str(str(self.arguments[1]).strip()).replace(" ", "")
            output_date = (self.today + timedelta(days=int(update))).strftime(dateFormat)
        else:
            output_date = self.today.strftime(dateFormat)
        return output_date


class timeClass:
    def __init__(self, execute):
        self.execute = execute
        now = datetime.now()
        self.now = now
        arguments = re.findall(r'{(.*?)}', self.execute)[0]
        self.arguments = arguments
        H, M, S = 0, 0, 0
        if len(arguments) > 6:
            time_change = re.findall(r'[(](.*?)[)]', arguments)[0].split(',')
            H, M, S = "","",""
            for value in time_change:
                if 'H' in value:
                    H = value[:-1]
                    break
                else:
                    H = 0
            for value in time_change:
                if 'M' in value:
                    M = value[:-1]
                    break
                else:
                    M = 0
            for value in time_change:
                if 'S' in value:
                    S = value[:-1]
                    break
                else:
                    S = 0
        else:
            pass

        self.H = H
        self.M = M
        self.S = S

    def executeTime(self):
        timeFormat = None
        if "NOW_24" in self.arguments:
            timeFormat = (self.now + relativedelta(hours=int(self.H), minutes=int(self.M), seconds=int(self.S))).strftime("%H:%M:%S")
        elif "NOW_12" in self.arguments:
            timeFormat = (self.now + relativedelta(hours=int(self.H), minutes=int(self.M), seconds=int(self.S))).strftime("%I:%M:%S %p")
        return timeFormat


class datetimeClass:
    def __init__(self, execute):
        self.execute = execute
        today = date.today()
        self.today = today
        arguments = re.findall(r'{(.*?)}', self.execute)[0].split(';')
        self.date_arguments = arguments[0]

        now = datetime.now()
        self.now = now
        self.time_arguments = arguments[1]
        H, M, S = 0, 0, 0
        if len(self.time_arguments) > 6:
            time_change = re.findall(r'[(](.*?)[)]', self.time_arguments)[0].split(',')
            H, M, S = "", "", ""
            for value in time_change:
                if 'H' in value:
                    H = value[:-1]
                    break
                else:
                    H = 0
            for value in time_change:
                if 'M' in value:
                    M = value[:-1]
                    break
                else:
                    M = 0
            for value in time_change:
                if 'S' in value:
                    S = value[:-1]
                    break
                else:
                    S = 0
        else:
            pass

        self.H = H
        self.M = M
        self.S = S

    def executeDatetime(self):
        date_arguments = re.findall(r'[(](.*?)[)]', self.date_arguments)[0].split(',')
        dateFormat = ""
        if date_arguments[0] == "TODAY_D/M/Y":
            dateFormat = "%d/%m/%Y"
        elif date_arguments[0] == "TODAY_D-M-Y":
            dateFormat = "%d-%m-%Y"
        elif date_arguments[0] == "TODAY_D/Mon/Y":
            dateFormat = "%d/%b/%Y"
        elif date_arguments[0] == "TODAY_D.M.Y":
            dateFormat = "%d.%m.%Y"
        elif date_arguments[0] == "TODAY_M/D/Y":
            dateFormat = "%m/%d/%Y"

        if len(date_arguments) == 2:
            update = date_arguments[1]
            output_date = (self.today + timedelta(days=int(update))).strftime(dateFormat)
        else:
            output_date = self.today.strftime(dateFormat)

        timeFormat = None
        if "NOW_24" in self.time_arguments:
            timeFormat = (self.now + relativedelta(hours=int(self.H), minutes=int(self.M), seconds=int(self.S))).strftime("%H:%M:%S")
        elif "NOW_12" in self.time_arguments:
            timeFormat = (self.now + relativedelta(hours=int(self.H), minutes=int(self.M), seconds=int(self.S))).strftime("%I:%M:%S %p")
        elif "NOW_HM" in self.time_arguments:
            timeFormat = (self.now + relativedelta(hours=int(self.H), minutes=int(self.M), seconds=int(self.S))).strftime("%H:%M")
        output = output_date + " " + timeFormat
        return output


class monthClass:
    def __init__(self, execute):
        self.execute = execute
        today = date.today()
        self.today = today
        arguments = re.findall(r'{(.*?)}', self.execute)[0]
        self.arguments = arguments

    def executeMonth(self):
        outputDate = None
        if self.arguments == "CurrentEndDate_D/M/Y":
            endDay = calendar.monthrange(self.today.year, self.today.month)[1]
            outputDate = str(endDay) + "/" + '{:02d}'.format(self.today.month) + "/" + str(self.today.year)
        elif self.arguments == "PreviousStartDate_D/M/Y":
            if self.today.month == 1:
                outputDate = "01/12/" + str(self.today.year - 1)
            else:
                outputDate = "01" + "/" + '{:02d}'.format(self.today.month - 1) + "/" + str(self.today.year)
        return outputDate


class financialYearClass:
    def __init__(self, execute):
        self.execute = execute
        today = date.today()
        self.today = today
        arguments = re.findall(r'{(.*?)}', self.execute)[0]
        self.arguments = arguments

    def executeFinancialYear(self):
        outputDate = None
        currentMonth = datetime.now().month
        # currentMonth = 12
        # if currentMonth == 1 or 2 or 3:
        if self.arguments == "CurrentStartDate_D/M/Y":
            if int(currentMonth) == 1 or int(currentMonth) == 2 or int(currentMonth) == 3:
                outputDate = "01/04/" + str(self.today.year - 1)
            else:
                outputDate = "01/04/" + str(self.today.year)
        elif self.arguments == "CurrentEndDate_D/M/Y":
            if int(currentMonth) == 1 or int(currentMonth) == 2 or int(currentMonth) == 3:
                outputDate = "31/03/" + str(self.today.year)
            else:
                outputDate = "31/03/" + str(self.today.year + 1)
        elif self.arguments == "PreviousStartDate_D/M/Y":
            if int(currentMonth) == 1 or int(currentMonth) == 2 or int(currentMonth) == 3:
                outputDate = "01/04/" + str(self.today.year - 2)
            else:
                outputDate = "01/04/" + str(self.today.year - 1)
        elif self.arguments == "PreviousEndDate_D/M/Y":
            if int(currentMonth) == 1 or int(currentMonth) == 2 or int(currentMonth) == 3:
                outputDate = "31/03/" + str(self.today.year - 1)
            else:
                outputDate = "31/03/" + str(self.today.year)
        return outputDate


def dataGenerator(execute):
    Variable_not_resettable.logger.debug(f"Data Generator value : {execute}")
    Variable_not_resettable.logger.info(f"Data Generator value : {execute}")
    if 'EXECUTE:DATE:HOLIDAYEXCLUDED:FORMAT' in execute:
        return dateClass(execute).executeholiday_excludeDate()
    elif 'EXECUTE:DATE:HOLIDAYEXCLUDED:SAVEDATA:FORMAT' in execute:
        return dateClass(execute).executeholiday_excludeDate_and_save_data()
    elif 'EXECUTE:DATE:SATURDAYSUNDAY+:FORMAT' in execute or 'EXECUTE:DATE:SATURDAYSUNDAY-:FORMAT' in execute:
        return dateClass(execute).executesatsun_includeDate()
    elif 'EXECUTE:DATE:FORMAT' in execute:
        return dateClass(execute).executeDate()
    elif 'EXECUTE:TIME:FORMAT' in execute:
        return timeClass(execute).executeTime()
    elif 'EXECUTE:DATETIME:FORMAT' in execute:
        return datetimeClass(execute).executeDatetime()
    elif 'EXECUTE:MONTH:FORMAT' in execute:
        return monthClass(execute).executeMonth()
    elif 'EXECUTE:FY:FORMAT' in execute:
        return financialYearClass(execute).executeFinancialYear()
    elif 'EXECUTE:RAND:FORMAT' in execute:
        properties = re.findall(r'{(.*?)}', execute)[0].split(',')
        if len(properties) > 1:
            return randomClass(execute).executeRandom()
        else:
            if "ALPHA_" in properties[0]:
                return randomClass(execute).randomAlpha()
            elif "ALPHANUM_" in properties[0]:
                return randomClass(execute).randomAlphaNum()
            elif "NUM" in properties[0]:
                return randomClass(execute).randomNum()
            