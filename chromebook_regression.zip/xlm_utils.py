from datetime import datetime
from common_object import Common_object, Common_path
import pandas as pd
from lxml import etree
import os




def make_directory(directory_path):
    try:
        os.makedirs(directory_path)
        return True
    except Exception as error:
        return False

def comparing_xml_with_excel(data_file_name,unzipped_xml_folder_path):
    #readinig excel 
    #Excel_path = r"D:\excel_comparing\New folder\Files\DataSheets\common\AU_STP_18_20220831_2_92.xlsx"
    xl_data_file_name = Common_path.dataSheet_path+"/"+Common_object.test_config_dictionary["DataTag"]+"/"+ data_file_name
    df = pd.read_excel(xl_data_file_name, sheet_name="xml_sheet", dtype="str")
    if df.to_dict("records") == []:
        print("Please update the excel with the values against the columns to be asserted")
    else:
        df = df.fillna("")
        df_dict = df.to_dict("records")
        #taking only column with values
        columns_for_asserting = []
        for val in df_dict[0]:
            if df_dict[0][val] != "":
                columns_for_asserting.append(val)
        entire_data_sheet=[]
        for i in range(len(df_dict)):
            row_in_sheet = []
            for col_name in columns_for_asserting:
                row_in_sheet.append(str((df_dict[i]).get(col_name)))
            entire_data_sheet.append(row_in_sheet)
        #print(entire_data_sheet)
        #reading xml files
        ##################################
        #XML_folder_name = "XML_"+(str(datetime.now().replace(microsecond=0))).replace(":", "_")
        ##################################
        # replace this with folder name 
        #print(XML_folder_name)
        xml_input_folder_path = unzipped_xml_folder_path
        xml_files = os.listdir(xml_input_folder_path)
        only_xml_files = []
        for xmlf in xml_files:
            if ".xml" in xmlf:
                only_xml_files.append(xmlf)
        list_of_data_from_xml_files = []
        for file in only_xml_files:
            #print("reading the xml file : ", file)
            xml_file_path = xml_input_folder_path + "/"+file
            root = etree.parse(xml_file_path)
            data_in_each_xml_file = []
            for column in columns_for_asserting:
                tag_in_xml = str(column).replace("_","/")
                try:	
                    xml_value = root.find(tag_in_xml).text
                except:
                    xml_value = ""
                data_in_each_xml_file.append(str(xml_value))
            list_of_data_from_xml_files.append(data_in_each_xml_file)
        # print(list_of_data_from_xml_files)
        columns_for_asserting.append("Status")
        list_for_writing_in_output = []
        for data_row in entire_data_sheet:
            if data_row in list_of_data_from_xml_files:
                # print("present")
                list_of_data_from_xml_files.remove(data_row)
                data_row.append("Pass")
                #print(data_row)
            elif data_row not in list_of_data_from_xml_files:
                data_row.append("Fail")
                # print(data_row)
                # print("not found")
            list_for_writing_in_output.append(data_row)
        df = pd.DataFrame(list_for_writing_in_output, columns=columns_for_asserting)
        #print(df)
        output_file_path = Common_path.base_path+"/Files\XML_Validation_Output/"+data_file_name.removesuffix(".xlsx").removesuffix(".xlsm").removesuffix(".xls")+"_"+(str(datetime.now().replace(microsecond=0))).replace(":", "_")+".xlsx"
        writer = pd.ExcelWriter(output_file_path, engine='xlsxwriter')
        df.to_excel(writer, sheet_name="xml_sheet", index=False)
        writer.save()
#comparing_xml_with_excel(data_file_name,data_sheet_name)

def grid_xml_compare(page_object, selector, file_name: str): # common for click link and Click button icon
        page_object.wait_for_selector(selector, timeout= Common_object.Timeout)
        download_clicked = True
        with page_object.expect_download() as download_info:
            if download_clicked:	
                page_object.locator(selector).click()	
                download_clicked = False
            #page_object.locator(selector).click()
        download = download_info.value
        page_object.set_viewport_size(Common_object.screen_resolution)
        # Wait for the download process to complete
        #print(download.path())
        path_to_save = Common_path.base_path+"/Files\Input_documents/"+"XML_"+(str(datetime.now().replace(microsecond=0))).replace(":", "_")+".zip"
        #download.save_as("D:/SwifTest_07_12_2022/openwebframework/Files/Input_Documents/XML.zip")
        download.save_as(path_to_save)
        from zipfile import ZipFile
        # D:\excel_comparing\New folder\Files\Input_documents\XML_Folder
        path_to_save_unzip = (path_to_save.split(".zip"))[0]
        with ZipFile(path_to_save, 'r') as zObject:
        #with ZipFile("D:/SwifTest_07_12_2022/openwebframework/Files/Input_Documents/XML.zip", 'r') as zObject:
            zObject.extractall(path=path_to_save_unzip)
        make_directory(Common_path.base_path+"/Files\XML_Validation_Output")
        comparing_xml_with_excel(file_name,path_to_save_unzip)